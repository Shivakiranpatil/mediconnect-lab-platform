# 🚀 MediConnect - Supabase + Vercel Deployment Guide

## Prerequisites

1. **Supabase Account** - [supabase.com](https://supabase.com)
2. **Vercel Account** - [vercel.com](https://vercel.com)
3. **SendGrid Account** (optional) - [sendgrid.com](https://sendgrid.com)

---

## Part 1: Supabase Database Setup

### Step 1: Create Supabase Project

1. Go to [supabase.com/dashboard](https://supabase.com/dashboard)
2. Click **"New Project"**
3. Fill in:
   - **Name:** mediconnect
   - **Database Password:** (save this securely!)
   - **Region:** Choose closest to your users (e.g., US East)
4. Click **"Create new project"** (takes ~2 minutes)

### Step 2: Get Database Connection String

1. In your Supabase project, go to **Settings** → **Database**
2. Scroll to **Connection String**
3. Select **"Transaction"** mode (for Drizzle ORM compatibility)
4. Copy the connection string (format: `postgresql://postgres.[PROJECT-REF]:[PASSWORD]@...`)
5. Replace `[PASSWORD]` with your actual database password

**Example:**
```
postgresql://postgres.abcdefghijk:your_password@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true
```

### Step 3: Run Database Migrations

**Option A: Using Drizzle Studio (Recommended)**

```bash
# Install Drizzle Kit globally (if not already)
npm install -g drizzle-kit

# Set your DATABASE_URL
export DATABASE_URL="your-supabase-connection-string"

# Generate migration files
npm run db:generate

# Apply migrations
npm run db:push
```

**Option B: Using Supabase SQL Editor**

1. Go to **SQL Editor** in Supabase Dashboard
2. Copy the SQL from `/migrations/0000_*.sql`
3. Paste and run the SQL

### Step 4: Seed the Database

After migrations are applied, seed the database:

```bash
# Build the project first
npm run build

# Run seed via API (after deployment)
# OR create a seed script that uses your Supabase credentials
```

---

## Part 2: Vercel Deployment

### Step 1: Connect GitHub Repository

1. Push your code to GitHub:
```bash
git init
git add .
git commit -m "Initial commit - MediConnect"
git remote add origin https://github.com/yourusername/mediconnect.git
git push -u origin main
```

2. Go to [vercel.com/new](https://vercel.com/new)
3. Click **"Import Git Repository"**
4. Select your `mediconnect` repository
5. Click **"Import"**

### Step 2: Configure Environment Variables

In Vercel project settings, add these environment variables:

**Required:**
```
DATABASE_URL=postgresql://postgres.[PROJECT-REF]:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true
EMERGENT_LLM_KEY=sk-emergent-58d282c84009b629f5
SESSION_SECRET=your-random-secret-string-here
NODE_ENV=production
```

**Optional (for email):**
```
SENDGRID_API_KEY=SG.your-sendgrid-api-key
SENDER_EMAIL=noreply@yourdomain.com
```

### Step 3: Configure Build Settings

Vercel should auto-detect, but verify:

- **Framework Preset:** Other
- **Build Command:** `npm run build` or `yarn build`
- **Output Directory:** `dist`
- **Install Command:** `npm install` or `yarn install`

### Step 4: Deploy

1. Click **"Deploy"**
2. Wait for build to complete (~2-3 minutes)
3. Your app will be live at `https://your-project.vercel.app`

### Step 5: Custom Domain (Optional)

1. Go to **Settings** → **Domains**
2. Add your custom domain (e.g., `mediconnect.com`)
3. Follow DNS configuration instructions
4. Update `SENDER_EMAIL` in environment variables to match your domain

---

## Part 3: Post-Deployment Setup

### Seed Database via API

**Option 1: Via Admin Panel**
1. Login to admin panel: `https://your-app.vercel.app/admin`
2. Username: `admin` | Password: `admin123`
3. Navigate to settings and click "Reset & Seed Database"

**Option 2: Via API Call**
```bash
curl -X POST https://your-app.vercel.app/api/admin/reset-database \
  -H "Content-Type: application/json" \
  -H "Cookie: connect.sid=your-session-cookie"
```

### Test the Application

1. **Homepage:** `https://your-app.vercel.app/`
2. **Tests Page:** `https://your-app.vercel.app/tests`
3. **AI Discovery:** `https://your-app.vercel.app/ai-discovery`
4. **Admin Panel:** `https://your-app.vercel.app/admin`
5. **Lab Portal:** `https://your-app.vercel.app/lab`

### Default Credentials

After seeding:
```
Admin:      username: admin    | password: admin123
Lab Admin:  username: labadmin | password: lab123
User:       username: user     | password: user123
```

**🔒 IMPORTANT:** Change these passwords immediately in production!

---

## Part 4: SendGrid Email Setup (Optional)

### Step 1: Create SendGrid Account

1. Go to [sendgrid.com/pricing](https://sendgrid.com/pricing)
2. Sign up for Free Plan (100 emails/day)

### Step 2: Verify Sender Identity

1. Go to **Settings** → **Sender Authentication**
2. Click **"Verify a Single Sender"**
3. Fill in your email and details
4. Verify via email confirmation

### Step 3: Create API Key

1. Go to **Settings** → **API Keys**
2. Click **"Create API Key"**
3. Name: `MediConnect Production`
4. Permissions: **Full Access**
5. Copy the API key (starts with `SG.`)

### Step 4: Add to Vercel

1. Go to Vercel project → **Settings** → **Environment Variables**
2. Add:
   - `SENDGRID_API_KEY`: Your SendGrid API key
   - `SENDER_EMAIL`: Your verified sender email

3. Redeploy the application

---

## Part 5: Monitoring & Maintenance

### Supabase Monitoring

- **Database Dashboard:** Monitor connections, queries, disk usage
- **Table Editor:** View and edit data directly
- **API Logs:** Track database queries and performance

### Vercel Monitoring

- **Deployments:** View build logs and deployment history
- **Analytics:** Track page views and performance
- **Functions:** Monitor serverless function executions
- **Logs:** Real-time application logs

### Backup Strategy

**Supabase Backups:**
- Enable automatic daily backups in Supabase settings
- Point-in-time recovery available on paid plans

**Database Export:**
```bash
# Export using pg_dump
pg_dump $DATABASE_URL > backup.sql

# Or use Supabase CLI
supabase db dump -f backup.sql
```

---

## Part 6: Troubleshooting

### Database Connection Issues

**Error:** "Connection refused" or "Invalid connection string"
- Verify DATABASE_URL format and credentials
- Check if Supabase project is active
- Ensure using "Transaction" mode connection string

**Error:** "Too many connections"
- Supabase has connection limits
- Using pgBouncer (in connection string) helps manage connections
- Consider upgrading Supabase plan for more connections

### Build Failures

**Error:** "Module not found"
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

**Error:** "TypeScript compilation errors"
```bash
# Run type checking locally
npm run check
```

### Email Not Sending

- Verify SENDGRID_API_KEY is set correctly
- Check SendGrid sender verification status
- Review Vercel function logs for errors
- Ensure SENDER_EMAIL matches verified sender

---

## Part 7: Production Checklist

Before going live:

- [ ] Change all default passwords
- [ ] Set strong SESSION_SECRET
- [ ] Enable HTTPS (automatic with Vercel)
- [ ] Configure custom domain
- [ ] Set up SendGrid with verified domain
- [ ] Enable Supabase database backups
- [ ] Review and test all API endpoints
- [ ] Test booking and email flows
- [ ] Set up error monitoring (Sentry, LogRocket)
- [ ] Configure rate limiting for APIs
- [ ] Review CORS settings for production domain
- [ ] Test responsive design on mobile devices
- [ ] Enable Vercel Analytics
- [ ] Set up uptime monitoring

---

## Support & Resources

- **Supabase Docs:** [supabase.com/docs](https://supabase.com/docs)
- **Vercel Docs:** [vercel.com/docs](https://vercel.com/docs)
- **Drizzle ORM:** [orm.drizzle.team](https://orm.drizzle.team)
- **SendGrid Docs:** [docs.sendgrid.com](https://docs.sendgrid.com)

---

## Quick Deploy Commands

```bash
# 1. Clone and setup
git clone <your-repo>
cd mediconnect
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your Supabase connection string

# 3. Run migrations
npx drizzle-kit push

# 4. Build
npm run build

# 5. Deploy to Vercel
vercel --prod

# 6. Seed database via API or admin panel
```

---

**🎉 Your MediConnect application is now live on Supabase + Vercel!**
