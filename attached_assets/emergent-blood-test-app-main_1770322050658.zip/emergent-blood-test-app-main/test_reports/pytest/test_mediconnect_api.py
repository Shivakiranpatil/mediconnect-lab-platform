"""
MediConnect Lab Test Discovery Platform - API Tests
Tests for: Tests, Bundles, Packages, User Management, and User Addresses APIs
"""
import pytest
import requests
import uuid
import os

# Use localhost:3000 as specified in the review request
BASE_URL = os.environ.get('BASE_URL', 'http://localhost:3000')

class TestPublicAPIs:
    """Test public API endpoints for Tests, Bundles, and Packages"""
    
    def test_get_tests_returns_data(self):
        """GET /api/tests - Should return test data (mock or Supabase)"""
        response = requests.get(f"{BASE_URL}/api/tests")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        assert len(data) > 0, "Should return at least one test"
        
        # Verify test structure
        first_test = data[0]
        assert "id" in first_test, "Test should have id"
        assert "name" in first_test, "Test should have name"
        assert "category" in first_test, "Test should have category"
        print(f"✓ GET /api/tests returned {len(data)} tests")
    
    def test_get_bundles_returns_data(self):
        """GET /api/bundles - Should return bundle data (mock or Supabase)"""
        response = requests.get(f"{BASE_URL}/api/bundles")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        assert len(data) > 0, "Should return at least one bundle"
        
        # Verify bundle structure
        first_bundle = data[0]
        assert "id" in first_bundle, "Bundle should have id"
        assert "name" in first_bundle, "Bundle should have name"
        print(f"✓ GET /api/bundles returned {len(data)} bundles")
    
    def test_get_packages_returns_data(self):
        """GET /api/packages - Should return package data with lab pricing"""
        response = requests.get(f"{BASE_URL}/api/packages")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        assert len(data) > 0, "Should return at least one package"
        
        # Verify package structure
        first_package = data[0]
        assert "id" in first_package, "Package should have id"
        assert "name" in first_package, "Package should have name"
        assert "lowestPrice" in first_package, "Package should have lowestPrice"
        print(f"✓ GET /api/packages returned {len(data)} packages")
    
    def test_get_labs_returns_data(self):
        """GET /api/labs - Should return lab data"""
        response = requests.get(f"{BASE_URL}/api/labs")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        assert len(data) > 0, "Should return at least one lab"
        print(f"✓ GET /api/labs returned {len(data)} labs")


class TestSupabaseUsersAPI:
    """Test Supabase users API endpoints"""
    
    def test_get_all_users(self):
        """GET /api/supabase/users - Should return user list"""
        response = requests.get(f"{BASE_URL}/api/supabase/users")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"✓ GET /api/supabase/users returned {len(data)} users")
        return data
    
    def test_create_user(self):
        """POST /api/supabase/users - Should create a new user"""
        test_email = f"test_user_{uuid.uuid4().hex[:8]}@test.com"
        user_data = {
            "email": test_email,
            "name": "Test User",
            "phone": "+971501234567",
            "role": "user"
        }
        
        response = requests.post(
            f"{BASE_URL}/api/supabase/users",
            json=user_data
        )
        
        # May fail if user_addresses table doesn't exist, which is OK
        if response.status_code == 500 and "user_addresses" in response.text:
            pytest.skip("user_addresses table may not exist in Supabase")
        
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert data["email"] == test_email, "Email should match"
        assert "id" in data, "Should return user id"
        print(f"✓ POST /api/supabase/users created user with id: {data['id']}")
        return data
    
    def test_update_user_profile(self):
        """PUT /api/supabase/users/:id/address - Should update user profile"""
        # First get existing users
        response = requests.get(f"{BASE_URL}/api/supabase/users")
        if response.status_code != 200 or len(response.json()) == 0:
            pytest.skip("No users available to update")
        
        users = response.json()
        user_id = users[0]["id"]
        
        update_data = {
            "name": "Updated Name",
            "phone": "+971509876543",
            "city": "Dubai",
            "area": "Marina"
        }
        
        response = requests.put(
            f"{BASE_URL}/api/supabase/users/{user_id}/address",
            json=update_data
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        print(f"✓ PUT /api/supabase/users/{user_id}/address succeeded")


class TestUserAddressesAPI:
    """Test user addresses CRUD operations (multiple addresses per user)"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Get or create a test user for address tests"""
        # Try to get existing users
        response = requests.get(f"{BASE_URL}/api/supabase/users")
        if response.status_code == 200 and len(response.json()) > 0:
            self.user_id = response.json()[0]["id"]
        else:
            # Create a test user
            test_email = f"test_address_{uuid.uuid4().hex[:8]}@test.com"
            response = requests.post(
                f"{BASE_URL}/api/supabase/users",
                json={"email": test_email, "name": "Address Test User"}
            )
            if response.status_code == 201:
                self.user_id = response.json()["id"]
            else:
                self.user_id = None
    
    def test_get_user_addresses(self):
        """GET /api/supabase/users/:userId/addresses - Should return user addresses"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        response = requests.get(f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses")
        
        # Check if table exists
        if response.status_code == 500 and "user_addresses" in response.text:
            pytest.skip("user_addresses table may not exist in Supabase")
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"✓ GET /api/supabase/users/{self.user_id}/addresses returned {len(data)} addresses")
        return data
    
    def test_create_user_address(self):
        """POST /api/supabase/users/:userId/addresses - Should create new address"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        address_data = {
            "label": "Home",
            "name": "Test Person",
            "phone": "+971501234567",
            "city": "Dubai",
            "area": "Dubai Marina",
            "building": "Test Tower",
            "flat_number": "101",
            "full_address": "Street 1, Near Mall",
            "landmark": "Near Metro",
            "is_default": True
        }
        
        response = requests.post(
            f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses",
            json=address_data
        )
        
        # Check if table exists
        if response.status_code == 500 and "user_addresses" in response.text:
            pytest.skip("user_addresses table may not exist in Supabase")
        
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert data["label"] == "Home", "Label should match"
        assert data["city"] == "Dubai", "City should match"
        assert "id" in data, "Should return address id"
        print(f"✓ POST /api/supabase/users/{self.user_id}/addresses created address with id: {data['id']}")
        return data
    
    def test_create_and_get_address_flow(self):
        """Test full flow: Create address → GET to verify persistence"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        # Create address
        address_data = {
            "label": "Office",
            "name": "Office Contact",
            "phone": "+971509999999",
            "city": "Abu Dhabi",
            "area": "Downtown",
            "building": "Business Tower",
            "flat_number": "501",
            "is_default": False
        }
        
        create_response = requests.post(
            f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses",
            json=address_data
        )
        
        if create_response.status_code == 500 and "user_addresses" in create_response.text:
            pytest.skip("user_addresses table may not exist in Supabase")
        
        assert create_response.status_code == 201, f"Create failed: {create_response.text}"
        created = create_response.json()
        
        # GET to verify persistence
        get_response = requests.get(f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses")
        assert get_response.status_code == 200, f"GET failed: {get_response.text}"
        
        addresses = get_response.json()
        found = any(addr["id"] == created["id"] for addr in addresses)
        assert found, "Created address should be in the list"
        print(f"✓ Address persistence verified: created and retrieved successfully")
    
    def test_update_address(self):
        """PUT /api/supabase/addresses/:id - Should update existing address"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        # First create an address
        create_response = requests.post(
            f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses",
            json={
                "label": "Other",
                "city": "Sharjah",
                "area": "Al Nahda",
                "building": "Test Building"
            }
        )
        
        if create_response.status_code == 500:
            pytest.skip("user_addresses table may not exist")
        
        if create_response.status_code != 201:
            pytest.skip(f"Could not create address: {create_response.text}")
        
        address_id = create_response.json()["id"]
        
        # Update the address
        update_response = requests.put(
            f"{BASE_URL}/api/supabase/addresses/{address_id}",
            json={
                "area": "Updated Area",
                "building": "Updated Building"
            }
        )
        
        assert update_response.status_code == 200, f"Expected 200, got {update_response.status_code}: {update_response.text}"
        
        updated = update_response.json()
        assert updated["area"] == "Updated Area", "Area should be updated"
        print(f"✓ PUT /api/supabase/addresses/{address_id} updated successfully")
    
    def test_delete_address(self):
        """DELETE /api/supabase/addresses/:id - Should delete address"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        # First create an address
        create_response = requests.post(
            f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses",
            json={
                "label": "Home",
                "city": "Ajman",
                "area": "Test Area",
                "building": "To Delete"
            }
        )
        
        if create_response.status_code == 500:
            pytest.skip("user_addresses table may not exist")
        
        if create_response.status_code != 201:
            pytest.skip(f"Could not create address: {create_response.text}")
        
        address_id = create_response.json()["id"]
        
        # Delete the address
        delete_response = requests.delete(f"{BASE_URL}/api/supabase/addresses/{address_id}")
        assert delete_response.status_code == 200, f"Expected 200, got {delete_response.status_code}: {delete_response.text}"
        
        # Verify deletion
        get_response = requests.get(f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses")
        if get_response.status_code == 200:
            addresses = get_response.json()
            found = any(addr["id"] == address_id for addr in addresses)
            assert not found, "Deleted address should not be in the list"
        
        print(f"✓ DELETE /api/supabase/addresses/{address_id} succeeded")
    
    def test_set_default_address(self):
        """PUT /api/supabase/addresses/:id/default - Should set default address"""
        if not self.user_id:
            pytest.skip("No user available for address test")
        
        # Create a non-default address
        create_response = requests.post(
            f"{BASE_URL}/api/supabase/users/{self.user_id}/addresses",
            json={
                "label": "Home",
                "city": "Dubai",
                "area": "JLT",
                "building": "Test Tower",
                "is_default": False
            }
        )
        
        if create_response.status_code == 500:
            pytest.skip("user_addresses table may not exist")
        
        if create_response.status_code != 201:
            pytest.skip(f"Could not create address: {create_response.text}")
        
        address_id = create_response.json()["id"]
        
        # Set as default
        default_response = requests.put(
            f"{BASE_URL}/api/supabase/addresses/{address_id}/default",
            json={"userId": self.user_id}
        )
        
        assert default_response.status_code == 200, f"Expected 200, got {default_response.status_code}: {default_response.text}"
        
        data = default_response.json()
        assert data.get("is_default") == True, "Address should be marked as default"
        print(f"✓ PUT /api/supabase/addresses/{address_id}/default succeeded")


class TestFilterAndSearch:
    """Test filtering and search functionality"""
    
    def test_tests_search(self):
        """GET /api/tests?search=... - Should filter tests by search term"""
        response = requests.get(f"{BASE_URL}/api/tests?search=blood")
        assert response.status_code == 200
        print(f"✓ GET /api/tests?search=blood returned {len(response.json())} results")
    
    def test_tests_category_filter(self):
        """GET /api/tests?category=... - Should filter tests by category"""
        response = requests.get(f"{BASE_URL}/api/tests?category=Diabetes")
        assert response.status_code == 200
        
        data = response.json()
        if len(data) > 0:
            for test in data:
                assert test["category"] == "Diabetes", "All tests should be in Diabetes category"
        print(f"✓ GET /api/tests?category=Diabetes returned {len(data)} results")
    
    def test_packages_sorting(self):
        """GET /api/packages?sort=price_asc - Should sort packages by price"""
        response = requests.get(f"{BASE_URL}/api/packages?sort=price_asc")
        assert response.status_code == 200
        
        data = response.json()
        if len(data) > 1:
            prices = [pkg["lowestPrice"] for pkg in data]
            assert prices == sorted(prices), "Packages should be sorted by price ascending"
        print(f"✓ GET /api/packages?sort=price_asc returns sorted results")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
