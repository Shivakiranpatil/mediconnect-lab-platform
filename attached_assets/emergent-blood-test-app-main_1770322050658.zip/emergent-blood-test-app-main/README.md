# 🏥 MediConnect - AI-Driven Lab Test Booking Platform

> **Smart Lab Tests, Just for You** - AI-powered health test discovery and booking platform for Dubai, UAE

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)
![React](https://img.shields.io/badge/react-18.3.1-61DAFB.svg)
![TypeScript](https://img.shields.io/badge/typescript-5.6.3-3178C6.svg)

---

## 🌟 Features

### For Users
- **🤖 AI-Powered Discovery** - Conversational AI helps find the right tests based on health needs
- **💎 Test Bundles** - Pre-configured packages for common health concerns
- **🔬 Individual Tests** - Browse and search 100+ individual lab tests
- **📍 Multi-Lab Network** - Partner with leading labs across Dubai (MEDICLINIC, NMC, Al Borg, Prime Health, DINER)
- **🏠 Home Collection** - Book home visits or lab appointments
- **📧 Email Notifications** - Automated booking confirmations and reminders
- **📱 Responsive Design** - Works seamlessly on desktop and mobile

### For Lab Administrators
- **📊 Dashboard** - View and manage bookings
- **⏰ Schedule Management** - Configure lab hours and service areas
- **💰 Pricing Control** - Set custom pricing for test bundles
- **📈 Reports** - Track performance and revenue

### For Platform Admins
- **👥 User Management** - Manage users, labs, and permissions
- **🧪 Test Catalog** - Add/edit tests and bundles
- **🤖 AI Rules Engine** - Configure AI recommendation logic
- **📧 Email/SMS Settings** - Configure notification services
- **📊 Analytics Dashboard** - Monitor platform metrics

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm/yarn
- Supabase account (free tier available)
- SendGrid account (optional, for email notifications)

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd mediconnect

# Install dependencies
yarn install

# Configure environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Run database migrations
yarn db:push

# Start development server
yarn dev
```

Visit `http://localhost:5000`

---

## 📦 Tech Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Shadcn/UI** - Component library
- **Framer Motion** - Animations
- **Wouter** - Routing
- **TanStack Query** - Data fetching

### Backend
- **Express.js** - Web framework
- **TypeScript** - Type safety
- **Drizzle ORM** - Database ORM
- **Zod** - Schema validation
- **Passport.js** - Authentication

### Database
- **Supabase (PostgreSQL)** - Database hosting
- **Drizzle Kit** - Migrations

### Integrations
- **OpenAI GPT-5.2** - AI chat recommendations (via Emergent LLM Key)
- **SendGrid** - Email notifications
- **Vercel** - Hosting & deployment

---

## 🗂️ Project Structure

```
/app
├── client/                  # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
│   └── public/             # Static assets
│
├── server/                  # Express backend
│   ├── index.ts            # Server entry point
│   ├── routes.ts           # API routes
│   ├── db.ts               # Database connection
│   ├── storage.ts          # Data access layer
│   ├── email.ts            # Email service
│   ├── ai-discovery.ts     # AI recommendation engine
│   └── seed.ts             # Database seeding
│
├── shared/                  # Shared code
│   ├── schema.ts           # Database schema
│   ├── routes.ts           # API route definitions
│   └── models/             # Shared types
│
├── migrations/              # Database migrations
├── script/                  # Build scripts
└── ...config files
```

---

## 🎯 Key Pages

### Public Pages
- **`/`** - Homepage with hero, features, and CTAs
- **`/tests`** - Searchable test catalog (bundles & individual tests)
- **`/ai-discovery`** - AI-powered health test recommendations
- **`/bundles/:id`** - Test bundle details and booking

### User Pages
- **`/auth`** - User authentication (login/register)

### Admin Portal
- **`/admin`** - Admin login
- **`/admin/dashboard`** - Analytics overview
- **`/admin/bookings`** - Manage all bookings
- **`/admin/catalog`** - Manage tests and bundles
- **`/admin/labs`** - Manage partner labs
- **`/admin/users`** - User management
- **`/admin/ai-rules`** - Configure AI recommendation engine
- **`/admin/settings`** - Platform settings & integrations

### Lab Portal
- **`/lab`** - Lab admin login
- **`/lab/dashboard`** - Lab overview
- **`/lab/bookings`** - View and manage bookings
- **`/lab/zones`** - Configure service areas
- **`/lab/pricing`** - Set custom pricing
- **`/lab/hours`** - Manage lab hours

---

## 🔐 Default Credentials

After seeding the database:

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Lab Admin | `labadmin` | `lab123` |
| User | `user` | `user123` |

**⚠️ IMPORTANT:** Change these passwords immediately in production!

---

## 🚢 Deployment

### Deploy to Vercel

1. **Connect Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Import to Vercel**
   - Go to [vercel.com/new](https://vercel.com/new)
   - Import your repository
   - Configure environment variables (see below)

3. **Environment Variables**
   ```env
   DATABASE_URL=your-supabase-connection-string
   EMERGENT_LLM_KEY=sk-emergent-58d282c84009b629f5
   SESSION_SECRET=your-random-secret
   SENDGRID_API_KEY=your-sendgrid-key (optional)
   SENDER_EMAIL=noreply@yourdomain.com
   NODE_ENV=production
   ```

4. **Deploy**
   - Vercel auto-deploys on push to main
   - First deployment takes ~3-5 minutes

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed instructions.

---

## 🛠️ Development

### Run Locally

```bash
# Start development server (with hot reload)
yarn dev

# Build for production
yarn build

# Run production build locally
yarn start

# Database commands
yarn db:generate    # Generate migrations
yarn db:push        # Apply migrations
yarn db:studio      # Open Drizzle Studio (DB GUI)

# Type checking
yarn check
```

### Environment Variables

Create a `.env` file in the root directory:

```env
# Supabase Database
DATABASE_URL=postgresql://postgres.[PROJECT]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true

# AI Integration (Emergent Universal Key)
EMERGENT_LLM_KEY=sk-emergent-58d282c84009b629f5

# Email Service (optional)
SENDGRID_API_KEY=SG.your-key-here
SENDER_EMAIL=noreply@mediconnect.ae

# Session
SESSION_SECRET=your-random-secret-string

# Environment
NODE_ENV=development
PORT=5000
```

---

## 📊 Database Schema

### Core Tables
- **users** - User accounts with role-based access
- **bundles** - Test bundle packages
- **tests** - Individual lab tests
- **appointments** - Booking records
- **partner_labs** - Laboratory partners
- **ai_rule_sets** - AI recommendation rules
- **ai_questions** - Discovery flow questions
- **ai_mapping_rules** - Condition → Bundle mappings

### Relationships
- Bundles ↔ Tests (many-to-many via `bundle_tests`)
- Labs ↔ Bundles (pricing via `lab_bundle_pricing`)
- Labs ↔ Areas (service zones via `lab_zones`)
- Appointments → Users, Labs, Bundles (many-to-one)

---

## 🔌 API Endpoints

### Public API
```
GET  /api/bundles              # List all test bundles
GET  /api/bundles/:id          # Get bundle details
GET  /api/tests                # Search lab tests
POST /api/ai/chat              # AI chat conversation
POST /api/ai/recommend         # Get bundle recommendations
```

### Auth API
```
POST /api/auth/register        # User registration
POST /api/auth/login           # User login
GET  /api/auth/me              # Get current user
POST /api/auth/logout          # Logout
```

### Admin API
```
GET    /api/admin/bookings             # List all bookings
PATCH  /api/admin/bookings/:id/status  # Update booking status
GET    /api/admin/tests                # List tests
POST   /api/admin/tests                # Create test
PATCH  /api/admin/tests/:id            # Update test
POST   /api/admin/bundles              # Create bundle
PATCH  /api/admin/bundles/:id          # Update bundle
GET    /api/admin/labs                 # List labs
POST   /api/admin/labs                 # Create lab
GET    /api/admin/users                # List users
POST   /api/admin/reset-database       # Reset & seed database
```

### Lab API
```
GET    /api/lab/bookings               # Lab bookings
PATCH  /api/lab/bookings/:id/status    # Update booking
```

---

## 🧪 Testing

### Seed Database

Via Admin Panel (after login):
```
1. Login as admin (admin/admin123)
2. Go to Settings
3. Click "Reset & Seed Database"
```

Via API:
```bash
curl -X POST https://your-app.vercel.app/api/admin/reset-database \
  -H "Cookie: connect.sid=your-session-cookie"
```

### Test Data Includes
- 3 users (admin, lab admin, regular user)
- 5 partner labs
- 8 individual tests
- 6 test bundles
- AI rule sets with questions and mapping rules

---

## 📧 Email Notifications

### Supported Email Types
1. **Booking Confirmation** - Sent after successful booking
2. **Appointment Reminder** - 24hrs before appointment
3. **Test Results Ready** - When results are available

### Email Configuration

1. **Sign up for SendGrid** - [sendgrid.com](https://sendgrid.com)
2. **Verify sender email** - Settings → Sender Authentication
3. **Create API key** - Settings → API Keys → Create
4. **Add to environment variables**
   ```env
   SENDGRID_API_KEY=SG.your-key
   SENDER_EMAIL=verified-email@yourdomain.com
   ```

---

## 🤖 AI Discovery Flow

### How It Works
1. User starts conversation on `/ai-discovery`
2. AI asks 3-4 questions about health goals, age, conditions, etc.
3. Based on answers, AI recommends 2-3 relevant test bundles
4. User can view details and book directly

### Customizing AI Behavior
Edit AI rules via Admin Panel → AI Rules:
- **Questions** - Add/edit discovery questions
- **Rule Sets** - Configure recommendation logic
- **Mapping Rules** - Define condition → bundle mappings

---

## 🎨 Design System

### Colors
- **Primary:** Blue (#2563eb)
- **Secondary:** Purple (#7c3aed)
- **Success:** Green (#10b981)
- **Warning:** Amber (#f59e0b)
- **Error:** Red (#ef4444)

### Typography
- **Font:** System font stack (clean & fast)
- **Headings:** Bold, large sizes
- **Body:** Regular weight, readable sizes

### Components
All components use **shadcn/ui** (Radix UI + Tailwind):
- Buttons, Forms, Dialogs, Dropdowns
- Cards, Tables, Tooltips
- Toasts, Alerts, Badges

---

## 🔒 Security Best Practices

- ✅ All passwords hashed (in production, add bcrypt)
- ✅ Session-based authentication
- ✅ CORS configured for production domain
- ✅ Input validation with Zod
- ✅ SQL injection prevention (Drizzle ORM)
- ✅ XSS protection (React escaping)
- ✅ Environment variables for sensitive data

### TODO for Production
- [ ] Add bcrypt for password hashing
- [ ] Implement rate limiting
- [ ] Add CSRF protection
- [ ] Enable HTTPS only
- [ ] Set up monitoring (Sentry)
- [ ] Configure WAF (Web Application Firewall)

---

## 📈 Performance

### Optimization Strategies
- **Code Splitting** - Dynamic imports for routes
- **Image Optimization** - Compressed assets
- **Caching** - API response caching
- **CDN** - Vercel Edge Network
- **Database** - Indexed queries, connection pooling

### Lighthouse Scores (Target)
- Performance: 90+
- Accessibility: 95+
- Best Practices: 95+
- SEO: 100

---

## 🐛 Troubleshooting

### Common Issues

**Database connection fails**
```
Error: connect ECONNREFUSED
Solution: Check DATABASE_URL in .env, verify Supabase project is active
```

**Build fails**
```
Error: Module not found
Solution: rm -rf node_modules && yarn install
```

**Emails not sending**
```
Error: SendGrid authentication failed
Solution: Verify SENDGRID_API_KEY is correct, check sender verification
```

**AI recommendations not working**
```
Issue: Returns fallback bundles
Solution: Check database has seeded data, verify bundle slugs match
```

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Coding Standards
- TypeScript for all new code
- ESLint + Prettier for formatting
- Meaningful commit messages
- Add tests for new features

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 📞 Support

- **Documentation:** [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Issues:** [GitHub Issues](https://github.com/yourusername/mediconnect/issues)
- **Email:** support@mediconnect.ae

---

## 🙏 Acknowledgments

- **Emergent AI** - For the universal LLM key and development platform
- **Supabase** - For database hosting
- **Vercel** - For deployment and hosting
- **shadcn/ui** - For beautiful UI components
- **Drizzle ORM** - For type-safe database queries

---

**Built with ❤️ for better healthcare access in Dubai, UAE**

---

## 📸 Screenshots

### Homepage
![Homepage](docs/screenshots/homepage.png)

### AI Discovery
![AI Discovery](docs/screenshots/ai-discovery.png)

### Tests Catalog
![Tests Catalog](docs/screenshots/tests-catalog.png)

### Admin Dashboard
![Admin Dashboard](docs/screenshots/admin-dashboard.png)

---

**Last Updated:** January 2026
**Version:** 1.0.0
