CREATE TABLE "ai_mapping_rules" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"rule_set_id" uuid,
	"name" text NOT NULL,
	"conditions" jsonb NOT NULL,
	"recommended_bundle_ids" jsonb NOT NULL,
	"reason_template" text,
	"priority" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "ai_questions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"rule_set_id" uuid,
	"question_key" text NOT NULL,
	"question_text" text NOT NULL,
	"question_type" text DEFAULT 'single',
	"options" jsonb NOT NULL,
	"helper_text" text,
	"icon" text,
	"sort_order" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "ai_rule_sets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"max_bundles" integer DEFAULT 3,
	"disclaimer_text" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "appointments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid,
	"lab_id" uuid,
	"bundle_id" uuid,
	"status" text DEFAULT 'pending',
	"appointment_time" timestamp,
	"address" text,
	"city" text,
	"total_price" numeric,
	"payment_status" text DEFAULT 'pending',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "bundle_tests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"bundle_id" uuid,
	"test_id" uuid
);
--> statement-breakpoint
CREATE TABLE "bundles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"slug" text,
	"description" text,
	"short_description" text,
	"category" text,
	"tags" jsonb DEFAULT '[]'::jsonb,
	"icon" text DEFAULT 'activity',
	"color" text DEFAULT 'blue',
	"base_price" numeric NOT NULL,
	"is_popular" boolean DEFAULT false,
	"is_active" boolean DEFAULT true,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "bundles_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "lab_bundle_pricing" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"lab_id" uuid,
	"bundle_id" uuid,
	"price" numeric NOT NULL,
	"home_collection_fee" numeric DEFAULT '50',
	"is_active" boolean DEFAULT true
);
--> statement-breakpoint
CREATE TABLE "lab_hours" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"lab_id" uuid,
	"day_of_week" integer NOT NULL,
	"open_time" time NOT NULL,
	"close_time" time NOT NULL,
	"is_active" boolean DEFAULT true
);
--> statement-breakpoint
CREATE TABLE "lab_zones" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"lab_id" uuid,
	"city" text NOT NULL,
	"area" text NOT NULL,
	"is_active" boolean DEFAULT true
);
--> statement-breakpoint
CREATE TABLE "partner_labs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"slug" text,
	"logo_url" text,
	"description" text,
	"emirate" text,
	"status" text DEFAULT 'active',
	"avg_confirmation_hours" numeric DEFAULT '2',
	"rating" numeric DEFAULT '4.5',
	"total_reviews" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "partner_labs_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "tests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"category" text,
	"biomarkers" jsonb DEFAULT '[]'::jsonb,
	"preparation" text,
	"turnaround_hours" integer DEFAULT 24,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	"role" text DEFAULT 'user',
	"name" text,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "conversations" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"created_at" timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE "messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"conversation_id" integer NOT NULL,
	"role" text NOT NULL,
	"content" text NOT NULL,
	"created_at" timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
ALTER TABLE "ai_mapping_rules" ADD CONSTRAINT "ai_mapping_rules_rule_set_id_ai_rule_sets_id_fk" FOREIGN KEY ("rule_set_id") REFERENCES "public"."ai_rule_sets"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_questions" ADD CONSTRAINT "ai_questions_rule_set_id_ai_rule_sets_id_fk" FOREIGN KEY ("rule_set_id") REFERENCES "public"."ai_rule_sets"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_lab_id_partner_labs_id_fk" FOREIGN KEY ("lab_id") REFERENCES "public"."partner_labs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_bundle_id_bundles_id_fk" FOREIGN KEY ("bundle_id") REFERENCES "public"."bundles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bundle_tests" ADD CONSTRAINT "bundle_tests_bundle_id_bundles_id_fk" FOREIGN KEY ("bundle_id") REFERENCES "public"."bundles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bundle_tests" ADD CONSTRAINT "bundle_tests_test_id_tests_id_fk" FOREIGN KEY ("test_id") REFERENCES "public"."tests"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lab_bundle_pricing" ADD CONSTRAINT "lab_bundle_pricing_lab_id_partner_labs_id_fk" FOREIGN KEY ("lab_id") REFERENCES "public"."partner_labs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lab_bundle_pricing" ADD CONSTRAINT "lab_bundle_pricing_bundle_id_bundles_id_fk" FOREIGN KEY ("bundle_id") REFERENCES "public"."bundles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lab_hours" ADD CONSTRAINT "lab_hours_lab_id_partner_labs_id_fk" FOREIGN KEY ("lab_id") REFERENCES "public"."partner_labs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lab_zones" ADD CONSTRAINT "lab_zones_lab_id_partner_labs_id_fk" FOREIGN KEY ("lab_id") REFERENCES "public"."partner_labs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_conversation_id_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."conversations"("id") ON DELETE cascade ON UPDATE no action;