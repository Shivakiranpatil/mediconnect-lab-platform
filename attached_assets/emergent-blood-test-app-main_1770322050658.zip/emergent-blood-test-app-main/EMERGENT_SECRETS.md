# 🔐 EMERGENT SECRETS CONFIGURATION

## Required Secrets for Deployment

Add these secrets in your Emergent workspace:

### 1. Database (Supabase)
```
SUPABASE_URL=postgresql://postgres.[PROJECT-REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true
```

**How to get:**
1. Go to [supabase.com](https://supabase.com)
2. Create project or use existing
3. Navigate to: Project Settings → Database
4. Copy "Connection string" (Transaction mode, port 6543)
5. Add as secret in Emergent: `SUPABASE_URL`

---

### 2. Email Service (Optional - SendGrid)
```
SENDGRID_API_KEY=SG.your-api-key-here
```

**How to get:**
1. Go to [sendgrid.com](https://sendgrid.com)
2. Sign up / Login
3. Navigate to: Settings → API Keys
4. Create new API key with "Full Access"
5. Add as secret in Emergent: `SENDGRID_API_KEY`

---

## Environment Variables Already Set

These are already configured in `.env`:
- ✅ `OPENAI_API_KEY` - Your OpenAI key for AI chat
- ✅ `EMERGENT_LLM_KEY` - Universal key for OpenAI/Anthropic/Gemini
- ✅ `SESSION_SECRET` - Session encryption
- ✅ `NODE_ENV` - Production mode
- ✅ `PORT` - Server port (3000)

---

## Setting Secrets in Emergent

### Method 1: Via Emergent UI
1. Open your Emergent workspace
2. Go to Settings / Environment Variables / Secrets
3. Add each secret with name and value
4. Save changes

### Method 2: Via CLI (if available)
```bash
emergent secrets set SUPABASE_URL "your-connection-string"
emergent secrets set SENDGRID_API_KEY "your-sendgrid-key"
```

---

## Local Development vs Production

**Local Development:**
- Set secrets in `.env` file directly
- Use mock database if no Supabase configured

**Emergent Production:**
- Secrets pulled from Emergent environment
- Automatic injection at runtime
- Secure and not in code

---

## Testing After Setting Secrets

Once secrets are set:
1. Restart the application
2. Check logs for "✅ OpenAI initialized successfully"
3. Test AI chat at `/ai-discovery`
4. Verify database connection
5. Test email notifications (if configured)

---

## Current Configuration

The app will automatically use:
1. `SUPABASE_URL` if provided → Real database
2. Mock database if not provided → Still works!
3. `SENDGRID_API_KEY` if provided → Email notifications
4. No key → Emails logged but not sent

**Your app works without any secrets set!** 
Mock data mode ensures full functionality for testing.

---

## Security Notes

- ✅ Never commit secrets to git
- ✅ Use Emergent Secrets for sensitive data
- ✅ Rotate keys periodically
- ✅ Use different keys for dev/prod
- ✅ Monitor API usage and costs
