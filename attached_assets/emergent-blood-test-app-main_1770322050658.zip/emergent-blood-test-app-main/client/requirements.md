## Packages
framer-motion | Complex page transitions and hero animations
clsx | Conditional class merging
tailwind-merge | Class merging for components

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['"DM Sans"', "sans-serif"],
  display: ['"Outfit"', "sans-serif"],
}
