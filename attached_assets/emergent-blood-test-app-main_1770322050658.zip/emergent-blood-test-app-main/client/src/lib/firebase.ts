import { initializeApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyCADqx49Hpwa9rQQsoHDbyawcxsAYXuXuQ",
  authDomain: "vitalsmarket-17a23.firebaseapp.com",
  projectId: "vitalsmarket-17a23",
  storageBucket: "vitalsmarket-17a23.firebasestorage.app",
  messagingSenderId: "938279526456",
  appId: "1:938279526456:web:b536578315ce41781d06cd",
  measurementId: "G-4MVQ1NCQEG"
};

// Initialize Firebase (singleton pattern)
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Configure Google provider with OAuth client ID
googleProvider.setCustomParameters({
  prompt: 'select_account',
  client_id: '938279526456-p6k2gsanukhjhipt29c4ovatcgrk3a1q.apps.googleusercontent.com'
});

// Add scopes for user info
googleProvider.addScope('profile');
googleProvider.addScope('email');

export default app;
