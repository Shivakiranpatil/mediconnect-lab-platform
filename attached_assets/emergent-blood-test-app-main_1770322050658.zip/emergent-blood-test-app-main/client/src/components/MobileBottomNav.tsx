import { Link, useLocation } from "wouter";
import { Home, Search, Sparkles, Calendar, User } from "lucide-react";

export function MobileBottomNav() {
  const [location] = useLocation();

  const navItems = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Search', href: '/tests', icon: Search },
    { name: 'AI', href: '/ai-discovery', icon: Sparkles },
    { name: 'Bookings', href: '/bookings', icon: Calendar },
    { name: 'Account', href: '/auth', icon: User },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location === '/';
    return location.startsWith(href);
  };

  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 safe-area-bottom" data-testid="mobile-bottom-nav">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          return (
            <Link key={item.name} href={item.href}>
              <button
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors ${
                  active
                    ? 'text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                data-testid={`mobile-nav-${item.name.toLowerCase()}`}
              >
                <Icon className={`w-5 h-5 ${active ? 'stroke-[2.5px]' : ''}`} />
                <span className="text-[10px] font-medium">{item.name}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
