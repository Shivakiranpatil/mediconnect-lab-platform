import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Sparkles, ArrowRight, ChevronRight, Activity, Heart, Zap, Droplets, Beaker } from "lucide-react";
import { Link, useLocation } from "wouter";

interface QuickAssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Question {
  id: string;
  text: string;
  options: {
    label: string;
    icon: string;
    value: string;
    relatedTests: string[];
  }[];
}

const questions: Question[] = [
  {
    id: "goal",
    text: "What's your main health goal?",
    options: [
      { label: "Routine Checkup", icon: "🩺", value: "routine", relatedTests: ["Full Body Checkup", "Essential Health Check"] },
      { label: "Energy & Fatigue", icon: "⚡", value: "fatigue", relatedTests: ["Energy & Fatigue Panel", "Vitamin D", "Iron Studies", "Thyroid Function Panel"] },
      { label: "Heart Health", icon: "❤️", value: "heart", relatedTests: ["Heart & Cholesterol Panel", "Lipid Profile"] },
      { label: "Diabetes Check", icon: "🍬", value: "diabetes", relatedTests: ["HbA1c Blood Sugar Test", "Diabetes Monitoring Panel"] },
    ]
  },
  {
    id: "age",
    text: "What's your age group?",
    options: [
      { label: "18-30", icon: "👤", value: "18-30", relatedTests: ["HbA1c Blood Sugar Test"] },
      { label: "31-45", icon: "👤", value: "31-45", relatedTests: ["Lipid Profile", "Thyroid Function Panel"] },
      { label: "46-60", icon: "👤", value: "46-60", relatedTests: ["Full Body Checkup", "Heart & Cholesterol Panel", "HbA1c Blood Sugar Test"] },
      { label: "60+", icon: "👤", value: "60+", relatedTests: ["Full Body Checkup", "Kidney Function Test", "Liver Function Test", "HbA1c Blood Sugar Test"] },
    ]
  },
  {
    id: "gender",
    text: "What's your gender?",
    options: [
      { label: "Male", icon: "♂️", value: "male", relatedTests: [] },
      { label: "Female", icon: "♀️", value: "female", relatedTests: ["Women's Wellness Panel"] },
      { label: "Prefer not to say", icon: "🙂", value: "other", relatedTests: [] },
    ]
  }
];

interface Recommendation {
  name: string;
  description: string;
  price: string;
  icon: any;
  gradient: string;
  bundleId: string;
}

const bundleRecommendations: Record<string, Recommendation> = {
  "Full Body Checkup": {
    name: "Full Body Checkup",
    description: "Complete health screening with 40+ parameters",
    price: "699",
    icon: Activity,
    gradient: "from-blue-500 to-blue-600",
    bundleId: "1"
  },
  "Women's Wellness Panel": {
    name: "Women's Wellness Panel",
    description: "Hormone balance, PCOS screening, and fertility markers",
    price: "599",
    icon: Heart,
    gradient: "from-pink-500 to-pink-600",
    bundleId: "2"
  },
  "Heart & Cholesterol Panel": {
    name: "Heart & Cholesterol Panel",
    description: "Comprehensive cardiovascular risk assessment",
    price: "299",
    icon: Heart,
    gradient: "from-red-500 to-red-600",
    bundleId: "3"
  },
  "Energy & Fatigue Panel": {
    name: "Energy & Fatigue Panel",
    description: "Identify vitamin deficiencies causing tiredness",
    price: "449",
    icon: Zap,
    gradient: "from-amber-500 to-amber-600",
    bundleId: "4"
  },
  "Diabetes Monitoring Panel": {
    name: "Diabetes Monitoring Panel",
    description: "Complete diabetes screening and management",
    price: "249",
    icon: Droplets,
    gradient: "from-orange-500 to-orange-600",
    bundleId: "5"
  },
  "Essential Health Check": {
    name: "Essential Health Check",
    description: "Basic health screening for routine checkups",
    price: "199",
    icon: Beaker,
    gradient: "from-teal-500 to-teal-600",
    bundleId: "6"
  },
  "HbA1c Blood Sugar Test": {
    name: "HbA1c Blood Sugar Test",
    description: "Affordable blood sugar monitoring test",
    price: "99",
    icon: Droplets,
    gradient: "from-green-500 to-green-600",
    bundleId: "7"
  }
};

export function QuickAssessmentModal({ isOpen, onClose }: QuickAssessmentModalProps) {
  const [, navigate] = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (value: string) => {
    const question = questions[currentQuestion];
    setAnswers(prev => ({ ...prev, [question.id]: value }));

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setShowResults(true);
    }
  };

  const getRecommendations = (): Recommendation[] => {
    const recommendedTests = new Set<string>();
    
    // Add tests based on all answers
    Object.entries(answers).forEach(([questionId, answerValue]) => {
      const question = questions.find(q => q.id === questionId);
      if (question) {
        const selectedOption = question.options.find(o => o.value === answerValue);
        if (selectedOption) {
          selectedOption.relatedTests.forEach(test => recommendedTests.add(test));
        }
      }
    });

    // Convert to recommendations
    const recs: Recommendation[] = [];
    recommendedTests.forEach(testName => {
      if (bundleRecommendations[testName]) {
        recs.push(bundleRecommendations[testName]);
      }
    });

    // If no specific recommendations, suggest routine checkup
    if (recs.length === 0) {
      recs.push(bundleRecommendations["Full Body Checkup"]);
      recs.push(bundleRecommendations["Essential Health Check"]);
    }

    return recs.slice(0, 3); // Max 3 recommendations
  };

  const resetAssessment = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
  };

  const handleClose = () => {
    resetAssessment();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
          data-testid="quick-assessment-modal"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-colors"
              data-testid="close-assessment-modal"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Quick Health Assessment</h2>
                <p className="text-blue-100 text-sm">Answer 3 questions to get personalized recommendations</p>
              </div>
            </div>

            {/* Progress bar */}
            {!showResults && (
              <div className="mt-4">
                <div className="flex justify-between text-xs text-blue-200 mb-1">
                  <span>Question {currentQuestion + 1} of {questions.length}</span>
                  <span>{Math.round(((currentQuestion + 1) / questions.length) * 100)}%</span>
                </div>
                <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                    className="h-full bg-white rounded-full"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-6">
            {!showResults ? (
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {questions[currentQuestion].text}
                </h3>
                
                <div className="space-y-3">
                  {questions[currentQuestion].options.map((option, index) => (
                    <motion.button
                      key={option.value}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => handleAnswer(option.value)}
                      className="w-full p-4 bg-gray-50 hover:bg-blue-50 border-2 border-gray-200 hover:border-blue-400 rounded-xl transition-all duration-200 flex items-center gap-3 group"
                      data-testid={`assessment-option-${option.value}`}
                    >
                      <span className="text-2xl">{option.icon}</span>
                      <span className="flex-1 text-left font-medium text-gray-700 group-hover:text-blue-600">
                        {option.label}
                      </span>
                      <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Your Recommended Tests</h3>
                  <p className="text-sm text-gray-600 mt-1">Based on your health goals</p>
                </div>

                <div className="space-y-3">
                  {getRecommendations().map((rec, index) => {
                    const Icon = rec.icon;
                    return (
                      <motion.div
                        key={rec.name}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() => navigate(`/book/${rec.bundleId}`)}
                        className="p-4 bg-gradient-to-r from-gray-50 to-white border-2 border-gray-200 hover:border-green-400 rounded-xl cursor-pointer group transition-all"
                        data-testid={`recommendation-${rec.bundleId}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 bg-gradient-to-br ${rec.gradient} rounded-xl flex items-center justify-center transform group-hover:scale-110 transition-transform`}>
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-bold text-gray-900 group-hover:text-green-600 transition-colors">
                              {rec.name}
                            </h4>
                            <p className="text-xs text-gray-500">{rec.description}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-lg font-bold text-blue-600">AED {rec.price}</span>
                            <p className="text-xs text-green-600 font-medium">Click to Book →</p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={resetAssessment}
                    className="flex-1 py-3 px-4 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                    data-testid="restart-assessment"
                  >
                    Start Over
                  </button>
                  <Link href="/ai-discovery" className="flex-1">
                    <button
                      className="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-medium hover:from-blue-700 hover:to-blue-800 transition-all flex items-center justify-center gap-2"
                      data-testid="go-to-ai-discovery"
                    >
                      <Sparkles className="w-4 h-4" />
                      Ask AI for More
                    </button>
                  </Link>
                </div>

                <p className="text-xs text-gray-500 text-center mt-4">
                  💡 For personalized advice, use our AI Discovery chat
                </p>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
