import { Link, useLocation } from "wouter";
import { Home as HomeIcon, Calendar, User, LogOut, Menu, X, MapPin, Phone, ChevronDown, TestTube } from "lucide-react";
import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import { useMyTests } from "@/contexts/MyTestsContext";
import { useAuth } from "@/contexts/AuthContext";

export function Navbar() {
  const [location, navigate] = useLocation();
  const { user, logout, isAuthenticated, loading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { getItemCount } = useCart();
  const { getItemCount: getMyTestsCount, setSidebarOpen } = useMyTests();
  
  const cartCount = getItemCount();
  const myTestsCount = getMyTestsCount();

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'All Tests', href: '/tests' },
    { name: 'Test Finder', href: '/ai-discovery', tooltip: 'Get test suggestions based on symptoms (not a diagnosis)' },
    { name: 'Partner Labs', href: '/labs' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location === '/';
    if (href.startsWith('#')) return false;
    return location.startsWith(href);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="bg-white sticky top-0 z-50 border-b border-gray-100" data-testid="navbar">
      {/* Top bar with location and phone */}
      <div className="bg-gray-50 border-b border-gray-100 py-2 px-4 sm:px-6 hidden sm:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-sm">
          <button className="flex items-center gap-1.5 text-gray-700 hover:text-blue-600 transition-colors">
            <MapPin className="w-4 h-4 text-blue-600" />
            <span className="font-medium">Dubai</span>
            <ChevronDown className="w-3 h-3" />
          </button>
          <a href="tel:800-MEDI" className="flex items-center gap-1.5 text-gray-700 hover:text-blue-600 transition-colors">
            <Phone className="w-4 h-4 text-green-600" />
            <span className="font-medium">800-MEDI</span>
          </a>
        </div>
      </div>
      
      {/* Main navbar */}
      <div className="px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo/Brand */}
          <Link href="/">
            <div className="flex items-center gap-2 text-blue-600 font-bold text-lg cursor-pointer" data-testid="logo">
              <HomeIcon className="w-5 h-5" />
              <span>MediConnect</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <button
                  className={`text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? 'text-blue-600'
                      : 'text-gray-700 hover:text-blue-600'
                  }`}
                  data-testid={`nav-${item.name.toLowerCase().replace(/\s/g, '-')}`}
                  title={item.tooltip}
                >
                  {item.name}
                </button>
              </Link>
            ))}
          </nav>

          {/* Auth buttons - Desktop */}
          <div className="hidden md:flex items-center gap-3">
            {/* My Tests / Cart Icon - Shows cart count */}
            <button 
              onClick={() => setSidebarOpen(true)}
              className="relative flex items-center gap-1.5 px-3 py-2 text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              data-testid="my-tests-icon"
              title="My Tests"
            >
              <TestTube className="w-5 h-5" />
              <span className="text-sm font-medium">My Tests</span>
              {/* Show cart count badge - prominent */}
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full font-bold min-w-[20px] text-center animate-pulse">
                  {cartCount}
                </span>
              )}
              {/* Show compare count if cart is empty but compare has items */}
              {cartCount === 0 && myTestsCount > 0 && (
                <span className="px-1.5 py-0.5 bg-blue-600 text-white text-xs rounded-full font-bold min-w-[20px] text-center">
                  {myTestsCount}
                </span>
              )}
            </button>
            
            {isAuthenticated && user ? (
            <div className="flex items-center gap-3">
              <Link href="/bookings">
                <button 
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
                  data-testid="button-bookings"
                >
                  <Calendar className="w-4 h-4" />
                  My Bookings
                </button>
              </Link>
              <Link href="/profile">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-full hover:bg-blue-100 transition-colors cursor-pointer">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="" className="w-6 h-6 rounded-full" />
                  ) : (
                    <User className="w-4 h-4 text-blue-600" />
                  )}
                  <span className="text-sm font-medium text-blue-700">{user.displayName || user.email?.split('@')[0]}</span>
                </div>
              </Link>
              <button 
                onClick={handleLogout}
                className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                data-testid="button-logout"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <Link href="/bookings">
                <button 
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
                  data-testid="button-bookings-guest"
                >
                  <Calendar className="w-4 h-4" />
                  My Bookings
                </button>
              </Link>
              <Link href="/auth">
                <button 
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors" 
                  data-testid="button-login"
                >
                  Login
                </button>
              </Link>
              <Link href="/auth">
                <button 
                  className="px-6 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all shadow-md hover:shadow-lg" 
                  data-testid="button-signup"
                >
                  Sign Up
                </button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button 
          className="md:hidden p-2 text-gray-600"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="mobile-menu-toggle"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-4 pb-4 border-t border-gray-100 pt-4">
          <nav className="flex flex-col gap-2">
            {navItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className={`w-full text-left px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    isActive(item.href)
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.name}
                </button>
              </Link>
            ))}
            <Link href="/bookings">
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="w-full text-left px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-lg flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                My Bookings
              </button>
            </Link>
            {!user && (
              <Link href="/auth">
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full mt-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg"
                >
                  Login / Sign Up
                </button>
              </Link>
            )}
            {user && (
              <>
                <Link href="/profile">
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="w-full text-left px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-lg flex items-center gap-2"
                  >
                    <User className="w-4 h-4" />
                    My Profile
                  </button>
                </Link>
                <button
                  onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
