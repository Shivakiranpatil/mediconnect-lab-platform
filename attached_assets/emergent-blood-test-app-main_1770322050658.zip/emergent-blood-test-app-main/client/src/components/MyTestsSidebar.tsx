import { Link } from "wouter";
import { X, TestTube, Trash2, Package, ArrowRight, AlertTriangle, Sparkles, ShoppingBag } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useMyTests } from "@/contexts/MyTestsContext";
import { useCart } from "@/contexts/CartContext";

export function MyTestsSidebar() {
  const { 
    items, 
    removeItem, 
    clearItems, 
    getTotal, 
    getItemCount,
    getRecommendedPackage,
    sidebarOpen, 
    setSidebarOpen 
  } = useMyTests();
  
  const { items: cartItems, getItemCount: getCartCount, getCartTotal, removeFromCart, clearCart } = useCart();

  const total = getTotal();
  const count = getItemCount();
  const cartCount = getCartCount();
  const cartTotal = getCartTotal();
  const recommendation = getRecommendedPackage();
  const pricePerTest = count > 0 ? Math.round(total / count) : 0;

  return (
    <AnimatePresence>
      {sidebarOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50"
            onClick={() => setSidebarOpen(false)}
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25 }}
            className="fixed top-0 right-0 w-full max-w-md h-full bg-white shadow-2xl z-50 flex flex-col"
            data-testid="my-tests-sidebar"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                  <TestTube className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-gray-900">My Tests</h2>
                  <p className="text-xs text-gray-500">
                    {cartCount > 0 
                      ? `${cartCount} test${cartCount !== 1 ? 's' : ''} selected for booking` 
                      : count > 0 
                        ? `${count} test${count !== 1 ? 's' : ''} for comparison`
                        : 'Browse tests below'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSidebarOpen(false)}
                className="p-2 hover:bg-white/50 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto">
              {/* Show Cart Items if any */}
              {cartCount > 0 ? (
                <div className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-900">Selected Tests</h3>
                    <button 
                      onClick={clearCart}
                      className="text-xs text-red-500 hover:text-red-600"
                    >
                      Clear All
                    </button>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    {cartItems.map((item) => (
                      <div key={item.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{item.name}</h4>
                            {item.testCount && (
                              <p className="text-xs text-gray-500 mt-1">{item.testCount} tests included</p>
                            )}
                            {item.selectedLab && (
                              <p className="text-xs text-blue-600 mt-1">{item.selectedLab.name}</p>
                            )}
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-blue-600">AED {item.selectedLab?.price || item.price}</p>
                            <button 
                              onClick={() => removeFromCart(item.id)}
                              className="text-xs text-red-500 hover:text-red-600 mt-1"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Cart Total */}
                  <div className="bg-gray-50 rounded-xl p-4 mb-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total</span>
                      <span className="text-xl font-bold text-blue-600">AED {cartTotal}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-2 text-xs text-green-600">
                      <span>✓</span>
                      <span>FREE Home/Office Collection included</span>
                    </div>
                  </div>
                  
                  {/* Book Now Button */}
                  <Link href="/checkout">
                    <button 
                      onClick={() => setSidebarOpen(false)}
                      className="w-full py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-5 h-5" />
                      Book Appointment
                    </button>
                  </Link>
                </div>
              ) : count === 0 ? (
                /* Empty State - Simple browse buttons, no message */
                <div className="p-6">
                  <div className="flex flex-col gap-3 mb-6">
                    <Link href="/tests?tab=bundles">
                      <button 
                        onClick={() => setSidebarOpen(false)}
                        className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                      >
                        <Package className="w-5 h-5" />
                        Browse Packages
                      </button>
                    </Link>
                    <Link href="/tests?tab=individual">
                      <button 
                        onClick={() => setSidebarOpen(false)}
                        className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                      >
                        Browse Individual Tests
                      </button>
                    </Link>
                  </div>

                  {/* Popular Packages */}
                  <div className="text-left">
                    <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-yellow-500" />
                      MOST POPULAR PACKAGES
                    </h4>
                    <div className="space-y-2">
                      {[
                        { name: 'Full Body Checkup', price: 699, tests: 60, id: '1' },
                        { name: "Women's Wellness", price: 599, tests: 45, id: '2' },
                        { name: 'Essential Health', price: 299, tests: 25, id: '6' },
                      ].map(pkg => (
                        <Link key={pkg.id} href={`/bundles/${pkg.id}`}>
                          <div 
                            onClick={() => setSidebarOpen(false)}
                            className="p-3 bg-gray-50 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                          >
                            <div className="flex justify-between items-center">
                              <span className="font-medium text-gray-900 text-sm">{pkg.name}</span>
                              <span className="text-blue-600 font-bold text-sm">AED {pkg.price}</span>
                            </div>
                            <span className="text-xs text-gray-500">{pkg.tests} tests</span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* Items List */
                <div className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Your Selected Tests</h3>
                    <button 
                      onClick={clearItems}
                      className="text-xs text-red-500 hover:text-red-600 font-medium"
                    >
                      Clear All
                    </button>
                  </div>

                  <div className="space-y-2 mb-4">
                    {items.map(item => (
                      <div 
                        key={item.id}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-xl"
                      >
                        <div>
                          <p className="font-medium text-gray-900 text-sm">{item.name}</p>
                          {item.category && (
                            <p className="text-xs text-gray-500">{item.category}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-gray-900">AED {item.price}</span>
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Summary */}
                  <div className="border-t border-b py-4 mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Your Total ({count} tests)</span>
                      <span className="font-bold text-gray-900">AED {total}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Price per test</span>
                      <span className="font-medium text-gray-700">AED {pricePerTest}</span>
                    </div>
                  </div>

                  {/* Package Recommendation */}
                  {recommendation && (
                    <div className={`rounded-2xl p-4 mb-4 ${
                      recommendation.recommendation === 'CRITICAL' 
                        ? 'bg-red-50 border-2 border-red-200'
                        : recommendation.recommendation === 'ALERT'
                        ? 'bg-orange-50 border-2 border-orange-200'
                        : recommendation.recommendation === 'WARNING'
                        ? 'bg-yellow-50 border-2 border-yellow-200'
                        : 'bg-blue-50 border-2 border-blue-200'
                    }`}>
                      <div className="flex items-start gap-2 mb-3">
                        <AlertTriangle className={`w-5 h-5 flex-shrink-0 ${
                          recommendation.recommendation === 'CRITICAL' ? 'text-red-500' :
                          recommendation.recommendation === 'ALERT' ? 'text-orange-500' :
                          recommendation.recommendation === 'WARNING' ? 'text-yellow-600' :
                          'text-blue-500'
                        }`} />
                        <span className={`font-bold text-sm ${
                          recommendation.recommendation === 'CRITICAL' ? 'text-red-700' :
                          recommendation.recommendation === 'ALERT' ? 'text-orange-700' :
                          recommendation.recommendation === 'WARNING' ? 'text-yellow-700' :
                          'text-blue-700'
                        }`}>
                          {recommendation.recommendation === 'CRITICAL' ? "🚨 STOP! You're overpaying!" :
                           recommendation.recommendation === 'ALERT' ? "⚠️ You're paying more for less!" :
                           recommendation.recommendation === 'WARNING' ? "💡 Better value available!" :
                           "💡 Consider this package"}
                        </span>
                      </div>

                      <div className="bg-white rounded-xl p-4 border border-gray-100">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded-full">
                            🏆 BEST VALUE
                          </span>
                        </div>
                        <h4 className="font-bold text-gray-900 mb-1">{recommendation.name}</h4>
                        
                        <div className="space-y-1 text-sm mb-3">
                          <div className="flex items-center gap-2 text-green-600">
                            <span>✓</span>
                            <span>Includes all {count} tests you selected</span>
                          </div>
                          <div className="flex items-center gap-2 text-green-600">
                            <span>✓</span>
                            <span>PLUS {recommendation.extraTests} more tests</span>
                          </div>
                          {recommendation.priceDifference > 0 ? (
                            <div className="flex items-center gap-2 text-green-600">
                              <span>✓</span>
                              <span>Only AED {recommendation.priceDifference} more!</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-green-600">
                              <span>✓</span>
                              <span>Save AED {Math.abs(recommendation.priceDifference)}!</span>
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3 p-3 bg-gray-50 rounded-lg text-center mb-3">
                          <div>
                            <p className="text-xs text-gray-500">Your selection</p>
                            <p className="font-bold text-gray-700">{count} tests = AED {total}</p>
                            <p className="text-xs text-gray-500">AED {pricePerTest}/test</p>
                          </div>
                          <div className="border-l">
                            <p className="text-xs text-gray-500">This package</p>
                            <p className="font-bold text-green-600">{recommendation.testCount} tests = AED {recommendation.price}</p>
                            <p className="text-xs text-green-600">AED {recommendation.pricePerTestPackage}/test</p>
                          </div>
                        </div>

                        <Link href={`/bundles/${recommendation.id}`}>
                          <button 
                            onClick={() => setSidebarOpen(false)}
                            className="w-full py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                          >
                            🏆 Switch to Package - AED {recommendation.price}
                          </button>
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer Actions */}
            {count > 0 && (
              <div className="p-4 border-t bg-gray-50">
                <Link href="/tests">
                  <button 
                    onClick={() => setSidebarOpen(false)}
                    className="w-full py-2 text-blue-600 font-medium hover:text-blue-700 mb-2"
                  >
                    Continue Browsing
                  </button>
                </Link>
                <Link href="/checkout">
                  <button 
                    onClick={() => setSidebarOpen(false)}
                    className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-white transition-colors"
                  >
                    Book Selected Tests - AED {total}
                  </button>
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
