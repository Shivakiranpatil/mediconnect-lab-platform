import { Link } from "wouter";
import { X, Check, Package, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { getPackagesContainingTest } from "@/contexts/MyTestsContext";

interface AddToCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  testName: string;
  testPrice: number;
  onViewMyTests: () => void;
}

export function AddToCompareModal({ 
  isOpen, 
  onClose, 
  testName, 
  testPrice,
  onViewMyTests 
}: AddToCompareModalProps) {
  const packages = getPackagesContainingTest(testName);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-white rounded-2xl shadow-2xl z-50 overflow-hidden"
            data-testid="add-compare-modal"
          >
            {/* Header */}
            <div className="p-5 border-b bg-gradient-to-r from-green-50 to-emerald-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">Added to Compare List</h3>
                    <p className="text-sm text-gray-600">{testName} - AED {testPrice}</p>
                  </div>
                </div>
                <button 
                  onClick={onClose}
                  className="p-2 hover:bg-white/50 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-5">
              {packages.length > 0 && (
                <div className="mb-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Package className="w-5 h-5 text-blue-600" />
                    <span className="font-bold text-gray-900">DID YOU KNOW?</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    This test is included in these packages:
                  </p>
                  
                  <div className="space-y-2">
                    {packages.slice(0, 3).map(pkg => (
                      <Link key={pkg.id} href={`/bundles/${pkg.id}`}>
                        <div 
                          onClick={onClose}
                          className="p-3 bg-blue-50 hover:bg-blue-100 rounded-xl cursor-pointer transition-colors"
                        >
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-semibold text-gray-900">{pkg.name}</p>
                              <p className="text-xs text-gray-500">{pkg.testCount} tests • AED {pkg.pricePerTest}/test</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-blue-600">AED {pkg.price}</p>
                              <ArrowRight className="w-4 h-4 text-blue-400 ml-auto" />
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>

                  <p className="text-sm text-green-600 font-medium mt-3 text-center">
                    💡 Get more tests for better value!
                  </p>
                </div>
              )}

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
                <Link href="/tests?tab=bundles" className="flex-1">
                  <button 
                    onClick={onClose}
                    className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                  >
                    View Packages
                  </button>
                </Link>
                <button 
                  onClick={onClose}
                  className="flex-1 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                >
                  Continue Browsing
                </button>
                <button 
                  onClick={() => { onClose(); onViewMyTests(); }}
                  className="flex-1 py-3 text-blue-600 font-medium hover:text-blue-700"
                >
                  View My Tests →
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
