import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Shield, CheckCircle, Clock, Activity, Beaker, 
  ArrowRight, Heart, Zap, ArrowLeft, Dumbbell
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const mensPackages = [
  {
    id: "12",
    name: "Men's Complete Wellness",
    description: "Comprehensive health screening covering all aspects of men's health including cardiac risk, hormones, and vital organs",
    price: "699",
    originalPrice: "899",
    popular: true,
    testsIncluded: 45,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Cardiac Risk", tests: ["Lipid Profile", "hs-CRP", "Homocysteine", "Lipoprotein(a)"] },
      { category: "Hormone Panel", tests: ["Testosterone", "Free Testosterone", "SHBG", "Prolactin"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c", "Fasting Insulin"] },
      { category: "Liver Function", tests: ["Complete Liver Panel", "GGT"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN", "Uric Acid", "eGFR"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12"] },
      { category: "Prostate", tests: ["PSA (Total)", "Free PSA"] },
    ],
    benefits: [
      "Heart health assessment",
      "Testosterone levels",
      "Prostate screening",
      "Complete organ check"
    ]
  },
  {
    id: "13",
    name: "Testosterone & Vitality Panel",
    description: "Focused panel for men experiencing fatigue, low energy, or suspected hormone imbalance",
    price: "399",
    originalPrice: "499",
    popular: false,
    testsIncluded: 15,
    turnaround: "24 hours",
    parameters: [
      { category: "Hormones", tests: ["Total Testosterone", "Free Testosterone", "SHBG", "Estradiol"] },
      { category: "Thyroid", tests: ["TSH", "Free T4"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Blood Count", tests: ["CBC", "Hemoglobin"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12"] },
    ],
    benefits: [
      "Hormone optimization",
      "Energy assessment",
      "Fatigue investigation",
      "Vitality check"
    ]
  },
  {
    id: "14",
    name: "Prostate Health Panel",
    description: "Essential screening for prostate health, recommended for men over 40",
    price: "299",
    originalPrice: "399",
    popular: false,
    testsIncluded: 10,
    turnaround: "24 hours",
    parameters: [
      { category: "Prostate Markers", tests: ["PSA (Total)", "Free PSA", "PSA Ratio"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN", "Uric Acid"] },
      { category: "Urine", tests: ["Urine Routine", "Urine Culture"] },
    ],
    benefits: [
      "Early cancer detection",
      "BPH monitoring",
      "Urinary health check",
      "Peace of mind"
    ]
  },
  {
    id: "15",
    name: "Executive Men's Checkup",
    description: "Premium health assessment for busy professionals covering stress markers and lifestyle diseases",
    price: "999",
    originalPrice: "1299",
    popular: false,
    testsIncluded: 60,
    turnaround: "48 hours",
    parameters: [
      { category: "Cardiac", tests: ["Complete Lipid Panel", "hs-CRP", "Homocysteine", "ApoB", "Lp(a)"] },
      { category: "Hormones", tests: ["Complete Male Hormone Panel"] },
      { category: "Diabetes", tests: ["Complete Diabetes Panel", "HOMA-IR"] },
      { category: "Liver & Kidney", tests: ["Complete Organ Function Panel"] },
      { category: "Thyroid", tests: ["Complete Thyroid Panel with Antibodies"] },
      { category: "Vitamins & Minerals", tests: ["Complete Vitamin Panel", "Minerals Panel"] },
      { category: "Stress Markers", tests: ["Cortisol", "DHEA-S"] },
      { category: "Prostate", tests: ["Complete Prostate Panel"] },
    ],
    benefits: [
      "Executive-level screening",
      "Stress assessment",
      "Lifestyle disease check",
      "Detailed consultation"
    ]
  }
];

const individualTests = [
  { name: "Testosterone (Total)", price: "129", description: "Primary male hormone level" },
  { name: "Free Testosterone", price: "149", description: "Bioavailable testosterone" },
  { name: "PSA (Prostate Specific Antigen)", price: "99", description: "Prostate health marker" },
  { name: "SHBG", price: "89", description: "Sex hormone binding globulin" },
  { name: "Lipid Profile", price: "89", description: "Heart health assessment" },
  { name: "HbA1c", price: "79", description: "Diabetes monitoring" },
  { name: "Vitamin D", price: "99", description: "Bone and immune health" },
  { name: "Liver Function Test", price: "129", description: "Liver health check" },
  { name: "Kidney Function Test", price: "99", description: "Kidney health assessment" },
  { name: "Cortisol", price: "89", description: "Stress hormone level" },
];

export default function MensHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("12");

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-700 via-slate-800 to-gray-900 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-blue-400 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-slate-400 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Dumbbell className="w-6 h-6" />
              </div>
              <span className="text-blue-300 font-medium">Men's Wellness</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Men's Health Screening
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Comprehensive health packages designed for men's specific health needs - from heart health to hormones and prostate care.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>Prostate Screening</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-400" />
                <span>Results in 24-48 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-blue-300" />
                <span>Hormone Testing</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Men's Health Packages</h2>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {mensPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-slate-700' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-slate-700 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-slate-700">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.benefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-slate-600 flex-shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expandable Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="text-slate-700 text-sm font-medium mb-4 hover:underline"
                  >
                    {expandedPackage === pkg.id ? '- Hide' : '+'} View all parameters
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-sm font-semibold text-gray-700">{param.category}</h5>
                          <p className="text-xs text-gray-500">{param.tests.join(', ')}</p>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  {/* Book Button */}
                  <Link href={`/book/${pkg.id}`}>
                    <button className="w-full py-3 bg-gradient-to-r from-slate-700 to-gray-800 text-white rounded-xl font-semibold hover:from-slate-800 hover:to-gray-900 transition-all flex items-center justify-center gap-2">
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  <span className="text-slate-700 font-bold">AED {test.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-3">{test.description}</p>
                <Link href="/tests">
                  <button className="text-slate-700 text-sm font-medium hover:underline flex items-center gap-1">
                    View Details <ArrowRight className="w-3 h-3" />
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Men's Health Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Men's Health Screening?</h2>
            <p className="text-gray-600">
              Men often neglect regular health checkups. Early detection of issues can prevent serious conditions and maintain vitality.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-slate-50 rounded-2xl">
              <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Heart Health</h3>
              <p className="text-sm text-gray-600">Men are at higher risk for heart disease. Regular screening is essential</p>
            </div>
            <div className="text-center p-6 bg-slate-50 rounded-2xl">
              <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Hormone Balance</h3>
              <p className="text-sm text-gray-600">Testosterone levels affect energy, mood, and overall well-being</p>
            </div>
            <div className="text-center p-6 bg-slate-50 rounded-2xl">
              <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Prostate Care</h3>
              <p className="text-sm text-gray-600">Early detection of prostate issues leads to better outcomes</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-slate-700 to-gray-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Invest in Your Health Today</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Book your men's health screening now and take the first step towards optimal health.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-3 bg-white text-slate-700 rounded-full font-semibold hover:bg-gray-100 transition-all flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </Link>
            <Link href="/tests">
              <button className="px-8 py-3 bg-slate-600 text-white rounded-full font-semibold hover:bg-slate-500 transition-all border border-white/30">
                Browse All Tests
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
