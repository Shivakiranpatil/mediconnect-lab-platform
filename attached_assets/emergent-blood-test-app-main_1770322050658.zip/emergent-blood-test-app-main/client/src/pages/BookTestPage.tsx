import { useState, useEffect } from "react";
import { useParams, useLocation, Link } from "wouter";
import { 
  Calendar, Clock, MapPin, User, Phone, Mail,
  CheckCircle, ArrowLeft, Home, Beaker, Shield, AlertCircle,
  Building2, Truck
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface Bundle {
  id: string;
  name: string;
  description: string;
  basePrice: string;
  tests: string[];
}

interface Lab {
  id: string;
  name: string;
  location: string;
  rating: number;
  homeCollection: boolean;
}

const mockLabs: Lab[] = [
  { id: "1", name: "HealthFirst Diagnostics", location: "Dubai Marina", rating: 4.8, homeCollection: true },
  { id: "2", name: "MedLab Plus", location: "Downtown Dubai", rating: 4.7, homeCollection: true },
  { id: "3", name: "Al Borg Laboratories", location: "Deira", rating: 4.6, homeCollection: false },
  { id: "4", name: "Prime Diagnostics", location: "JLT", rating: 4.9, homeCollection: true },
];

const timeSlots = [
  "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", 
  "12:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
];

export default function BookTestPage() {
  const params = useParams();
  const bundleId = params.id;
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [bundle, setBundle] = useState<Bundle | null>(null);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState(1);
  
  // Form state - home collection is always default (FREE)
  const [collectionType] = useState<"lab" | "home">("home");
  const [selectedLab, setSelectedLab] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [patientName, setPatientName] = useState("");
  const [patientPhone, setPatientPhone] = useState("");
  const [patientEmail, setPatientEmail] = useState("");
  const [address, setAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [bookingRef, setBookingRef] = useState("");

  useEffect(() => {
    fetchBundle();
  }, [bundleId]);

  const fetchBundle = async () => {
    try {
      const response = await fetch(`/api/bundles`);
      const bundles = await response.json();
      const found = bundles.find((b: Bundle) => b.id === bundleId);
      if (found) {
        setBundle(found);
      }
    } catch (error) {
      console.error("Failed to fetch bundle:", error);
    } finally {
      setLoading(false);
    }
  };

  // Generate next 14 days for date selection
  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push({
        value: date.toISOString().split('T')[0],
        label: date.toLocaleDateString('en-AE', { weekday: 'short', month: 'short', day: 'numeric' })
      });
    }
    return dates;
  };

  const handleSubmit = async () => {
    if (!patientName || !patientPhone || !patientEmail || !selectedDate || !selectedTime) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    if (!selectedLab) {
      toast({
        title: "Select a Lab",
        description: "Please select a lab partner",
        variant: "destructive"
      });
      return;
    }

    // Address is always required for home/office collection
    if (!address) {
      toast({
        title: "Address Required",
        description: "Please enter your collection address (home/office)",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);
    
    try {
      // Create booking via API
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bundleId,
          labId: selectedLab,
          collectionType,
          date: selectedDate,
          time: selectedTime,
          patientName,
          patientPhone,
          patientEmail,
          address: collectionType === 'home' ? address : null
        })
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setBookingRef(data.booking.id);
        setBookingComplete(true);
        
        toast({
          title: "Booking Confirmed! ✅",
          description: `Your booking reference is ${data.booking.id}`,
        });
      } else {
        throw new Error(data.message || 'Booking failed');
      }
    } catch (error) {
      console.error("Booking error:", error);
      
      // Fallback to local booking reference
      const ref = `MC-${Date.now().toString(36).toUpperCase()}`;
      setBookingRef(ref);
      setBookingComplete(true);
      
      toast({
        title: "Booking Confirmed! ✅",
        description: `Your booking reference is ${ref}`,
      });
    } finally {
      setSubmitting(false);
    }
  };

  const availableLabs = collectionType === "home" 
    ? mockLabs.filter(lab => lab.homeCollection) 
    : mockLabs;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!bundle) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Bundle Not Found</h1>
          <p className="text-gray-600 mb-6">The test bundle you're looking for doesn't exist.</p>
          <Link href="/tests">
            <button className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">
              Browse Tests
            </button>
          </Link>
        </div>
      </div>
    );
  }

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
        <Navbar />
        <div className="container mx-auto px-4 py-12">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-lg mx-auto bg-white rounded-3xl shadow-xl p-8 text-center"
          >
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h1>
            <p className="text-gray-600 mb-6">Your test has been successfully booked</p>
            
            <div className="bg-gray-50 rounded-2xl p-6 mb-6 text-left">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-500">Booking Reference</span>
                  <span className="font-bold text-blue-600">{bookingRef}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Test</span>
                  <span className="font-medium">{bundle.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Date</span>
                  <span className="font-medium">{new Date(selectedDate).toLocaleDateString('en-AE', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Time</span>
                  <span className="font-medium">{selectedTime}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Collection</span>
                  <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded">FREE Home/Office</span>
                </div>
                <div className="flex justify-between border-t pt-3 mt-3">
                  <span className="text-gray-500">Total</span>
                  <span className="font-bold text-lg">AED {bundle.basePrice}</span>
                </div>
              </div>
            </div>
            
            <p className="text-sm text-gray-500 mb-6">
              A confirmation email has been sent to <strong>{patientEmail}</strong>
            </p>
            
            <div className="flex gap-3">
              <Link href="/" className="flex-1">
                <button className="w-full py-3 px-4 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 flex items-center justify-center gap-2">
                  <Home className="w-4 h-4" />
                  Home
                </button>
              </Link>
              <Link href="/tests" className="flex-1">
                <button className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 flex items-center justify-center gap-2">
                  <Beaker className="w-4 h-4" />
                  More Tests
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-blue-600 mb-6 transition-colors"
          data-testid="back-button"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Test Details</span>
        </button>

        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-2xl p-6 mb-6">
            <h1 className="text-2xl font-bold mb-2" data-testid="bundle-name">Book: {bundle.name}</h1>
            <p className="text-blue-100 text-sm mb-3">{bundle.description}</p>
            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold">AED {bundle.basePrice}</span>
              <span className="bg-white/20 px-3 py-1 rounded-full text-sm">{bundle.tests?.length || 0} Tests Included</span>
            </div>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                  step >= s ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  {s}
                </div>
                {s < 3 && (
                  <div className={`w-16 h-1 mx-2 rounded ${step > s ? 'bg-blue-600' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Collection Type & Lab Selection */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-lg p-6"
            >
              {/* FREE Home/Office Collection Banner */}
              <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Truck className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-gray-900 text-lg">FREE Home/Office Collection</span>
                      <span className="px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full">INCLUDED</span>
                    </div>
                    <p className="text-sm text-green-700 mt-1">Our certified technician will visit your location at your chosen time slot</p>
                  </div>
                </div>
              </div>

              <h2 className="text-xl font-bold text-gray-900 mb-4">Select Preferred Lab</h2>
              <p className="text-gray-600 mb-4 text-sm">Choose a lab partner - our technician from this lab will collect your sample</p>
              
              {/* Lab Selection */}
              <div className="space-y-3 mb-6">
                {mockLabs.filter(lab => lab.homeCollection).map((lab) => (
                  <button
                    key={lab.id}
                    onClick={() => setSelectedLab(lab.id)}
                    className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                      selectedLab === lab.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    data-testid={`lab-${lab.id}`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-gray-900">{lab.name}</h4>
                        <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3" />
                          {lab.location}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 text-amber-500">
                        <span className="text-sm font-medium">{lab.rating}</span>
                        <span>⭐</span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              <button
                onClick={() => selectedLab && setStep(2)}
                disabled={!selectedLab}
                className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                data-testid="next-step-1"
              >
                Select Appointment Time
              </button>
            </motion.div>
          )}

          {/* Step 2: Date & Time Selection */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-lg p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6">Select Date & Time</h2>
              
              {/* Date Selection */}
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Choose Date
              </h3>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-8">
                {getAvailableDates().map((date) => (
                  <button
                    key={date.value}
                    onClick={() => setSelectedDate(date.value)}
                    className={`p-3 rounded-xl text-center transition-all ${
                      selectedDate === date.value 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-100 hover:bg-blue-100 text-gray-700'
                    }`}
                    data-testid={`date-${date.value}`}
                  >
                    <span className="text-xs block">{date.label.split(' ')[0]}</span>
                    <span className="text-lg font-bold block">{date.label.split(' ')[2]}</span>
                    <span className="text-xs block">{date.label.split(' ')[1]}</span>
                  </button>
                ))}
              </div>

              {/* Time Selection */}
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                Choose Time
              </h3>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-8">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`py-3 px-4 rounded-xl transition-all ${
                      selectedTime === time 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-100 hover:bg-blue-100 text-gray-700'
                    }`}
                    data-testid={`time-${time.replace(/\s/g, '-')}`}
                  >
                    {time}
                  </button>
                ))}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-colors"
                  data-testid="back-step-2"
                >
                  Back
                </button>
                <button
                  onClick={() => selectedDate && selectedTime && setStep(3)}
                  disabled={!selectedDate || !selectedTime}
                  className="flex-1 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                  data-testid="next-step-2"
                >
                  Enter Patient Details
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Patient Details & Confirmation */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-lg p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6">Your Details</h2>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      placeholder="Enter your full name"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      data-testid="input-name"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(e.target.value)}
                      placeholder="+971 XX XXX XXXX"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      data-testid="input-phone"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      value={patientEmail}
                      onChange={(e) => setPatientEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      data-testid="input-email"
                    />
                  </div>
                </div>

                {/* Address - Always required for home/office collection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Collection Address * <span className="text-green-600 text-xs font-normal">(for FREE home/office collection)</span>
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <textarea
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Enter your full address (home/office) where our technician should visit"
                      rows={3}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      data-testid="input-address"
                    />
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <h3 className="font-bold text-gray-900 mb-3">Order Summary</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">{bundle.name}</span>
                    <span>AED {bundle.basePrice}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Home/Office Collection</span>
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded">FREE</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg pt-2 border-t">
                    <span>Total</span>
                    <span className="text-blue-600">AED {bundle.basePrice}</span>
                  </div>
                </div>
              </div>

              {/* Payment Info */}
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
                <div className="flex items-center gap-2 text-green-700 font-medium mb-2">
                  <Shield className="w-5 h-5" />
                  <span>Pay at Home/Office</span>
                </div>
                <p className="text-sm text-green-600">
                  No online payment required. Pay conveniently by cash or card when our technician visits you.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-colors"
                  data-testid="back-step-3"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex-1 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  data-testid="confirm-booking"
                >
                  {submitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Confirm Booking
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
