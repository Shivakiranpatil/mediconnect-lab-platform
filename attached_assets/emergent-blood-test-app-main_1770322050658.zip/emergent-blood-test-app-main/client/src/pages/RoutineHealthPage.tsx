import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Activity, CheckCircle, Clock, Shield, Users, Beaker, 
  ArrowRight, Star, Heart, Zap, FileText, Calendar, ArrowLeft
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const routinePackages = [
  {
    id: "1",
    name: "Full Body Checkup",
    description: "Our most comprehensive health screening with 40+ parameters covering all major organ systems",
    price: "699",
    originalPrice: "899",
    popular: true,
    testsIncluded: 42,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "WBC Count", "Platelet Count", "RBC Indices"] },
      { category: "Liver Function", tests: ["ALT", "AST", "Bilirubin", "Albumin", "ALP", "GGT"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN", "Uric Acid", "eGFR"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides", "VLDL"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate"] },
      { category: "Minerals", tests: ["Calcium", "Iron", "Ferritin"] },
    ],
    benefits: [
      "Complete health overview",
      "Early disease detection",
      "Baseline health records",
      "Doctor consultation included"
    ]
  },
  {
    id: "6",
    name: "Essential Health Check",
    description: "Basic health screening perfect for young adults and routine annual checkups",
    price: "199",
    originalPrice: "299",
    popular: false,
    testsIncluded: 18,
    turnaround: "24 hours",
    parameters: [
      { category: "Blood Count", tests: ["CBC", "Hemoglobin", "WBC Count"] },
      { category: "Liver Function", tests: ["ALT", "AST", "Bilirubin"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN"] },
      { category: "Diabetes", tests: ["Fasting Glucose"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
    ],
    benefits: [
      "Affordable screening",
      "Quick results",
      "Essential parameters",
      "Perfect for annual checkups"
    ]
  },
  {
    id: "8",
    name: "Senior Citizen Panel",
    description: "Specialized screening for adults 60+ covering age-specific health markers",
    price: "799",
    originalPrice: "999",
    popular: false,
    testsIncluded: 50,
    turnaround: "48 hours",
    parameters: [
      { category: "Blood Count", tests: ["CBC with ESR", "Peripheral Smear"] },
      { category: "Cardiac Markers", tests: ["Lipid Profile", "hs-CRP", "Homocysteine"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c", "Insulin"] },
      { category: "Bone Health", tests: ["Calcium", "Phosphorus", "Vitamin D", "ALP"] },
      { category: "Kidney Function", tests: ["Complete Kidney Panel", "Microalbumin"] },
      { category: "Liver Function", tests: ["Complete Liver Panel"] },
      { category: "Thyroid", tests: ["Complete Thyroid Panel"] },
      { category: "Prostate/Hormones", tests: ["PSA (Men)", "Estrogen (Women)"] },
    ],
    benefits: [
      "Age-specific markers",
      "Bone health assessment",
      "Cardiac risk evaluation",
      "Comprehensive report"
    ]
  }
];

const individualTests = [
  { name: "Complete Blood Count (CBC)", price: "49", description: "Evaluates overall health and detects disorders" },
  { name: "Liver Function Test", price: "129", description: "Assesses liver health and function" },
  { name: "Kidney Function Test", price: "99", description: "Evaluates kidney health" },
  { name: "Fasting Blood Sugar", price: "29", description: "Measures blood glucose levels" },
  { name: "HbA1c", price: "79", description: "3-month average blood sugar" },
  { name: "Vitamin D", price: "99", description: "Essential for bone health" },
  { name: "Vitamin B12", price: "89", description: "Important for nerve function" },
  { name: "Thyroid Profile", price: "149", description: "TSH, T3, T4 levels" },
  { name: "Iron Studies", price: "119", description: "Detects iron deficiency" },
  { name: "Urine Routine", price: "39", description: "Urinary tract assessment" },
];

export default function RoutineHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("1");

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6" />
              </div>
              <span className="text-blue-200 font-medium">Health Screening</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Routine Health Checkup
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Comprehensive health screening packages to monitor your overall wellness and detect potential health issues early.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>40+ Parameters</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-400" />
                <span>Results in 24-48 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-blue-300" />
                <span>NABL Certified Labs</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Health Checkup Packages</h2>
          
          <div className="grid lg:grid-cols-3 gap-6">
            {routinePackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-blue-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-blue-500 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-blue-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="space-y-2 mb-6">
                    {pkg.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>

                  {/* Parameters Preview */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="w-full text-left text-sm text-blue-600 font-medium mb-4 flex items-center justify-between"
                  >
                    <span>View all parameters</span>
                    <ArrowRight className={`w-4 h-4 transition-transform ${expandedPackage === pkg.id ? 'rotate-90' : ''}`} />
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-xs font-semibold text-gray-500 uppercase mb-1">{param.category}</h5>
                          <div className="flex flex-wrap gap-1">
                            {param.tests.map((test, j) => (
                              <span key={j} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                {test}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/bundles/${pkg.id}`)}
                      className="flex-1 py-3 border-2 border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors"
                    >
                      Details
                    </button>
                    <button
                      onClick={() => navigate(`/book/${pkg.id}`)}
                      className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                      data-testid={`book-${pkg.id}`}
                    >
                      <Calendar className="w-4 h-4" />
                      Book Now
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all border border-gray-100"
              >
                <h4 className="font-semibold text-gray-900 text-sm mb-1">{test.name}</h4>
                <p className="text-xs text-gray-500 mb-3">{test.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-600">AED {test.price}</span>
                  <Link href="/ai-discovery">
                    <button className="text-xs text-blue-600 hover:underline">Ask AI →</button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Why Regular Health Checkups Matter</h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: "Early Detection", desc: "Identify health issues before they become serious" },
              { icon: FileText, title: "Track Progress", desc: "Monitor your health trends over time" },
              { icon: Heart, title: "Peace of Mind", desc: "Know your health status with confidence" },
              { icon: Users, title: "Expert Guidance", desc: "Get personalized health recommendations" },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Not sure which package to choose?</h2>
          <p className="text-blue-100 mb-6">Let our AI assistant help you find the right tests based on your health profile</p>
          <Link href="/ai-discovery">
            <button className="px-8 py-4 bg-white text-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-colors shadow-lg">
              Talk to AI Assistant
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}
