import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Edit, Search, User, Shield, Building2, Mail, Phone, MapPin, RefreshCw, CheckCircle, XCircle, Trash2 } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SupabaseUser {
  id: string;
  email: string;
  name?: string;
  phone?: string;
  role?: string;
  is_active?: boolean;
  firebase_uid?: string;
  created_at?: string;
  address?: string;
  city?: string;
  area?: string;
}

export default function AdminUsersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [editingUser, setEditingUser] = useState<SupabaseUser | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  // Fetch users from Supabase
  const { data: users = [], isLoading, refetch } = useQuery<SupabaseUser[]>({
    queryKey: ['/api/supabase/users'],
    queryFn: async () => {
      const res = await fetch('/api/supabase/users');
      if (!res.ok) throw new Error('Failed to fetch users');
      return res.json();
    },
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
    toast({ title: "Refreshed", description: "User list updated" });
  };

  const saveUserMutation = useMutation({
    mutationFn: async (user: Partial<SupabaseUser>) => {
      if (user.id) {
        // Update existing user
        const res = await fetch(`/api/supabase/users/${user.id}/address`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(user),
        });
        if (!res.ok) throw new Error('Failed to update user');
        return res.json();
      } else {
        // Create new user
        const res = await fetch('/api/supabase/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(user),
        });
        if (!res.ok) throw new Error('Failed to create user');
        return res.json();
      }
    },
    onSuccess: () => {
      refetch();
      setEditingUser(null);
      setIsCreating(false);
      toast({ title: "Success", description: "User saved successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const filteredUsers = users.filter(user => {
    const matchesSearch = !searchTerm || 
      user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const getRoleBadge = (role: string | undefined | null) => {
    const styles: Record<string, { bg: string; icon: React.ReactNode }> = {
      admin: { bg: 'bg-red-500/20 text-red-400', icon: <Shield className="w-3 h-3 mr-1" /> },
      lab_admin: { bg: 'bg-purple-500/20 text-purple-400', icon: <Building2 className="w-3 h-3 mr-1" /> },
      user: { bg: 'bg-blue-500/20 text-blue-400', icon: <User className="w-3 h-3 mr-1" /> },
    };
    const style = styles[role || 'user'] || styles.user;
    return (
      <Badge className={`${style.bg} flex items-center`}>
        {style.icon}
        {role === 'lab_admin' ? 'Lab Admin' : role || 'user'}
      </Badge>
    );
  };

  const getStatusBadge = (isActive: boolean | undefined) => {
    if (isActive === false) {
      return (
        <Badge className="bg-red-500/20 text-red-400 flex items-center gap-1">
          <XCircle className="w-3 h-3" />
          Inactive
        </Badge>
      );
    }
    return (
      <Badge className="bg-green-500/20 text-green-400 flex items-center gap-1">
        <CheckCircle className="w-3 h-3" />
        Active
      </Badge>
    );
  };

  return (
    <AdminLayout title="Users" subtitle="Manage platform users (synced from Firebase Auth)">
      <div className="space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-sm text-slate-400">Total Users</p>
            <p className="text-2xl font-bold text-white">{users.length}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-sm text-slate-400">Regular Users</p>
            <p className="text-2xl font-bold text-blue-400">{users.filter(u => u.role === 'user' || !u.role).length}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-sm text-slate-400">Admins</p>
            <p className="text-2xl font-bold text-red-400">{users.filter(u => u.role === 'admin').length}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-sm text-slate-400">Lab Admins</p>
            <p className="text-2xl font-bold text-purple-400">{users.filter(u => u.role === 'lab_admin').length}</p>
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-800 border-slate-700 text-white"
                data-testid="input-search-users"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-40 bg-slate-800 border-slate-700 text-white" data-testid="select-role-filter">
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="lab_admin">Lab Admin</SelectItem>
                <SelectItem value="user">User</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button onClick={() => setIsCreating(true)} className="bg-blue-600 hover:bg-blue-700" data-testid="button-add-user">
              <Plus className="w-4 h-4 mr-2" />
              Add User
            </Button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
          <p className="text-sm text-blue-300">
            <strong>Note:</strong> Users are automatically synced when they sign in with Google or register via Firebase Auth. 
            You can update their role and profile information here.
          </p>
        </div>

        {/* Users Table */}
        <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto" />
              <p className="text-slate-400 mt-4">Loading users...</p>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="p-12 text-center">
              <User className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">No users found</p>
            </div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="bg-slate-700/30">
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">User</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Contact</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Role</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Status</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Joined</th>
                  <th className="text-right text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-700/20" data-testid={`row-user-${user.id}`}>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center text-white font-bold">
                          {user.name?.charAt(0) || user.email.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-white">{user.name || 'No Name'}</p>
                          <p className="text-xs text-slate-500">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        {user.phone && (
                          <p className="text-sm text-slate-400 flex items-center gap-1">
                            <Phone className="w-3 h-3" /> {user.phone}
                          </p>
                        )}
                        {user.city && (
                          <p className="text-sm text-slate-400 flex items-center gap-1">
                            <MapPin className="w-3 h-3" /> {user.city}
                          </p>
                        )}
                        {!user.phone && !user.city && (
                          <p className="text-sm text-slate-500">-</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">{getRoleBadge(user.role)}</td>
                    <td className="px-6 py-4">{getStatusBadge(user.is_active)}</td>
                    <td className="px-6 py-4 text-sm text-slate-400">
                      {user.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="text-slate-400 hover:text-white" 
                        onClick={() => setEditingUser(user)} 
                        data-testid={`button-edit-user-${user.id}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Edit/Create User Modal */}
      <Dialog open={!!editingUser || isCreating} onOpenChange={() => { setEditingUser(null); setIsCreating(false); }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingUser ? 'Edit User' : 'Create User'}</DialogTitle>
          </DialogHeader>
          <UserForm 
            user={editingUser} 
            onSave={(data) => saveUserMutation.mutate(data)}
            isPending={saveUserMutation.isPending}
            isEditing={!!editingUser}
          />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function UserForm({ user, onSave, isPending, isEditing }: { 
  user: SupabaseUser | null; 
  onSave: (data: Partial<SupabaseUser>) => void; 
  isPending: boolean; 
  isEditing: boolean;
}) {
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    role: user?.role || 'user',
    is_active: user?.is_active !== false,
    city: user?.city || '',
    area: user?.area || '',
    address: user?.address || '',
  });

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        role: user.role || 'user',
        is_active: user.is_active !== false,
        city: user.city || '',
        area: user.area || '',
        address: user.address || '',
      });
    }
  }, [user]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-slate-300">Full Name</Label>
          <Input 
            value={formData.name} 
            onChange={(e) => setFormData({ ...formData, name: e.target.value })} 
            className="bg-slate-700 border-slate-600 mt-1" 
            data-testid="input-user-name" 
          />
        </div>
        <div>
          <Label className="text-slate-300">Email</Label>
          <Input 
            value={formData.email} 
            onChange={(e) => setFormData({ ...formData, email: e.target.value })} 
            className="bg-slate-700 border-slate-600 mt-1" 
            disabled={isEditing}
            data-testid="input-user-email" 
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-slate-300">Phone</Label>
          <Input 
            value={formData.phone} 
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })} 
            placeholder="+971 XX XXX XXXX"
            className="bg-slate-700 border-slate-600 mt-1" 
            data-testid="input-user-phone" 
          />
        </div>
        <div>
          <Label className="text-slate-300">Role</Label>
          <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v })}>
            <SelectTrigger className="bg-slate-700 border-slate-600 mt-1" data-testid="select-user-role">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="lab_admin">Lab Admin</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-slate-300">City</Label>
          <Input 
            value={formData.city} 
            onChange={(e) => setFormData({ ...formData, city: e.target.value })} 
            placeholder="Dubai"
            className="bg-slate-700 border-slate-600 mt-1" 
            data-testid="input-user-city" 
          />
        </div>
        <div>
          <Label className="text-slate-300">Area</Label>
          <Input 
            value={formData.area} 
            onChange={(e) => setFormData({ ...formData, area: e.target.value })} 
            placeholder="Dubai Marina"
            className="bg-slate-700 border-slate-600 mt-1" 
            data-testid="input-user-area" 
          />
        </div>
      </div>

      <div>
        <Label className="text-slate-300">Address</Label>
        <Input 
          value={formData.address} 
          onChange={(e) => setFormData({ ...formData, address: e.target.value })} 
          placeholder="Full address"
          className="bg-slate-700 border-slate-600 mt-1" 
          data-testid="input-user-address" 
        />
      </div>

      <label className="flex items-center gap-2 cursor-pointer">
        <input
          type="checkbox"
          checked={formData.is_active}
          onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
          className="w-4 h-4 text-blue-600 rounded"
        />
        <span className="text-sm text-slate-300">Account is active</span>
      </label>

      <DialogFooter className="pt-4">
        <Button 
          onClick={() => onSave({ ...user, ...formData })} 
          disabled={isPending} 
          className="bg-blue-600 hover:bg-blue-700" 
          data-testid="button-save-user"
        >
          {isPending ? 'Saving...' : 'Save User'}
        </Button>
      </DialogFooter>
    </div>
  );
}
