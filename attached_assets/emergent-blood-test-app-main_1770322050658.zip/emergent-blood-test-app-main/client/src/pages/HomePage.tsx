import { Link, useLocation } from "wouter";
import { 
  Search, Sparkles, ArrowRight, Mic, Bot, Home as HomeIcon, 
  TrendingUp, MessageCircle, FileSearch, Calendar, Activity,
  Heart, Zap, Facebook, Twitter, Instagram, Linkedin,
  Mail, Phone, MapPin, Send, Loader2, ClipboardCheck, Beaker,
  Clock, Shield, Star, Users, CheckCircle, BadgeCheck
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { QuickAssessmentModal } from "@/components/QuickAssessmentModal";

import fullBodyImg from "@assets/stock_images/professional_medical_5f834d8f.jpg";
import womenWellnessImg from "@assets/stock_images/middle_eastern_woman_c8937e09.jpg";
import heartHealthImg from "@assets/stock_images/heart_health_cardiov_fa509467.jpg";

export default function HomePage() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [showAssessment, setShowAssessment] = useState(false);
  const { toast } = useToast();

  const handleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast({ title: "Not Supported", description: "Voice input is not supported in your browser.", variant: "destructive" });
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      setSearchQuery(event.results[0][0].transcript);
      setIsListening(false);
    };
    recognition.onerror = () => {
      setIsListening(false);
      toast({ title: "Error", description: "Could not capture voice.", variant: "destructive" });
    };
    recognition.onend = () => setIsListening(false);
    recognition.start();
  };

  // Handle quick search - navigate to tests page with pre-filled search
  const handleQuickSearch = (searchTerm: string) => {
    navigate(`/tests?search=${encodeURIComponent(searchTerm)}`);
  };

  // Handle main search
  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/tests?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const quickSearches = [
    { name: 'HbA1c', color: 'bg-orange-100 text-orange-700 hover:bg-orange-200' },
    { name: 'Cholesterol', color: 'bg-red-100 text-red-700 hover:bg-red-200' },
    { name: 'Vitamin D', color: 'bg-amber-100 text-amber-700 hover:bg-amber-200' },
    { name: 'Full Body', color: 'bg-blue-100 text-blue-700 hover:bg-blue-200' },
    { name: 'Iron', color: 'bg-rose-100 text-rose-700 hover:bg-rose-200' },
    { name: 'Thyroid', color: 'bg-purple-100 text-purple-700 hover:bg-purple-200' },
    { name: 'Liver', color: 'bg-green-100 text-green-700 hover:bg-green-200' },
    { name: 'Kidney', color: 'bg-cyan-100 text-cyan-700 hover:bg-cyan-200' },
  ];

  const features = [
    {
      icon: Shield,
      title: 'Certified Labs Only',
      description: 'All partner labs are NABL/CAP certified with quality assurance standards.',
      bgColor: 'bg-gradient-to-br from-blue-50 to-blue-100',
      iconBg: 'bg-blue-500',
      image: fullBodyImg,
    },
    {
      icon: HomeIcon,
      title: 'Home or Lab Visit',
      description: 'Book home sample collection at your convenience or visit any of our 50+ partner labs.',
      bgColor: 'bg-gradient-to-br from-green-50 to-green-100',
      iconBg: 'bg-green-500',
      image: womenWellnessImg,
    },
    {
      icon: TrendingUp,
      title: 'Transparent Pricing',
      description: 'Compare prices across labs with no hidden fees. Save up to 50% on tests.',
      bgColor: 'bg-gradient-to-br from-pink-50 to-pink-100',
      iconBg: 'bg-pink-500',
      image: heartHealthImg,
    },
  ];

  const steps = [
    {
      step: '01',
      icon: Search,
      title: 'Search or Browse Tests',
      description: 'Find tests by name or browse health categories. Use our Test Finder if you need help.',
      gradient: 'from-blue-400 to-blue-600',
    },
    {
      step: '02',
      icon: FileSearch,
      title: 'Compare & Choose',
      description: 'Compare prices across certified labs. Select home collection or lab visit.',
      gradient: 'from-purple-400 to-purple-600',
    },
    {
      step: '03',
      icon: Calendar,
      title: 'Book & Get Results',
      description: 'Book your appointment and receive digital reports within 24-48 hours.',
      gradient: 'from-pink-400 to-pink-600',
    },
  ];

  const popularBundles = [
    {
      id: '1',
      title: 'Full Body Checkup',
      subtitle: '40+ Parameters',
      description: 'Complete health screening with liver, kidney, thyroid, diabetes & more',
      price: '699',
      originalPrice: '899',
      tests: 42,
      turnaround: '24-48 hrs',
      icon: Activity,
      gradient: 'from-blue-500 to-blue-700',
      popular: true,
      image: fullBodyImg,
    },
    {
      id: '2',
      title: "Women's Wellness",
      subtitle: 'Hormone Panel',
      description: 'FSH, LH, Estrogen, Thyroid, Iron & Vitamin tests for women',
      price: '599',
      originalPrice: '799',
      tests: 35,
      turnaround: '24-48 hrs',
      icon: Heart,
      gradient: 'from-pink-500 to-pink-700',
      popular: true,
      image: womenWellnessImg,
    },
    {
      id: '3',
      title: 'Heart Health Panel',
      subtitle: 'Cardiac Risk Assessment',
      description: 'Lipid Profile, hs-CRP, Homocysteine & cardiac markers',
      price: '299',
      originalPrice: '399',
      tests: 15,
      turnaround: '24 hrs',
      icon: Zap,
      gradient: 'from-red-500 to-red-700',
      popular: false,
      image: heartHealthImg,
    },
    {
      id: '5',
      title: 'Diabetes Panel',
      subtitle: 'Blood Sugar Monitoring',
      description: 'HbA1c, Fasting Glucose, Post-Prandial & kidney markers',
      price: '249',
      originalPrice: '349',
      tests: 12,
      turnaround: '24 hrs',
      icon: Activity,
      gradient: 'from-orange-500 to-orange-700',
      popular: false,
      image: fullBodyImg,
    },
  ];

  // Popular individual tests with prices
  const popularTests = [
    {
      id: 'hba1c',
      name: 'HbA1c (Diabetes)',
      originalPrice: '149',
      price: '79',
      savings: '47%',
      nextSlot: 'Today, 2:00 PM',
      turnaround: '24 hrs',
    },
    {
      id: 'thyroid',
      name: 'Thyroid Profile (TSH, T3, T4)',
      originalPrice: '249',
      price: '149',
      savings: '40%',
      nextSlot: 'Today, 3:30 PM',
      turnaround: '24 hrs',
    },
    {
      id: 'vitd',
      name: 'Vitamin D (25-OH)',
      originalPrice: '199',
      price: '99',
      savings: '50%',
      nextSlot: 'Tomorrow, 9:00 AM',
      turnaround: '24 hrs',
    },
    {
      id: 'lipid',
      name: 'Lipid Profile (Cholesterol)',
      originalPrice: '149',
      price: '89',
      savings: '40%',
      nextSlot: 'Today, 4:00 PM',
      turnaround: '24 hrs',
    },
  ];

  // Customer reviews
  const customerReviews = [
    {
      name: 'Sarah M.',
      location: 'Dubai Marina',
      rating: 5,
      text: 'Booked a full body checkup for my parents. Home collection was on time, and reports came within 24 hours. Great prices compared to going directly to labs!',
      date: '2 days ago',
      verified: true,
    },
    {
      name: 'Ahmed K.',
      location: 'Business Bay',
      rating: 5,
      text: 'The Test Finder helped me figure out which tests I needed for my fatigue. Saved me a lot of time and money. Highly recommend!',
      date: '1 week ago',
      verified: true,
    },
    {
      name: 'Priya S.',
      location: 'JLT',
      rating: 5,
      text: 'Very transparent pricing - no hidden fees. I compared prices with 3 labs before booking. MediConnect had the best deal for my thyroid panel.',
      date: '3 days ago',
      verified: true,
    },
  ];

  const partners = [
    { name: 'MEDICLINIC', logo: '🏥', locations: '15+ locations' },
    { name: 'NMC Healthcare', logo: '🏨', locations: '20+ locations' },
    { name: 'Al Borg Diagnostics', logo: '🔬', locations: '25+ locations' },
    { name: 'Prime Healthcare', logo: '💊', locations: '10+ locations' },
    { name: 'ASTER Labs', logo: '🩺', locations: '30+ locations' },
    { name: 'Thumbay Labs', logo: '⚕️', locations: '12+ locations' },
  ];

  const stats = [
    { value: '50+', label: 'Partner Labs' },
    { value: '100K+', label: 'Tests Booked' },
    { value: '4.9★', label: 'User Rating' },
    { value: '24–48hrs', label: 'Report Delivery' },
  ];

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, color: 'hover:bg-blue-600' },
    { name: 'Twitter', icon: Twitter, color: 'hover:bg-sky-500' },
    { name: 'Instagram', icon: Instagram, color: 'hover:bg-pink-600' },
    { name: 'LinkedIn', icon: Linkedin, color: 'hover:bg-blue-700' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-blue-50 relative overflow-hidden pb-16 sm:pb-0" data-testid="home-page">
      {/* Background decorative waves */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <svg className="absolute top-0 left-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 0.1 }} />
              <stop offset="100%" style={{ stopColor: '#8b5cf6', stopOpacity: 0.1 }} />
            </linearGradient>
          </defs>
          <path d="M0,100 Q250,50 500,100 T1000,100 L1000,0 L0,0 Z" fill="url(#grad1)" />
          <path d="M0,200 Q300,150 600,200 T1200,200 L1200,0 L0,0 Z" fill="url(#grad1)" opacity="0.5" />
        </svg>
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-blue-100/30 to-transparent" />
      </div>

      <div className="relative z-10">
        <Navbar />

        {/* Hero Section */}
        <section className="text-center px-4 sm:px-6 pt-8 sm:pt-12 pb-8 sm:pb-12" data-testid="hero-section">
          <div className="max-w-5xl mx-auto">
            {/* Trust Badge */}
            <div className="flex justify-center mb-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-200 rounded-full text-sm">
                <BadgeCheck className="w-4 h-4 text-green-600" />
                <span className="text-green-700 font-medium">Trusted by 100,000+ users in Dubai</span>
              </div>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-3 sm:mb-4 leading-tight" data-testid="hero-title">
              Book Lab Tests from <br />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Trusted Labs Near You
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-gray-600 mb-6 max-w-2xl mx-auto" data-testid="hero-subtitle">
              Compare prices, choose certified diagnostic labs, and book home sample collection or lab visits in minutes.
            </p>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-6" data-testid="trust-indicators">
              <div className="flex items-center gap-2 text-gray-700">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Shield className="w-4 h-4 text-green-600" />
                </div>
                <span className="text-sm font-medium">Certified Labs</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <BadgeCheck className="w-4 h-4 text-blue-600" />
                </div>
                <span className="text-sm font-medium">Transparent Pricing</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <HomeIcon className="w-4 h-4 text-purple-600" />
                </div>
                <span className="text-sm font-medium">Home Collection Available</span>
              </div>
            </div>

            {/* Main Search Bar */}
            <div className="max-w-3xl mx-auto mb-4" data-testid="search-container">
              <div className="relative bg-white rounded-2xl shadow-xl border border-gray-200 hover:border-blue-400 hover:shadow-2xl transition-all duration-300 group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                <input
                  type="text"
                  placeholder="Search tests (CBC, Thyroid, HbA1c, Vitamin D…)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full pl-12 pr-36 py-4 text-base rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-transparent"
                  data-testid="input-search"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <button
                    onClick={handleVoiceInput}
                    className={`p-2.5 ${
                      isListening 
                        ? 'bg-red-500 animate-pulse' 
                        : 'bg-gray-100 hover:bg-gray-200'
                    } rounded-xl transition-all duration-300`}
                    data-testid="button-voice"
                    title="Voice search"
                  >
                    <Mic className={`w-4 h-4 ${isListening ? 'text-white' : 'text-gray-600'}`} />
                  </button>
                  <button
                    onClick={handleSearch}
                    className="px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-300 font-semibold flex items-center gap-2"
                    data-testid="button-search"
                  >
                    <Search className="w-4 h-4" />
                    Search Tests
                  </button>
                </div>
              </div>
            </div>

            {/* Secondary microcopy */}
            <p className="text-sm text-gray-500 text-center mb-4">
              Not sure which test to book? <Link href="/ai-discovery" className="text-blue-600 hover:underline font-medium">Get help with our Test Finder</Link>
            </p>

            {/* Quick Search Tags */}
            <div className="max-w-3xl mx-auto mb-8" data-testid="quick-searches">
              <div className="flex flex-wrap justify-center gap-2">
                <span className="text-sm text-gray-500 mr-2">Popular Tests:</span>
                {quickSearches.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickSearch(item.name)}
                    className={`px-3 py-1.5 ${item.color} rounded-full text-sm font-medium transition-all duration-200 hover:scale-105`}
                    data-testid={`quick-search-${item.name.toLowerCase()}`}
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Test Finder Button */}
            <div className="max-w-3xl mx-auto mb-10">
              <Link href="/ai-discovery">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3 mx-auto"
                  data-testid="ai-assistant-button"
                >
                  <Sparkles className="w-5 h-5" />
                  <span>Need Help? Try Our Test Finder</span>
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </Link>
            </div>

            {/* Stats Bar */}
            <div className="max-w-3xl mx-auto mb-10">
              <div className="grid grid-cols-4 gap-4 bg-white rounded-2xl shadow-lg p-4 border border-gray-100">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-blue-600">{stat.value}</div>
                    <div className="text-xs sm:text-sm text-gray-500">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Popular Tests & Prices Section */}
        <section className="px-4 sm:px-6 py-10 bg-white" data-testid="popular-tests-section">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Popular Tests & Prices</h2>
                <p className="text-gray-600">Best deals on frequently booked tests</p>
              </div>
              <Link href="/tests">
                <button className="hidden sm:flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium">
                  View All <ArrowRight className="w-4 h-4" />
                </button>
              </Link>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {popularTests.map((test, index) => (
                <motion.div
                  key={test.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl border-2 border-gray-100 hover:border-blue-200 p-5 hover:shadow-lg transition-all"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-bold text-gray-900 text-sm leading-tight">{test.name}</h3>
                    <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded-full">
                      Save {test.savings}
                    </span>
                  </div>
                  
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-2xl font-bold text-blue-600">AED {test.price}</span>
                    <span className="text-sm text-gray-400 line-through">AED {test.originalPrice}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Results in {test.turnaround}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-green-600 mb-4 bg-green-50 px-2 py-1.5 rounded-lg">
                    <Calendar className="w-3.5 h-3.5" />
                    <span className="font-medium">Next: {test.nextSlot}</span>
                  </div>
                  
                  <Link href={`/book/${test.id}`}>
                    <button className="w-full py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all text-sm">
                      Book Now
                    </button>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Health Categories Section */}
        <section className="px-4 sm:px-6 py-8 bg-gray-50" data-testid="categories-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Browse by Health Category</h2>
              <p className="text-gray-600">Find tests for your specific health needs</p>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
              <Link href="/routine-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-routine"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">💊</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Routine Health</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">42 tests • from AED 29</p>
                </motion.div>
              </Link>
              
              <Link href="/heart-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-heart"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">❤️</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Heart Health</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">18 tests • from AED 89</p>
                </motion.div>
              </Link>
              
              <Link href="/diabetes-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-diabetes"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">🩸</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Diabetes Care</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">12 tests • from AED 29</p>
                </motion.div>
              </Link>
              
              <Link href="/thyroid-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-thyroid"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">🦋</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Thyroid Health</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">10 tests • from AED 59</p>
                </motion.div>
              </Link>
              
              <Link href="/womens-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-women"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-pink-400 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">👩</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Women's Health</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">25 tests • from AED 79</p>
                </motion.div>
              </Link>

              <Link href="/mens-health">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-men"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-slate-500 to-slate-700 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">👨</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Men's Health</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">20 tests • from AED 99</p>
                </motion.div>
              </Link>

              <Link href="/energy-fatigue">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-energy"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">⚡</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">Energy & Fatigue</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">15 tests • from AED 49</p>
                </motion.div>
              </Link>

              <Link href="/tests">
                <motion.div
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="bg-white rounded-2xl p-4 sm:p-6 cursor-pointer shadow-md hover:shadow-xl transition-all border border-gray-100 text-center group"
                  data-testid="category-all"
                >
                  <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-green-400 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">🔬</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">All Tests</h3>
                  <p className="text-xs text-green-600 font-medium mt-1">100+ tests • from AED 29</p>
                </motion.div>
              </Link>
            </div>
          </div>
        </section>

        {/* Why Book Through Us Section */}
        <section className="px-4 sm:px-6 py-12 bg-white" data-testid="why-book-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Why Book Through Us?</h2>
              <p className="text-gray-600">Experience healthcare booking the easy way</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 text-center border border-blue-100 hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Search className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Easy Test Search</h3>
                <p className="text-gray-600 text-sm">Find and compare tests quickly. Use our Test Finder if you need help choosing the right test.</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 text-center border border-green-100 hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <HomeIcon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Home or Lab Visit</h3>
                <p className="text-gray-600 text-sm">Book home sample collection at your convenience or visit any of our 50+ certified partner labs.</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 text-center border border-amber-100 hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Best Price Guarantee</h3>
                <p className="text-gray-600 text-sm">Compare prices across labs and save up to 50%. Transparent pricing with no hidden fees.</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Test Finder Section */}
        <section className="px-4 sm:px-6 py-12 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900" data-testid="ai-discovery-section">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              {/* Left Content */}
              <div className="text-white">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/20 border border-blue-400/30 rounded-full text-sm mb-6">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                  <span className="text-blue-300 font-medium">Optional Help</span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                  Not Sure Which Test to Book?
                </h2>
                <p className="text-gray-300 text-lg mb-6">
                  Use our Test Finder to get suggestions based on your symptoms. This is not a diagnosis — always consult a doctor for medical advice.
                </p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">Select Your Symptoms</h4>
                      <p className="text-gray-400 text-sm">Choose from common symptoms to get relevant test suggestions</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">Get Test Suggestions</h4>
                      <p className="text-gray-400 text-sm">See which tests may be relevant based on your input</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">Book with Ease</h4>
                      <p className="text-gray-400 text-sm">Compare prices and book your chosen test in minutes</p>
                    </div>
                  </div>
                </div>

                <Link href="/ai-discovery">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-3"
                  >
                    <Search className="w-5 h-5" />
                    <span>Try Test Finder</span>
                    <ArrowRight className="w-5 h-5" />
                  </motion.button>
                </Link>
              </div>

              {/* Right - Symptom Selection Form Preview */}
              <div className="relative">
                <div className="bg-white rounded-3xl shadow-2xl p-6 max-w-md mx-auto">
                  {/* Select Symptoms */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Select your symptoms:</h4>
                    <div className="flex flex-wrap gap-2">
                      {['Fever', 'Cold', 'Cough', 'Sore throat', 'Headache', 'Fatigue', 'Stomach pain', 'Body aches'].map((symptom, i) => (
                        <button
                          key={symptom}
                          className={`px-3 py-1.5 rounded-full text-sm border transition-all ${
                            i === 0 || i === 5 
                              ? 'bg-blue-100 border-blue-400 text-blue-700' 
                              : 'bg-white border-gray-200 text-gray-600 hover:border-blue-300'
                          }`}
                        >
                          {symptom}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dropdowns */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <div>
                      <label className="text-sm text-gray-600 mb-1 block">Age group (optional):</label>
                      <div className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-500 bg-gray-50 flex items-center justify-between">
                        <span>Select age group</span>
                        <ArrowRight className="w-4 h-4 rotate-90" />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm text-gray-600 mb-1 block">Symptom duration:</label>
                      <div className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-500 bg-gray-50 flex items-center justify-between">
                        <span>Select duration</span>
                        <ArrowRight className="w-4 h-4 rotate-90" />
                      </div>
                    </div>
                  </div>

                  {/* Urgent Symptoms */}
                  <div className="bg-red-50 border border-red-100 rounded-xl p-4 mb-6">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-5 h-5 bg-amber-400 rounded flex items-center justify-center">
                        <span className="text-xs font-bold text-amber-900">!</span>
                      </div>
                      <span className="text-sm font-medium text-gray-700">Do you have any urgent symptoms?</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {['Chest pain', 'Severe shortness of breath', 'Confusion/fainting'].map((symptom) => (
                        <button
                          key={symptom}
                          className="px-3 py-1.5 rounded-full text-xs border border-red-300 text-red-600 bg-white hover:bg-red-50 transition-all"
                        >
                          {symptom}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* CTA Button */}
                  <button className="w-full py-3 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-xl font-semibold hover:from-teal-600 hover:to-emerald-600 transition-all shadow-md">
                    Get Test Suggestions
                  </button>
                </div>
                
                {/* Decorative elements */}
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl"></div>
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-purple-500/20 rounded-full blur-2xl"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Assessment Section */}
        <section className="px-4 sm:px-6 py-10" data-testid="assessment-section">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
              
              <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-2xl sm:text-3xl font-bold mb-3">Not Sure Which Test to Take?</h2>
                  <p className="text-white/90 mb-4">
                    Answer 3 quick questions about your health concerns. Get test suggestions based on your symptoms — takes only 30 seconds!
                  </p>
                  <p className="text-white/70 text-sm mb-4">
                    Note: This is not a medical diagnosis. Always consult a doctor for medical advice.
                  </p>
                  <div className="flex flex-wrap gap-3 justify-center md:justify-start text-sm">
                    <span className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full">
                      <CheckCircle className="w-4 h-4" /> 30 seconds
                    </span>
                    <span className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full">
                      <CheckCircle className="w-4 h-4" /> Simple questions
                    </span>
                    <span className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full">
                      <CheckCircle className="w-4 h-4" /> Free
                    </span>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowAssessment(true)}
                  className="px-8 py-4 bg-white text-purple-600 rounded-2xl font-bold shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center gap-3 whitespace-nowrap"
                  data-testid="quick-assessment-button"
                >
                  <ClipboardCheck className="w-6 h-6" />
                  <span>Start Quick Assessment</span>
                </motion.button>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="px-4 sm:px-6 py-12 bg-gray-50" data-testid="how-it-works-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">How It Works</h2>
              <p className="text-gray-600">Book your lab tests in 3 simple steps</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.2 }}
                    className="relative"
                  >
                    {/* Connector Line */}
                    {index < steps.length - 1 && (
                      <div className="hidden md:block absolute top-12 left-1/2 w-full h-0.5 bg-gradient-to-r from-blue-200 to-purple-200"></div>
                    )}
                    
                    <div className="bg-white rounded-2xl p-6 shadow-lg relative z-10 text-center hover:shadow-xl transition-shadow">
                      <div className={`w-16 h-16 bg-gradient-to-br ${step.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-sm font-bold text-blue-600 mb-2">STEP {step.step}</div>
                      <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                      <p className="text-gray-600 text-sm">{step.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Customer Reviews Section */}
        <section className="px-4 sm:px-6 py-12 bg-white" data-testid="customer-reviews-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">What Our Customers Say</h2>
              <p className="text-gray-600">Verified reviews from real customers</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              {customerReviews.map((review, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 text-sm leading-relaxed">"{review.text}"</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-gray-900 text-sm">{review.name}</p>
                      <p className="text-xs text-gray-500">{review.location}</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {review.verified && (
                        <span className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                          <CheckCircle className="w-3 h-3" />
                          Verified
                        </span>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 mt-3">{review.date}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Popular Test Bundles Section */}
        <section className="px-4 sm:px-6 py-12" data-testid="bundles-section">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Popular Test Packages</h2>
                <p className="text-gray-600">Our most booked health screening packages</p>
              </div>
              <Link href="/tests">
                <button className="hidden sm:flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium">
                  View All <ArrowRight className="w-4 h-4" />
                </button>
              </Link>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {popularBundles.map((bundle, index) => {
                const Icon = bundle.icon;
                return (
                  <motion.div
                    key={bundle.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all group"
                  >
                    {bundle.popular && (
                      <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-center py-1.5 text-xs font-bold">
                        🔥 MOST POPULAR
                      </div>
                    )}
                    
                    <div className="p-5">
                      <div className={`w-12 h-12 bg-gradient-to-br ${bundle.gradient} rounded-xl flex items-center justify-center mb-4 shadow-md group-hover:scale-110 transition-transform`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      
                      <h3 className="font-bold text-gray-900 mb-1">{bundle.title}</h3>
                      <p className="text-sm text-gray-500 mb-3">{bundle.subtitle}</p>
                      
                      <div className="flex items-center gap-3 text-xs text-gray-500 mb-4">
                        <span className="flex items-center gap-1">
                          <Beaker className="w-3.5 h-3.5" />
                          {bundle.tests} tests
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {bundle.turnaround}
                        </span>
                      </div>
                      
                      <div className="flex items-baseline gap-2 mb-4">
                        <span className="text-2xl font-bold text-gray-900">AED {bundle.price}</span>
                        {bundle.originalPrice && (
                          <span className="text-sm text-gray-400 line-through">AED {bundle.originalPrice}</span>
                        )}
                      </div>
                      
                      <Link href={`/bundles/${bundle.id}`}>
                        <button className={`w-full py-2.5 bg-gradient-to-r ${bundle.gradient} text-white rounded-xl font-semibold hover:opacity-90 transition-all flex items-center justify-center gap-2`}>
                          View Details
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </Link>
                    </div>
                  </motion.div>
                );
              })}
            </div>
            
            <div className="text-center mt-8 sm:hidden">
              <Link href="/tests">
                <button className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors">
                  View All Packages
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="px-4 sm:px-6 py-12 bg-white" data-testid="features-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Why Choose MediConnect?</h2>
              <p className="text-gray-600">The easy way to book lab tests in Dubai</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`${feature.bgColor} rounded-2xl p-6 text-center hover:shadow-lg transition-shadow`}
                  >
                    <div className={`w-16 h-16 ${feature.iconBg} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Trusted Partners Section */}
        <section className="px-4 sm:px-6 py-12 bg-gray-50" data-testid="partners-section">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Our Partner Labs</h2>
              <p className="text-gray-600">Certified diagnostic labs across Dubai</p>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {partners.map((partner, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-xl p-4 text-center shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="text-4xl mb-2">{partner.logo}</div>
                  <h4 className="font-semibold text-gray-800 text-sm">{partner.name}</h4>
                  <p className="text-xs text-gray-500">{partner.locations}</p>
                </motion.div>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Link href="/labs">
                <button className="px-6 py-3 border-2 border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors">
                  View All Partner Labs
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 sm:px-6 py-16 bg-gradient-to-r from-blue-600 to-purple-600" data-testid="cta-section">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Ready to Book Your Lab Tests?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Compare prices, choose your lab, and get results within 24-48 hours.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/tests">
                <button className="px-8 py-4 bg-white text-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-all shadow-xl flex items-center justify-center gap-2">
                  <Search className="w-5 h-5" />
                  Browse All Tests
                </button>
              </Link>
              <Link href="/ai-discovery">
                <button className="px-8 py-4 bg-white/10 backdrop-blur text-white rounded-xl font-bold hover:bg-white/20 transition-all border-2 border-white/30 flex items-center justify-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Need Help? Try Test Finder
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12 sm:py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
              {/* Company Info */}
              <div className="col-span-2 md:col-span-1">
                <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  MediConnect
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  Lab test aggregator in Dubai. Compare prices across certified labs, book home collection or lab visits, and get results fast.
                </p>
                <div className="flex gap-3">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={social.name}
                        href="#"
                        className={`w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center transition-colors ${social.color}`}
                        aria-label={social.name}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Quick Links */}
              <div>
                <h3 className="text-white font-semibold mb-4 text-base">Quick Links</h3>
                <ul className="space-y-3">
                  <li><Link href="/tests" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">All Tests</Link></li>
                  <li><Link href="/ai-discovery" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Test Finder</Link></li>
                  <li><Link href="/labs" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Partner Labs</Link></li>
                  <li><Link href="/bookings" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">My Bookings</Link></li>
                </ul>
              </div>

              {/* Health Categories */}
              <div>
                <h3 className="text-white font-semibold mb-4 text-base">Health Categories</h3>
                <ul className="space-y-3">
                  <li><Link href="/womens-health" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Women's Health</Link></li>
                  <li><Link href="/mens-health" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Men's Health</Link></li>
                  <li><Link href="/diabetes-health" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Diabetes Care</Link></li>
                  <li><Link href="/thyroid-health" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Thyroid Health</Link></li>
                  <li><Link href="/heart-health" className="text-sm text-gray-400 hover:text-blue-400 transition-colors">Heart Health</Link></li>
                </ul>
              </div>

              {/* Contact Info */}
              <div>
                <h3 className="text-white font-semibold mb-4 text-base">Contact Us</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2 text-sm text-gray-400">
                    <Phone className="w-4 h-4 text-blue-400" />
                    +971 4 XXX XXXX
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-400">
                    <Mail className="w-4 h-4 text-blue-400" />
                    hello@mediconnect.ae
                  </li>
                  <li className="flex items-start gap-2 text-sm text-gray-400">
                    <MapPin className="w-4 h-4 text-blue-400 mt-0.5" />
                    Dubai Healthcare City, UAE
                  </li>
                </ul>
              </div>
            </div>

            {/* Bottom Bar */}
            <div className="pt-8 border-t border-gray-800 flex flex-col sm:flex-row justify-between items-center gap-4">
              <p className="text-gray-500 text-sm">
                © 2024 MediConnect. All rights reserved.
              </p>
              <div className="flex gap-6 text-sm text-gray-500">
                <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-blue-400 transition-colors">Terms of Service</a>
                <a href="#" className="hover:text-blue-400 transition-colors">Support</a>
              </div>
            </div>
          </div>
        </footer>
      </div>

      {/* Quick Assessment Modal */}
      <QuickAssessmentModal 
        isOpen={showAssessment} 
        onClose={() => setShowAssessment(false)} 
      />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />
    </div>
  );
}
