import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Heart, CheckCircle, Clock, Shield, AlertTriangle, Activity,
  ArrowRight, Beaker, Calendar, TrendingUp, Stethoscope, ArrowLeft
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const heartPackages = [
  {
    id: "3",
    name: "Heart & Cholesterol Panel",
    description: "Comprehensive cardiovascular risk assessment including lipid profile and cardiac markers",
    price: "299",
    originalPrice: "399",
    popular: true,
    testsIncluded: 12,
    turnaround: "24 hours",
    parameters: [
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL Cholesterol", "HDL Cholesterol", "Triglycerides", "VLDL", "Total/HDL Ratio"] },
      { category: "Cardiac Markers", tests: ["hs-CRP (High-sensitivity C-Reactive Protein)", "Homocysteine"] },
      { category: "Blood Sugar", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Kidney", tests: ["Creatinine", "eGFR"] },
    ],
    benefits: [
      "Complete lipid analysis",
      "Heart disease risk score",
      "Inflammation markers",
      "Doctor interpretation"
    ],
    riskFactors: ["High cholesterol", "Family history of heart disease", "Smoking", "Diabetes", "High blood pressure"]
  },
  {
    id: "9",
    name: "Advanced Cardiac Panel",
    description: "In-depth cardiac assessment with advanced biomarkers for comprehensive heart health evaluation",
    price: "599",
    originalPrice: "799",
    popular: false,
    testsIncluded: 20,
    turnaround: "48 hours",
    parameters: [
      { category: "Lipid Profile", tests: ["Complete Lipid Panel", "Apolipoprotein A1", "Apolipoprotein B", "Lipoprotein(a)"] },
      { category: "Cardiac Markers", tests: ["hs-CRP", "Homocysteine", "NT-proBNP", "Troponin I"] },
      { category: "Inflammation", tests: ["ESR", "Fibrinogen"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c", "Insulin", "HOMA-IR"] },
      { category: "Electrolytes", tests: ["Sodium", "Potassium", "Magnesium"] },
    ],
    benefits: [
      "Advanced risk stratification",
      "Heart failure markers",
      "Metabolic syndrome screening",
      "Comprehensive report"
    ],
    riskFactors: ["Previous heart attack", "Heart failure symptoms", "Chest pain", "Shortness of breath"]
  },
  {
    id: "10",
    name: "Lipid Profile Basic",
    description: "Essential cholesterol screening to monitor your lipid levels",
    price: "89",
    originalPrice: "129",
    popular: false,
    testsIncluded: 5,
    turnaround: "24 hours",
    parameters: [
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL Cholesterol", "HDL Cholesterol", "Triglycerides", "VLDL"] },
    ],
    benefits: [
      "Quick results",
      "Affordable screening",
      "Essential lipid markers",
      "Fasting required"
    ],
    riskFactors: ["Routine monitoring", "Diet changes", "Medication follow-up"]
  }
];

const cardiacTests = [
  { name: "Total Cholesterol", price: "29", description: "Overall cholesterol level in blood", normal: "< 200 mg/dL" },
  { name: "LDL Cholesterol", price: "39", description: "Bad cholesterol - clogs arteries", normal: "< 100 mg/dL" },
  { name: "HDL Cholesterol", price: "39", description: "Good cholesterol - protects heart", normal: "> 40 mg/dL" },
  { name: "Triglycerides", price: "39", description: "Fat in blood from food", normal: "< 150 mg/dL" },
  { name: "hs-CRP", price: "79", description: "Inflammation marker for heart risk", normal: "< 1.0 mg/L" },
  { name: "Homocysteine", price: "99", description: "Amino acid linked to heart disease", normal: "5-15 µmol/L" },
  { name: "Apolipoprotein B", price: "129", description: "Advanced cardiovascular risk marker", normal: "< 90 mg/dL" },
  { name: "Lipoprotein(a)", price: "149", description: "Genetic heart disease risk factor", normal: "< 30 mg/dL" },
];

const riskFactorInfo = [
  { factor: "High Cholesterol", icon: "🩸", risk: "2-3x higher risk", action: "Get lipid profile every 6 months" },
  { factor: "High Blood Pressure", icon: "💓", risk: "4x higher risk", action: "Monitor BP + cardiac markers" },
  { factor: "Diabetes", icon: "🍬", risk: "2-4x higher risk", action: "Annual heart checkup recommended" },
  { factor: "Smoking", icon: "🚬", risk: "2-4x higher risk", action: "Quit smoking + regular screening" },
  { factor: "Family History", icon: "👨‍👩‍👧", risk: "2x higher risk", action: "Start screening at age 30" },
  { factor: "Obesity", icon: "⚖️", risk: "2x higher risk", action: "Lifestyle changes + monitoring" },
];

export default function HeartHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("3");

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-red-600 via-red-700 to-pink-700 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-red-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6" />
              </div>
              <span className="text-red-200 font-medium">Cardiovascular Health</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Heart Health Screening
            </h1>
            <p className="text-xl text-red-100 mb-8">
              Comprehensive cardiac risk assessment and cholesterol screening to protect your heart health and prevent cardiovascular disease.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>Complete Lipid Analysis</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Activity className="w-5 h-5 text-yellow-400" />
                <span>Cardiac Risk Score</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-red-300" />
                <span>Early Detection</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="bg-white py-8 shadow-md">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-red-600">17.9M</div>
              <div className="text-sm text-gray-600">Deaths/year from CVD globally</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-red-600">80%</div>
              <div className="text-sm text-gray-600">Preventable with early detection</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-red-600">#1</div>
              <div className="text-sm text-gray-600">Cause of death worldwide</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600">30+</div>
              <div className="text-sm text-gray-600">Age to start screening</div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Heart Health Packages</h2>
          
          <div className="grid lg:grid-cols-3 gap-6">
            {heartPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-red-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-red-500 text-white text-center py-2 text-sm font-semibold">
                    ❤️ Recommended
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-red-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="space-y-2 mb-4">
                    {pkg.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>

                  {/* Risk Factors */}
                  <div className="bg-red-50 rounded-lg p-3 mb-4">
                    <p className="text-xs font-semibold text-red-700 mb-2">Recommended if you have:</p>
                    <div className="flex flex-wrap gap-1">
                      {pkg.riskFactors.slice(0, 3).map((risk, i) => (
                        <span key={i} className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded">
                          {risk}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="w-full text-left text-sm text-red-600 font-medium mb-4 flex items-center justify-between"
                  >
                    <span>View all parameters</span>
                    <ArrowRight className={`w-4 h-4 transition-transform ${expandedPackage === pkg.id ? 'rotate-90' : ''}`} />
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-xs font-semibold text-gray-500 uppercase mb-1">{param.category}</h5>
                          <div className="flex flex-wrap gap-1">
                            {param.tests.map((test, j) => (
                              <span key={j} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                                {test}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/bundles/${pkg.id}`)}
                      className="flex-1 py-3 border-2 border-red-600 text-red-600 rounded-xl font-semibold hover:bg-red-50 transition-colors"
                    >
                      Details
                    </button>
                    <button
                      onClick={() => navigate(`/book/${pkg.id}`)}
                      className="flex-1 py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
                      data-testid={`book-${pkg.id}`}
                    >
                      <Calendar className="w-4 h-4" />
                      Book Now
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Cardiac Tests */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Cardiac Tests</h2>
          <p className="text-gray-600 mb-8">Book specific heart health tests with normal reference ranges</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {cardiacTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all border border-gray-100"
              >
                <h4 className="font-semibold text-gray-900 mb-1">{test.name}</h4>
                <p className="text-xs text-gray-500 mb-2">{test.description}</p>
                <div className="bg-green-50 text-green-700 text-xs px-2 py-1 rounded mb-3 inline-block">
                  Normal: {test.normal}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-red-600">AED {test.price}</span>
                  <Link href="/ai-discovery">
                    <button className="text-xs text-red-600 hover:underline">Ask AI →</button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Risk Factors Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">Know Your Risk Factors</h2>
          <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
            Understanding your risk factors helps you take proactive steps to protect your heart
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {riskFactorInfo.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-xl p-6 shadow-md border border-gray-100"
              >
                <div className="flex items-start gap-4">
                  <div className="text-3xl">{item.icon}</div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{item.factor}</h4>
                    <p className="text-red-600 font-semibold text-sm mb-2">{item.risk}</p>
                    <p className="text-xs text-gray-500">{item.action}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Warning Signs */}
      <section className="py-12 bg-red-50">
        <div className="container mx-auto px-4">
          <div className="flex items-start gap-4 max-w-3xl mx-auto">
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Warning Signs - Get Tested Immediately If You Experience:</h3>
              <div className="flex flex-wrap gap-2">
                {["Chest pain or discomfort", "Shortness of breath", "Dizziness or fainting", "Irregular heartbeat", "Fatigue", "Swelling in legs"].map((sign, i) => (
                  <span key={i} className="bg-white text-red-700 px-3 py-1 rounded-full text-sm border border-red-200">
                    {sign}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-gradient-to-r from-red-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Protect Your Heart Today</h2>
          <p className="text-red-100 mb-6">Get personalized recommendations based on your risk factors</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-4 bg-white text-red-600 rounded-xl font-bold hover:bg-red-50 transition-colors shadow-lg">
                Talk to AI Assistant
              </button>
            </Link>
            <button
              onClick={() => navigate('/book/3')}
              className="px-8 py-4 bg-red-800 text-white rounded-xl font-bold hover:bg-red-900 transition-colors shadow-lg"
            >
              Book Heart Checkup
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
