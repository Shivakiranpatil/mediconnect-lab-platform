import { useState, useEffect, useMemo, useRef } from "react";
import { Link, useSearch } from "wouter";
import { 
  Search, Filter, Activity, Heart, Zap, Beaker, TrendingUp, AlertCircle, 
  ArrowRight, ChevronDown, X, Clock, Home, Check, SlidersHorizontal,
  Droplets, Sun, Users, Plus, Package
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useMyTests, getPackagesContainingTest } from "@/contexts/MyTestsContext";
import { AddToCompareModal } from "@/components/AddToCompareModal";

interface Test {
  id: string;
  name: string;
  description: string;
  category: string;
  biomarkers: string[];
  preparation: string;
  turnaroundHours: number;
  price?: string;
  isActive: boolean;
}

interface Bundle {
  id: string;
  name: string;
  description: string;
  shortDescription: string;
  basePrice: string;
  category: string;
  icon: string;
  color: string;
  isPopular: boolean;
}

// Enhanced bundle data with additional fields
interface EnhancedBundle extends Bundle {
  originalPrice: string;
  testCount: number;
  discount: number;
  availableToday: boolean;
  nextSlot: string;
  homeCollection: boolean;
}

// Enhanced test data
interface EnhancedTest extends Test {
  originalPrice?: string;
  discount?: number;
  availableToday?: boolean;
  nextSlot?: string;
  homeCollection?: boolean;
}

const categoryIcons: Record<string, any> = {
  'Heart Health': Heart,
  'Diabetes': Activity,
  'Vitamins': Sun,
  'Energy': Zap,
  'General': TrendingUp,
  'Endocrine': Activity,
  'Liver': Activity,
  'Kidney': Activity,
  'Minerals': Beaker,
  'Blood': Droplets,
  'Thyroid': Activity,
  "Women's Health": Users,
  "Men's Health": Users,
};

const categoryColors: Record<string, string> = {
  'Heart Health': 'from-red-400 to-red-600',
  'Diabetes': 'from-orange-400 to-orange-600',
  'Vitamins': 'from-purple-400 to-purple-600',
  'Energy': 'from-amber-400 to-amber-600',
  'General': 'from-blue-400 to-blue-600',
  'Endocrine': 'from-teal-400 to-teal-600',
  'Liver': 'from-green-400 to-green-600',
  'Kidney': 'from-cyan-400 to-cyan-600',
  'Minerals': 'from-pink-400 to-pink-600',
  'Blood': 'from-red-500 to-red-700',
  'Thyroid': 'from-purple-500 to-purple-700',
  "Women's Health": 'from-pink-400 to-pink-600',
  "Men's Health": 'from-slate-500 to-slate-700',
};

// Category pills data
const categoryPills = [
  { id: 'all', name: 'All', icon: '🔬' },
  { id: 'blood', name: 'Blood', icon: '🩸' },
  { id: 'heart', name: 'Heart', icon: '❤️' },
  { id: 'thyroid', name: 'Thyroid', icon: '🦋' },
  { id: 'diabetes', name: 'Diabetes', icon: '💊' },
  { id: 'vitamins', name: 'Vitamins', icon: '☀️' },
  { id: 'womens', name: "Women's", icon: '👩' },
  { id: 'mens', name: "Men's", icon: '👨' },
];

// Price range filters
const priceRanges = [
  { id: 'under100', label: 'Under AED 100', min: 0, max: 100 },
  { id: '100-300', label: 'AED 100-300', min: 100, max: 300 },
  { id: '300-500', label: 'AED 300-500', min: 300, max: 500 },
  { id: 'above500', label: 'Above AED 500', min: 500, max: Infinity },
];

// Sort options
const sortOptions = [
  { id: 'popular', label: 'Most Popular' },
  { id: 'price-low', label: 'Price: Low to High' },
  { id: 'price-high', label: 'Price: High to Low' },
  { id: 'newest', label: 'Newest' },
];

export default function TestsPage() {
  const searchParams = useSearch();
  const urlSearchQuery = new URLSearchParams(searchParams).get('search') || '';
  const urlTab = new URLSearchParams(searchParams).get('tab') || '';
  
  const [tests, setTests] = useState<Test[]>([]);
  const [bundles, setBundles] = useState<Bundle[]>([]);
  const [searchQuery, setSearchQuery] = useState(urlSearchQuery);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedPill, setSelectedPill] = useState("all");
  const [activeTab, setActiveTab] = useState<"bundles" | "individual">(urlTab === 'individual' ? 'individual' : 'bundles');
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState("popular");
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  
  // Add to Compare modal state
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [lastAddedTest, setLastAddedTest] = useState<{ name: string; price: number } | null>(null);
  
  // Filter states
  const [priceFilter, setPriceFilter] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string[]>([]);
  const [availabilityFilter, setAvailabilityFilter] = useState<string[]>([]);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { addItem, removeItem, isInList, setSidebarOpen, getItemCount, items } = useMyTests();

  // List of individual test keywords
  const individualTestKeywords = ['hba1c', 'vitamin d', 'iron', 'thyroid', 'liver', 'kidney', 'lipid', 'cbc'];

  // Update search and tab when URL changes
  useEffect(() => {
    if (urlSearchQuery) {
      setSearchQuery(urlSearchQuery);
      const searchLower = urlSearchQuery.toLowerCase();
      const isIndividualTest = individualTestKeywords.some(keyword => searchLower.includes(keyword));
      if (isIndividualTest) {
        setActiveTab("individual");
      }
    }
  }, [urlSearchQuery]);

  useEffect(() => {
    fetchData();
  }, []);

  // Close autocomplete on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowAutocomplete(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchData = async () => {
    try {
      const bundlesRes = await fetch("/api/bundles");
      const bundlesData = await bundlesRes.json();
      setBundles(bundlesData);

      const testsRes = await fetch("/api/tests");
      const testsData = await testsRes.json();
      setTests(testsData);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      toast({
        title: "Error",
        description: "Failed to load tests. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Enhance bundles with additional mock data
  const enhancedBundles: EnhancedBundle[] = useMemo(() => {
    return bundles.map((bundle, index) => {
      const basePrice = parseInt(bundle.basePrice);
      const originalPrice = Math.round(basePrice * 1.25);
      const discount = Math.round(((originalPrice - basePrice) / originalPrice) * 100);
      const testCounts = [70, 45, 35, 25, 15, 20, 12];
      const slots = ['Today 4 PM', 'Today 6 PM', 'Tomorrow 9 AM', 'Tomorrow 2 PM'];
      
      return {
        ...bundle,
        originalPrice: originalPrice.toString(),
        testCount: testCounts[index % testCounts.length],
        discount,
        availableToday: index % 3 !== 2,
        nextSlot: slots[index % slots.length],
        homeCollection: index % 4 !== 3,
      };
    });
  }, [bundles]);

  // Enhance tests with additional mock data
  const enhancedTests: EnhancedTest[] = useMemo(() => {
    return tests.map((test, index) => {
      const basePrice = parseInt(test.price || '99');
      const originalPrice = Math.round(basePrice * 1.3);
      const discount = Math.round(((originalPrice - basePrice) / originalPrice) * 100);
      const slots = ['Today 3 PM', 'Today 5 PM', 'Tomorrow 10 AM', 'Tomorrow 1 PM'];
      
      return {
        ...test,
        originalPrice: originalPrice.toString(),
        discount,
        availableToday: index % 2 === 0,
        nextSlot: slots[index % slots.length],
        homeCollection: index % 3 !== 2,
      };
    });
  }, [tests]);

  // Autocomplete suggestions
  const autocompleteSuggestions = useMemo(() => {
    if (!searchQuery || searchQuery.length < 2) return { tests: [], bundles: [], categories: [] };
    
    const query = searchQuery.toLowerCase();
    const matchingTests = enhancedTests
      .filter(t => t.name.toLowerCase().includes(query))
      .slice(0, 3);
    const matchingBundles = enhancedBundles
      .filter(b => b.name.toLowerCase().includes(query))
      .slice(0, 3);
    const matchingCategories = categoryPills
      .filter(c => c.name.toLowerCase().includes(query) && c.id !== 'all')
      .slice(0, 2);
    
    return { tests: matchingTests, bundles: matchingBundles, categories: matchingCategories };
  }, [searchQuery, enhancedTests, enhancedBundles]);

  // Filter and sort logic
  const filteredBundles = useMemo(() => {
    let result = [...enhancedBundles];
    
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(b => 
        b.name.toLowerCase().includes(query) || 
        b.description?.toLowerCase().includes(query)
      );
    }
    
    // Category pill filter
    if (selectedPill !== 'all') {
      const pillMap: Record<string, string[]> = {
        'blood': ['General', 'Blood'],
        'heart': ['Heart Health'],
        'thyroid': ['Endocrine', 'Thyroid'],
        'diabetes': ['Diabetes'],
        'vitamins': ['Vitamins'],
        'womens': ["Women's Health"],
        'mens': ["Men's Health"],
      };
      const categories = pillMap[selectedPill] || [];
      result = result.filter(b => categories.some(c => b.category?.includes(c) || b.name.toLowerCase().includes(selectedPill)));
    }
    
    // Price filter
    if (priceFilter) {
      const range = priceRanges.find(r => r.id === priceFilter);
      if (range) {
        result = result.filter(b => {
          const price = parseInt(b.basePrice);
          return price >= range.min && price < range.max;
        });
      }
    }
    
    // Category filter
    if (categoryFilter.length > 0) {
      result = result.filter(b => categoryFilter.includes(b.category));
    }
    
    // Availability filter
    if (availabilityFilter.includes('today')) {
      result = result.filter(b => b.availableToday);
    }
    if (availabilityFilter.includes('home')) {
      result = result.filter(b => b.homeCollection);
    }
    
    // Sort
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => parseInt(a.basePrice) - parseInt(b.basePrice));
        break;
      case 'price-high':
        result.sort((a, b) => parseInt(b.basePrice) - parseInt(a.basePrice));
        break;
      case 'newest':
        result.reverse();
        break;
      case 'popular':
      default:
        result.sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0));
    }
    
    return result;
  }, [enhancedBundles, searchQuery, selectedPill, priceFilter, categoryFilter, availabilityFilter, sortBy]);

  const filteredTests = useMemo(() => {
    let result = [...enhancedTests];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(t => 
        t.name.toLowerCase().includes(query) || 
        t.description?.toLowerCase().includes(query) ||
        t.category?.toLowerCase().includes(query)
      );
    }
    
    if (selectedCategory !== "all") {
      result = result.filter(t => t.category === selectedCategory);
    }
    
    if (selectedPill !== 'all') {
      const pillMap: Record<string, string[]> = {
        'blood': ['General', 'Blood'],
        'heart': ['Heart Health'],
        'thyroid': ['Endocrine', 'Thyroid'],
        'diabetes': ['Diabetes'],
        'vitamins': ['Vitamins'],
        'womens': ["Women's Health"],
        'mens': ["Men's Health"],
      };
      const categories = pillMap[selectedPill] || [];
      result = result.filter(t => categories.some(c => t.category?.includes(c)));
    }
    
    if (priceFilter) {
      const range = priceRanges.find(r => r.id === priceFilter);
      if (range) {
        result = result.filter(t => {
          const price = parseInt(t.price || '0');
          return price >= range.min && price < range.max;
        });
      }
    }
    
    if (availabilityFilter.includes('today')) {
      result = result.filter(t => t.availableToday);
    }
    if (availabilityFilter.includes('home')) {
      result = result.filter(t => t.homeCollection);
    }
    
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => parseInt(a.price || '0') - parseInt(b.price || '0'));
        break;
      case 'price-high':
        result.sort((a, b) => parseInt(b.price || '0') - parseInt(a.price || '0'));
        break;
      case 'newest':
        result.reverse();
        break;
    }
    
    return result;
  }, [enhancedTests, searchQuery, selectedCategory, selectedPill, priceFilter, availabilityFilter, sortBy]);

  const categories = Array.from(new Set(tests.map(t => t.category).filter(Boolean)));

  const clearFilters = () => {
    setPriceFilter(null);
    setCategoryFilter([]);
    setAvailabilityFilter([]);
    setSelectedPill('all');
    setSelectedCategory('all');
  };

  // Toggle compare using MyTestsContext - find bundle/test data and add/remove
  const toggleCompare = (id: string, type: 'bundle' | 'test' = 'bundle') => {
    if (isInList(id)) {
      removeItem(id);
    } else {
      // Find the item data
      if (type === 'bundle') {
        const bundle = filteredBundles.find(b => b.id === id);
        if (bundle) {
          addItem({
            id: bundle.id,
            type: 'bundle',
            name: bundle.name,
            price: parseInt(bundle.basePrice || '0'),
            category: bundle.category
          });
        }
      } else {
        const test = filteredTests.find(t => t.id === id);
        if (test) {
          addItem({
            id: test.id,
            type: 'test',
            name: test.name,
            price: parseInt(test.price || '0'),
            category: test.category
          });
        }
      }
    }
  };

  const hasActiveFilters = priceFilter || categoryFilter.length > 0 || availabilityFilter.length > 0;
  const currentResults = activeTab === 'bundles' ? filteredBundles : filteredTests;
  const compareCount = getItemCount();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white pb-16 sm:pb-0">
      <Navbar />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-12 px-4 sticky top-0 z-30 sm:relative sm:top-auto" data-testid="tests-hero">
        <div className="max-w-6xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-3"
            data-testid="tests-page-title"
          >
            Browse 500+ Lab Tests & Health Packages
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-base md:text-lg text-blue-100 mb-6"
          >
            Compare prices across 50+ certified labs in UAE
          </motion.p>

          {/* Search Bar with Autocomplete */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="max-w-2xl mx-auto relative"
            ref={searchRef}
          >
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search for tests, vitamins, health checks..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowAutocomplete(e.target.value.length >= 2);
                }}
                onFocus={() => searchQuery.length >= 2 && setShowAutocomplete(true)}
                className="w-full pl-12 pr-4 py-4 rounded-2xl text-gray-900 focus:outline-none focus:ring-4 focus:ring-blue-300 shadow-xl"
                data-testid="tests-search-input"
              />
              {searchQuery && (
                <button 
                  onClick={() => { setSearchQuery(''); setShowAutocomplete(false); }}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Autocomplete Dropdown */}
            <AnimatePresence>
              {showAutocomplete && (autocompleteSuggestions.tests.length > 0 || autocompleteSuggestions.bundles.length > 0 || autocompleteSuggestions.categories.length > 0) && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-50"
                  data-testid="search-autocomplete"
                >
                  {autocompleteSuggestions.bundles.length > 0 && (
                    <div className="p-3 border-b border-gray-100">
                      <p className="text-xs font-semibold text-gray-500 mb-2">PACKAGES</p>
                      {autocompleteSuggestions.bundles.map(bundle => (
                        <Link key={bundle.id} href={`/bundles/${bundle.id}`}>
                          <div className="flex items-center justify-between p-2 hover:bg-blue-50 rounded-lg cursor-pointer" onClick={() => setShowAutocomplete(false)}>
                            <span className="text-gray-800 font-medium">{bundle.name}</span>
                            <span className="text-blue-600 font-bold">AED {bundle.basePrice}</span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                  {autocompleteSuggestions.tests.length > 0 && (
                    <div className="p-3 border-b border-gray-100">
                      <p className="text-xs font-semibold text-gray-500 mb-2">TESTS</p>
                      {autocompleteSuggestions.tests.map(test => (
                        <div 
                          key={test.id} 
                          className="flex items-center justify-between p-2 hover:bg-blue-50 rounded-lg cursor-pointer"
                          onClick={() => { setActiveTab('individual'); setShowAutocomplete(false); }}
                        >
                          <span className="text-gray-800 font-medium">{test.name}</span>
                          <span className="text-blue-600 font-bold">AED {test.price}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {autocompleteSuggestions.categories.length > 0 && (
                    <div className="p-3">
                      <p className="text-xs font-semibold text-gray-500 mb-2">CATEGORIES</p>
                      {autocompleteSuggestions.categories.map(cat => (
                        <div 
                          key={cat.id}
                          className="flex items-center gap-2 p-2 hover:bg-blue-50 rounded-lg cursor-pointer"
                          onClick={() => { setSelectedPill(cat.id); setShowAutocomplete(false); }}
                        >
                          <span className="text-lg">{cat.icon}</span>
                          <span className="text-gray-800 font-medium">{cat.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Category Pills */}
          <div className="mt-6 overflow-x-auto pb-2 -mx-4 px-4" data-testid="category-pills">
            <div className="flex gap-2 justify-start sm:justify-center min-w-max">
              {categoryPills.map(pill => (
                <button
                  key={pill.id}
                  onClick={() => setSelectedPill(pill.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    selectedPill === pill.id
                      ? 'bg-white text-blue-600 shadow-lg'
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                  data-testid={`pill-${pill.id}`}
                >
                  {pill.icon} {pill.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Filter Sidebar - Desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0" data-testid="filter-sidebar">
            <div className="bg-white rounded-2xl shadow-lg p-5 sticky top-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5" />
                  Filters
                </h3>
                {hasActiveFilters && (
                  <button onClick={clearFilters} className="text-sm text-blue-600 hover:underline">
                    Clear All
                  </button>
                )}
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-semibold text-gray-700 mb-3">Price Range</h4>
                <div className="space-y-2">
                  {priceRanges.map(range => (
                    <label key={range.id} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="radio"
                        name="priceRange"
                        checked={priceFilter === range.id}
                        onChange={() => setPriceFilter(priceFilter === range.id ? null : range.id)}
                        className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-600 group-hover:text-gray-900">{range.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Category */}
              <div className="mb-6">
                <h4 className="font-semibold text-gray-700 mb-3">Category</h4>
                <div className="space-y-2">
                  {['Blood Tests', 'Diabetes', 'Heart', 'Thyroid', 'Vitamins', "Women's", "Men's"].map(cat => (
                    <label key={cat} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={categoryFilter.includes(cat)}
                        onChange={() => {
                          setCategoryFilter(prev => 
                            prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
                          );
                        }}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-600 group-hover:text-gray-900">{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Availability */}
              <div className="mb-6">
                <h4 className="font-semibold text-gray-700 mb-3">Availability</h4>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={availabilityFilter.includes('today')}
                      onChange={() => {
                        setAvailabilityFilter(prev => 
                          prev.includes('today') ? prev.filter(a => a !== 'today') : [...prev, 'today']
                        );
                      }}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-600 group-hover:text-gray-900">Available Today</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={availabilityFilter.includes('home')}
                      onChange={() => {
                        setAvailabilityFilter(prev => 
                          prev.includes('home') ? prev.filter(a => a !== 'home') : [...prev, 'home']
                        );
                      }}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-600 group-hover:text-gray-900">Home Collection Available</span>
                  </label>
                </div>
              </div>

              {/* Clear Filters Button */}
              {hasActiveFilters && (
                <button
                  onClick={clearFilters}
                  className="w-full py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors text-sm font-medium"
                  data-testid="clear-filters-btn"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </aside>

          {/* Main Content Area */}
          <div className="flex-1">
            {/* Tabs */}
            <div className="flex gap-4 border-b border-gray-200 mb-4">
              <button
                onClick={() => setActiveTab("bundles")}
                className={`pb-3 px-4 font-semibold text-base transition-all ${
                  activeTab === "bundles"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-700"
                }`}
                data-testid="tab-bundles"
              >
                Test Bundles
                <span className="ml-2 text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                  {filteredBundles.length}
                </span>
              </button>
              <button
                onClick={() => setActiveTab("individual")}
                className={`pb-3 px-4 font-semibold text-base transition-all ${
                  activeTab === "individual"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-700"
                }`}
                data-testid="tab-individual"
              >
                Individual Tests
                <span className="ml-2 text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                  {filteredTests.length}
                </span>
              </button>
            </div>

            {/* Results Count & Sort */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4" data-testid="results-header">
              <p className="text-gray-600 text-sm">
                Showing <span className="font-semibold text-gray-900">{currentResults.length}</span> {activeTab === 'bundles' ? 'test bundles' : 'individual tests'}
              </p>
              
              <div className="flex items-center gap-3">
                {/* Mobile Filter Button */}
                <button
                  onClick={() => setShowMobileFilters(true)}
                  className="lg:hidden flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-xl text-sm font-medium hover:bg-gray-50"
                  data-testid="mobile-filter-btn"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                  {hasActiveFilters && <span className="w-2 h-2 bg-blue-600 rounded-full"></span>}
                </button>

                {/* Sort Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setShowSortDropdown(!showSortDropdown)}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-xl text-sm font-medium hover:bg-gray-50"
                    data-testid="sort-dropdown-btn"
                  >
                    Sort by: {sortOptions.find(s => s.id === sortBy)?.label}
                    <ChevronDown className={`w-4 h-4 transition-transform ${showSortDropdown ? 'rotate-180' : ''}`} />
                  </button>
                  
                  <AnimatePresence>
                    {showSortDropdown && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-gray-100 py-2 min-w-[200px] z-20"
                      >
                        {sortOptions.map(option => (
                          <button
                            key={option.id}
                            onClick={() => { setSortBy(option.id); setShowSortDropdown(false); }}
                            className={`w-full text-left px-4 py-2 text-sm hover:bg-blue-50 ${
                              sortBy === option.id ? 'text-blue-600 bg-blue-50' : 'text-gray-700'
                            }`}
                          >
                            {option.label}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* Loading State */}
            {loading && (
              <div className="text-center py-20">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
                <p className="mt-4 text-gray-600">Loading tests...</p>
              </div>
            )}

            {/* Test Bundles Grid */}
            {!loading && activeTab === "bundles" && (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {filteredBundles.map((bundle, index) => {
                  const IconComponent = categoryIcons[bundle.category] || Activity;
                  const isInCompare = isInList(bundle.id);
                  
                  return (
                    <motion.div
                      key={bundle.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 group"
                      data-testid={`bundle-card-${bundle.id}`}
                    >
                      <div className="p-5">
                        {/* Top Row: Badge + Compare */}
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            {bundle.isPopular && (
                              <span className="px-2.5 py-1 bg-orange-100 text-orange-600 text-xs font-bold rounded-full">
                                🔥 Popular
                              </span>
                            )}
                            <span className="px-2.5 py-1 bg-blue-100 text-blue-600 text-xs font-semibold rounded-full">
                              {bundle.testCount} tests
                            </span>
                          </div>
                          <label className="flex items-center gap-1.5 cursor-pointer text-xs text-gray-500 hover:text-gray-700">
                            <input
                              type="checkbox"
                              checked={isInCompare}
                              onChange={() => toggleCompare(bundle.id, 'bundle')}
                              className="w-3.5 h-3.5 text-blue-600 rounded focus:ring-blue-500"
                            />
                            Compare
                          </label>
                        </div>
                        
                        {/* Icon + Title */}
                        <div className="flex items-start gap-3 mb-3">
                          <div className={`w-12 h-12 bg-gradient-to-br ${categoryColors[bundle.category] || 'from-blue-400 to-blue-600'} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                            <IconComponent className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-gray-900 group-hover:text-blue-600 transition-colors leading-tight">
                              {bundle.name}
                            </h3>
                            <p className="text-xs text-gray-500 mt-0.5">{bundle.category}</p>
                          </div>
                        </div>

                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {bundle.description}
                        </p>

                        {/* Price */}
                        <div className="flex items-baseline gap-2 mb-3">
                          <span className="text-2xl font-bold text-blue-600">AED {bundle.basePrice}</span>
                          <span className="text-sm text-gray-400 line-through">AED {bundle.originalPrice}</span>
                          <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded-full">
                            Save {bundle.discount}%
                          </span>
                        </div>

                        {/* Availability Badges */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {bundle.availableToday ? (
                            <span className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-lg">
                              <Clock className="w-3 h-3" />
                              Next: {bundle.nextSlot}
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-lg">
                              <Clock className="w-3 h-3" />
                              {bundle.nextSlot}
                            </span>
                          )}
                          {bundle.homeCollection && (
                            <span className="flex items-center gap-1 text-xs text-purple-600 bg-purple-50 px-2 py-1 rounded-lg">
                              <Home className="w-3 h-3" />
                              Home Collection
                            </span>
                          )}
                        </div>

                        {/* Book Now Button */}
                        <Link href={`/bundles/${bundle.id}`}>
                          <button className="w-full py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2">
                            Book Now
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        </Link>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Individual Tests List */}
            {!loading && activeTab === "individual" && (
              <div className="space-y-4">
                {filteredTests.map((test, index) => {
                  const IconComponent = categoryIcons[test.category] || Activity;
                  const testInMyTests = isInList(test.id);
                  const packagesWithTest = getPackagesContainingTest(test.name);
                  const bestPackage = packagesWithTest[0];
                  
                  const handleAddToCompare = () => {
                    addItem({
                      id: test.id,
                      type: 'test',
                      name: test.name,
                      price: parseInt(test.price || '0'),
                      category: test.category
                    });
                    setLastAddedTest({ name: test.name, price: parseInt(test.price || '0') });
                    setShowCompareModal(true);
                  };
                  
                  return (
                    <motion.div
                      key={test.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100"
                      data-testid={`test-card-${test.id}`}
                    >
                      <div className="p-5">
                        <div className="flex items-start gap-4 mb-4">
                          <div className={`w-12 h-12 bg-gradient-to-br ${categoryColors[test.category] || 'from-blue-400 to-blue-600'} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md`}>
                            <IconComponent className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-lg font-bold text-gray-900">{test.name}</h4>
                            <p className="text-sm text-gray-500">Individual price: <span className="font-semibold text-gray-700">AED {test.price}</span></p>
                          </div>
                        </div>

                        <p className="text-sm text-gray-600 mb-4">{test.description}</p>

                        {/* Package Recommendation Box */}
                        {bestPackage && (
                          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 mb-4 border border-blue-100">
                            <div className="flex items-center gap-2 mb-2">
                              <Package className="w-4 h-4 text-blue-600" />
                              <span className="text-xs font-bold text-blue-700 uppercase">Included in Packages</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-semibold text-gray-900">{bestPackage.name} (AED {bestPackage.price})</p>
                                <p className="text-xs text-gray-600">{bestPackage.testCount} tests</p>
                                <p className="text-sm text-green-600 font-medium mt-1">
                                  That's AED {bestPackage.pricePerTest}/test vs AED {test.price}
                                </p>
                              </div>
                              <Link href={`/bundles/${bestPackage.id}`}>
                                <button className="px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-1">
                                  See Packages <ArrowRight className="w-4 h-4" />
                                </button>
                              </Link>
                            </div>
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="flex items-center justify-between pt-3 border-t">
                          <button
                            onClick={handleAddToCompare}
                            className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                              testInMyTests
                                ? 'bg-green-50 text-green-600 border border-green-200'
                                : 'border border-gray-300 text-gray-600 hover:border-blue-400 hover:text-blue-600'
                            }`}
                          >
                            {testInMyTests ? (
                              <>
                                <Check className="w-4 h-4" />
                                In My Tests
                              </>
                            ) : (
                              <>
                                <Plus className="w-4 h-4" />
                                Compare
                              </>
                            )}
                          </button>
                          
                          <Link href={`/book/${test.id}`}>
                            <span className="text-sm text-gray-500 hover:text-blue-600 underline">
                              Book Individual - AED {test.price}
                            </span>
                          </Link>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Empty States */}
            {!loading && activeTab === "bundles" && filteredBundles.length === 0 && (
              <div className="text-center py-16 bg-white rounded-2xl">
                <Beaker className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No bundles found</h3>
                <p className="text-gray-500 mb-4">Try adjusting your filters or search query</p>
                <button onClick={clearFilters} className="px-6 py-2 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">
                  Clear Filters
                </button>
              </div>
            )}

            {!loading && activeTab === "individual" && filteredTests.length === 0 && (
              <div className="text-center py-16 bg-white rounded-2xl">
                <Beaker className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No tests found</h3>
                <p className="text-gray-500 mb-4">Try adjusting your filters or search query</p>
                <button onClick={clearFilters} className="px-6 py-2 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Compare Floating Button */}
      <AnimatePresence>
        {compareCount >= 1 && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-40"
            data-testid="compare-floating-btn"
          >
            <button 
              onClick={() => setSidebarOpen(true)}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full font-bold shadow-2xl hover:shadow-3xl flex items-center gap-2 transition-all"
            >
              <span>My Tests ({compareCount})</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Filters Bottom Sheet */}
      <AnimatePresence>
        {showMobileFilters && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 lg:hidden"
              onClick={() => setShowMobileFilters(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl z-50 lg:hidden max-h-[80vh] overflow-auto"
              data-testid="mobile-filters-sheet"
            >
              <div className="p-5">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold text-gray-900">Filters</h3>
                  <button onClick={() => setShowMobileFilters(false)} className="p-2 hover:bg-gray-100 rounded-full">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-700 mb-3">Price Range</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {priceRanges.map(range => (
                      <button
                        key={range.id}
                        onClick={() => setPriceFilter(priceFilter === range.id ? null : range.id)}
                        className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                          priceFilter === range.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {range.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Availability */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-700 mb-3">Availability</h4>
                  <div className="space-y-2">
                    <button
                      onClick={() => setAvailabilityFilter(prev => prev.includes('today') ? prev.filter(a => a !== 'today') : [...prev, 'today'])}
                      className={`w-full px-4 py-3 rounded-xl text-left text-sm font-medium transition-all flex items-center justify-between ${
                        availabilityFilter.includes('today') ? 'bg-blue-100 text-blue-700 border-2 border-blue-500' : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      Available Today
                      {availabilityFilter.includes('today') && <Check className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={() => setAvailabilityFilter(prev => prev.includes('home') ? prev.filter(a => a !== 'home') : [...prev, 'home'])}
                      className={`w-full px-4 py-3 rounded-xl text-left text-sm font-medium transition-all flex items-center justify-between ${
                        availabilityFilter.includes('home') ? 'bg-blue-100 text-blue-700 border-2 border-blue-500' : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      Home Collection Available
                      {availabilityFilter.includes('home') && <Check className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4 border-t">
                  <button
                    onClick={clearFilters}
                    className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowMobileFilters(false)}
                    className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700"
                  >
                    Show Results
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-12 px-4 mt-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-3">
            Not Sure Which Test You Need?
          </h2>
          <p className="text-lg text-blue-100 mb-6">
            Let our Test Finder guide you to the right tests based on your symptoms
          </p>
          <Link href="/ai-discovery">
            <button className="px-8 py-4 bg-white text-blue-600 font-bold rounded-2xl hover:bg-blue-50 transition-all shadow-xl">
              Try Test Finder
            </button>
          </Link>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="max-w-6xl mx-auto px-4 py-6">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <p className="text-sm text-gray-600">
            <strong>Important:</strong> These tests are for informational purposes only. Always consult with a licensed healthcare professional for medical advice.
          </p>
        </div>
      </section>

      {/* Add to Compare Modal */}
      {lastAddedTest && (
        <AddToCompareModal
          isOpen={showCompareModal}
          onClose={() => setShowCompareModal(false)}
          testName={lastAddedTest.name}
          testPrice={lastAddedTest.price}
          onViewMyTests={() => setSidebarOpen(true)}
        />
      )}

      {/* Mobile Bottom Nav */}
      <MobileBottomNav />
    </div>
  );
}
