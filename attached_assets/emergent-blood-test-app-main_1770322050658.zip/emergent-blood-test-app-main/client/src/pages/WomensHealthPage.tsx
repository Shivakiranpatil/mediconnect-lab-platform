import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Heart, CheckCircle, Clock, Shield, Sparkles, Beaker, 
  ArrowRight, Star, Activity, Flower2, Calendar, ArrowLeft
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const womensPackages = [
  {
    id: "2",
    name: "Women's Wellness Panel",
    description: "Complete health screening designed specifically for women including hormone balance, reproductive health, and essential vitamins",
    price: "599",
    originalPrice: "799",
    popular: true,
    testsIncluded: 35,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Hormone Panel", tests: ["FSH", "LH", "Estradiol", "Progesterone", "Prolactin"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4", "Anti-TPO"] },
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "Iron", "Ferritin"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate", "Calcium"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
    ],
    benefits: [
      "Hormone balance check",
      "Fertility insights",
      "Bone health assessment",
      "Anemia detection"
    ]
  },
  {
    id: "9",
    name: "PCOS Screening Panel",
    description: "Specialized panel for detecting and monitoring Polycystic Ovary Syndrome",
    price: "449",
    originalPrice: "599",
    popular: false,
    testsIncluded: 18,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Hormone Panel", tests: ["FSH", "LH", "LH:FSH Ratio", "Testosterone", "DHEA-S"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "Fasting Insulin", "HOMA-IR"] },
      { category: "Thyroid", tests: ["TSH", "Free T4"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
      { category: "Inflammation", tests: ["hs-CRP"] },
    ],
    benefits: [
      "PCOS diagnosis support",
      "Insulin resistance check",
      "Hormone imbalance detection",
      "Metabolic health assessment"
    ]
  },
  {
    id: "10",
    name: "Fertility Assessment Panel",
    description: "Comprehensive fertility screening for women planning pregnancy",
    price: "699",
    originalPrice: "899",
    popular: false,
    testsIncluded: 25,
    turnaround: "48 hours",
    parameters: [
      { category: "Ovarian Reserve", tests: ["AMH", "FSH", "LH", "Estradiol"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4", "Anti-TPO"] },
      { category: "Infections", tests: ["Rubella IgG", "Toxoplasma IgG", "CMV IgG"] },
      { category: "Blood Group", tests: ["ABO & Rh Typing", "Antibody Screen"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate"] },
      { category: "Blood Count", tests: ["CBC", "Hemoglobin", "Iron Studies"] },
    ],
    benefits: [
      "Ovarian reserve assessment",
      "Infection screening",
      "Pre-pregnancy preparation",
      "Nutritional status check"
    ]
  },
  {
    id: "11",
    name: "Menopause Health Panel",
    description: "Hormone and health screening for women approaching or experiencing menopause",
    price: "549",
    originalPrice: "699",
    popular: false,
    testsIncluded: 22,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Hormone Panel", tests: ["FSH", "LH", "Estradiol", "Progesterone"] },
      { category: "Bone Health", tests: ["Calcium", "Phosphorus", "Vitamin D", "ALP"] },
      { category: "Cardiac Risk", tests: ["Lipid Profile", "hs-CRP", "Homocysteine"] },
      { category: "Thyroid", tests: ["TSH", "Free T4"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c"] },
    ],
    benefits: [
      "Hormone level assessment",
      "Bone density indicators",
      "Heart health check",
      "Metabolic monitoring"
    ]
  }
];

const individualTests = [
  { name: "AMH (Anti-Mullerian Hormone)", price: "199", description: "Ovarian reserve indicator" },
  { name: "FSH & LH Panel", price: "149", description: "Key fertility hormones" },
  { name: "Estradiol (E2)", price: "99", description: "Primary female hormone" },
  { name: "Progesterone", price: "89", description: "Ovulation confirmation" },
  { name: "Prolactin", price: "79", description: "Breast milk hormone" },
  { name: "Thyroid Panel (TSH, T3, T4)", price: "149", description: "Thyroid function test" },
  { name: "Iron Studies", price: "119", description: "Anemia screening" },
  { name: "Vitamin D", price: "99", description: "Bone health essential" },
  { name: "Vitamin B12 & Folate", price: "129", description: "Energy and pregnancy prep" },
  { name: "Pap Smear", price: "149", description: "Cervical cancer screening" },
];

export default function WomensHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("2");

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-pink-500 via-pink-600 to-rose-600 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-pink-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Flower2 className="w-6 h-6" />
              </div>
              <span className="text-pink-200 font-medium">Women's Wellness</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Women's Health Screening
            </h1>
            <p className="text-xl text-pink-100 mb-8">
              Specialized health packages designed for women's unique health needs - from hormone balance to fertility and menopause care.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>Hormone Testing</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-400" />
                <span>Results in 24-48 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-pink-300" />
                <span>Female Specialists</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Women's Health Packages</h2>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {womensPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-pink-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-pink-500 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-pink-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.benefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-pink-500 flex-shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expandable Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="text-pink-600 text-sm font-medium mb-4 hover:underline"
                  >
                    {expandedPackage === pkg.id ? '- Hide' : '+'} View all parameters
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-sm font-semibold text-gray-700">{param.category}</h5>
                          <p className="text-xs text-gray-500">{param.tests.join(', ')}</p>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  {/* Book Button */}
                  <Link href={`/book/${pkg.id}`}>
                    <button className="w-full py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-semibold hover:from-pink-600 hover:to-rose-600 transition-all flex items-center justify-center gap-2">
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  <span className="text-pink-600 font-bold">AED {test.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-3">{test.description}</p>
                <Link href="/tests">
                  <button className="text-pink-600 text-sm font-medium hover:underline flex items-center gap-1">
                    View Details <ArrowRight className="w-3 h-3" />
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Women's Health Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Women's Health Screening?</h2>
            <p className="text-gray-600">
              Women have unique health needs that require specialized attention. Regular screening helps in early detection and prevention.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-pink-50 rounded-2xl">
              <div className="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Hormone Balance</h3>
              <p className="text-sm text-gray-600">Monitor hormones that affect mood, energy, fertility, and overall well-being</p>
            </div>
            <div className="text-center p-6 bg-pink-50 rounded-2xl">
              <div className="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Early Detection</h3>
              <p className="text-sm text-gray-600">Catch PCOS, thyroid issues, and other conditions early for better outcomes</p>
            </div>
            <div className="text-center p-6 bg-pink-50 rounded-2xl">
              <div className="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Life Stage Care</h3>
              <p className="text-sm text-gray-600">Tailored tests for fertility, pregnancy, menopause, and every life stage</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-pink-500 to-rose-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Take Control of Your Health Today</h2>
          <p className="text-pink-100 mb-8 max-w-2xl mx-auto">
            Book your women's health screening now and get personalized insights into your well-being.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-3 bg-white text-pink-600 rounded-full font-semibold hover:bg-pink-50 transition-all flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </Link>
            <Link href="/tests">
              <button className="px-8 py-3 bg-pink-600 text-white rounded-full font-semibold hover:bg-pink-700 transition-all border border-white/30">
                Browse All Tests
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
