import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Droplets, CheckCircle, Clock, Shield, Activity, Beaker, 
  ArrowRight, Heart, Zap, ArrowLeft, AlertCircle
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const diabetesPackages = [
  {
    id: "5",
    name: "Diabetes Monitoring Panel",
    description: "Complete diabetes management panel to track blood sugar control and detect complications early",
    price: "249",
    originalPrice: "349",
    popular: true,
    testsIncluded: 12,
    turnaround: "24 hours",
    parameters: [
      { category: "Blood Sugar", tests: ["Fasting Glucose", "Post-Prandial Glucose", "HbA1c"] },
      { category: "Kidney Health", tests: ["Creatinine", "BUN", "Microalbumin/Creatinine Ratio"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
      { category: "Liver Function", tests: ["ALT", "AST"] },
    ],
    benefits: [
      "HbA1c monitoring",
      "Kidney function check",
      "Heart risk assessment",
      "Quarterly tracking"
    ]
  },
  {
    id: "16",
    name: "Pre-Diabetes Screening",
    description: "Early detection panel for those at risk of developing diabetes",
    price: "179",
    originalPrice: "249",
    popular: false,
    testsIncluded: 8,
    turnaround: "24 hours",
    parameters: [
      { category: "Blood Sugar", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Insulin", tests: ["Fasting Insulin", "HOMA-IR"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
    ],
    benefits: [
      "Pre-diabetes detection",
      "Insulin resistance check",
      "Lifestyle guidance",
      "Prevention focus"
    ]
  },
  {
    id: "17",
    name: "Advanced Diabetes Panel",
    description: "Comprehensive panel for diabetics including complication screening",
    price: "449",
    originalPrice: "599",
    popular: false,
    testsIncluded: 25,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Glycemic Control", tests: ["Fasting Glucose", "PP Glucose", "HbA1c", "Fructosamine"] },
      { category: "Insulin Function", tests: ["Fasting Insulin", "C-Peptide", "HOMA-IR", "HOMA-B"] },
      { category: "Kidney", tests: ["Complete Kidney Panel", "Microalbumin", "ACR"] },
      { category: "Cardiac Risk", tests: ["Lipid Profile", "hs-CRP", "Homocysteine"] },
      { category: "Liver", tests: ["Complete Liver Panel"] },
      { category: "Vitamins", tests: ["Vitamin B12", "Vitamin D"] },
    ],
    benefits: [
      "Complete diabetes assessment",
      "Complication screening",
      "Medication monitoring",
      "Detailed consultation"
    ]
  },
  {
    id: "18",
    name: "Diabetes + Thyroid Panel",
    description: "Combined screening for diabetes and thyroid disorders - often linked conditions",
    price: "349",
    originalPrice: "449",
    popular: false,
    testsIncluded: 15,
    turnaround: "24 hours",
    parameters: [
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c", "Fasting Insulin"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4", "Anti-TPO"] },
      { category: "Lipid Profile", tests: ["Complete Lipid Panel"] },
      { category: "Metabolic", tests: ["Uric Acid", "Liver Function"] },
    ],
    benefits: [
      "Dual condition screening",
      "Metabolic assessment",
      "Early detection",
      "Treatment optimization"
    ]
  }
];

const individualTests = [
  { name: "HbA1c (Glycated Hemoglobin)", price: "79", description: "3-month average blood sugar" },
  { name: "Fasting Blood Glucose", price: "29", description: "Current fasting sugar level" },
  { name: "Post-Prandial Glucose", price: "29", description: "2-hour after meal sugar" },
  { name: "Fasting Insulin", price: "99", description: "Insulin production level" },
  { name: "HOMA-IR", price: "149", description: "Insulin resistance index" },
  { name: "C-Peptide", price: "129", description: "Beta cell function marker" },
  { name: "Fructosamine", price: "89", description: "2-week glucose average" },
  { name: "Microalbumin", price: "79", description: "Early kidney damage marker" },
  { name: "Lipid Profile", price: "89", description: "Cholesterol panel" },
  { name: "Kidney Function Test", price: "99", description: "Creatinine, BUN, eGFR" },
];

const riskFactors = [
  { factor: "Family History", description: "Parent or sibling with diabetes" },
  { factor: "Overweight/Obesity", description: "BMI over 25" },
  { factor: "Sedentary Lifestyle", description: "Less than 3 days of exercise per week" },
  { factor: "Age Over 45", description: "Risk increases with age" },
  { factor: "High Blood Pressure", description: "BP > 130/80 mmHg" },
  { factor: "PCOS", description: "Polycystic ovary syndrome in women" },
];

export default function DiabetesHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("5");

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Droplets className="w-6 h-6" />
              </div>
              <span className="text-amber-200 font-medium">Blood Sugar Management</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Diabetes Health Screening
            </h1>
            <p className="text-xl text-amber-100 mb-8">
              Comprehensive diabetes monitoring and pre-diabetes screening to help you manage blood sugar effectively and prevent complications.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>HbA1c Monitoring</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-400" />
                <span>Results in 24 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-amber-300" />
                <span>Complication Screening</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Risk Factors Section */}
      <section className="py-8 bg-amber-50 border-b border-amber-100">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-5 h-5 text-amber-600" />
            <h3 className="font-semibold text-gray-900">Are you at risk? Common risk factors:</h3>
          </div>
          <div className="flex flex-wrap gap-3">
            {riskFactors.map((item, index) => (
              <div key={index} className="bg-white px-4 py-2 rounded-full text-sm border border-amber-200">
                <span className="font-medium text-gray-700">{item.factor}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Diabetes Health Packages</h2>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {diabetesPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-amber-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-amber-500 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-amber-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.benefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expandable Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="text-amber-600 text-sm font-medium mb-4 hover:underline"
                  >
                    {expandedPackage === pkg.id ? '- Hide' : '+'} View all parameters
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-sm font-semibold text-gray-700">{param.category}</h5>
                          <p className="text-xs text-gray-500">{param.tests.join(', ')}</p>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  {/* Book Button */}
                  <Link href={`/book/${pkg.id}`}>
                    <button className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-orange-600 transition-all flex items-center justify-center gap-2">
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  <span className="text-amber-600 font-bold">AED {test.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-3">{test.description}</p>
                <Link href="/tests">
                  <button className="text-amber-600 text-sm font-medium hover:underline flex items-center gap-1">
                    View Details <ArrowRight className="w-3 h-3" />
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Understanding Diabetes Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Understanding Your Results</h2>
            <p className="text-gray-600">
              Know what your diabetes markers mean for your health
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-md border border-amber-100">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <Droplets className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">HbA1c: Normal</h3>
              <p className="text-2xl font-bold text-green-600 mb-2">&lt; 5.7%</p>
              <p className="text-sm text-gray-600">No diabetes - maintain healthy lifestyle</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-md border border-amber-100">
              <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mb-4">
                <Droplets className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">HbA1c: Pre-Diabetes</h3>
              <p className="text-2xl font-bold text-amber-600 mb-2">5.7% - 6.4%</p>
              <p className="text-sm text-gray-600">At risk - lifestyle changes recommended</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-md border border-amber-100">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Droplets className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">HbA1c: Diabetes</h3>
              <p className="text-2xl font-bold text-red-600 mb-2">≥ 6.5%</p>
              <p className="text-sm text-gray-600">Diabetes - medical management needed</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Take Control of Your Blood Sugar</h2>
          <p className="text-amber-100 mb-8 max-w-2xl mx-auto">
            Early detection and regular monitoring are key to managing diabetes effectively.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-3 bg-white text-amber-600 rounded-full font-semibold hover:bg-amber-50 transition-all flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </Link>
            <Link href="/tests">
              <button className="px-8 py-3 bg-amber-600 text-white rounded-full font-semibold hover:bg-amber-700 transition-all border border-white/30">
                Browse All Tests
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
