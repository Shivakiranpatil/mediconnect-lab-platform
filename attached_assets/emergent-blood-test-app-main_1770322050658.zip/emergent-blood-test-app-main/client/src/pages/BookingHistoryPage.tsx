import { useState, useEffect } from "react";
import { Link } from "wouter";
import { 
  Calendar, Clock, MapPin, CheckCircle, AlertCircle, 
  ArrowLeft, Building2, Truck, FileText, RefreshCw
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface Booking {
  id: string;
  bundleId: string;
  bundleName?: string;
  labId: string;
  labName?: string;
  collectionType: "lab" | "home";
  date: string;
  time: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  address?: string;
  status: string;
  createdAt: string;
}

const mockLabs: Record<string, string> = {
  "1": "HealthFirst Diagnostics",
  "2": "MedLab Plus",
  "3": "Al Borg Laboratories",
  "4": "Prime Diagnostics"
};

export default function BookingHistoryPage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await fetch('/api/bookings');
      if (response.ok) {
        const data = await response.json();
        // Enrich with bundle names
        const enrichedBookings = await Promise.all(data.map(async (booking: Booking) => {
          try {
            const bundleRes = await fetch('/api/bundles');
            const bundles = await bundleRes.json();
            const bundle = bundles.find((b: any) => b.id === booking.bundleId);
            return {
              ...booking,
              bundleName: bundle?.name || `Bundle ${booking.bundleId}`,
              labName: mockLabs[booking.labId] || `Lab ${booking.labId}`
            };
          } catch {
            return {
              ...booking,
              bundleName: `Bundle ${booking.bundleId}`,
              labName: mockLabs[booking.labId] || `Lab ${booking.labId}`
            };
          }
        }));
        setBookings(enrichedBookings.reverse()); // Most recent first
      }
    } catch (error) {
      console.error("Failed to fetch bookings:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'completed': return 'bg-blue-100 text-blue-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-AE', { 
      weekday: 'short', 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link href="/">
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" data-testid="back-home">
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">My Bookings</h1>
              <p className="text-sm text-gray-500">View and manage your lab test appointments</p>
            </div>
          </div>
          <button
            onClick={fetchBookings}
            className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
            data-testid="refresh-bookings"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : bookings.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg p-12 text-center"
          >
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <FileText className="w-10 h-10 text-gray-400" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">No Bookings Yet</h2>
            <p className="text-gray-500 mb-6">You haven't made any test bookings yet. Start by exploring our tests!</p>
            <Link href="/tests">
              <button className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors" data-testid="browse-tests">
                Browse Tests
              </button>
            </Link>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking, index) => (
              <motion.div
                key={booking.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
                data-testid={`booking-${booking.id}`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  {/* Booking Info */}
                  <div className="flex-1">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        booking.collectionType === 'home' ? 'bg-purple-100' : 'bg-blue-100'
                      }`}>
                        {booking.collectionType === 'home' ? (
                          <Truck className="w-6 h-6 text-purple-600" />
                        ) : (
                          <Building2 className="w-6 h-6 text-blue-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900 text-lg">{booking.bundleName}</h3>
                        <p className="text-sm text-gray-500">{booking.labName}</p>
                        
                        <div className="flex flex-wrap gap-4 mt-3 text-sm">
                          <span className="flex items-center gap-1.5 text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {formatDate(booking.date)}
                          </span>
                          <span className="flex items-center gap-1.5 text-gray-600">
                            <Clock className="w-4 h-4" />
                            {booking.time}
                          </span>
                          {booking.collectionType === 'home' && booking.address && (
                            <span className="flex items-center gap-1.5 text-gray-600">
                              <MapPin className="w-4 h-4" />
                              Home Collection
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Status & Reference */}
                  <div className="flex items-center gap-4 lg:flex-col lg:items-end">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(booking.status)}`}>
                      {booking.status === 'confirmed' && <CheckCircle className="w-3 h-3 inline mr-1" />}
                      {booking.status}
                    </span>
                    <div className="text-right">
                      <p className="text-xs text-gray-400">Reference</p>
                      <p className="font-mono font-bold text-blue-600">{booking.id}</p>
                    </div>
                  </div>
                </div>

                {/* Patient Details (Expandable) */}
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-400 text-xs mb-1">Patient Name</p>
                      <p className="font-medium text-gray-700">{booking.patientName}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs mb-1">Phone</p>
                      <p className="font-medium text-gray-700">{booking.patientPhone}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs mb-1">Email</p>
                      <p className="font-medium text-gray-700">{booking.patientEmail}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Quick Actions */}
        {bookings.length > 0 && (
          <div className="mt-8 text-center">
            <Link href="/tests">
              <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-medium hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg" data-testid="book-another">
                Book Another Test
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
