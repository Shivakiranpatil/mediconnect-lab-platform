import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, Package, FlaskConical, Search, DollarSign, Building2 } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Bundle, Test } from "@shared/schema";

export default function AdminCatalogPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [editingBundle, setEditingBundle] = useState<Bundle | null>(null);
  const [editingTest, setEditingTest] = useState<Test | null>(null);
  const [isCreatingBundle, setIsCreatingBundle] = useState(false);
  const [isCreatingTest, setIsCreatingTest] = useState(false);
  
  // Lab pricing modal states
  const [pricingBundle, setPricingBundle] = useState<Bundle | null>(null);
  const [pricingTest, setPricingTest] = useState<Test | null>(null);

  // Fetch from Supabase
  const { data: bundles = [], refetch: refetchBundles } = useQuery<Bundle[]>({
    queryKey: ['supabase-bundles'],
    queryFn: async () => {
      const res = await fetch('/api/supabase/bundles');
      if (!res.ok) throw new Error('Failed to fetch bundles');
      return res.json();
    }
  });

  const { data: tests = [], refetch: refetchTests } = useQuery<Test[]>({
    queryKey: ['supabase-tests'],
    queryFn: async () => {
      const res = await fetch('/api/supabase/tests');
      if (!res.ok) throw new Error('Failed to fetch tests');
      return res.json();
    }
  });

  const { data: labs = [] } = useQuery({
    queryKey: ['supabase-labs'],
    queryFn: async () => {
      const res = await fetch('/api/supabase/labs');
      if (!res.ok) throw new Error('Failed to fetch labs');
      return res.json();
    }
  });

  const saveBundleMutation = useMutation({
    mutationFn: async (bundle: Partial<Bundle>) => {
      const method = bundle.id ? 'PUT' : 'POST';
      const url = bundle.id ? `/api/supabase/bundles/${bundle.id}` : '/api/supabase/bundles';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bundle),
      });
      if (!res.ok) throw new Error('Failed to save bundle');
      return res.json();
    },
    onSuccess: () => {
      refetchBundles();
      setEditingBundle(null);
      setIsCreatingBundle(false);
      toast({ title: "Bundle saved successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to save bundle", variant: "destructive" });
    },
  });

  const saveTestMutation = useMutation({
    mutationFn: async (test: Partial<Test>) => {
      const method = test.id ? 'PUT' : 'POST';
      const url = test.id ? `/api/supabase/tests/${test.id}` : '/api/supabase/tests';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(test),
      });
      if (!res.ok) throw new Error('Failed to save test');
      return res.json();
    },
    onSuccess: () => {
      refetchTests();
      setEditingTest(null);
      setIsCreatingTest(false);
      toast({ title: "Test saved successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to save test", variant: "destructive" });
    },
  });

  // Transform Supabase data to match expected format
  const transformedBundles = bundles.map((b: any) => ({
    ...b,
    basePrice: b.base_price,
    testsIncluded: b.tests_included,
    isActive: b.is_active,
    isPopular: b.is_popular,
  }));

  const transformedTests = tests.map((t: any) => ({
    ...t,
    basePrice: t.base_price,
    turnaroundHours: t.turnaround_hours,
    isActive: t.is_active,
    fastingRequired: t.fasting_required,
    sampleType: t.sample_type,
  }));

  // Use Supabase data or fallback to empty
  const displayLabs = labs.length > 0 ? labs : [];
  const displayBundles = transformedBundles.length > 0 ? transformedBundles : bundles;
  const displayTests = transformedTests.length > 0 ? transformedTests : tests;

  const filteredBundles = displayBundles.filter((b: any) => 
    b.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTests = displayTests.filter((t: any) => 
    t.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout title="Catalog" subtitle="Manage test bundles and individual tests">
      <Tabs defaultValue="bundles" className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList className="bg-slate-800">
            <TabsTrigger value="bundles" className="data-[state=active]:bg-blue-600" data-testid="tab-bundles">
              <Package className="w-4 h-4 mr-2" />
              Bundles ({filteredBundles.length})
            </TabsTrigger>
            <TabsTrigger value="tests" className="data-[state=active]:bg-blue-600" data-testid="tab-tests">
              <FlaskConical className="w-4 h-4 mr-2" />
              Individual Tests
            </TabsTrigger>
          </TabsList>
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64 bg-slate-800 border-slate-700 text-white"
                data-testid="input-search-catalog"
              />
            </div>
          </div>
        </div>

        <TabsContent value="bundles" className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setIsCreatingBundle(true)} className="bg-blue-600 hover:bg-blue-700" data-testid="button-add-bundle">
              <Plus className="w-4 h-4 mr-2" />
              Add Bundle
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBundles.map((bundle) => (
              <div
                key={bundle.id}
                className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 hover:border-slate-600 transition-colors"
                data-testid={`card-bundle-${bundle.id}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                    <Package className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-center gap-2">
                    {bundle.isPopular && (
                      <Badge className="bg-amber-500/20 text-amber-400">Popular</Badge>
                    )}
                    <Badge className={bundle.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}>
                      {bundle.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{bundle.name}</h3>
                <p className="text-sm text-slate-400 mb-4 line-clamp-2">{bundle.description}</p>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-2xl font-bold text-white">AED {bundle.basePrice}</p>
                  <Button size="icon" variant="ghost" className="text-slate-400 hover:text-white" onClick={() => setEditingBundle(bundle)} data-testid={`button-edit-bundle-${bundle.id}`}>
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700" 
                  onClick={() => setPricingBundle(bundle)}
                  data-testid={`button-lab-pricing-bundle-${bundle.id}`}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Manage Lab Pricing
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tests" className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setIsCreatingTest(true)} className="bg-blue-600 hover:bg-blue-700" data-testid="button-add-test">
              <Plus className="w-4 h-4 mr-2" />
              Add Individual Test
            </Button>
          </div>

          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-700/30">
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Test Name</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Category</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Base Price</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Biomarkers</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Turnaround</th>
                  <th className="text-left text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Status</th>
                  <th className="text-right text-xs font-medium text-slate-400 uppercase tracking-wider px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredTests.map((test) => (
                  <tr key={test.id} className="hover:bg-slate-700/20" data-testid={`row-test-${test.id}`}>
                    <td className="px-6 py-4">
                      <p className="font-medium text-white">{test.name}</p>
                      <p className="text-sm text-slate-400 line-clamp-1">{test.description}</p>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="border-slate-600 text-slate-300">{test.category}</Badge>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-white">
                      AED {(test as any).basePrice || '-'}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">
                      {Array.isArray(test.biomarkers) ? test.biomarkers.slice(0, 3).join(', ') : '-'}
                      {Array.isArray(test.biomarkers) && test.biomarkers.length > 3 && (
                        <span className="text-slate-500"> +{test.biomarkers.length - 3} more</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">{test.turnaroundHours}h</td>
                    <td className="px-6 py-4">
                      <Badge className={test.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}>
                        {test.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button size="sm" variant="ghost" className="text-slate-400 hover:text-white" onClick={() => setPricingTest(test)} data-testid={`button-lab-pricing-test-${test.id}`} title="Lab Pricing">
                          <DollarSign className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-slate-400 hover:text-white" onClick={() => setEditingTest(test)} data-testid={`button-edit-test-${test.id}`} title="Edit Test">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={!!editingBundle || isCreatingBundle} onOpenChange={() => { setEditingBundle(null); setIsCreatingBundle(false); }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingBundle ? 'Edit Bundle' : 'Create Bundle'}</DialogTitle>
          </DialogHeader>
          <BundleForm 
            bundle={editingBundle} 
            onSave={(data) => saveBundleMutation.mutate(data)}
            isPending={saveBundleMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingTest || isCreatingTest} onOpenChange={() => { setEditingTest(null); setIsCreatingTest(false); }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>{editingTest ? 'Edit Test' : 'Create Test'}</DialogTitle>
          </DialogHeader>
          <TestForm 
            test={editingTest} 
            onSave={(data) => saveTestMutation.mutate(data)}
            isPending={saveTestMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Lab Pricing Modal for Bundles */}
      <Dialog open={!!pricingBundle} onOpenChange={() => setPricingBundle(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Lab Pricing - {pricingBundle?.name}</DialogTitle>
          </DialogHeader>
          {pricingBundle && <LabPricingForm item={pricingBundle} type="bundle" onClose={() => setPricingBundle(null)} />}
        </DialogContent>
      </Dialog>

      {/* Lab Pricing Modal for Tests */}
      <Dialog open={!!pricingTest} onOpenChange={() => setPricingTest(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Lab Pricing - {pricingTest?.name}</DialogTitle>
          </DialogHeader>
          {pricingTest && <LabPricingForm item={pricingTest} type="test" onClose={() => setPricingTest(null)} />}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function BundleForm({ bundle, onSave, isPending }: { bundle: Bundle | null; onSave: (data: Partial<Bundle>) => void; isPending: boolean }) {
  const categories = [
    'Premium', 'Basic', 'Heart Health', "Women's Health", "Men's Health", 
    'Diabetes', 'Thyroid', 'Energy', 'Senior Care', 'Sports & Fitness'
  ];
  
  const [formData, setFormData] = useState({
    name: bundle?.name || '',
    description: bundle?.description || '',
    basePrice: bundle?.basePrice || '',
    originalPrice: (bundle as any)?.originalPrice || '',
    category: bundle?.category || '',
    isActive: bundle?.isActive ?? true,
    isPopular: bundle?.isPopular ?? false,
    turnaroundHours: (bundle as any)?.turnaroundHours || '24-48',
    homeCollection: (bundle as any)?.homeCollection ?? true,
    fastingRequired: (bundle as any)?.fastingRequired ?? false,
    fastingHours: (bundle as any)?.fastingHours || '',
  });
  
  // Mock tests for selection
  const availableTests = [
    { id: '1', name: 'Complete Blood Count', category: 'Blood' },
    { id: '2', name: 'Lipid Panel', category: 'Heart' },
    { id: '3', name: 'Thyroid Function (TSH, T3, T4)', category: 'Thyroid' },
    { id: '4', name: 'HbA1c', category: 'Diabetes' },
    { id: '5', name: 'Liver Function (LFT)', category: 'Liver' },
    { id: '6', name: 'Kidney Function (KFT)', category: 'Kidney' },
    { id: '7', name: 'Vitamin D', category: 'Vitamins' },
    { id: '8', name: 'Vitamin B12', category: 'Vitamins' },
    { id: '9', name: 'Iron Studies', category: 'Minerals' },
    { id: '10', name: 'Testosterone', category: 'Hormones' },
    { id: '11', name: 'Fasting Glucose', category: 'Diabetes' },
    { id: '12', name: 'Uric Acid', category: 'Kidney' },
    { id: '13', name: 'Calcium', category: 'Minerals' },
    { id: '14', name: 'Ferritin', category: 'Blood' },
    { id: '15', name: 'ESR', category: 'Blood' },
  ];
  
  const [selectedTests, setSelectedTests] = useState<string[]>([]);

  const toggleTest = (testId: string) => {
    setSelectedTests(prev => 
      prev.includes(testId) 
        ? prev.filter(id => id !== testId)
        : [...prev, testId]
    );
  };

  return (
    <div className="space-y-4 max-h-[70vh] overflow-auto">
      <div>
        <Label>Package Name *</Label>
        <Input 
          value={formData.name} 
          onChange={(e) => setFormData({ ...formData, name: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="e.g., Full Body Checkup Premium"
          data-testid="input-bundle-name" 
        />
      </div>
      
      <div>
        <Label>Description</Label>
        <Textarea 
          value={formData.description} 
          onChange={(e) => setFormData({ ...formData, description: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="Describe what this package covers and who it's ideal for..."
          data-testid="input-bundle-description" 
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Category *</Label>
          <select 
            value={formData.category} 
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full h-10 px-3 rounded-md bg-slate-700 border border-slate-600 text-white text-sm"
            data-testid="select-bundle-category"
          >
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div>
          <Label>Turnaround Time</Label>
          <Input 
            value={formData.turnaroundHours} 
            onChange={(e) => setFormData({ ...formData, turnaroundHours: e.target.value })} 
            className="bg-slate-700 border-slate-600" 
            placeholder="e.g., 24-48 hours"
            data-testid="input-bundle-turnaround" 
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Selling Price (AED) *</Label>
          <Input 
            type="number" 
            value={formData.basePrice} 
            onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })} 
            className="bg-slate-700 border-slate-600" 
            placeholder="e.g., 699"
            data-testid="input-bundle-price" 
          />
        </div>
        <div>
          <Label>Original Price (AED)</Label>
          <Input 
            type="number" 
            value={formData.originalPrice} 
            onChange={(e) => setFormData({ ...formData, originalPrice: e.target.value })} 
            className="bg-slate-700 border-slate-600" 
            placeholder="e.g., 899 (for showing discount)"
            data-testid="input-bundle-original-price" 
          />
        </div>
      </div>
      
      {formData.basePrice && formData.originalPrice && parseInt(formData.originalPrice) > parseInt(formData.basePrice) && (
        <p className="text-sm text-emerald-400">
          💰 {Math.round((1 - parseInt(formData.basePrice) / parseInt(formData.originalPrice)) * 100)}% discount will be shown to customers
        </p>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
          <Switch 
            checked={formData.fastingRequired} 
            onCheckedChange={(c) => setFormData({ ...formData, fastingRequired: c })} 
            data-testid="switch-bundle-fasting" 
          />
          <Label className="cursor-pointer">Fasting Required</Label>
        </div>
        {formData.fastingRequired && (
          <div>
            <Label>Fasting Hours</Label>
            <Input 
              value={formData.fastingHours} 
              onChange={(e) => setFormData({ ...formData, fastingHours: e.target.value })} 
              className="bg-slate-700 border-slate-600" 
              placeholder="e.g., 10-12"
              data-testid="input-bundle-fasting-hours" 
            />
          </div>
        )}
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
          <Switch checked={formData.isActive} onCheckedChange={(c) => setFormData({ ...formData, isActive: c })} data-testid="switch-bundle-active" />
          <Label className="cursor-pointer">Active</Label>
        </div>
        <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
          <Switch checked={formData.isPopular} onCheckedChange={(c) => setFormData({ ...formData, isPopular: c })} data-testid="switch-bundle-popular" />
          <Label className="cursor-pointer">Popular Badge</Label>
        </div>
        <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
          <Switch checked={formData.homeCollection} onCheckedChange={(c) => setFormData({ ...formData, homeCollection: c })} data-testid="switch-bundle-home" />
          <Label className="cursor-pointer">Home Collection</Label>
        </div>
      </div>
      
      {/* Test Selection Section */}
      <div className="border-t border-slate-700 pt-4">
        <Label className="text-base font-semibold mb-3 block">Include Tests in Package</Label>
        <p className="text-sm text-slate-400 mb-3">Select which tests are included in this package ({selectedTests.length} selected)</p>
        <div className="grid grid-cols-2 gap-2 max-h-48 overflow-auto bg-slate-700/30 rounded-lg p-3">
          {availableTests.map(test => (
            <label 
              key={test.id}
              className={`flex items-center gap-2 p-2 rounded cursor-pointer transition-colors ${
                selectedTests.includes(test.id) ? 'bg-blue-600/30' : 'hover:bg-slate-600/50'
              }`}
            >
              <Checkbox 
                checked={selectedTests.includes(test.id)}
                onCheckedChange={() => toggleTest(test.id)}
              />
              <div>
                <span className="text-sm text-white">{test.name}</span>
                <span className="text-xs text-slate-400 ml-2">({test.category})</span>
              </div>
            </label>
          ))}
        </div>
      </div>
      
      <DialogFooter className="pt-4 border-t border-slate-700">
        <Button 
          onClick={() => onSave({ 
            ...bundle, 
            ...formData,
            testsIncluded: selectedTests.length,
          })} 
          disabled={isPending || !formData.name || !formData.category || !formData.basePrice} 
          className="bg-blue-600 hover:bg-blue-700" 
          data-testid="button-save-bundle"
        >
          {isPending ? 'Saving...' : bundle ? 'Update Package' : 'Create Package'}
        </Button>
      </DialogFooter>
    </div>
  );
}

function TestForm({ test, onSave, isPending }: { test: Test | null; onSave: (data: Partial<Test>) => void; isPending: boolean }) {
  const categories = [
    'Blood', 'Heart', 'Diabetes', 'Thyroid', 'Liver', 'Kidney', 
    'Vitamins', 'Hormones', 'Minerals', 'Allergy', 'Infection', 'Cancer Markers'
  ];
  
  const [formData, setFormData] = useState({
    name: test?.name || '',
    description: test?.description || '',
    category: test?.category || '',
    preparation: test?.preparation || '',
    turnaroundHours: test?.turnaroundHours || 24,
    isActive: test?.isActive ?? true,
    basePrice: (test as any)?.basePrice || '',
    biomarkers: Array.isArray(test?.biomarkers) ? test.biomarkers.join(', ') : '',
    sampleType: (test as any)?.sampleType || 'Blood',
    fastingRequired: (test as any)?.fastingRequired ?? false,
    fastingHours: (test as any)?.fastingHours || '',
  });

  const sampleTypes = ['Blood', 'Urine', 'Stool', 'Saliva', 'Swab'];

  return (
    <div className="space-y-4 max-h-[70vh] overflow-auto">
      <div>
        <Label>Test Name *</Label>
        <Input 
          value={formData.name} 
          onChange={(e) => setFormData({ ...formData, name: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="e.g., Complete Blood Count (CBC)"
          data-testid="input-test-name" 
        />
      </div>
      
      <div>
        <Label>Description</Label>
        <Textarea 
          value={formData.description} 
          onChange={(e) => setFormData({ ...formData, description: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="Brief description of what this test measures..."
          data-testid="input-test-description" 
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Category *</Label>
          <select 
            value={formData.category} 
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full h-10 px-3 rounded-md bg-slate-700 border border-slate-600 text-white text-sm"
            data-testid="select-test-category"
          >
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div>
          <Label>Base Price (AED) *</Label>
          <Input 
            type="number" 
            value={formData.basePrice} 
            onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })} 
            className="bg-slate-700 border-slate-600" 
            placeholder="e.g., 99"
            data-testid="input-test-price" 
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Sample Type</Label>
          <select 
            value={formData.sampleType} 
            onChange={(e) => setFormData({ ...formData, sampleType: e.target.value })}
            className="w-full h-10 px-3 rounded-md bg-slate-700 border border-slate-600 text-white text-sm"
            data-testid="select-test-sample-type"
          >
            {sampleTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        <div>
          <Label>Turnaround (hours)</Label>
          <Input 
            type="number" 
            value={formData.turnaroundHours} 
            onChange={(e) => setFormData({ ...formData, turnaroundHours: parseInt(e.target.value) || 24 })} 
            className="bg-slate-700 border-slate-600" 
            placeholder="24"
            data-testid="input-test-turnaround" 
          />
        </div>
      </div>

      <div>
        <Label>Biomarkers / Parameters</Label>
        <Textarea 
          value={formData.biomarkers} 
          onChange={(e) => setFormData({ ...formData, biomarkers: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="Enter biomarkers separated by commas (e.g., RBC, WBC, Platelets, Hemoglobin)"
          rows={2}
          data-testid="input-test-biomarkers" 
        />
        <p className="text-xs text-slate-400 mt-1">Separate multiple biomarkers with commas</p>
      </div>

      <div>
        <Label>Preparation Instructions</Label>
        <Textarea 
          value={formData.preparation} 
          onChange={(e) => setFormData({ ...formData, preparation: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="e.g., No fasting required, Avoid alcohol 24 hours before"
          data-testid="input-test-preparation" 
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
          <Switch 
            checked={formData.fastingRequired} 
            onCheckedChange={(c) => setFormData({ ...formData, fastingRequired: c })} 
            data-testid="switch-test-fasting" 
          />
          <Label className="cursor-pointer">Fasting Required</Label>
        </div>
        {formData.fastingRequired && (
          <div>
            <Label>Fasting Hours</Label>
            <Input 
              type="number" 
              value={formData.fastingHours} 
              onChange={(e) => setFormData({ ...formData, fastingHours: e.target.value })} 
              className="bg-slate-700 border-slate-600" 
              placeholder="e.g., 8-12"
              data-testid="input-test-fasting-hours" 
            />
          </div>
        )}
      </div>

      <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
        <Switch 
          checked={formData.isActive} 
          onCheckedChange={(c) => setFormData({ ...formData, isActive: c })} 
          data-testid="switch-test-active" 
        />
        <Label className="cursor-pointer">Active (visible to customers)</Label>
      </div>

      <DialogFooter className="pt-4 border-t border-slate-700">
        <Button 
          onClick={() => onSave({ 
            ...test, 
            ...formData,
            biomarkers: formData.biomarkers.split(',').map(b => b.trim()).filter(Boolean),
            basePrice: parseInt(formData.basePrice) || 0,
          })} 
          disabled={isPending || !formData.name || !formData.category} 
          className="bg-blue-600 hover:bg-blue-700" 
          data-testid="button-save-test"
        >
          {isPending ? 'Saving...' : test ? 'Update Test' : 'Create Test'}
        </Button>
      </DialogFooter>
    </div>
  );
}

// Lab Pricing Form Component
function LabPricingForm({ item, type, onClose }: { item: Bundle | Test; type: 'bundle' | 'test'; onClose: () => void }) {
  const [labPricing, setLabPricing] = useState<Record<string, { price: string; originalPrice: string; turnaroundHours: string; isActive: boolean }>>({
    '1': { price: '599', originalPrice: '699', turnaroundHours: '48', isActive: true },
    '2': { price: '649', originalPrice: '699', turnaroundHours: '48', isActive: true },
    '3': { price: '699', originalPrice: '699', turnaroundHours: '48', isActive: true },
    '4': { price: '899', originalPrice: '899', turnaroundHours: '24', isActive: false },
  });

  const handlePriceChange = (labId: string, field: string, value: string | boolean) => {
    setLabPricing(prev => ({
      ...prev,
      [labId]: { ...prev[labId], [field]: value }
    }));
  };

  const handleSave = () => {
    // In production, this would make an API call
    console.log('Saving lab pricing:', labPricing);
    onClose();
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-400">
        Set specific prices for each lab partner. Labs without pricing will use the base price.
      </p>
      
      <div className="space-y-4 max-h-96 overflow-auto">
        {mockLabs.map(lab => (
          <div key={lab.id} className="bg-slate-700/50 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-white">{lab.name}</h4>
                  <p className="text-xs text-slate-400">Rating: {lab.rating}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch 
                  checked={labPricing[lab.id]?.isActive ?? false}
                  onCheckedChange={(c) => handlePriceChange(lab.id, 'isActive', c)}
                />
                <span className="text-xs text-slate-400">Active</span>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-xs">Price (AED)</Label>
                <Input 
                  type="number"
                  value={labPricing[lab.id]?.price || ''}
                  onChange={(e) => handlePriceChange(lab.id, 'price', e.target.value)}
                  className="bg-slate-600 border-slate-500 h-9"
                  placeholder="0"
                />
              </div>
              <div>
                <Label className="text-xs">Original Price</Label>
                <Input 
                  type="number"
                  value={labPricing[lab.id]?.originalPrice || ''}
                  onChange={(e) => handlePriceChange(lab.id, 'originalPrice', e.target.value)}
                  className="bg-slate-600 border-slate-500 h-9"
                  placeholder="0"
                />
              </div>
              <div>
                <Label className="text-xs">Turnaround (hrs)</Label>
                <Input 
                  type="number"
                  value={labPricing[lab.id]?.turnaroundHours || ''}
                  onChange={(e) => handlePriceChange(lab.id, 'turnaroundHours', e.target.value)}
                  className="bg-slate-600 border-slate-500 h-9"
                  placeholder="24"
                />
              </div>
            </div>
            
            {labPricing[lab.id]?.price && labPricing[lab.id]?.originalPrice && 
             parseInt(labPricing[lab.id].price) < parseInt(labPricing[lab.id].originalPrice) && (
              <p className="text-xs text-emerald-400 mt-2">
                💰 {Math.round((1 - parseInt(labPricing[lab.id].price) / parseInt(labPricing[lab.id].originalPrice)) * 100)}% discount
              </p>
            )}
          </div>
        ))}
      </div>
      
      <DialogFooter>
        <Button variant="outline" onClick={onClose} className="border-slate-600">Cancel</Button>
        <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
          Save Pricing
        </Button>
      </DialogFooter>
    </div>
  );
}
