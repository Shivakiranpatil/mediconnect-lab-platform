import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { 
  Trash2, User, Phone, Mail, MapPin, 
  CheckCircle, ArrowLeft, Home, Shield, Clock, Building2, Truck,
  Lock, ChevronRight, Beaker
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";

// Generate or get device ID for guest tracking
const getDeviceId = () => {
  let deviceId = localStorage.getItem('mediconnect_device_id');
  if (!deviceId) {
    deviceId = 'device_' + Math.random().toString(36).substring(2, 15);
    localStorage.setItem('mediconnect_device_id', deviceId);
  }
  return deviceId;
};

export default function CheckoutPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { items, removeItem, getCartTotal, clearCart } = useCart();
  const { user, isAuthenticated, signInWithGoogle } = useAuth();
  
  const [step, setStep] = useState(1); // 1: Review, 2: Details, 3: Payment
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [guestProfileId, setGuestProfileId] = useState<string | null>(null);
  
  // Form state
  const [patientName, setPatientName] = useState("");
  const [patientPhone, setPatientPhone] = useState("");
  const [patientEmail, setPatientEmail] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("Dubai");
  const [area, setArea] = useState("");
  const [buildingName, setBuildingName] = useState("");
  const [apartmentNo, setApartmentNo] = useState("");
  
  // Login form
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  
  // Payment - only Pay at Lab/Home
  const [submitting, setSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [bookingRef, setBookingRef] = useState("");

  // Load saved address on mount
  // Load saved address and user data on mount
  useEffect(() => {
    loadSavedAddress();
  }, []);

  // Pre-fill from Firebase user when authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.displayName && !patientName) setPatientName(user.displayName);
      if (user.email && !patientEmail) setPatientEmail(user.email);
      if (user.phoneNumber && !patientPhone) setPatientPhone(user.phoneNumber);
    }
  }, [isAuthenticated, user]);

  const loadSavedAddress = async () => {
    try {
      const deviceId = getDeviceId();
      const savedEmail = localStorage.getItem('mediconnect_guest_email');
      
      // Try to load guest profile from Supabase
      const params = new URLSearchParams();
      params.append('device_id', deviceId);
      if (savedEmail) params.append('email', savedEmail);
      
      const response = await fetch(`/api/supabase/guest-profile?${params}`);
      if (response.ok) {
        const profile = await response.json();
        if (profile) {
          setGuestProfileId(profile.id);
          if (profile.name && !patientName) setPatientName(profile.name);
          if (profile.email && !patientEmail) setPatientEmail(profile.email);
          if (profile.phone && !patientPhone) setPatientPhone(profile.phone);
          if (profile.address) setAddress(profile.address);
          if (profile.city) setCity(profile.city);
          if (profile.area) setArea(profile.area);
          if (profile.building) setBuildingName(profile.building);
          if (profile.flat_number) setApartmentNo(profile.flat_number);
        }
      }
    } catch (error) {
      console.error('Failed to load saved address:', error);
    }
  };

  const saveGuestProfile = async () => {
    try {
      const deviceId = getDeviceId();
      const profile = {
        device_id: deviceId,
        name: patientName,
        email: patientEmail,
        phone: patientPhone,
        address,
        city,
        area,
        building: buildingName,
        flat_number: apartmentNo,
      };
      
      const response = await fetch('/api/supabase/guest-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile),
      });
      
      if (response.ok) {
        const saved = await response.json();
        setGuestProfileId(saved.id);
        // Save email for future reference
        if (patientEmail) {
          localStorage.setItem('mediconnect_guest_email', patientEmail);
        }
      }
    } catch (error) {
      console.error('Failed to save guest profile:', error);
    }
  };

  // Check if any item has home collection
  const hasHomeCollection = items.some(item => item.homeCollection);
  const cartTotal = getCartTotal();
  const finalTotal = cartTotal;

  // Handle Google sign in from checkout
  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
      toast({ title: "Signed in successfully!" });
    } catch (error) {
      toast({ title: "Sign in failed", variant: "destructive" });
    }
  };

  // Mock login (keeping for email/password)
  const handleLogin = () => {
    if (loginEmail && loginPassword) {
      setIsLoggedIn(true);
      setPatientEmail(loginEmail);
      setShowLoginForm(false);
      toast({ title: "Logged in successfully!" });
    }
  };

  // Mock signup
  const handleSignup = () => {
    if (loginEmail && loginPassword) {
      setIsLoggedIn(true);
      setPatientEmail(loginEmail);
      setShowLoginForm(false);
      toast({ title: "Account created successfully!" });
    }
  };

  const handleSubmitOrder = async () => {
    // Validate
    if (!patientName || !patientPhone || !patientEmail) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Address is always required for FREE home/office collection
    if (!address || !area) {
      toast({
        title: "Address Required",
        description: "Please enter your collection address (home/office)",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);

    try {
      // Save guest profile first
      await saveGuestProfile();
      
      // Create booking in Supabase for each item
      for (const item of items) {
        const bookingData = {
          bundle_name: item.name,
          lab_name: item.labName || 'TBD',
          price: item.price,
          status: 'Pending',
          appointment_date: item.appointmentDate,
          appointment_time: item.appointmentTime,
          patient_name: patientName,
          patient_email: patientEmail,
          patient_phone: patientPhone,
          patient_address: `${address}, ${buildingName ? buildingName + ', ' : ''}${apartmentNo ? 'Flat ' + apartmentNo + ', ' : ''}${area}, ${city}`,
          payment_method: 'Pay at Home/Lab',
        };
        
        await fetch('/api/supabase/bookings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bookingData),
        });
      }
      
      const ref = `MC-${Date.now().toString(36).toUpperCase()}`;
      setBookingRef(ref);
      setBookingComplete(true);
      clearCart();
      
      toast({
        title: "Booking Confirmed! ✅",
        description: `Your booking reference is ${ref}`,
      });
    } catch (error) {
      console.error('Booking error:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Empty cart state
  if (items.length === 0 && !bookingComplete) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <Beaker className="w-20 h-20 text-gray-300 mx-auto mb-6" />
          <h1 className="text-2xl font-bold text-gray-900 mb-3">Your Test Basket is Empty</h1>
          <p className="text-gray-600 mb-8">Add some tests or packages to get started</p>
          <Link href="/tests">
            <button className="px-8 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700">
              Browse Tests
            </button>
          </Link>
        </div>
        <MobileBottomNav />
      </div>
    );
  }

  // Booking complete state
  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
        <Navbar />
        <div className="max-w-lg mx-auto px-4 py-12">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-xl p-8 text-center"
          >
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h1>
            <p className="text-gray-600 mb-6">Your tests have been successfully booked</p>
            
            <div className="bg-gray-50 rounded-2xl p-6 mb-6 text-left">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-500">Booking Reference</span>
                  <span className="font-bold text-blue-600">{bookingRef}</span>
                </div>
                <div className="flex justify-between border-t pt-3 mt-3">
                  <span className="text-gray-500">Total Paid</span>
                  <span className="font-bold text-lg">AED {finalTotal}</span>
                </div>
              </div>
            </div>
            
            <p className="text-sm text-gray-500 mb-6">
              A confirmation email has been sent to <strong>{patientEmail}</strong>
            </p>
            
            <div className="flex gap-3">
              <Link href="/" className="flex-1">
                <button className="w-full py-3 px-4 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 flex items-center justify-center gap-2">
                  <Home className="w-4 h-4" />
                  Home
                </button>
              </Link>
              <Link href="/bookings" className="flex-1">
                <button className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 flex items-center justify-center gap-2">
                  View Bookings
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
        <MobileBottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24 sm:pb-0">
      <Navbar />
      
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-blue-600 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Browse More Tests</span>
        </button>

        {/* Page Title */}
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6" data-testid="checkout-title">
          Book Appointment ({items.length} {items.length === 1 ? 'test' : 'tests'})
        </h1>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[
            { num: 1, label: 'Review' },
            { num: 2, label: 'Details' },
            { num: 3, label: 'Payment' }
          ].map((s, i) => (
            <div key={s.num} className="flex items-center">
              <div 
                className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                  step >= s.num 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-sm font-bold">
                  {step > s.num ? '✓' : s.num}
                </span>
                <span className="hidden sm:inline font-medium">{s.label}</span>
              </div>
              {i < 2 && (
                <ChevronRight className={`w-5 h-5 mx-2 ${step > s.num ? 'text-blue-600' : 'text-gray-300'}`} />
              )}
            </div>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main Content */}
          <div className="flex-1">
            {/* Step 1: Review Cart */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                  <div className="p-4 border-b bg-gray-50">
                    <h2 className="font-bold text-gray-900">Your Tests</h2>
                  </div>
                  
                  <div className="divide-y">
                    {items.map((item) => (
                      <div key={item.id} className="p-4" data-testid={`test-item-${item.id}`}>
                        <div className="flex gap-4">
                          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Beaker className="w-8 h-8 text-white" />
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <h3 className="font-bold text-gray-900">{item.name}</h3>
                                {item.testCount && (
                                  <p className="text-sm text-gray-500">{item.testCount} tests included</p>
                                )}
                              </div>
                              <button 
                                onClick={() => removeItem(item.id)}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            
                            {/* Selected options */}
                            <div className="mt-2 flex flex-wrap gap-2">
                              {item.selectedLab && (
                                <span className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded-full flex items-center gap-1">
                                  <Building2 className="w-3 h-3" />
                                  {item.selectedLab.name}
                                </span>
                              )}
                              {item.selectedSlot && (
                                <span className="text-xs bg-green-50 text-green-600 px-2 py-1 rounded-full flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {item.selectedSlot}
                                </span>
                              )}
                              {item.homeCollection && (
                                <span className="text-xs bg-purple-50 text-purple-600 px-2 py-1 rounded-full flex items-center gap-1">
                                  <Truck className="w-3 h-3" />
                                  Home Collection
                                </span>
                              )}
                            </div>
                            
                            {/* Addons */}
                            {item.addons && item.addons.length > 0 && (
                              <div className="mt-2">
                                <p className="text-xs text-gray-500 mb-1">Add-ons:</p>
                                <div className="flex flex-wrap gap-1">
                                  {item.addons.map(addon => (
                                    <span key={addon.id} className="text-xs bg-orange-50 text-orange-600 px-2 py-0.5 rounded">
                                      + {addon.name} (AED {addon.price})
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {/* Price */}
                            <div className="mt-3 flex items-baseline gap-2">
                              <span className="text-xl font-bold text-blue-600">
                                AED {item.selectedLab?.price || item.price}
                              </span>
                              {item.originalPrice && item.originalPrice > item.price && (
                                <span className="text-sm text-gray-400 line-through">
                                  AED {item.originalPrice}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors"
                >
                  Proceed to Patient Details
                </button>
              </motion.div>
            )}

            {/* Step 2: Account & Details */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                {/* Login/Signup Section */}
                {!isLoggedIn && (
                  <div className="bg-white rounded-2xl shadow-lg p-6">
                    <h2 className="font-bold text-gray-900 mb-4">Account</h2>
                    
                    {!showLoginForm ? (
                      <div className="flex flex-col sm:flex-row gap-3">
                        <button
                          onClick={() => setShowLoginForm(true)}
                          className="flex-1 py-3 px-4 border-2 border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-50"
                        >
                          Login
                        </button>
                        <button
                          onClick={() => setShowLoginForm(true)}
                          className="flex-1 py-3 px-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700"
                        >
                          Sign Up
                        </button>
                        <span className="text-center text-gray-500 self-center">or</span>
                        <button
                          onClick={() => {/* Continue as guest */}}
                          className="flex-1 py-3 px-4 text-gray-600 hover:text-gray-900"
                        >
                          Book as Guest
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                          <input
                            type="email"
                            value={loginEmail}
                            onChange={(e) => setLoginEmail(e.target.value)}
                            placeholder="your@email.com"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                          <input
                            type="password"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            placeholder="Enter password"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div className="flex gap-3">
                          <button
                            onClick={handleLogin}
                            className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700"
                          >
                            Login
                          </button>
                          <button
                            onClick={handleSignup}
                            className="flex-1 py-3 border-2 border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-50"
                          >
                            Sign Up
                          </button>
                        </div>
                        <button
                          onClick={() => setShowLoginForm(false)}
                          className="w-full text-gray-500 text-sm hover:text-gray-700"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Patient Details */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <h2 className="font-bold text-gray-900 mb-4">Patient Details</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          value={patientName}
                          onChange={(e) => setPatientName(e.target.value)}
                          placeholder="Enter your full name"
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                          data-testid="input-name"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="tel"
                          value={patientPhone}
                          onChange={(e) => setPatientPhone(e.target.value)}
                          placeholder="+971 XX XXX XXXX"
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                          data-testid="input-phone"
                        />
                      </div>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="email"
                          value={patientEmail}
                          onChange={(e) => setPatientEmail(e.target.value)}
                          placeholder="your@email.com"
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                          data-testid="input-email"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Collection Address - Always required */}
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-bold text-gray-900 flex items-center gap-2">
                      <Truck className="w-5 h-5 text-green-600" />
                      Collection Address
                    </h2>
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded">FREE Home/Office</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                      >
                        <option>Dubai</option>
                        <option>Abu Dhabi</option>
                        <option>Sharjah</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Area *</label>
                      <input
                        type="text"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        placeholder="e.g., Dubai Marina"
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                        data-testid="input-area"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Building Name</label>
                      <input
                        type="text"
                        value={buildingName}
                        onChange={(e) => setBuildingName(e.target.value)}
                        placeholder="Building name"
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Apt/Villa No.</label>
                      <input
                        type="text"
                        value={apartmentNo}
                        onChange={(e) => setApartmentNo(e.target.value)}
                        placeholder="Apartment number"
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Address *</label>
                      <textarea
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Enter your complete address with landmarks (where our technician should visit)"
                        rows={2}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500"
                        data-testid="input-address"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    className="flex-1 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700"
                  >
                    Proceed to Confirmation
                  </button>
                </div>
              </motion.div>
            )}

            {/* Step 3: Payment Confirmation */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <h2 className="font-bold text-gray-900 mb-4">Payment Method</h2>
                  
                  {/* Pay at Home/Office - Single Option */}
                  <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                        <span className="text-2xl">💵</span>
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 text-lg">Pay at Home/Office</h3>
                        <p className="text-green-600 font-medium">Cash or Card accepted</p>
                      </div>
                    </div>
                    
                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-600">No online payment required - pay when our technician visits</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-600">Pay by cash or card - whatever is convenient for you</p>
                      </div>
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-600">FREE home/office collection included with your booking</p>
                      </div>
                    </div>
                  </div>

                  {/* Info Notice */}
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <p className="text-sm text-blue-800 flex items-center gap-2">
                      <Mail className="w-4 h-4 flex-shrink-0" />
                      A booking confirmation will be sent to your email with all the details.
                    </p>
                  </div>
                </div>

                {/* Security badges */}
                <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-1">
                    <Lock className="w-4 h-4 text-green-500" />
                    <span>Secure Booking</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Shield className="w-4 h-4 text-blue-500" />
                    <span>100% Refund Guarantee</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(2)}
                    className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleSubmitOrder}
                    disabled={submitting}
                    className="flex-1 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 disabled:bg-gray-300 flex items-center justify-center gap-2"
                    data-testid="confirm-booking-btn"
                  >
                    {submitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-5 h-5" />
                        Confirm Booking
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:w-[350px]">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-4">
              <h3 className="font-bold text-gray-900 mb-4">Order Summary</h3>
              
              <div className="space-y-3 mb-4">
                {items.map(item => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.name}</span>
                    <span className="font-medium">AED {item.selectedLab?.price || item.price}</span>
                  </div>
                ))}
                
                {items.map(item => item.addons?.map(addon => (
                  <div key={addon.id} className="flex justify-between text-sm text-orange-600">
                    <span>+ {addon.name}</span>
                    <span>AED {addon.price}</span>
                  </div>
                )))}
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span>AED {cartTotal}</span>
                </div>
                <div className="flex justify-between text-sm items-center">
                  <span className="text-gray-600">Home/Office Collection</span>
                  <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-bold rounded">FREE</span>
                </div>
                <div className="flex justify-between font-bold text-lg pt-2 border-t">
                  <span>Total</span>
                  <span className="text-blue-600">AED {finalTotal}</span>
                </div>
                <div className="bg-green-50 rounded-lg p-3 mt-2">
                  <p className="text-xs text-green-700 font-medium flex items-center gap-1">
                    <span>💵</span> Pay at Home/Office - Cash or Card
                  </p>
                </div>
              </div>
              
              {/* Trust badges */}
              <div className="mt-6 pt-4 border-t space-y-2">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Free cancellation up to 2 hrs</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Shield className="w-4 h-4 text-blue-500" />
                  <span>100% refund guarantee</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Lock className="w-4 h-4 text-green-500" />
                  <span>Secure payment</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Bottom Nav */}
      <MobileBottomNav />
    </div>
  );
}
