import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Activity, CheckCircle, Clock, Shield, Beaker, 
  ArrowRight, Heart, Zap, ArrowLeft, Brain
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const thyroidPackages = [
  {
    id: "19",
    name: "Complete Thyroid Panel",
    description: "Comprehensive thyroid assessment including hormones, antibodies, and related markers",
    price: "299",
    originalPrice: "399",
    popular: true,
    testsIncluded: 12,
    turnaround: "24 hours",
    parameters: [
      { category: "Thyroid Hormones", tests: ["TSH", "Free T3", "Free T4", "Total T3", "Total T4"] },
      { category: "Thyroid Antibodies", tests: ["Anti-TPO", "Anti-TG", "TSI (if indicated)"] },
      { category: "Related Markers", tests: ["Vitamin D", "Vitamin B12", "Iron"] },
    ],
    benefits: [
      "Complete thyroid assessment",
      "Autoimmune detection",
      "Related deficiency check",
      "Detailed interpretation"
    ]
  },
  {
    id: "20",
    name: "Basic Thyroid Profile",
    description: "Essential thyroid screening for routine health checkups",
    price: "149",
    originalPrice: "199",
    popular: false,
    testsIncluded: 5,
    turnaround: "24 hours",
    parameters: [
      { category: "Thyroid Hormones", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Blood Count", tests: ["Hemoglobin", "CBC"] },
    ],
    benefits: [
      "Quick screening",
      "Affordable option",
      "Essential markers",
      "Fast results"
    ]
  },
  {
    id: "21",
    name: "Thyroid Autoimmune Panel",
    description: "Specialized panel for suspected Hashimoto's or Graves' disease",
    price: "349",
    originalPrice: "449",
    popular: false,
    testsIncluded: 10,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Thyroid Function", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Autoimmune Markers", tests: ["Anti-TPO", "Anti-TG", "TSI", "TRAb"] },
      { category: "Inflammation", tests: ["ESR", "hs-CRP"] },
    ],
    benefits: [
      "Hashimoto's detection",
      "Graves' disease screening",
      "Autoimmune confirmation",
      "Treatment planning"
    ]
  },
  {
    id: "22",
    name: "Thyroid + Metabolic Panel",
    description: "Combined thyroid and metabolic assessment for weight and energy issues",
    price: "399",
    originalPrice: "499",
    popular: false,
    testsIncluded: 18,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Thyroid", tests: ["Complete Thyroid Panel with Antibodies"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c", "Fasting Insulin"] },
      { category: "Lipid Profile", tests: ["Complete Lipid Panel"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12"] },
    ],
    benefits: [
      "Weight management insight",
      "Energy assessment",
      "Metabolic health check",
      "Comprehensive view"
    ]
  }
];

const individualTests = [
  { name: "TSH (Thyroid Stimulating Hormone)", price: "59", description: "Primary thyroid function marker" },
  { name: "Free T3", price: "69", description: "Active thyroid hormone" },
  { name: "Free T4", price: "69", description: "Main thyroid hormone" },
  { name: "Anti-TPO Antibodies", price: "89", description: "Hashimoto's marker" },
  { name: "Anti-TG Antibodies", price: "89", description: "Thyroid autoimmune marker" },
  { name: "TSI (Thyroid Stimulating Immunoglobulin)", price: "149", description: "Graves' disease marker" },
  { name: "Total T3 & T4", price: "99", description: "Complete hormone levels" },
  { name: "Thyroglobulin", price: "129", description: "Thyroid cancer marker" },
  { name: "Reverse T3", price: "149", description: "Thyroid conversion marker" },
  { name: "Vitamin D", price: "99", description: "Often low in thyroid disorders" },
];

const symptoms = {
  hypothyroid: [
    "Fatigue & tiredness",
    "Weight gain",
    "Feeling cold",
    "Dry skin & hair",
    "Constipation",
    "Depression",
    "Muscle weakness",
    "Memory issues"
  ],
  hyperthyroid: [
    "Weight loss",
    "Rapid heartbeat",
    "Anxiety & nervousness",
    "Tremors",
    "Sweating",
    "Sleep problems",
    "Frequent bowel movements",
    "Eye problems"
  ]
};

export default function ThyroidHealthPage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("19");

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-purple-600 via-purple-700 to-indigo-700 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6" />
              </div>
              <span className="text-purple-200 font-medium">Thyroid Health</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Thyroid Health Screening
            </h1>
            <p className="text-xl text-purple-100 mb-8">
              Comprehensive thyroid testing to assess your metabolism, energy levels, and hormonal balance.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>Complete Hormone Panel</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-400" />
                <span>Results in 24 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-purple-300" />
                <span>Autoimmune Screening</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Symptoms Section */}
      <section className="py-8 bg-purple-50 border-b border-purple-100">
        <div className="container mx-auto px-4">
          <h3 className="font-semibold text-gray-900 mb-4 text-center">Common Thyroid Symptoms</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-xl border border-blue-200">
              <h4 className="font-semibold text-blue-700 mb-3 flex items-center gap-2">
                <span className="text-xl">❄️</span> Underactive Thyroid (Hypothyroid)
              </h4>
              <div className="flex flex-wrap gap-2">
                {symptoms.hypothyroid.map((symptom, i) => (
                  <span key={i} className="text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
                    {symptom}
                  </span>
                ))}
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-orange-200">
              <h4 className="font-semibold text-orange-700 mb-3 flex items-center gap-2">
                <span className="text-xl">🔥</span> Overactive Thyroid (Hyperthyroid)
              </h4>
              <div className="flex flex-wrap gap-2">
                {symptoms.hyperthyroid.map((symptom, i) => (
                  <span key={i} className="text-sm bg-orange-50 text-orange-700 px-3 py-1 rounded-full">
                    {symptom}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Thyroid Health Packages</h2>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {thyroidPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-purple-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-purple-500 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-purple-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.benefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-purple-500 flex-shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expandable Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="text-purple-600 text-sm font-medium mb-4 hover:underline"
                  >
                    {expandedPackage === pkg.id ? '- Hide' : '+'} View all parameters
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-sm font-semibold text-gray-700">{param.category}</h5>
                          <p className="text-xs text-gray-500">{param.tests.join(', ')}</p>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  {/* Book Button */}
                  <Link href={`/book/${pkg.id}`}>
                    <button className="w-full py-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all flex items-center justify-center gap-2">
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  <span className="text-purple-600 font-bold">AED {test.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-3">{test.description}</p>
                <Link href="/tests">
                  <button className="text-purple-600 text-sm font-medium hover:underline flex items-center gap-1">
                    View Details <ArrowRight className="w-3 h-3" />
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Understanding TSH Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Understanding Your TSH Results</h2>
            <p className="text-gray-600">
              TSH is the primary marker for thyroid function
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-md border border-purple-100">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Low TSH</h3>
              <p className="text-2xl font-bold text-blue-600 mb-2">&lt; 0.4 mIU/L</p>
              <p className="text-sm text-gray-600">May indicate hyperthyroidism (overactive thyroid)</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-md border border-purple-100">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Normal TSH</h3>
              <p className="text-2xl font-bold text-green-600 mb-2">0.4 - 4.0 mIU/L</p>
              <p className="text-sm text-gray-600">Thyroid functioning normally</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-md border border-purple-100">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                <Activity className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">High TSH</h3>
              <p className="text-2xl font-bold text-orange-600 mb-2">&gt; 4.0 mIU/L</p>
              <p className="text-sm text-gray-600">May indicate hypothyroidism (underactive thyroid)</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Get Your Thyroid Checked Today</h2>
          <p className="text-purple-100 mb-8 max-w-2xl mx-auto">
            Thyroid disorders are common and highly treatable when detected early.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-3 bg-white text-purple-600 rounded-full font-semibold hover:bg-purple-50 transition-all flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </Link>
            <Link href="/tests">
              <button className="px-8 py-3 bg-purple-700 text-white rounded-full font-semibold hover:bg-purple-800 transition-all border border-white/30">
                Browse All Tests
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
