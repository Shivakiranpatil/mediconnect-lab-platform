import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Edit, Building2, Star, MapPin, Clock, Search, DollarSign, Package, FlaskConical } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { PartnerLab } from "@shared/schema";

export default function AdminLabsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingLab, setEditingLab] = useState<PartnerLab | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [pricingLab, setPricingLab] = useState<PartnerLab | null>(null);

  const { data: labs = [] } = useQuery<PartnerLab[]>({
    queryKey: ['/api/admin/labs'],
  });

  const saveLabMutation = useMutation({
    mutationFn: async (lab: Partial<PartnerLab>) => {
      const method = lab.id ? 'PATCH' : 'POST';
      const url = lab.id ? `/api/admin/labs/${lab.id}` : '/api/admin/labs';
      return apiRequest(method, url, lab);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/labs'] });
      setEditingLab(null);
      setIsCreating(false);
    },
  });

  const mockLabs: PartnerLab[] = [
    { id: '1', name: 'HealthFirst Diagnostics', slug: 'healthfirst', logoUrl: null, description: 'Premier diagnostics center', emirate: 'Dubai', status: 'active', avgConfirmationHours: '1.5', rating: '4.8', totalReviews: 245, createdAt: new Date() },
    { id: '2', name: 'MediCare Labs', slug: 'medicare', logoUrl: null, description: 'Trusted healthcare partner', emirate: 'Abu Dhabi', status: 'active', avgConfirmationHours: '2.0', rating: '4.6', totalReviews: 189, createdAt: new Date() },
    { id: '3', name: 'QuickTest UAE', slug: 'quicktest', logoUrl: null, description: 'Fast and accurate testing', emirate: 'Sharjah', status: 'active', avgConfirmationHours: '1.8', rating: '4.5', totalReviews: 156, createdAt: new Date() },
    { id: '4', name: 'ProHealth Center', slug: 'prohealth', logoUrl: null, description: 'Complete health solutions', emirate: 'Dubai', status: 'inactive', avgConfirmationHours: '2.5', rating: '4.2', totalReviews: 98, createdAt: new Date() },
  ];

  const displayLabs = labs.length > 0 ? labs : mockLabs;
  const filteredLabs = displayLabs.filter(lab => 
    lab.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lab.emirate?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout title="Partner Labs" subtitle="Manage laboratory partners">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search labs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64 bg-slate-800 border-slate-700 text-white"
              data-testid="input-search-labs"
            />
          </div>
          <Button onClick={() => setIsCreating(true)} className="bg-blue-600 hover:bg-blue-700" data-testid="button-add-lab">
            <Plus className="w-4 h-4 mr-2" />
            Add Lab Partner
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredLabs.map((lab) => (
            <div
              key={lab.id}
              className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 hover:border-slate-600 transition-colors"
              data-testid={`card-lab-${lab.id}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{lab.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <MapPin className="w-3 h-3" />
                      {lab.emirate}
                    </div>
                  </div>
                </div>
                <Badge className={lab.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}>
                  {lab.status}
                </Badge>
              </div>

              <p className="text-sm text-slate-400 mb-4">{lab.description}</p>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 text-amber-400 mb-1">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="font-bold">{lab.rating}</span>
                  </div>
                  <p className="text-xs text-slate-400">{lab.totalReviews} reviews</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <div className="flex items-center justify-center gap-1 text-blue-400 mb-1">
                    <Clock className="w-4 h-4" />
                    <span className="font-bold">{lab.avgConfirmationHours}h</span>
                  </div>
                  <p className="text-xs text-slate-400">Avg. Response</p>
                </div>
                <div className="bg-slate-700/30 rounded-xl p-3 text-center">
                  <p className="font-bold text-emerald-400 mb-1">15</p>
                  <p className="text-xs text-slate-400">Active Zones</p>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 border-slate-600 text-slate-300" onClick={() => setEditingLab(lab)} data-testid={`button-edit-lab-${lab.id}`}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Details
                  </Button>
                  <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700" data-testid={`button-manage-zones-${lab.id}`}>
                    Manage Zones
                  </Button>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10" 
                  onClick={() => setPricingLab(lab)}
                  data-testid={`button-manage-pricing-${lab.id}`}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Manage Tests & Pricing
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={!!editingLab || isCreating} onOpenChange={() => { setEditingLab(null); setIsCreating(false); }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>{editingLab ? 'Edit Lab Partner' : 'Add Lab Partner'}</DialogTitle>
          </DialogHeader>
          <LabForm 
            lab={editingLab} 
            onSave={(data) => saveLabMutation.mutate(data)}
            isPending={saveLabMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Lab Tests & Pricing Modal */}
      <Dialog open={!!pricingLab} onOpenChange={() => setPricingLab(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Tests & Pricing - {pricingLab?.name}</DialogTitle>
          </DialogHeader>
          {pricingLab && <LabTestsPricingForm lab={pricingLab} onClose={() => setPricingLab(null)} />}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function LabForm({ lab, onSave, isPending }: { lab: PartnerLab | null; onSave: (data: Partial<PartnerLab>) => void; isPending: boolean }) {
  const [formData, setFormData] = useState({
    name: lab?.name || '',
    description: lab?.description || '',
    emirate: lab?.emirate || '',
    status: lab?.status || 'active',
    avgConfirmationHours: lab?.avgConfirmationHours || '2',
  });

  return (
    <div className="space-y-4">
      <div>
        <Label>Lab Name</Label>
        <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="bg-slate-700 border-slate-600" data-testid="input-lab-name" />
      </div>
      <div>
        <Label>Description</Label>
        <Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="bg-slate-700 border-slate-600" data-testid="input-lab-description" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Emirate</Label>
          <Input value={formData.emirate} onChange={(e) => setFormData({ ...formData, emirate: e.target.value })} className="bg-slate-700 border-slate-600" data-testid="input-lab-emirate" />
        </div>
        <div>
          <Label>Avg. Confirmation Hours</Label>
          <Input type="number" step="0.5" value={formData.avgConfirmationHours} onChange={(e) => setFormData({ ...formData, avgConfirmationHours: e.target.value })} className="bg-slate-700 border-slate-600" data-testid="input-lab-hours" />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Switch checked={formData.status === 'active'} onCheckedChange={(c) => setFormData({ ...formData, status: c ? 'active' : 'inactive' })} data-testid="switch-lab-active" />
        <Label>Active</Label>
      </div>
      <DialogFooter>
        <Button onClick={() => onSave({ ...lab, ...formData })} disabled={isPending} className="bg-blue-600 hover:bg-blue-700" data-testid="button-save-lab">
          {isPending ? 'Saving...' : 'Save Lab'}
        </Button>
      </DialogFooter>
    </div>
  );
}

// Lab Tests & Pricing Form Component
function LabTestsPricingForm({ lab, onClose }: { lab: PartnerLab; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState('packages');
  
  // Mock data for packages with this lab's pricing
  const mockPackages = [
    { id: '1', name: 'Full Body Checkup', basePrice: 699, labPrice: 599, originalPrice: 699, testCount: 60, isActive: true },
    { id: '2', name: "Women's Wellness Panel", basePrice: 599, labPrice: 499, originalPrice: 599, testCount: 45, isActive: true },
    { id: '3', name: 'Heart & Cholesterol Panel', basePrice: 299, labPrice: 249, originalPrice: 299, testCount: 15, isActive: true },
    { id: '4', name: 'Energy & Fatigue Panel', basePrice: 449, labPrice: '', originalPrice: '', testCount: 30, isActive: false },
    { id: '5', name: 'Diabetes Monitoring Panel', basePrice: 249, labPrice: 199, originalPrice: 249, testCount: 12, isActive: true },
  ];

  const mockTests = [
    { id: '1', name: 'Complete Blood Count', category: 'Blood', basePrice: 49, labPrice: 35, isActive: true },
    { id: '2', name: 'Lipid Panel', category: 'Heart', basePrice: 89, labPrice: 75, isActive: true },
    { id: '3', name: 'Thyroid Function', category: 'Hormone', basePrice: 149, labPrice: 125, isActive: true },
    { id: '4', name: 'HbA1c', category: 'Diabetes', basePrice: 79, labPrice: 65, isActive: true },
    { id: '5', name: 'Liver Function', category: 'Liver', basePrice: 129, labPrice: '', isActive: false },
    { id: '6', name: 'Kidney Function', category: 'Kidney', basePrice: 99, labPrice: 79, isActive: true },
    { id: '7', name: 'Vitamin D', category: 'Vitamins', basePrice: 99, labPrice: 85, isActive: true },
    { id: '8', name: 'Vitamin B12', category: 'Vitamins', basePrice: 89, labPrice: '', isActive: false },
  ];

  const [packagePricing, setPackagePricing] = useState<Record<string, { labPrice: string; originalPrice: string; turnaround: string; isActive: boolean }>>(
    mockPackages.reduce((acc, pkg) => ({
      ...acc,
      [pkg.id]: { labPrice: pkg.labPrice?.toString() || '', originalPrice: pkg.originalPrice?.toString() || '', turnaround: '48', isActive: pkg.isActive }
    }), {})
  );

  const [testPricing, setTestPricing] = useState<Record<string, { labPrice: string; turnaround: string; isActive: boolean }>>(
    mockTests.reduce((acc, test) => ({
      ...acc,
      [test.id]: { labPrice: test.labPrice?.toString() || '', turnaround: '24', isActive: test.isActive }
    }), {})
  );

  const handleSave = () => {
    console.log('Saving lab pricing:', { packages: packagePricing, tests: testPricing });
    onClose();
  };

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-700 w-full">
          <TabsTrigger value="packages" className="flex-1 data-[state=active]:bg-blue-600">
            <Package className="w-4 h-4 mr-2" />
            Packages ({mockPackages.length})
          </TabsTrigger>
          <TabsTrigger value="tests" className="flex-1 data-[state=active]:bg-blue-600">
            <FlaskConical className="w-4 h-4 mr-2" />
            Individual Tests ({mockTests.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="packages" className="mt-4">
          <div className="space-y-3 max-h-96 overflow-auto pr-2">
            {mockPackages.map(pkg => (
              <div key={pkg.id} className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-white">{pkg.name}</h4>
                    <p className="text-xs text-slate-400">{pkg.testCount} tests • Base: AED {pkg.basePrice}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch 
                      checked={packagePricing[pkg.id]?.isActive ?? false}
                      onCheckedChange={(c) => setPackagePricing(prev => ({
                        ...prev,
                        [pkg.id]: { ...prev[pkg.id], isActive: c }
                      }))}
                    />
                    <span className="text-xs text-slate-400">Available</span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <Label className="text-xs">Lab Price (AED)</Label>
                    <Input 
                      type="number"
                      value={packagePricing[pkg.id]?.labPrice || ''}
                      onChange={(e) => setPackagePricing(prev => ({
                        ...prev,
                        [pkg.id]: { ...prev[pkg.id], labPrice: e.target.value }
                      }))}
                      className="bg-slate-600 border-slate-500 h-9"
                      placeholder={pkg.basePrice.toString()}
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Original Price</Label>
                    <Input 
                      type="number"
                      value={packagePricing[pkg.id]?.originalPrice || ''}
                      onChange={(e) => setPackagePricing(prev => ({
                        ...prev,
                        [pkg.id]: { ...prev[pkg.id], originalPrice: e.target.value }
                      }))}
                      className="bg-slate-600 border-slate-500 h-9"
                      placeholder={pkg.basePrice.toString()}
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Turnaround (hrs)</Label>
                    <Input 
                      type="number"
                      value={packagePricing[pkg.id]?.turnaround || ''}
                      onChange={(e) => setPackagePricing(prev => ({
                        ...prev,
                        [pkg.id]: { ...prev[pkg.id], turnaround: e.target.value }
                      }))}
                      className="bg-slate-600 border-slate-500 h-9"
                      placeholder="48"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tests" className="mt-4">
          <div className="space-y-3 max-h-96 overflow-auto pr-2">
            {mockTests.map(test => (
              <div key={test.id} className="bg-slate-700/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-white">{test.name}</h4>
                    <p className="text-xs text-slate-400">{test.category} • Base: AED {test.basePrice}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch 
                      checked={testPricing[test.id]?.isActive ?? false}
                      onCheckedChange={(c) => setTestPricing(prev => ({
                        ...prev,
                        [test.id]: { ...prev[test.id], isActive: c }
                      }))}
                    />
                    <span className="text-xs text-slate-400">Available</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">Lab Price (AED)</Label>
                    <Input 
                      type="number"
                      value={testPricing[test.id]?.labPrice || ''}
                      onChange={(e) => setTestPricing(prev => ({
                        ...prev,
                        [test.id]: { ...prev[test.id], labPrice: e.target.value }
                      }))}
                      className="bg-slate-600 border-slate-500 h-9"
                      placeholder={test.basePrice.toString()}
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Turnaround (hrs)</Label>
                    <Input 
                      type="number"
                      value={testPricing[test.id]?.turnaround || ''}
                      onChange={(e) => setTestPricing(prev => ({
                        ...prev,
                        [test.id]: { ...prev[test.id], turnaround: e.target.value }
                      }))}
                      className="bg-slate-600 border-slate-500 h-9"
                      placeholder="24"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <DialogFooter>
        <Button variant="outline" onClick={onClose} className="border-slate-600">Cancel</Button>
        <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
          Save All Pricing
        </Button>
      </DialogFooter>
    </div>
  );
}
