import { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Sparkles, Send, ArrowLeft, Loader2, Activity, Heart, Zap, Users, Beaker, Calendar, ChevronDown, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  bundles?: BundleRecommendation[];
  quickOptions?: QuickOption[];
}

interface BundleRecommendation {
  id: string;
  name: string;
  description: string;
  price: string;
  originalPrice?: string;
  icon?: string;
  gradient?: string;
  reason?: string;
}

interface QuickOption {
  type: 'symptom' | 'age' | 'gender' | 'condition';
  label: string;
  options: string[];
}

const bundleIcons: Record<string, any> = {
  'activity': Activity,
  'heart': Heart,
  'zap': Zap,
  'users': Users,
  'beaker': Beaker,
};

// Quick selection options
const symptomOptions = [
  "Fatigue & tiredness",
  "Weight changes",
  "Hair loss",
  "Joint pain",
  "Digestive issues",
  "Skin problems",
  "Mood changes",
  "Sleep problems",
  "Frequent infections",
  "Other"
];

const ageOptions = [
  "18-25",
  "26-35",
  "36-45",
  "46-55",
  "56-65",
  "65+"
];

const genderOptions = [
  "Male",
  "Female",
  "Prefer not to say"
];

const conditionOptions = [
  "Diabetes",
  "High blood pressure",
  "Heart disease",
  "Thyroid issues",
  "PCOS",
  "None of the above"
];

export default function AIDiscoveryPage() {
  const [, navigate] = useLocation();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Hello! I'm here to help you find the right lab tests for your health needs. 👋\n\nLet's start by understanding your situation. What symptoms or concerns bring you here today?",
      quickOptions: [
        { type: 'symptom', label: 'Select your main concern:', options: symptomOptions }
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => `session-${Date.now()}`);
  const [conversationStep, setConversationStep] = useState(0);
  const [userProfile, setUserProfile] = useState({
    symptoms: [] as string[],
    age: '',
    gender: '',
    conditions: [] as string[]
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleQuickSelect = (type: string, value: string) => {
    // Add user's selection as a message
    const userMessage: Message = { role: 'user', content: value };
    setMessages(prev => [...prev, userMessage]);

    // Update user profile
    if (type === 'symptom') {
      setUserProfile(prev => ({ ...prev, symptoms: [...prev.symptoms, value] }));
      
      // Ask for age next
      setTimeout(() => {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `I understand you're experiencing ${value.toLowerCase()}. This helps me narrow down the right tests for you.\n\nWhat's your age group?`,
          quickOptions: [
            { type: 'age', label: 'Select your age:', options: ageOptions }
          ]
        }]);
        setConversationStep(1);
      }, 500);
    } else if (type === 'age') {
      setUserProfile(prev => ({ ...prev, age: value }));
      
      // Ask for gender next
      setTimeout(() => {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `Great, noted! And your gender? This helps us include relevant hormone and wellness tests.`,
          quickOptions: [
            { type: 'gender', label: 'Select gender:', options: genderOptions }
          ]
        }]);
        setConversationStep(2);
      }, 500);
    } else if (type === 'gender') {
      setUserProfile(prev => ({ ...prev, gender: value }));
      
      // Ask for conditions
      setTimeout(() => {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `Almost done! Do you have any existing medical conditions we should consider?`,
          quickOptions: [
            { type: 'condition', label: 'Any existing conditions?', options: conditionOptions }
          ]
        }]);
        setConversationStep(3);
      }, 500);
    } else if (type === 'condition') {
      const updatedProfile = { ...userProfile, conditions: [value] };
      setUserProfile(updatedProfile);
      setConversationStep(4);
      
      // Generate recommendations
      generateRecommendations(updatedProfile, value);
    }
  };

  const generateRecommendations = async (profile: typeof userProfile, lastInput: string) => {
    setIsLoading(true);
    
    try {
      // Build context for AI
      const context = `User profile: Age ${profile.age}, Gender: ${profile.gender}, Symptoms: ${profile.symptoms.join(', ')}, Conditions: ${profile.conditions.join(', ') || 'None'}`;
      
      // Call AI for personalized response
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: `Based on my profile (${context}), what tests do you recommend?`,
          history: messages.map(m => ({ role: m.role, content: m.content }))
        })
      });

      let aiResponse = "Based on your profile, I recommend the following tests:";
      
      if (response.ok) {
        const data = await response.json();
        aiResponse = data.response;
      }

      // Get bundle recommendations
      const recResponse = await fetch('/api/ai/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context })
      });

      let bundles: BundleRecommendation[] = [];
      
      if (recResponse.ok) {
        const recData = await recResponse.json();
        if (recData.recommendations && recData.recommendations.length > 0) {
          bundles = recData.recommendations.map((rec: any) => ({
            id: rec.id,
            name: rec.name,
            description: rec.reason || 'Recommended based on your profile',
            price: rec.price,
            gradient: getGradientForBundle(rec.name),
            icon: 'activity'
          }));
        }
      }

      // Fallback recommendations based on symptoms
      if (bundles.length === 0) {
        bundles = getDefaultRecommendations(profile);
      }

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `${aiResponse}\n\nHere are my personalized recommendations for you:`,
        bundles
      }]);

    } catch (error) {
      console.error('Error generating recommendations:', error);
      
      // Fallback to default recommendations
      const bundles = getDefaultRecommendations(profile);
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `Based on your profile, here are my recommendations:\n\n• Age: ${profile.age}\n• Concerns: ${profile.symptoms.join(', ')}\n• Conditions: ${profile.conditions.join(', ') || 'None reported'}`,
        bundles
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getGradientForBundle = (name: string): string => {
    if (name.toLowerCase().includes('heart') || name.toLowerCase().includes('cholesterol')) {
      return 'from-red-500 to-red-600';
    }
    if (name.toLowerCase().includes('diabetes') || name.toLowerCase().includes('hba1c')) {
      return 'from-orange-500 to-orange-600';
    }
    if (name.toLowerCase().includes('energy') || name.toLowerCase().includes('fatigue')) {
      return 'from-amber-500 to-amber-600';
    }
    if (name.toLowerCase().includes('women') || name.toLowerCase().includes('wellness')) {
      return 'from-pink-500 to-pink-600';
    }
    if (name.toLowerCase().includes('thyroid')) {
      return 'from-teal-500 to-teal-600';
    }
    return 'from-blue-500 to-blue-600';
  };

  const getDefaultRecommendations = (profile: typeof userProfile): BundleRecommendation[] => {
    const recommendations: BundleRecommendation[] = [];
    
    // Based on symptoms
    if (profile.symptoms.some(s => s.toLowerCase().includes('fatigue') || s.toLowerCase().includes('tired'))) {
      recommendations.push({
        id: '4',
        name: 'Energy & Fatigue Panel',
        description: 'Identifies vitamin deficiencies and thyroid issues causing tiredness',
        price: '449',
        gradient: 'from-amber-500 to-amber-600',
        icon: 'zap'
      });
    }
    
    if (profile.symptoms.some(s => s.toLowerCase().includes('weight'))) {
      recommendations.push({
        id: '4',
        name: 'Thyroid Function Panel',
        description: 'Checks thyroid hormones that affect metabolism and weight',
        price: '149',
        gradient: 'from-teal-500 to-teal-600',
        icon: 'activity'
      });
    }

    // Based on gender
    if (profile.gender === 'Female') {
      recommendations.push({
        id: '2',
        name: "Women's Wellness Panel",
        description: 'Hormone balance, PCOS screening, and fertility markers',
        price: '599',
        gradient: 'from-pink-500 to-pink-600',
        icon: 'heart'
      });
    }

    // Based on age
    if (profile.age && parseInt(profile.age) >= 46) {
      recommendations.push({
        id: '3',
        name: 'Heart & Cholesterol Panel',
        description: 'Comprehensive cardiovascular risk assessment',
        price: '299',
        gradient: 'from-red-500 to-red-600',
        icon: 'heart'
      });
    }

    // Based on conditions
    if (profile.conditions.some(c => c.toLowerCase().includes('diabetes'))) {
      recommendations.push({
        id: '7',
        name: 'HbA1c Blood Sugar Test',
        description: 'Monitor blood sugar levels - essential for diabetes management',
        price: '99',
        gradient: 'from-orange-500 to-orange-600',
        icon: 'activity'
      });
    }

    // Always recommend a comprehensive option
    if (recommendations.length < 3) {
      recommendations.push({
        id: '1',
        name: 'Full Body Checkup',
        description: 'Complete health screening with 40+ parameters',
        price: '699',
        gradient: 'from-blue-500 to-blue-600',
        icon: 'activity'
      });
    }

    return recommendations.slice(0, 3);
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: input,
          history: messages.map(m => ({ role: m.role, content: m.content }))
        })
      });

      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }

      const data = await response.json();
      
      let assistantMessage: Message = {
        role: 'assistant',
        content: data.response
      };

      // Check if we should show recommendations
      const hasRecommendations = data.response.toLowerCase().includes('recommend') || 
                                  messages.length >= 4;

      if (hasRecommendations) {
        try {
          const context = messages.map(m => m.content).join(' ') + ' ' + input;
          const recResponse = await fetch('/api/ai/recommend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ context })
          });

          if (recResponse.ok) {
            const recData = await recResponse.json();
            if (recData.recommendations && recData.recommendations.length > 0) {
              assistantMessage.bundles = recData.recommendations.map((rec: any) => ({
                id: rec.id,
                name: rec.name,
                description: rec.reason || 'Recommended based on your profile',
                price: rec.price,
                gradient: getGradientForBundle(rec.name),
                icon: 'activity'
              }));
            }
          }
        } catch (error) {
          console.error('Failed to fetch recommendations:', error);
        }
      }

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error: any) {
      console.error('AI Chat error:', error);
      
      toast({
        title: "Connection Error",
        description: "Failed to connect to AI service. Please try again.",
        variant: "destructive"
      });
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I apologize, but I'm having trouble connecting right now. Please try again."
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBookNow = (bundleId: string) => {
    navigate(`/book/${bundleId}`);
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50" data-testid="ai-discovery-page">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 flex-shrink-0 z-50 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <Link href="/">
            <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors" data-testid="button-back">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium text-sm sm:text-base">Back</span>
            </button>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold text-gray-900 text-sm sm:text-base">AI Health Assistant</span>
          </div>
          <div className="w-20"></div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 overflow-y-auto" data-testid="chat-container">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`mb-4 sm:mb-6 flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[90%] sm:max-w-[85%] rounded-2xl px-4 sm:px-6 py-3 sm:py-4 ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg'
                    : 'bg-white border border-gray-200 text-gray-800 shadow-md'
                }`}>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-xs font-semibold text-gray-500">AI Assistant</span>
                    </div>
                  )}
                  <div className="whitespace-pre-line text-sm sm:text-base leading-relaxed">{message.content}</div>

                  {/* Quick Selection Options */}
                  {message.quickOptions && message.quickOptions.length > 0 && (
                    <div className="mt-4 space-y-3">
                      {message.quickOptions.map((option, optIdx) => (
                        <div key={optIdx}>
                          <p className="text-xs font-medium text-gray-500 mb-2">{option.label}</p>
                          <div className="flex flex-wrap gap-2">
                            {option.options.map((opt, i) => (
                              <button
                                key={i}
                                onClick={() => handleQuickSelect(option.type, opt)}
                                className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 text-sm rounded-full border border-blue-200 hover:border-blue-400 transition-all"
                                data-testid={`quick-option-${option.type}-${i}`}
                              >
                                {opt}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Bundle Recommendations */}
                  {message.bundles && message.bundles.length > 0 && (
                    <div className="mt-4 sm:mt-6 space-y-3 sm:space-y-4">
                      <div className="text-sm font-semibold text-gray-700 mb-2">
                        ✨ Recommended Test Bundles:
                      </div>
                      {message.bundles.map(bundle => {
                        const IconComponent = bundleIcons[bundle.icon || 'activity'] || Activity;
                        return (
                          <motion.div
                            key={bundle.id}
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 hover:border-blue-400 rounded-xl p-4 transition-all duration-300 hover:shadow-xl"
                            data-testid={`bundle-card-${bundle.id}`}
                          >
                            <div className="flex items-start gap-3 sm:gap-4">
                              <div className={`w-12 h-12 bg-gradient-to-br ${bundle.gradient || 'from-blue-500 to-blue-600'} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md`}>
                                <IconComponent className="w-6 h-6 text-white" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-gray-900 mb-1 text-base">{bundle.name}</h4>
                                <p className="text-sm text-gray-600 mb-3">{bundle.description}</p>
                                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                                  <span className="text-2xl font-bold text-blue-600">AED {bundle.price}</span>
                                  <div className="flex gap-2">
                                    <button
                                      onClick={() => navigate(`/bundles/${bundle.id}`)}
                                      className="px-4 py-2 border-2 border-blue-600 text-blue-600 text-sm font-semibold rounded-lg hover:bg-blue-50 transition-colors"
                                    >
                                      View Details
                                    </button>
                                    <button
                                      onClick={() => handleBookNow(bundle.id)}
                                      className="px-4 py-2 bg-green-600 text-white text-sm font-semibold rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                                      data-testid={`book-now-${bundle.id}`}
                                    >
                                      <Calendar className="w-4 h-4" />
                                      Book Now
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                      <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm text-green-800">
                          ✅ Click <strong>"Book Now"</strong> to schedule your test appointment immediately!
                        </p>
                      </div>
                      <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <p className="text-xs text-gray-600">
                          💡 <strong>Remember:</strong> These are discovery suggestions. Please consult your healthcare provider for personalized medical advice.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start mb-6">
              <div className="bg-white border border-gray-200 rounded-2xl px-6 py-4 shadow-md">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                  <span className="text-gray-600">AI is analyzing your profile...</span>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="flex-shrink-0 bg-white border-t border-gray-200 shadow-2xl" data-testid="chat-input-area">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder="Type your message or use quick options above..."
              className="flex-1 px-6 py-4 border-2 border-gray-300 rounded-full focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all shadow-sm"
              disabled={isLoading}
              data-testid="input-chat"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-full hover:from-blue-700 hover:to-blue-800 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
              data-testid="button-send"
            >
              <Send className="w-5 h-5" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-3 text-center">
            🔬 This is a discovery tool, not medical advice. Always consult healthcare professionals.
          </p>
        </div>
      </div>
    </div>
  );
}
