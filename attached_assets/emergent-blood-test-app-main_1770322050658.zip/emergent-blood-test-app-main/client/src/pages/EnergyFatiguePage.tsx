import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Battery, CheckCircle, Clock, Shield, Activity, Beaker, 
  ArrowRight, Heart, Zap, ArrowLeft, Moon, Sun, Coffee
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";

const energyPackages = [
  {
    id: "4",
    name: "Energy & Fatigue Panel",
    description: "Comprehensive panel to identify causes of fatigue, low energy, and tiredness",
    price: "449",
    originalPrice: "599",
    popular: true,
    testsIncluded: 22,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "Iron", "Ferritin", "TIBC"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Liver & Kidney", tests: ["ALT", "AST", "Creatinine", "BUN"] },
      { category: "Electrolytes", tests: ["Sodium", "Potassium", "Calcium", "Magnesium"] },
    ],
    benefits: [
      "Identify fatigue causes",
      "Anemia detection",
      "Thyroid assessment",
      "Vitamin deficiency check"
    ]
  },
  {
    id: "23",
    name: "Anemia Profile",
    description: "Complete anemia screening including iron studies and red blood cell assessment",
    price: "199",
    originalPrice: "279",
    popular: false,
    testsIncluded: 12,
    turnaround: "24 hours",
    parameters: [
      { category: "Blood Count", tests: ["CBC", "Hemoglobin", "Hematocrit", "RBC Indices"] },
      { category: "Iron Studies", tests: ["Serum Iron", "Ferritin", "TIBC", "Transferrin Saturation"] },
      { category: "Vitamins", tests: ["Vitamin B12", "Folate"] },
      { category: "Inflammation", tests: ["ESR"] },
    ],
    benefits: [
      "Anemia type identification",
      "Iron deficiency detection",
      "B12 deficiency check",
      "Treatment guidance"
    ]
  },
  {
    id: "24",
    name: "Vitamin Deficiency Panel",
    description: "Complete vitamin and mineral assessment for those feeling tired or weak",
    price: "349",
    originalPrice: "449",
    popular: false,
    testsIncluded: 15,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Fat-Soluble Vitamins", tests: ["Vitamin D", "Vitamin E", "Vitamin A"] },
      { category: "Water-Soluble Vitamins", tests: ["Vitamin B12", "Folate", "Vitamin B6", "Vitamin C"] },
      { category: "Minerals", tests: ["Iron", "Ferritin", "Calcium", "Magnesium", "Zinc"] },
      { category: "Blood Count", tests: ["CBC", "Hemoglobin"] },
    ],
    benefits: [
      "Complete vitamin check",
      "Mineral assessment",
      "Supplement guidance",
      "Energy optimization"
    ]
  },
  {
    id: "25",
    name: "Sleep & Stress Panel",
    description: "Hormones and markers affecting sleep quality and stress response",
    price: "399",
    originalPrice: "499",
    popular: false,
    testsIncluded: 12,
    turnaround: "24-48 hours",
    parameters: [
      { category: "Stress Hormones", tests: ["Cortisol (Morning)", "DHEA-S"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Blood Sugar", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Magnesium"] },
    ],
    benefits: [
      "Stress assessment",
      "Sleep quality insight",
      "Hormone balance check",
      "Energy restoration"
    ]
  }
];

const individualTests = [
  { name: "Complete Blood Count (CBC)", price: "49", description: "Blood cell analysis" },
  { name: "Hemoglobin", price: "29", description: "Oxygen-carrying capacity" },
  { name: "Iron Studies Panel", price: "119", description: "Iron, Ferritin, TIBC" },
  { name: "Vitamin D", price: "99", description: "Sunlight vitamin" },
  { name: "Vitamin B12", price: "89", description: "Energy and nerve health" },
  { name: "Folate (B9)", price: "79", description: "Cell production vitamin" },
  { name: "Thyroid Profile (TSH, T3, T4)", price: "149", description: "Metabolism regulation" },
  { name: "Cortisol (Morning)", price: "89", description: "Stress hormone" },
  { name: "Magnesium", price: "59", description: "Energy and muscle function" },
  { name: "Ferritin", price: "69", description: "Iron storage marker" },
];

const fatigueCauses = [
  { cause: "Iron Deficiency Anemia", icon: "🩸", description: "Low iron affects oxygen delivery to tissues", color: "red" },
  { cause: "Vitamin B12 Deficiency", icon: "💊", description: "Essential for nerve function and energy", color: "blue" },
  { cause: "Vitamin D Deficiency", icon: "☀️", description: "Low levels cause fatigue and muscle weakness", color: "amber" },
  { cause: "Thyroid Disorders", icon: "🦋", description: "Both hypo and hyperthyroidism cause fatigue", color: "purple" },
  { cause: "Diabetes", icon: "🍬", description: "Uncontrolled blood sugar leads to tiredness", color: "orange" },
  { cause: "Chronic Stress", icon: "😰", description: "High cortisol depletes energy reserves", color: "gray" },
];

export default function EnergyFatiguePage() {
  const [, navigate] = useLocation();
  const [expandedPackage, setExpandedPackage] = useState<string | null>("4");

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-yellow-300 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          {/* Back Button */}
          <Link href="/">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-6 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to Home</span>
            </button>
          </Link>
          
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Battery className="w-6 h-6" />
              </div>
              <span className="text-yellow-200 font-medium">Energy & Vitality</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="page-title">
              Energy & Fatigue Testing
            </h1>
            <p className="text-xl text-yellow-100 mb-8">
              Feeling tired all the time? Discover the underlying causes of your fatigue with comprehensive testing.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>Anemia Screening</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Clock className="w-5 h-5 text-yellow-200" />
                <span>Results in 24 hrs</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                <Shield className="w-5 h-5 text-amber-300" />
                <span>Vitamin Check</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Common Causes Section */}
      <section className="py-8 bg-amber-50 border-b border-amber-100">
        <div className="container mx-auto px-4">
          <h3 className="font-semibold text-gray-900 mb-4 text-center">Common Causes of Fatigue</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {fatigueCauses.map((item, index) => (
              <div key={index} className="bg-white p-4 rounded-xl text-center border border-amber-100 hover:shadow-md transition-all">
                <span className="text-3xl mb-2 block">{item.icon}</span>
                <h4 className="font-semibold text-gray-900 text-sm">{item.cause}</h4>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Energy & Fatigue Packages</h2>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {energyPackages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${
                  pkg.popular ? 'border-amber-500' : 'border-gray-100'
                }`}
                data-testid={`package-${pkg.id}`}
              >
                {pkg.popular && (
                  <div className="bg-amber-500 text-white text-center py-2 text-sm font-semibold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-sm text-gray-600 mb-4">{pkg.description}</p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-3xl font-bold text-amber-600">AED {pkg.price}</span>
                    {pkg.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">AED {pkg.originalPrice}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                    <span className="flex items-center gap-1">
                      <Beaker className="w-4 h-4" />
                      {pkg.testsIncluded} tests
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {pkg.turnaround}
                    </span>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Benefits:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.benefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                          <span>{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expandable Parameters */}
                  <button
                    onClick={() => setExpandedPackage(expandedPackage === pkg.id ? null : pkg.id)}
                    className="text-amber-600 text-sm font-medium mb-4 hover:underline"
                  >
                    {expandedPackage === pkg.id ? '- Hide' : '+'} View all parameters
                  </button>

                  {expandedPackage === pkg.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="border-t pt-4 mb-4"
                    >
                      {pkg.parameters.map((param, i) => (
                        <div key={i} className="mb-3">
                          <h5 className="text-sm font-semibold text-gray-700">{param.category}</h5>
                          <p className="text-xs text-gray-500">{param.tests.join(', ')}</p>
                        </div>
                      ))}
                    </motion.div>
                  )}

                  {/* Book Button */}
                  <Link href={`/book/${pkg.id}`}>
                    <button className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-orange-600 transition-all flex items-center justify-center gap-2">
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Individual Tests Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Individual Tests</h2>
          <p className="text-gray-600 mb-8">Book specific tests based on your needs</p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {individualTests.map((test, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                  <span className="text-amber-600 font-bold">AED {test.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-3">{test.description}</p>
                <Link href="/tests">
                  <button className="text-amber-600 text-sm font-medium hover:underline flex items-center gap-1">
                    View Details <ArrowRight className="w-3 h-3" />
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Energy Tips Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Boost Your Energy Naturally</h2>
            <p className="text-gray-600">
              While testing helps identify deficiencies, these habits can help improve energy levels
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Moon className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Quality Sleep</h3>
              <p className="text-sm text-gray-600">Aim for 7-9 hours of quality sleep each night</p>
            </div>
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sun className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Sunlight Exposure</h3>
              <p className="text-sm text-gray-600">Get morning sunlight for vitamin D and circadian rhythm</p>
            </div>
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Regular Exercise</h3>
              <p className="text-sm text-gray-600">30 minutes of moderate activity daily boosts energy</p>
            </div>
            <div className="text-center p-6 bg-amber-50 rounded-2xl">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Coffee className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Balanced Diet</h3>
              <p className="text-sm text-gray-600">Eat iron-rich foods, proteins, and stay hydrated</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Stop Feeling Tired All The Time</h2>
          <p className="text-amber-100 mb-8 max-w-2xl mx-auto">
            Get tested today and find out what's draining your energy. Most causes are easily treatable.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/ai-discovery">
              <button className="px-8 py-3 bg-white text-amber-600 rounded-full font-semibold hover:bg-amber-50 transition-all flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Get AI Recommendations
              </button>
            </Link>
            <Link href="/tests">
              <button className="px-8 py-3 bg-amber-600 text-white rounded-full font-semibold hover:bg-amber-700 transition-all border border-white/30">
                Browse All Tests
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
