import { useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, Package, FlaskConical, Tag, GripVertical } from "lucide-react";

// Initial test categories
const initialTestCategories = [
  { id: '1', name: 'Blood', description: 'Blood-related tests including CBC, hemoglobin', color: 'red', isActive: true, testCount: 5 },
  { id: '2', name: 'Heart', description: 'Cardiovascular health tests', color: 'pink', isActive: true, testCount: 3 },
  { id: '3', name: 'Diabetes', description: 'Blood sugar and diabetes monitoring', color: 'orange', isActive: true, testCount: 4 },
  { id: '4', name: 'Thyroid', description: 'Thyroid function tests', color: 'purple', isActive: true, testCount: 3 },
  { id: '5', name: 'Liver', description: 'Liver function and health tests', color: 'green', isActive: true, testCount: 2 },
  { id: '6', name: 'Kidney', description: 'Kidney function tests', color: 'blue', isActive: true, testCount: 2 },
  { id: '7', name: 'Vitamins', description: 'Vitamin level tests', color: 'yellow', isActive: true, testCount: 3 },
  { id: '8', name: 'Hormones', description: 'Hormone level tests', color: 'indigo', isActive: true, testCount: 2 },
  { id: '9', name: 'Minerals', description: 'Mineral and electrolyte tests', color: 'teal', isActive: true, testCount: 2 },
  { id: '10', name: 'Allergy', description: 'Allergy and sensitivity tests', color: 'amber', isActive: true, testCount: 0 },
  { id: '11', name: 'Infection', description: 'Infection and immunity tests', color: 'rose', isActive: true, testCount: 0 },
  { id: '12', name: 'Cancer Markers', description: 'Tumor markers and cancer screening', color: 'slate', isActive: true, testCount: 0 },
];

// Initial bundle/package categories
const initialBundleCategories = [
  { id: '1', name: 'Premium', description: 'Comprehensive health checkup packages', color: 'blue', isActive: true, bundleCount: 2 },
  { id: '2', name: 'Basic', description: 'Essential health screening packages', color: 'gray', isActive: true, bundleCount: 1 },
  { id: '3', name: 'Heart Health', description: 'Cardiovascular health packages', color: 'red', isActive: true, bundleCount: 1 },
  { id: '4', name: "Women's Health", description: 'Health packages designed for women', color: 'pink', isActive: true, bundleCount: 1 },
  { id: '5', name: "Men's Health", description: 'Health packages designed for men', color: 'indigo', isActive: true, bundleCount: 0 },
  { id: '6', name: 'Diabetes', description: 'Diabetes monitoring packages', color: 'orange', isActive: true, bundleCount: 1 },
  { id: '7', name: 'Thyroid', description: 'Thyroid health packages', color: 'purple', isActive: true, bundleCount: 0 },
  { id: '8', name: 'Energy', description: 'Energy and fatigue packages', color: 'yellow', isActive: true, bundleCount: 1 },
  { id: '9', name: 'Senior Care', description: 'Health packages for seniors', color: 'teal', isActive: true, bundleCount: 0 },
  { id: '10', name: 'Sports & Fitness', description: 'Athletic performance packages', color: 'green', isActive: true, bundleCount: 0 },
];

const colorOptions = [
  { value: 'red', label: 'Red', bg: 'bg-red-500' },
  { value: 'pink', label: 'Pink', bg: 'bg-pink-500' },
  { value: 'orange', label: 'Orange', bg: 'bg-orange-500' },
  { value: 'yellow', label: 'Yellow', bg: 'bg-yellow-500' },
  { value: 'amber', label: 'Amber', bg: 'bg-amber-500' },
  { value: 'green', label: 'Green', bg: 'bg-green-500' },
  { value: 'teal', label: 'Teal', bg: 'bg-teal-500' },
  { value: 'blue', label: 'Blue', bg: 'bg-blue-500' },
  { value: 'indigo', label: 'Indigo', bg: 'bg-indigo-500' },
  { value: 'purple', label: 'Purple', bg: 'bg-purple-500' },
  { value: 'rose', label: 'Rose', bg: 'bg-rose-500' },
  { value: 'slate', label: 'Slate', bg: 'bg-slate-500' },
  { value: 'gray', label: 'Gray', bg: 'bg-gray-500' },
];

interface Category {
  id: string;
  name: string;
  description: string;
  color: string;
  isActive: boolean;
  testCount?: number;
  bundleCount?: number;
}

export default function AdminCategoriesPage() {
  const [testCategories, setTestCategories] = useState<Category[]>(initialTestCategories);
  const [bundleCategories, setBundleCategories] = useState<Category[]>(initialBundleCategories);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [activeTab, setActiveTab] = useState<'tests' | 'bundles'>('tests');
  const [deleteConfirm, setDeleteConfirm] = useState<Category | null>(null);

  const handleSave = (category: Category) => {
    if (activeTab === 'tests') {
      if (editingCategory) {
        setTestCategories(prev => prev.map(c => c.id === category.id ? category : c));
      } else {
        setTestCategories(prev => [...prev, { ...category, id: String(Date.now()), testCount: 0 }]);
      }
    } else {
      if (editingCategory) {
        setBundleCategories(prev => prev.map(c => c.id === category.id ? category : c));
      } else {
        setBundleCategories(prev => [...prev, { ...category, id: String(Date.now()), bundleCount: 0 }]);
      }
    }
    setEditingCategory(null);
    setIsCreating(false);
  };

  const handleDelete = (category: Category) => {
    if (activeTab === 'tests') {
      setTestCategories(prev => prev.filter(c => c.id !== category.id));
    } else {
      setBundleCategories(prev => prev.filter(c => c.id !== category.id));
    }
    setDeleteConfirm(null);
  };

  const handleToggleActive = (category: Category) => {
    if (activeTab === 'tests') {
      setTestCategories(prev => prev.map(c => 
        c.id === category.id ? { ...c, isActive: !c.isActive } : c
      ));
    } else {
      setBundleCategories(prev => prev.map(c => 
        c.id === category.id ? { ...c, isActive: !c.isActive } : c
      ));
    }
  };

  const categories = activeTab === 'tests' ? testCategories : bundleCategories;

  return (
    <AdminLayout title="Categories" subtitle="Manage test and package categories">
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'tests' | 'bundles')} className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList className="bg-slate-800">
            <TabsTrigger value="tests" className="data-[state=active]:bg-blue-600" data-testid="tab-test-categories">
              <FlaskConical className="w-4 h-4 mr-2" />
              Test Categories ({testCategories.length})
            </TabsTrigger>
            <TabsTrigger value="bundles" className="data-[state=active]:bg-blue-600" data-testid="tab-bundle-categories">
              <Package className="w-4 h-4 mr-2" />
              Package Categories ({bundleCategories.length})
            </TabsTrigger>
          </TabsList>
          
          <Button 
            onClick={() => setIsCreating(true)} 
            className="bg-blue-600 hover:bg-blue-700"
            data-testid="button-add-category"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Category
          </Button>
        </div>

        <TabsContent value="tests" className="space-y-4">
          <p className="text-sm text-slate-400">
            These categories are used for individual lab tests. Tests will be grouped by these categories on the customer-facing site.
          </p>
          <CategoryList 
            categories={testCategories} 
            onEdit={setEditingCategory}
            onDelete={setDeleteConfirm}
            onToggle={handleToggleActive}
            type="test"
          />
        </TabsContent>

        <TabsContent value="bundles" className="space-y-4">
          <p className="text-sm text-slate-400">
            These categories are used for test packages/bundles. Packages will be grouped by these categories on the customer-facing site.
          </p>
          <CategoryList 
            categories={bundleCategories} 
            onEdit={setEditingCategory}
            onDelete={setDeleteConfirm}
            onToggle={handleToggleActive}
            type="bundle"
          />
        </TabsContent>
      </Tabs>

      {/* Create/Edit Dialog */}
      <Dialog open={!!editingCategory || isCreating} onOpenChange={() => { setEditingCategory(null); setIsCreating(false); }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>{editingCategory ? 'Edit Category' : 'Create Category'}</DialogTitle>
          </DialogHeader>
          <CategoryForm 
            category={editingCategory}
            onSave={handleSave}
            type={activeTab}
          />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>Delete Category</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-slate-300">
              Are you sure you want to delete <span className="font-semibold text-white">"{deleteConfirm?.name}"</span>?
            </p>
            {((deleteConfirm?.testCount || 0) > 0 || (deleteConfirm?.bundleCount || 0) > 0) && (
              <p className="mt-2 text-amber-400 text-sm">
                ⚠️ This category has {deleteConfirm?.testCount || deleteConfirm?.bundleCount} items assigned to it. 
                They will need to be reassigned to another category.
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirm(null)} className="border-slate-600">
              Cancel
            </Button>
            <Button 
              onClick={() => deleteConfirm && handleDelete(deleteConfirm)} 
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function CategoryList({ 
  categories, 
  onEdit, 
  onDelete,
  onToggle,
  type 
}: { 
  categories: Category[]; 
  onEdit: (cat: Category) => void;
  onDelete: (cat: Category) => void;
  onToggle: (cat: Category) => void;
  type: 'test' | 'bundle';
}) {
  const getColorClass = (color: string) => {
    const colorMap: Record<string, string> = {
      red: 'bg-red-500',
      pink: 'bg-pink-500',
      orange: 'bg-orange-500',
      yellow: 'bg-yellow-500',
      amber: 'bg-amber-500',
      green: 'bg-green-500',
      teal: 'bg-teal-500',
      blue: 'bg-blue-500',
      indigo: 'bg-indigo-500',
      purple: 'bg-purple-500',
      rose: 'bg-rose-500',
      slate: 'bg-slate-500',
      gray: 'bg-gray-500',
    };
    return colorMap[color] || 'bg-slate-500';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {categories.map((category) => (
        <div
          key={category.id}
          className={`bg-slate-800/50 rounded-xl p-4 border transition-all ${
            category.isActive ? 'border-slate-700 hover:border-slate-600' : 'border-slate-800 opacity-60'
          }`}
          data-testid={`category-card-${category.id}`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${getColorClass(category.color)} flex items-center justify-center`}>
                <Tag className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">{category.name}</h3>
                <p className="text-xs text-slate-400">
                  {type === 'test' ? `${category.testCount || 0} tests` : `${category.bundleCount || 0} packages`}
                </p>
              </div>
            </div>
            <Switch 
              checked={category.isActive}
              onCheckedChange={() => onToggle(category)}
              data-testid={`toggle-category-${category.id}`}
            />
          </div>
          
          <p className="text-sm text-slate-400 mb-4 line-clamp-2">{category.description}</p>
          
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              variant="outline" 
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
              onClick={() => onEdit(category)}
              data-testid={`button-edit-category-${category.id}`}
            >
              <Edit className="w-4 h-4 mr-1" />
              Edit
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="border-red-500/50 text-red-400 hover:bg-red-500/10"
              onClick={() => onDelete(category)}
              data-testid={`button-delete-category-${category.id}`}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}

function CategoryForm({ 
  category, 
  onSave,
  type 
}: { 
  category: Category | null; 
  onSave: (cat: Category) => void;
  type: 'tests' | 'bundles';
}) {
  const [formData, setFormData] = useState({
    name: category?.name || '',
    description: category?.description || '',
    color: category?.color || 'blue',
    isActive: category?.isActive ?? true,
  });

  const handleSubmit = () => {
    onSave({
      id: category?.id || '',
      ...formData,
      testCount: category?.testCount,
      bundleCount: category?.bundleCount,
    });
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Category Name *</Label>
        <Input 
          value={formData.name} 
          onChange={(e) => setFormData({ ...formData, name: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder={type === 'tests' ? "e.g., Blood, Heart, Diabetes" : "e.g., Premium, Women's Health"}
          data-testid="input-category-name"
        />
      </div>
      
      <div>
        <Label>Description</Label>
        <Input 
          value={formData.description} 
          onChange={(e) => setFormData({ ...formData, description: e.target.value })} 
          className="bg-slate-700 border-slate-600" 
          placeholder="Brief description of this category"
          data-testid="input-category-description"
        />
      </div>

      <div>
        <Label>Color</Label>
        <div className="flex flex-wrap gap-2 mt-2">
          {colorOptions.map(color => (
            <button
              key={color.value}
              onClick={() => setFormData({ ...formData, color: color.value })}
              className={`w-8 h-8 rounded-lg ${color.bg} transition-all ${
                formData.color === color.value 
                  ? 'ring-2 ring-white ring-offset-2 ring-offset-slate-800' 
                  : 'hover:scale-110'
              }`}
              title={color.label}
              data-testid={`color-${color.value}`}
            />
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
        <Switch 
          checked={formData.isActive} 
          onCheckedChange={(c) => setFormData({ ...formData, isActive: c })} 
          data-testid="switch-category-active"
        />
        <Label className="cursor-pointer">Active (visible on site)</Label>
      </div>

      <DialogFooter className="pt-4">
        <Button 
          onClick={handleSubmit} 
          disabled={!formData.name.trim()}
          className="bg-blue-600 hover:bg-blue-700"
          data-testid="button-save-category"
        >
          {category ? 'Update Category' : 'Create Category'}
        </Button>
      </DialogFooter>
    </div>
  );
}
