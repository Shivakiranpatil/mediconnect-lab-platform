import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { 
  BarChart3, TrendingUp, TrendingDown, Calendar, DollarSign, Users, 
  Building2, Package, Download, FileText, RefreshCw, Trash2, AlertTriangle
} from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface Booking {
  id: string;
  bundleName: string;
  labName: string;
  price: number;
  status: string;
  createdAt: string;
  patientName?: string;
}

interface Lab {
  id: number;
  name: string;
  city: string;
  rating: number;
  isActive: boolean;
}

interface User {
  id: number;
  name: string;
  username: string;
  role: string;
  createdAt?: string;
}

interface ReportStats {
  totalRevenue: number;
  totalBookings: number;
  newUsers: number;
  activeLabs: number;
  revenueChange: number;
  bookingsChange: number;
  usersChange: number;
  labsChange: number;
}

// Local storage key for persisted report data
const REPORT_DATA_KEY = 'mediconnect_report_data';

export default function AdminReportsPage() {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState("30");
  const [isLoading, setIsLoading] = useState(true);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  
  // Live data states
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [labs, setLabs] = useState<Lab[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState<ReportStats>({
    totalRevenue: 0,
    totalBookings: 0,
    newUsers: 0,
    activeLabs: 0,
    revenueChange: 0,
    bookingsChange: 0,
    usersChange: 0,
    labsChange: 0,
  });

  // Fetch all data on mount
  useEffect(() => {
    fetchAllData();
  }, [dateRange]);

  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      // Fetch bookings from Supabase
      const bookingsRes = await fetch('/api/supabase/bookings');
      const bookingsData = bookingsRes.ok ? await bookingsRes.json() : [];
      
      // Fetch labs from Supabase
      const labsRes = await fetch('/api/supabase/labs');
      const labsData = labsRes.ok ? await labsRes.json() : [];
      
      // Fetch users from Supabase
      const usersRes = await fetch('/api/supabase/users');
      const usersData = usersRes.ok ? await usersRes.json() : [];

      // Transform Supabase data to match expected format
      const transformedBookings = Array.isArray(bookingsData) ? bookingsData.map((b: any) => ({
        id: b.id,
        bundleName: b.bundle_name,
        labName: b.lab_name,
        price: parseFloat(b.price) || 0,
        status: b.status,
        createdAt: b.created_at,
        patientName: b.patient_name,
      })) : [];

      setBookings(transformedBookings);
      setLabs(Array.isArray(labsData) ? labsData : []);
      setUsers(Array.isArray(usersData) ? usersData : []);
      
      // Calculate stats
      calculateStats(transformedBookings, Array.isArray(labsData) ? labsData : [], Array.isArray(usersData) ? usersData : []);
    } catch (error) {
      console.error('Error fetching report data:', error);
      // Use persisted data as fallback
      const persistedData = getPersistedData();
      setBookings(persistedData.bookings);
      setUsers(persistedData.users);
      calculateStats(persistedData.bookings, [], persistedData.users);
    } finally {
      setIsLoading(false);
    }
  };

  const getPersistedData = () => {
    try {
      const data = localStorage.getItem(REPORT_DATA_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Error reading persisted data:', e);
    }
    return { bookings: [], users: [] };
  };

  const persistData = (bookings: Booking[], users: User[]) => {
    try {
      localStorage.setItem(REPORT_DATA_KEY, JSON.stringify({ bookings, users }));
    } catch (e) {
      console.error('Error persisting data:', e);
    }
  };

  const calculateStats = (bookings: Booking[], labs: Lab[], users: User[]) => {
    const now = new Date();
    const daysAgo = parseInt(dateRange);
    const startDate = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);
    const prevStartDate = new Date(startDate.getTime() - daysAgo * 24 * 60 * 60 * 1000);

    // Filter bookings by date range
    const currentBookings = bookings.filter(b => new Date(b.createdAt) >= startDate);
    const prevBookings = bookings.filter(b => {
      const date = new Date(b.createdAt);
      return date >= prevStartDate && date < startDate;
    });

    // Calculate revenue
    const currentRevenue = currentBookings.reduce((sum, b) => sum + (b.price || 0), 0);
    const prevRevenue = prevBookings.reduce((sum, b) => sum + (b.price || 0), 0);
    const revenueChange = prevRevenue > 0 ? ((currentRevenue - prevRevenue) / prevRevenue) * 100 : 0;

    // Calculate bookings change
    const bookingsChange = prevBookings.length > 0 
      ? ((currentBookings.length - prevBookings.length) / prevBookings.length) * 100 
      : 0;

    // Active labs
    const activeLabs = labs.filter(l => l.isActive !== false).length;

    // New users (mock calculation based on total)
    const newUsers = users.length;

    setStats({
      totalRevenue: currentRevenue,
      totalBookings: currentBookings.length,
      newUsers,
      activeLabs: activeLabs || 4, // Default to 4 if no data
      revenueChange: Math.round(revenueChange * 10) / 10,
      bookingsChange: Math.round(bookingsChange * 10) / 10,
      usersChange: 0,
      labsChange: 0,
    });
  };

  const handleResetReports = async () => {
    setIsResetting(true);
    try {
      // Clear bookings from Supabase
      await fetch('/api/supabase/bookings/reset', { method: 'POST' });
      
      // Clear local storage
      localStorage.removeItem(REPORT_DATA_KEY);
      localStorage.removeItem('mediconnect_cart');

      // Reset state
      setBookings([]);
      setStats({
        totalRevenue: 0,
        totalBookings: 0,
        newUsers: 0,
        activeLabs: labs.length || 4,
        revenueChange: 0,
        bookingsChange: 0,
        usersChange: 0,
        labsChange: 0,
      });

      toast({
        title: "Reports Reset",
        description: "All booking data has been cleared from the database.",
      });
      
      setShowResetDialog(false);
      
      // Refresh data
      fetchAllData();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reset reports. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsResetting(false);
    }
  };

  // Get top bundles from bookings
  const getTopBundles = () => {
    const bundleStats: Record<string, { bookings: number; revenue: number }> = {};
    
    bookings.forEach(booking => {
      const name = booking.bundleName || 'Unknown Bundle';
      if (!bundleStats[name]) {
        bundleStats[name] = { bookings: 0, revenue: 0 };
      }
      bundleStats[name].bookings++;
      bundleStats[name].revenue += booking.price || 0;
    });

    return Object.entries(bundleStats)
      .map(([name, data]) => ({ name, ...data, change: '+0%' }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  };

  // Get top labs from bookings
  const getTopLabs = () => {
    const labStats: Record<string, { bookings: number; revenue: number }> = {};
    
    bookings.forEach(booking => {
      const name = booking.labName || 'Unknown Lab';
      if (!labStats[name]) {
        labStats[name] = { bookings: 0, revenue: 0 };
      }
      labStats[name].bookings++;
      labStats[name].revenue += booking.price || 0;
    });

    return Object.entries(labStats)
      .map(([name, data]) => ({ 
        name, 
        ...data, 
        rating: labs.find(l => l.name === name)?.rating || 4.5 
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 4);
  };

  // Get bookings by status
  const getBookingsByStatus = () => {
    const statusCounts: Record<string, number> = {
      Completed: 0,
      Confirmed: 0,
      Pending: 0,
      Cancelled: 0,
    };

    bookings.forEach(booking => {
      const status = booking.status || 'Pending';
      if (statusCounts[status] !== undefined) {
        statusCounts[status]++;
      }
    });

    const total = Object.values(statusCounts).reduce((a, b) => a + b, 0) || 1;

    return Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
      percentage: Math.round((count / total) * 1000) / 10,
    }));
  };

  const statCards = [
    { 
      label: 'Total Revenue', 
      value: `AED ${stats.totalRevenue.toLocaleString()}`, 
      change: stats.revenueChange, 
      icon: DollarSign, 
      color: 'from-emerald-500 to-teal-500' 
    },
    { 
      label: 'Total Bookings', 
      value: stats.totalBookings.toLocaleString(), 
      change: stats.bookingsChange, 
      icon: Calendar, 
      color: 'from-blue-500 to-cyan-500' 
    },
    { 
      label: 'Total Users', 
      value: stats.newUsers.toLocaleString(), 
      change: stats.usersChange, 
      icon: Users, 
      color: 'from-violet-500 to-purple-500' 
    },
    { 
      label: 'Active Labs', 
      value: stats.activeLabs.toLocaleString(), 
      change: stats.labsChange, 
      icon: Building2, 
      color: 'from-orange-500 to-amber-500' 
    },
  ];

  const topBundles = getTopBundles();
  const topLabs = getTopLabs();
  const bookingsByStatus = getBookingsByStatus();

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Completed: 'bg-emerald-500',
      Confirmed: 'bg-blue-500',
      Pending: 'bg-amber-500',
      Cancelled: 'bg-red-500',
    };
    return colors[status] || 'bg-slate-500';
  };

  return (
    <AdminLayout title="Reports" subtitle="Analytics and performance insights">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-48 bg-slate-800 border-slate-700 text-white" data-testid="select-date-range">
                <Calendar className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              className="border-slate-600 text-slate-300" 
              onClick={fetchAllData}
              disabled={isLoading}
              data-testid="button-refresh"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              className="border-red-500/50 text-red-400 hover:bg-red-500/10" 
              onClick={() => setShowResetDialog(true)}
              data-testid="button-reset-reports"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Reset Reports
            </Button>
            <Button variant="outline" className="border-slate-600 text-slate-300" data-testid="button-export-report">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Live Data Indicator */}
        <div className="flex items-center gap-2 text-sm">
          <span className={`w-2 h-2 rounded-full ${bookings.length > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-slate-500'}`} />
          <span className="text-slate-400">
            {bookings.length > 0 
              ? `Live data: ${bookings.length} bookings tracked` 
              : 'No bookings yet. Data will appear as customers make bookings.'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((stat, i) => (
            <div
              key={i}
              className="relative overflow-hidden bg-slate-800/50 rounded-2xl p-6 border border-slate-700"
              data-testid={`stat-card-${i}`}
            >
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${stat.color} opacity-20 rounded-full -translate-y-1/2 translate-x-1/2`} />
              <div className="relative">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-4`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <p className="text-3xl font-bold text-white">{stat.value}</p>
                <p className="text-slate-400">{stat.label}</p>
                {stat.change !== 0 && (
                  <div className="flex items-center gap-1 mt-2">
                    {stat.change > 0 ? (
                      <>
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm text-emerald-400">+{stat.change}%</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-4 h-4 text-red-400" />
                        <span className="text-sm text-red-400">{stat.change}%</span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-6 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Package className="w-5 h-5 text-blue-400" />
                <h3 className="text-lg font-semibold text-white">Top Performing Bundles</h3>
              </div>
              <Badge variant="outline" className="border-slate-600 text-slate-400">
                {topBundles.length} bundles
              </Badge>
            </div>
            <div className="divide-y divide-slate-700/50">
              {topBundles.length > 0 ? topBundles.map((bundle, i) => (
                <div key={i} className="p-4 flex items-center justify-between" data-testid={`bundle-row-${i}`}>
                  <div className="flex items-center gap-4">
                    <span className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center text-slate-400 font-bold text-sm">{i + 1}</span>
                    <div>
                      <p className="font-medium text-white">{bundle.name}</p>
                      <p className="text-sm text-slate-400">{bundle.bookings} bookings</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-white">AED {bundle.revenue.toLocaleString()}</p>
                  </div>
                </div>
              )) : (
                <div className="p-8 text-center text-slate-400">
                  <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No bundle data yet</p>
                  <p className="text-sm">Bookings will appear here</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-6 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Building2 className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg font-semibold text-white">Top Partner Labs</h3>
              </div>
              <Badge variant="outline" className="border-slate-600 text-slate-400">
                {topLabs.length} labs
              </Badge>
            </div>
            <div className="divide-y divide-slate-700/50">
              {topLabs.length > 0 ? topLabs.map((lab, i) => (
                <div key={i} className="p-4 flex items-center justify-between" data-testid={`lab-row-${i}`}>
                  <div className="flex items-center gap-4">
                    <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">{i + 1}</span>
                    <div>
                      <p className="font-medium text-white">{lab.name}</p>
                      <p className="text-sm text-slate-400">{lab.bookings} bookings</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-white">AED {lab.revenue.toLocaleString()}</p>
                    <Badge className="bg-amber-500/20 text-amber-400 mt-1">{lab.rating} rating</Badge>
                  </div>
                </div>
              )) : (
                <div className="p-8 text-center text-slate-400">
                  <Building2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No lab data yet</p>
                  <p className="text-sm">Bookings will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <div className="flex items-center gap-3 mb-6">
              <BarChart3 className="w-5 h-5 text-teal-400" />
              <h3 className="text-lg font-semibold text-white">Bookings by Status</h3>
            </div>
            <div className="space-y-4">
              {bookingsByStatus.map((item, i) => (
                <div key={i} data-testid={`status-bar-${i}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-slate-400">{item.status}</span>
                    <span className="text-sm font-medium text-white">{item.count} ({item.percentage}%)</span>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${getStatusColor(item.status)} rounded-full transition-all`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <div className="flex items-center gap-3 mb-6">
              <FileText className="w-5 h-5 text-blue-400" />
              <h3 className="text-lg font-semibold text-white">Quick Reports</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-auto py-4 border-slate-600 text-slate-300 justify-start" data-testid="button-revenue-report">
                <DollarSign className="w-5 h-5 mr-3 text-emerald-400" />
                <div className="text-left">
                  <p className="font-medium">Revenue Report</p>
                  <p className="text-xs text-slate-500">Detailed breakdown</p>
                </div>
              </Button>
              <Button variant="outline" className="h-auto py-4 border-slate-600 text-slate-300 justify-start" data-testid="button-booking-report">
                <Calendar className="w-5 h-5 mr-3 text-blue-400" />
                <div className="text-left">
                  <p className="font-medium">Booking Report</p>
                  <p className="text-xs text-slate-500">All appointments</p>
                </div>
              </Button>
              <Button variant="outline" className="h-auto py-4 border-slate-600 text-slate-300 justify-start" data-testid="button-lab-report">
                <Building2 className="w-5 h-5 mr-3 text-purple-400" />
                <div className="text-left">
                  <p className="font-medium">Lab Performance</p>
                  <p className="text-xs text-slate-500">Partner analytics</p>
                </div>
              </Button>
              <Button variant="outline" className="h-auto py-4 border-slate-600 text-slate-300 justify-start" data-testid="button-user-report">
                <Users className="w-5 h-5 mr-3 text-amber-400" />
                <div className="text-left">
                  <p className="font-medium">User Report</p>
                  <p className="text-xs text-slate-500">Registration trends</p>
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Dialog */}
      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-400">
              <AlertTriangle className="w-5 h-5" />
              Reset All Report Data
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-slate-300 mb-4">
              Are you sure you want to reset all report data? This will clear:
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                All booking records and history
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                Revenue and statistics data
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                Cart data and session information
              </li>
            </ul>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowResetDialog(false)}
              className="border-slate-600"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleResetReports}
              disabled={isResetting}
              className="bg-red-600 hover:bg-red-700"
              data-testid="button-confirm-reset"
            >
              {isResetting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Resetting...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Reset All Data
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
