import { useState, useEffect } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { 
  ArrowLeft, Check, Clock, AlertCircle, ShieldCheck, MapPin, Phone, Beaker, ArrowRight,
  ChevronDown, ChevronUp, Star, Home, CreditCard, FileText, X, Plus, Users,
  Droplets, BadgeCheck, MessageCircle, HelpCircle, ShoppingCart
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Navbar } from "@/components/Navbar";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { useCart } from "@/contexts/CartContext";

// Comprehensive bundle data with all packages
const bundleDetailsData: Record<string, {
  name: string;
  description: string;
  category: string;
  price: string;
  originalPrice?: string;
  turnaround: string;
  testsIncluded: number;
  isPopular: boolean;
  color: string;
  gradient: string;
  parameters: { category: string; tests: string[] }[];
  benefits: string[];
  preparation: string[];
  whoShouldTake: string[];
  fasting?: string;
  homeCollection?: boolean;
}> = {
  // Full Body Checkup
  "1": {
    name: "Full Body Checkup",
    description: "Our most comprehensive health screening with 40+ parameters covering all major organ systems. Ideal for annual health assessments and early disease detection.",
    category: "Premium",
    price: "699",
    originalPrice: "899",
    turnaround: "24-48 hours",
    testsIncluded: 42,
    isPopular: true,
    color: "blue",
    gradient: "from-blue-600 to-indigo-600",
    fasting: "10-12 hrs",
    homeCollection: true,
    parameters: [
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "WBC Count", "Platelet Count", "RBC Indices", "PCV"] },
      { category: "Liver Function", tests: ["ALT", "AST", "Bilirubin", "Albumin", "ALP", "GGT"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN", "Uric Acid", "eGFR"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides", "VLDL"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate"] },
      { category: "Minerals", tests: ["Calcium", "Iron", "Ferritin"] },
    ],
    benefits: ["Complete health overview", "Early disease detection", "Baseline health records", "Doctor consultation included"],
    preparation: ["Fasting required for 10-12 hours", "Drink plenty of water", "Avoid alcohol 24 hours before", "Bring a valid ID"],
    whoShouldTake: ["Adults over 30 for annual checkup", "Anyone with family history of chronic diseases", "People starting a new fitness program", "Those experiencing unexplained symptoms"]
  },
  // Women's Wellness Panel
  "2": {
    name: "Women's Wellness Panel",
    description: "Complete health screening designed specifically for women including hormone balance, reproductive health, and essential vitamins for overall wellness.",
    category: "Women's Health",
    price: "599",
    originalPrice: "799",
    turnaround: "24-48 hours",
    testsIncluded: 35,
    isPopular: true,
    color: "pink",
    gradient: "from-pink-500 to-rose-600",
    fasting: "8-10 hrs",
    homeCollection: true,
    parameters: [
      { category: "Hormone Panel", tests: ["FSH", "LH", "Estradiol", "Progesterone", "Prolactin"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4", "Anti-TPO"] },
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "Iron", "Ferritin"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate", "Calcium"] },
      { category: "Diabetes", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
    ],
    benefits: ["Hormone balance check", "Fertility insights", "Bone health assessment", "Anemia detection"],
    preparation: ["Best done on day 2-5 of menstrual cycle for hormone tests", "Fasting required for 8-10 hours", "Inform about any medications"],
    whoShouldTake: ["Women aged 25-45 for routine screening", "Those with irregular periods", "Women planning pregnancy", "Anyone experiencing fatigue or mood changes"]
  },
  // Heart & Cholesterol Panel
  "3": {
    name: "Heart & Cholesterol Panel",
    description: "Comprehensive cardiovascular risk assessment including lipid profile, cardiac markers, and inflammation indicators to evaluate your heart health.",
    category: "Heart Health",
    price: "299",
    originalPrice: "399",
    turnaround: "24 hours",
    testsIncluded: 15,
    isPopular: true,
    color: "red",
    gradient: "from-red-500 to-red-700",
    fasting: "12 hrs",
    homeCollection: true,
    parameters: [
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL Cholesterol", "HDL Cholesterol", "Triglycerides", "VLDL", "Non-HDL Cholesterol"] },
      { category: "Cardiac Markers", tests: ["hs-CRP", "Homocysteine", "Lipoprotein(a)"] },
      { category: "Blood Sugar", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN"] },
    ],
    benefits: ["Heart disease risk assessment", "Cholesterol monitoring", "Inflammation detection", "Lifestyle guidance"],
    preparation: ["Fasting required for 12 hours", "Avoid fatty foods 24 hours before", "No exercise morning of test"],
    whoShouldTake: ["Adults over 40", "Those with family history of heart disease", "People with high blood pressure", "Smokers and diabetics"]
  },
  // Energy & Fatigue Panel
  "4": {
    name: "Energy & Fatigue Panel",
    description: "Comprehensive panel to identify causes of fatigue, low energy, and tiredness including vitamin deficiencies, thyroid disorders, and anemia.",
    category: "Energy",
    price: "449",
    originalPrice: "599",
    turnaround: "24-48 hours",
    testsIncluded: 22,
    isPopular: false,
    color: "amber",
    gradient: "from-amber-500 to-orange-500",
    fasting: "8-10 hrs",
    homeCollection: true,
    parameters: [
      { category: "Blood Count", tests: ["CBC with ESR", "Hemoglobin", "Iron", "Ferritin", "TIBC"] },
      { category: "Thyroid", tests: ["TSH", "Free T3", "Free T4"] },
      { category: "Vitamins", tests: ["Vitamin D", "Vitamin B12", "Folate"] },
      { category: "Metabolic", tests: ["Fasting Glucose", "HbA1c"] },
      { category: "Liver & Kidney", tests: ["ALT", "AST", "Creatinine", "BUN"] },
      { category: "Electrolytes", tests: ["Sodium", "Potassium", "Calcium", "Magnesium"] },
    ],
    benefits: ["Identify fatigue causes", "Anemia detection", "Thyroid assessment", "Vitamin deficiency check"],
    preparation: ["Fasting required for 8-10 hours", "Get adequate sleep before test", "List all medications and supplements"],
    whoShouldTake: ["Anyone feeling constantly tired", "Those with unexplained fatigue", "People with poor sleep quality", "Vegetarians and vegans"]
  },
  // Diabetes Monitoring Panel
  "5": {
    name: "Diabetes Monitoring Panel",
    description: "Complete diabetes management panel to track blood sugar control and detect complications early including kidney function and lipid profile.",
    category: "Diabetes",
    price: "249",
    originalPrice: "349",
    turnaround: "24 hours",
    testsIncluded: 12,
    isPopular: false,
    color: "orange",
    gradient: "from-orange-500 to-amber-600",
    fasting: "10-12 hrs",
    homeCollection: true,
    parameters: [
      { category: "Blood Sugar", tests: ["Fasting Glucose", "Post-Prandial Glucose", "HbA1c"] },
      { category: "Kidney Health", tests: ["Creatinine", "BUN", "Microalbumin/Creatinine Ratio"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
      { category: "Liver Function", tests: ["ALT", "AST"] },
    ],
    benefits: ["HbA1c monitoring", "Kidney function check", "Heart risk assessment", "Quarterly tracking"],
    preparation: ["Fasting required for 10-12 hours", "Take medications as usual unless instructed otherwise", "Bring previous test reports"],
    whoShouldTake: ["Diagnosed diabetics for monitoring", "Pre-diabetics", "Those with family history of diabetes", "People with obesity or metabolic syndrome"]
  },
  // Essential Health Check
  "6": {
    name: "Essential Health Check",
    description: "Basic health screening perfect for young adults and routine annual checkups covering essential parameters at an affordable price.",
    category: "General",
    price: "199",
    originalPrice: "299",
    turnaround: "24 hours",
    testsIncluded: 18,
    isPopular: false,
    color: "blue",
    gradient: "from-blue-500 to-blue-700",
    fasting: "8-10 hrs",
    homeCollection: true,
    parameters: [
      { category: "Blood Count", tests: ["CBC", "Hemoglobin", "WBC Count"] },
      { category: "Liver Function", tests: ["ALT", "AST", "Bilirubin"] },
      { category: "Kidney Function", tests: ["Creatinine", "BUN"] },
      { category: "Diabetes", tests: ["Fasting Glucose"] },
      { category: "Lipid Profile", tests: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"] },
    ],
    benefits: ["Affordable screening", "Quick results", "Essential parameters", "Perfect for annual checkups"],
    preparation: ["Fasting required for 8-10 hours", "Drink water normally", "Avoid heavy meals the night before"],
    whoShouldTake: ["Young adults 18-35", "Anyone seeking basic health screening", "Pre-employment checkups", "Insurance health assessments"]
  },
  // HbA1c Blood Sugar Test
  "7": {
    name: "HbA1c Blood Sugar Test",
    description: "Affordable HbA1c test to monitor your blood sugar levels over the past 2-3 months. Essential for diabetes screening and management.",
    category: "Diabetes",
    price: "99",
    turnaround: "24 hours",
    testsIncluded: 1,
    isPopular: true,
    color: "orange",
    gradient: "from-orange-400 to-orange-600",
    fasting: "None",
    homeCollection: true,
    parameters: [
      { category: "Blood Sugar", tests: ["HbA1c (Glycated Hemoglobin)"] },
    ],
    benefits: ["3-month average blood sugar", "No fasting required", "Quick and affordable", "Diabetes risk assessment"],
    preparation: ["No fasting required", "Can be done any time of day", "No special preparation needed"],
    whoShouldTake: ["Diabetics for regular monitoring", "Those at risk of diabetes", "Anyone over 45", "People with prediabetes"]
  },
};

// Lab options data
const labOptions = [
  { id: 'alborg', name: 'Al Borg Diagnostics', price: 699, rating: 4.9, locations: 25, bestPrice: false },
  { id: 'aster', name: 'Aster Labs', price: 749, rating: 4.8, locations: 30, bestPrice: false },
  { id: 'nmc', name: 'NMC Healthcare', price: 649, rating: 4.7, locations: 20, bestPrice: true },
  { id: 'mediclinic', name: 'Mediclinic', price: 729, rating: 4.8, locations: 15, bestPrice: false },
];

// Time slots
const timeSlots = [
  { id: 't1', label: 'Today 3 PM', available: true },
  { id: 't2', label: 'Today 5 PM', available: true },
  { id: 't3', label: 'Tomorrow 9 AM', available: true },
  { id: 't4', label: 'Tomorrow 2 PM', available: true },
];

// Customer reviews data
const customerReviews = [
  {
    id: 1,
    name: 'Fatima A.',
    location: 'Dubai Marina',
    rating: 5,
    text: 'Very professional service! The home collection was on time and the reports came within 24 hours. Highly recommend for anyone looking for comprehensive health screening.',
    date: '3 days ago',
    verified: true,
  },
  {
    id: 2,
    name: 'Mohammed K.',
    location: 'Business Bay',
    rating: 5,
    text: 'Best price I found for this comprehensive checkup. The lab staff was very professional and I received a call from the doctor to explain my results.',
    date: '1 week ago',
    verified: true,
  },
  {
    id: 3,
    name: 'Sarah L.',
    location: 'JLT',
    rating: 4,
    text: 'Good experience overall. Easy booking process and timely results. The only suggestion would be to have more time slots available on weekends.',
    date: '2 weeks ago',
    verified: true,
  },
];

// FAQ data
const faqData = [
  {
    question: 'How long do I need to fast before the test?',
    answer: 'For most comprehensive panels, fasting for 10-12 hours is recommended. This means no food or drinks except water. The specific fasting requirement is mentioned in the preparation guidelines above.',
  },
  {
    question: 'Can I take my regular medications before the test?',
    answer: 'Most medications can be continued as prescribed. However, certain medications like biotin supplements may need to be stopped before thyroid tests. Please inform the lab about all medications you are taking.',
  },
  {
    question: 'How will I receive my test results?',
    answer: 'Test results are sent via email and are also available in your MediConnect account within 24-48 hours. You will also receive a WhatsApp notification when results are ready. A doctor consultation can be scheduled if needed.',
  },
  {
    question: 'What should I do if my results are abnormal?',
    answer: 'All packages include a free doctor consultation to explain your results. If any values are significantly abnormal, our medical team will proactively reach out to you. Never make medical decisions without consulting a qualified healthcare provider.',
  },
];

// Upsell add-ons
const upsellAddons = [
  { id: 'vitd', name: 'Vitamin D Test', price: 85, popularity: '78% of users add this', description: 'Check vitamin D levels' },
  { id: 'hba1c', name: 'HbA1c (Diabetes)', price: 65, popularity: 'Complete diabetes screening', description: '3-month blood sugar average' },
  { id: 'iron', name: 'Iron Studies', price: 95, popularity: 'Popular with women', description: 'Comprehensive iron panel' },
];

export default function BundleDetailsPage() {
  const [, params] = useRoute("/bundles/:id");
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState(true);
  const [selectedLab, setSelectedLab] = useState('nmc');
  const [selectedSlot, setSelectedSlot] = useState('t1');
  const [homeCollection, setHomeCollection] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('Dubai');
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [showSampleReport, setShowSampleReport] = useState(false);
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const { toast } = useToast();
  const { addItem, isInCart, getItemCount } = useCart();

  const bundleId = params?.id || "";
  const bundleDetails = bundleDetailsData[bundleId] || bundleDetailsData["1"];

  // Initialize first category as expanded
  useEffect(() => {
    if (bundleDetails?.parameters?.length > 0) {
      setExpandedCategories([bundleDetails.parameters[0].category]);
    }
  }, [bundleId]);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(timer);
  }, [bundleId]);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const toggleAddon = (addonId: string) => {
    setSelectedAddons(prev => 
      prev.includes(addonId)
        ? prev.filter(a => a !== addonId)
        : [...prev, addonId]
    );
  };

  // Calculate total price
  const selectedLabData = labOptions.find(l => l.id === selectedLab);
  const basePrice = selectedLabData?.price || parseInt(bundleDetails.price);
  const homeCollectionFee = 0; // Home collection is now FREE
  const addonsTotal = selectedAddons.reduce((sum, id) => {
    const addon = upsellAddons.find(a => a.id === id);
    return sum + (addon?.price || 0);
  }, 0);
  const totalPrice = basePrice + homeCollectionFee + addonsTotal;
  const originalPrice = parseInt(bundleDetails.originalPrice || bundleDetails.price);
  const discount = Math.round(((originalPrice - parseInt(bundleDetails.price)) / originalPrice) * 100);

  // Similar packages for comparison
  const similarPackages = [
    { id: bundleId, name: bundleDetails.name, tests: bundleDetails.testsIncluded, price: bundleDetails.price, current: true },
    { id: '6', name: 'Essential Health Check', tests: 18, price: '199', current: false, label: 'Budget Option' },
    { id: '8', name: 'Senior Citizen Panel', tests: 50, price: '799', current: false, label: 'Premium' },
  ];

  // Add to cart handler
  const handleAddToCart = () => {
    const selectedLabData = labOptions.find(l => l.id === selectedLab);
    const selectedSlotData = timeSlots.find(s => s.id === selectedSlot);
    
    addItem({
      id: bundleId,
      type: 'bundle',
      name: bundleDetails.name,
      description: bundleDetails.description,
      price: parseInt(bundleDetails.price),
      originalPrice: bundleDetails.originalPrice ? parseInt(bundleDetails.originalPrice) : undefined,
      testCount: bundleDetails.testsIncluded,
      selectedLab: selectedLabData ? {
        id: selectedLabData.id,
        name: selectedLabData.name,
        price: selectedLabData.price,
      } : undefined,
      selectedSlot: selectedSlotData?.label,
      homeCollection,
      addons: selectedAddons.map(addonId => {
        const addon = upsellAddons.find(a => a.id === addonId);
        return addon ? { id: addon.id, name: addon.name, price: addon.price } : null;
      }).filter(Boolean) as { id: string; name: string; price: number }[],
    });

    toast({
      title: "Added to My Tests! 🩺",
      description: `${bundleDetails.name} has been added to your test basket`,
    });
  };

  // Handle checkout navigation
  const handleCheckout = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  const itemInCart = isInCart(bundleId);
  const cartCount = getItemCount();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-6xl mx-auto px-4 py-20 text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
          <p className="mt-4 text-gray-600">Loading package details...</p>
        </div>
      </div>
    );
  }

  if (!bundleDetails) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-6xl mx-auto px-4 py-20 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Package Not Found</h2>
          <p className="text-gray-600 mb-6">The package you're looking for doesn't exist.</p>
          <Link href="/tests">
            <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Browse All Tests
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24 sm:pb-0">
      <Navbar />

      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <Link href="/tests" className="hover:text-blue-600">Tests</Link>
            <span>/</span>
            <span className="text-gray-900 font-medium">{bundleDetails.name}</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className={`bg-gradient-to-r ${bundleDetails.gradient} text-white py-10`}>
        <div className="max-w-7xl mx-auto px-4">
          <Link href="/tests">
            <button className="flex items-center gap-2 text-white/80 hover:text-white mb-4 transition-colors" data-testid="back-button">
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Tests</span>
            </button>
          </Link>

          <div className="flex-1">
            {bundleDetails.isPopular && (
              <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur rounded-full text-sm font-semibold mb-3">
                🔥 Popular Choice
              </span>
            )}
            <h1 className="text-3xl md:text-4xl font-bold mb-3" data-testid="bundle-title">
              {bundleDetails.name}
            </h1>
            <p className="text-lg text-white/90 mb-4 max-w-3xl">
              {bundleDetails.description}
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-white/10 backdrop-blur rounded-full text-sm">
                {bundleDetails.category}
              </span>
              <span className="px-3 py-1 bg-white/10 backdrop-blur rounded-full text-sm flex items-center gap-1">
                <Beaker className="w-4 h-4" />
                {bundleDetails.testsIncluded} tests
              </span>
              <span className="px-3 py-1 bg-white/10 backdrop-blur rounded-full text-sm flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {bundleDetails.turnaround}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Info Bar */}
      <section className="bg-white border-b" data-testid="quick-info-bar">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-8 text-sm">
            <div className="flex items-center gap-2 text-gray-700">
              <Clock className="w-4 h-4 text-blue-600" />
              <span><strong>Results:</strong> {bundleDetails.turnaround}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-700">
              <Droplets className="w-4 h-4 text-red-500" />
              <span><strong>Fasting:</strong> {bundleDetails.fasting || '10-12 hrs'}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-700">
              <Home className="w-4 h-4 text-purple-600" />
              <span><strong>Home:</strong> {bundleDetails.homeCollection !== false ? 'Yes' : 'No'}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-700">
              <MapPin className="w-4 h-4 text-green-600" />
              <span><strong>{labOptions.length} Labs</strong> available</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Column - Main Content */}
          <div className="flex-1 space-y-8">
            {/* Tests Included - Collapsible Accordion */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden" data-testid="tests-accordion">
              <div className="p-6 border-b">
                <h2 className="text-2xl font-bold text-gray-900">Tests Included ({bundleDetails.testsIncluded})</h2>
              </div>
              <div className="divide-y">
                {bundleDetails.parameters.map((param) => {
                  const isExpanded = expandedCategories.includes(param.category);
                  return (
                    <div key={param.category}>
                      <button
                        onClick={() => toggleCategory(param.category)}
                        className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${bundleDetails.gradient}`}></div>
                          <span className="font-semibold text-gray-900">{param.category}</span>
                          <span className="text-sm text-gray-500">({param.tests.length} tests)</span>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="px-6 pb-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {param.tests.map((test, i) => (
                                <div key={i} className="flex items-center gap-2 text-sm text-gray-600 py-1">
                                  <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                                  <span>{test}</span>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Benefits */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Benefits</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {bundleDetails.benefits.map((benefit, index) => (
                  <div key={index} className="text-center p-4 bg-gray-50 rounded-xl">
                    <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${bundleDetails.gradient} flex items-center justify-center mx-auto mb-2`}>
                      <Check className="w-5 h-5 text-white" />
                    </div>
                    <p className="text-sm font-medium text-gray-700">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Who Should Take */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Who Should Take This Test?</h2>
              <div className="grid md:grid-cols-2 gap-3">
                {bundleDetails.whoShouldTake.map((item, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${bundleDetails.gradient} flex items-center justify-center flex-shrink-0`}>
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <p className="text-gray-700 text-sm">{item}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Customer Reviews */}
            <div className="bg-white rounded-2xl shadow-lg p-6" data-testid="customer-reviews">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Customer Reviews (234)</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-0.5">
                      {[1,2,3,4,5].map(i => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="font-semibold text-gray-900">4.8</span>
                  </div>
                </div>
                <button className="text-blue-600 hover:underline text-sm font-medium">
                  Read all reviews →
                </button>
              </div>
              
              <div className="space-y-4">
                {customerReviews.map(review => (
                  <div key={review.id} className="border border-gray-100 rounded-xl p-4">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-700 text-sm mb-3">"{review.text}"</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-gray-900 text-sm">{review.name}</span>
                        <span className="text-gray-500 text-xs">{review.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {review.verified && (
                          <span className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                            <BadgeCheck className="w-3 h-3" /> Verified
                          </span>
                        )}
                        <span className="text-xs text-gray-400">{review.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Compare Section */}
            <div className="bg-white rounded-2xl shadow-lg p-6" data-testid="compare-section">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Compare with Similar Packages</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {similarPackages.map(pkg => (
                  <div 
                    key={pkg.id} 
                    className={`border-2 rounded-xl p-4 transition-all ${
                      pkg.current 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {pkg.current && (
                      <span className="inline-block px-2 py-0.5 bg-blue-600 text-white text-xs font-semibold rounded-full mb-2">
                        Current Selection
                      </span>
                    )}
                    {pkg.label && !pkg.current && (
                      <span className="inline-block px-2 py-0.5 bg-gray-200 text-gray-700 text-xs font-semibold rounded-full mb-2">
                        {pkg.label}
                      </span>
                    )}
                    <h3 className="font-bold text-gray-900 mb-1">{pkg.name}</h3>
                    <p className="text-sm text-gray-500 mb-2">{pkg.tests} tests</p>
                    <p className="text-xl font-bold text-blue-600">AED {pkg.price}</p>
                    {!pkg.current && (
                      <Link href={`/bundles/${pkg.id}`}>
                        <button className="mt-3 w-full py-2 text-sm text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50">
                          View Details
                        </button>
                      </Link>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* FAQ Accordion */}
            <div className="bg-white rounded-2xl shadow-lg p-6" data-testid="faq-section">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <HelpCircle className="w-6 h-6 text-blue-600" />
                Frequently Asked Questions
              </h2>
              <div className="space-y-2">
                {faqData.map((faq, index) => (
                  <div key={index} className="border border-gray-200 rounded-xl overflow-hidden">
                    <button
                      onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                      className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-gray-50"
                    >
                      <span className="font-medium text-gray-900">{faq.question}</span>
                      {expandedFaq === index ? (
                        <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                      )}
                    </button>
                    <AnimatePresence>
                      {expandedFaq === index && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-5 pb-4 text-gray-600 text-sm">
                            {faq.answer}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
            </div>

            {/* Preparation Guidelines */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Preparation Guidelines</h3>
                  <ul className="space-y-2 text-gray-700">
                    {bundleDetails.preparation.map((item, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <span className="text-amber-600 mt-0.5">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Sticky Price Card */}
          <div className="lg:w-[380px]">
            <div className="sticky top-4 space-y-4">
              {/* Price Card */}
              <div className="bg-white rounded-2xl shadow-xl p-6" data-testid="price-card">
                {/* Location Selector */}
                <div className="flex items-center justify-between mb-4 pb-4 border-b">
                  <button className="flex items-center gap-2 text-gray-700 hover:text-blue-600">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">{selectedLocation}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                </div>

                {/* Lab Selection */}
                <div className="mb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-3">Select Lab:</p>
                  <div className="space-y-2">
                    {labOptions.map(lab => (
                      <label 
                        key={lab.id}
                        className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                          selectedLab === lab.id 
                            ? 'bg-blue-50 border-2 border-blue-500' 
                            : 'bg-gray-50 border-2 border-transparent hover:border-gray-200'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="radio"
                            name="lab"
                            value={lab.id}
                            checked={selectedLab === lab.id}
                            onChange={() => setSelectedLab(lab.id)}
                            className="w-4 h-4 text-blue-600"
                          />
                          <div>
                            <p className="font-medium text-gray-900 text-sm">{lab.name}</p>
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              {lab.rating}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-gray-900">AED {lab.price}</p>
                          {lab.bestPrice && (
                            <span className="text-xs text-green-600 font-medium">🏷️ Best Price</span>
                          )}
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Time Slots */}
                <div className="mb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-3">Next Available:</p>
                  <div className="flex flex-wrap gap-2">
                    {timeSlots.map(slot => (
                      <button
                        key={slot.id}
                        onClick={() => setSelectedSlot(slot.id)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          selectedSlot === slot.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {slot.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* FREE Home/Office Collection Banner */}
                <div className="mb-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Home className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-900">FREE Home/Office Collection</span>
                        <span className="px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full">INCLUDED</span>
                      </div>
                      <p className="text-sm text-green-700 mt-0.5">Our technician will visit your location at your chosen time</p>
                    </div>
                  </div>
                </div>

                {/* Total Price */}
                <div className="mb-4 text-center">
                  <p className="text-sm text-gray-500">Total Amount</p>
                  <div className="flex items-baseline justify-center gap-2">
                    <span className="text-4xl font-bold text-blue-600">AED {totalPrice}</span>
                  </div>
                  {discount > 0 && (
                    <p className="text-sm text-green-600 font-medium">Save {discount}% vs walk-in</p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <button 
                    onClick={handleCheckout}
                    className={`w-full py-4 bg-gradient-to-r ${bundleDetails.gradient} text-white rounded-xl font-bold hover:opacity-90 transition-all shadow-lg flex items-center justify-center gap-2`}
                    data-testid="checkout-btn"
                  >
                    Book Now
                    <ArrowRight className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={handleAddToCart}
                    className={`w-full py-3 border-2 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
                      itemInCart 
                        ? 'border-green-500 text-green-600 bg-green-50' 
                        : 'border-blue-600 text-blue-600 hover:bg-blue-50'
                    }`}
                    data-testid="add-to-cart-btn"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {itemInCart ? 'Added to My Tests ✓' : 'Add to My Tests'}
                  </button>
                  {cartCount > 0 && (
                    <Link href="/checkout">
                      <button className="w-full py-2 text-sm text-blue-600 hover:underline">
                        View Test Basket ({cartCount} {cartCount === 1 ? 'test' : 'tests'})
                      </button>
                    </Link>
                  )}
                </div>

                {/* Trust Text */}
                <p className="text-center text-xs text-gray-500 mt-4 flex items-center justify-center gap-1">
                  <Check className="w-4 h-4 text-green-500" />
                  Free cancellation up to 2 hrs
                </p>
              </div>

              {/* Sample Report Button */}
              <button 
                onClick={() => setShowSampleReport(true)}
                className="w-full py-3 bg-white border border-gray-200 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
                data-testid="sample-report-btn"
              >
                <FileText className="w-5 h-5 text-blue-600" />
                View Sample Report
              </button>

              {/* Trust Enhancements */}
              <div className="bg-green-50 border border-green-200 rounded-xl p-4" data-testid="trust-section">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <Check className="w-4 h-4" />
                    Same tests, 20-30% lower than walk-in
                  </div>
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <Check className="w-4 h-4" />
                    NABL certified labs only
                  </div>
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <Check className="w-4 h-4" />
                    Free doctor consultation
                  </div>
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <Check className="w-4 h-4" />
                    100% refund guarantee
                  </div>
                </div>
              </div>

              {/* Upsell Section */}
              <div className="bg-white rounded-xl shadow-lg p-4" data-testid="upsell-section">
                <h3 className="font-bold text-gray-900 mb-3">Enhance Your Checkup</h3>
                <div className="space-y-2">
                  {upsellAddons.map(addon => (
                    <div 
                      key={addon.id}
                      className={`p-3 rounded-xl transition-all ${
                        selectedAddons.includes(addon.id)
                          ? 'bg-blue-50 border-2 border-blue-500'
                          : 'bg-gray-50 border-2 border-transparent'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-gray-900 text-sm">{addon.name}</p>
                          <p className="text-xs text-gray-500">{addon.popularity}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-gray-900">+AED {addon.price}</span>
                          <button
                            onClick={() => toggleAddon(addon.id)}
                            className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                              selectedAddons.includes(addon.id)
                                ? 'bg-blue-600 text-white'
                                : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                            }`}
                          >
                            {selectedAddons.includes(addon.id) ? 'Added' : 'Add'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sample Report Modal */}
      <AnimatePresence>
        {showSampleReport && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50"
              onClick={() => setShowSampleReport(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-4 md:inset-10 bg-white rounded-2xl z-50 flex flex-col"
            >
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="font-bold text-lg">Sample Report Preview</h3>
                <button onClick={() => setShowSampleReport(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 p-6 overflow-auto">
                <div className="max-w-2xl mx-auto">
                  <div className="bg-gray-50 rounded-xl p-8 text-center">
                    <FileText className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{bundleDetails.name}</h4>
                    <p className="text-gray-600 mb-6">Sample Lab Report</p>
                    <div className="bg-white rounded-lg p-6 text-left border">
                      <p className="text-sm text-gray-500 mb-4">This is a sample report preview. Actual reports include:</p>
                      <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Detailed test results with reference ranges</li>
                        <li className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Visual indicators for normal/abnormal values</li>
                        <li className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Doctor's interpretation notes</li>
                        <li className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" /> Recommendations for follow-up</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Bottom Bar */}
      <div className="sm:hidden fixed bottom-16 left-0 right-0 bg-white border-t shadow-2xl z-40 p-3" data-testid="mobile-bottom-bar">
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-blue-600">AED {totalPrice}</span>
              {discount > 0 && (
                <span className="text-xs text-green-600 font-medium">(Save {discount}%)</span>
              )}
            </div>
          </div>
          <button 
            onClick={handleAddToCart}
            className={`p-3 rounded-xl border-2 ${
              itemInCart ? 'border-green-500 text-green-600 bg-green-50' : 'border-blue-600 text-blue-600'
            }`}
          >
            <ShoppingCart className="w-5 h-5" />
          </button>
          <button 
            onClick={handleCheckout}
            className={`px-5 py-3 bg-gradient-to-r ${bundleDetails.gradient} text-white rounded-xl font-bold`}
          >
            Book Now
          </button>
        </div>
      </div>

      {/* Mobile Bottom Nav */}
      <MobileBottomNav />
    </div>
  );
}
