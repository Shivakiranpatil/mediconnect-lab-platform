import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Navbar } from "@/components/Navbar";
import { MobileBottomNav } from "@/components/MobileBottomNav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { 
  User, Mail, Phone, MapPin, Building2, Home, Save, LogOut,
  Shield, Calendar, ChevronRight, Edit, Check, Plus, Trash2, 
  Star, Briefcase, MoreHorizontal
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface Address {
  id: string;
  user_id: string;
  label: string;
  name: string;
  phone: string;
  city: string;
  area: string;
  building: string;
  flat_number: string;
  full_address: string;
  landmark: string;
  is_default: boolean;
}

const addressLabels = [
  { value: 'Home', icon: Home, color: 'bg-blue-100 text-blue-600' },
  { value: 'Office', icon: Briefcase, color: 'bg-purple-100 text-purple-600' },
  { value: 'Other', icon: MapPin, color: 'bg-gray-100 text-gray-600' },
];

export default function ProfilePage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isAuthenticated, logout, loading } = useAuth();
  
  const [supabaseUser, setSupabaseUser] = useState<any>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loadingAddresses, setLoadingAddresses] = useState(true);
  
  // Modal state
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [savingAddress, setSavingAddress] = useState(false);
  
  // Address form state
  const [addressForm, setAddressForm] = useState({
    label: 'Home',
    name: '',
    phone: '',
    city: 'Dubai',
    area: '',
    building: '',
    flat_number: '',
    full_address: '',
    landmark: '',
    is_default: false,
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate("/auth");
    }
  }, [loading, isAuthenticated, navigate]);

  // Load user data from Supabase
  useEffect(() => {
    if (user?.email) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    try {
      setLoadingAddresses(true);
      const res = await fetch(`/api/supabase/users/email/${encodeURIComponent(user!.email!)}`);
      if (res.ok) {
        const data = await res.json();
        if (data) {
          setSupabaseUser(data);
          // Load addresses
          const addressesRes = await fetch(`/api/supabase/users/${data.id}/addresses`);
          if (addressesRes.ok) {
            const addressesData = await addressesRes.json();
            setAddresses(addressesData);
          }
        }
      }
    } catch (error) {
      console.error("Failed to load user data:", error);
    } finally {
      setLoadingAddresses(false);
    }
  };

  const openAddAddress = () => {
    setEditingAddress(null);
    setAddressForm({
      label: 'Home',
      name: user?.displayName || '',
      phone: '',
      city: 'Dubai',
      area: '',
      building: '',
      flat_number: '',
      full_address: '',
      landmark: '',
      is_default: addresses.length === 0, // First address is default
    });
    setShowAddressModal(true);
  };

  const openEditAddress = (address: Address) => {
    setEditingAddress(address);
    setAddressForm({
      label: address.label || 'Home',
      name: address.name || '',
      phone: address.phone || '',
      city: address.city || 'Dubai',
      area: address.area || '',
      building: address.building || '',
      flat_number: address.flat_number || '',
      full_address: address.full_address || '',
      landmark: address.landmark || '',
      is_default: address.is_default || false,
    });
    setShowAddressModal(true);
  };

  const handleSaveAddress = async () => {
    if (!supabaseUser?.id) {
      toast({ title: "Error", description: "User not found", variant: "destructive" });
      return;
    }

    if (!addressForm.area || !addressForm.building) {
      toast({ title: "Error", description: "Area and Building are required", variant: "destructive" });
      return;
    }

    setSavingAddress(true);
    try {
      if (editingAddress) {
        // Update existing address
        const res = await fetch(`/api/supabase/addresses/${editingAddress.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(addressForm),
        });
        if (!res.ok) throw new Error("Failed to update");
        toast({ title: "Address Updated", description: "Your address has been updated" });
      } else {
        // Create new address
        const res = await fetch(`/api/supabase/users/${supabaseUser.id}/addresses`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(addressForm),
        });
        if (!res.ok) throw new Error("Failed to create");
        toast({ title: "Address Added", description: "New address has been saved" });
      }
      
      setShowAddressModal(false);
      loadUserData();
    } catch (error) {
      toast({ title: "Error", description: "Failed to save address", variant: "destructive" });
    } finally {
      setSavingAddress(false);
    }
  };

  const handleDeleteAddress = async (addressId: string) => {
    if (!confirm("Are you sure you want to delete this address?")) return;
    
    try {
      const res = await fetch(`/api/supabase/addresses/${addressId}`, {
        method: "DELETE",
      });
      if (res.ok) {
        toast({ title: "Address Deleted", description: "Address has been removed" });
        loadUserData();
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete address", variant: "destructive" });
    }
  };

  const handleSetDefault = async (address: Address) => {
    try {
      const res = await fetch(`/api/supabase/addresses/${address.id}/default`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: supabaseUser.id }),
      });
      if (res.ok) {
        toast({ title: "Default Address Set", description: `${address.label} is now your default address` });
        loadUserData();
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to set default", variant: "destructive" });
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const getLabelConfig = (label: string) => {
    return addressLabels.find(l => l.value === label) || addressLabels[2];
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0" data-testid="profile-page">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Profile Header */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-6">
              <div className="relative">
                {user.photoURL ? (
                  <img 
                    src={user.photoURL} 
                    alt={user.displayName || "Profile"} 
                    className="w-20 h-20 rounded-full object-cover border-4 border-blue-100"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <User className="w-10 h-10 text-white" />
                  </div>
                )}
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                  <Check className="w-3 h-3 text-white" />
                </div>
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">{user.displayName || "User"}</h1>
                <p className="text-gray-500 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {user.email}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                    Verified Account
                  </span>
                </div>
              </div>
              <Button
                variant="outline"
                className="border-red-200 text-red-600 hover:bg-red-50"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>

          {/* Saved Addresses */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Saved Addresses</h2>
                  <p className="text-sm text-gray-500">Manage your collection addresses</p>
                </div>
              </div>
              <Button
                onClick={openAddAddress}
                className="bg-blue-600 hover:bg-blue-700"
                data-testid="button-add-address"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Address
              </Button>
            </div>

            {loadingAddresses ? (
              <div className="py-8 text-center">
                <div className="animate-spin w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full mx-auto" />
              </div>
            ) : addresses.length === 0 ? (
              <div className="py-12 text-center border-2 border-dashed border-gray-200 rounded-xl">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 mb-4">No saved addresses yet</p>
                <Button onClick={openAddAddress} variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Address
                </Button>
              </div>
            ) : (
              <div className="grid gap-4">
                <AnimatePresence>
                  {addresses.map((address) => {
                    const labelConfig = getLabelConfig(address.label);
                    const IconComponent = labelConfig.icon;
                    
                    return (
                      <motion.div
                        key={address.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className={`relative p-4 rounded-xl border-2 transition-all ${
                          address.is_default 
                            ? 'border-blue-500 bg-blue-50/50' 
                            : 'border-gray-100 hover:border-gray-200'
                        }`}
                        data-testid={`address-card-${address.id}`}
                      >
                        <div className="flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${labelConfig.color}`}>
                            <IconComponent className="w-5 h-5" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-gray-900">{address.label}</span>
                              {address.is_default && (
                                <span className="px-2 py-0.5 bg-blue-600 text-white text-xs font-medium rounded-full flex items-center gap-1">
                                  <Star className="w-3 h-3" />
                                  Default
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-gray-600">
                              {address.building}{address.flat_number ? `, ${address.flat_number}` : ''}
                            </p>
                            <p className="text-sm text-gray-600">
                              {address.area}, {address.city}
                            </p>
                            {address.full_address && (
                              <p className="text-sm text-gray-500 mt-1">{address.full_address}</p>
                            )}
                            {address.phone && (
                              <p className="text-sm text-gray-500 mt-1 flex items-center gap-1">
                                <Phone className="w-3 h-3" /> {address.phone}
                              </p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            {!address.is_default && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                onClick={() => handleSetDefault(address)}
                                data-testid={`button-set-default-${address.id}`}
                              >
                                Set Default
                              </Button>
                            )}
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-gray-400 hover:text-gray-600"
                              onClick={() => openEditAddress(address)}
                              data-testid={`button-edit-address-${address.id}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-gray-400 hover:text-red-600"
                              onClick={() => handleDeleteAddress(address.id)}
                              data-testid={`button-delete-address-${address.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h2>
            <div className="space-y-2">
              <button
                onClick={() => navigate("/bookings")}
                className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-xl transition-colors"
                data-testid="link-bookings"
              >
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">My Bookings</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
              <button
                onClick={() => navigate("/tests")}
                className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-xl transition-colors"
                data-testid="link-tests"
              >
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-emerald-600" />
                  <span className="font-medium text-gray-900">Browse Tests</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </div>
        </motion.div>
      </main>

      {/* Address Modal */}
      <Dialog open={showAddressModal} onOpenChange={setShowAddressModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingAddress ? 'Edit Address' : 'Add New Address'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Address Type */}
            <div>
              <Label className="text-gray-600 mb-2 block">Address Type</Label>
              <div className="flex gap-2">
                {addressLabels.map((label) => {
                  const IconComponent = label.icon;
                  return (
                    <button
                      key={label.value}
                      type="button"
                      onClick={() => setAddressForm({ ...addressForm, label: label.value })}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 transition-all ${
                        addressForm.label === label.value
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      data-testid={`address-type-${label.value.toLowerCase()}`}
                    >
                      <IconComponent className="w-4 h-4" />
                      <span className="font-medium">{label.value}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-600">Contact Name</Label>
                <Input
                  value={addressForm.name}
                  onChange={(e) => setAddressForm({ ...addressForm, name: e.target.value })}
                  placeholder="Full name"
                  className="mt-1"
                  data-testid="input-address-name"
                />
              </div>
              <div>
                <Label className="text-gray-600">Phone Number</Label>
                <Input
                  value={addressForm.phone}
                  onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                  placeholder="+971 XX XXX XXXX"
                  className="mt-1"
                  data-testid="input-address-phone"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-600">City *</Label>
                <select
                  value={addressForm.city}
                  onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                  className="mt-1 w-full h-10 px-3 border border-gray-200 rounded-lg"
                  data-testid="select-address-city"
                >
                  <option value="Dubai">Dubai</option>
                  <option value="Abu Dhabi">Abu Dhabi</option>
                  <option value="Sharjah">Sharjah</option>
                  <option value="Ajman">Ajman</option>
                </select>
              </div>
              <div>
                <Label className="text-gray-600">Area *</Label>
                <Input
                  value={addressForm.area}
                  onChange={(e) => setAddressForm({ ...addressForm, area: e.target.value })}
                  placeholder="e.g., Dubai Marina"
                  className="mt-1"
                  data-testid="input-address-area"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-600">Building Name *</Label>
                <Input
                  value={addressForm.building}
                  onChange={(e) => setAddressForm({ ...addressForm, building: e.target.value })}
                  placeholder="Building name"
                  className="mt-1"
                  data-testid="input-address-building"
                />
              </div>
              <div>
                <Label className="text-gray-600">Apt / Villa No.</Label>
                <Input
                  value={addressForm.flat_number}
                  onChange={(e) => setAddressForm({ ...addressForm, flat_number: e.target.value })}
                  placeholder="Flat number"
                  className="mt-1"
                  data-testid="input-address-flat"
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-600">Full Address / Street</Label>
              <Input
                value={addressForm.full_address}
                onChange={(e) => setAddressForm({ ...addressForm, full_address: e.target.value })}
                placeholder="Street name, landmarks"
                className="mt-1"
                data-testid="input-address-full"
              />
            </div>

            <div>
              <Label className="text-gray-600">Landmark (Optional)</Label>
              <Input
                value={addressForm.landmark}
                onChange={(e) => setAddressForm({ ...addressForm, landmark: e.target.value })}
                placeholder="Near mall, metro station, etc."
                className="mt-1"
                data-testid="input-address-landmark"
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={addressForm.is_default}
                onChange={(e) => setAddressForm({ ...addressForm, is_default: e.target.checked })}
                className="w-4 h-4 text-blue-600 rounded"
                data-testid="checkbox-address-default"
              />
              <span className="text-sm text-gray-600">Set as default address</span>
            </label>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAddressModal(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveAddress}
              disabled={savingAddress}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-save-address"
            >
              {savingAddress ? 'Saving...' : editingAddress ? 'Update Address' : 'Save Address'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <MobileBottomNav />
    </div>
  );
}
