import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface CompareItem {
  id: string;
  type: 'test' | 'bundle';
  name: string;
  price: number;
  category?: string;
}

export interface PackageRecommendation {
  id: string;
  name: string;
  price: number;
  testCount: number;
  testsIncluded: string[];
  matchedTests: number;
  extraTests: number;
  priceDifference: number;
  pricePerTestCart: number;
  pricePerTestPackage: number;
  recommendation: 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL';
  savings: number;
}

interface MyTestsContextType {
  items: CompareItem[];
  addItem: (item: CompareItem) => void;
  removeItem: (id: string) => void;
  clearItems: () => void;
  getTotal: () => number;
  getItemCount: () => number;
  isInList: (id: string) => boolean;
  getRecommendedPackage: () => PackageRecommendation | null;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const MyTestsContext = createContext<MyTestsContextType | undefined>(undefined);

const STORAGE_KEY = 'mediconnect_my_tests';

// Package data for matching
const packages = [
  {
    id: '6',
    name: 'Essential Health Package',
    price: 299,
    testCount: 25,
    testsIncluded: ['CBC', 'Vitamin D', 'Thyroid Profile', 'Liver Function', 'Kidney Function', 'Lipid Profile', 'HbA1c', 'Iron Studies', 'Vitamin B12', 'Fasting Glucose', 'Uric Acid', 'Calcium', 'Phosphorus', 'Electrolytes', 'Urine Analysis']
  },
  {
    id: '4',
    name: 'Comprehensive Health Package',
    price: 499,
    testCount: 45,
    testsIncluded: ['CBC', 'Vitamin D', 'Thyroid Profile', 'Liver Function', 'Kidney Function', 'Lipid Profile', 'HbA1c', 'Iron Studies', 'Vitamin B12', 'Fasting Glucose', 'Uric Acid', 'Calcium', 'Phosphorus', 'Electrolytes', 'Urine Analysis', 'Homocysteine', 'hs-CRP', 'Testosterone', 'Estrogen', 'Cortisol', 'DHEA']
  },
  {
    id: '1',
    name: 'Full Body Checkup',
    price: 699,
    testCount: 60,
    testsIncluded: ['CBC', 'Vitamin D', 'Thyroid Profile', 'Liver Function', 'Kidney Function', 'Lipid Profile', 'HbA1c', 'Iron Studies', 'Vitamin B12', 'Fasting Glucose', 'Uric Acid', 'Calcium', 'Phosphorus', 'Electrolytes', 'Urine Analysis', 'Homocysteine', 'hs-CRP', 'Testosterone', 'Estrogen', 'Cortisol', 'DHEA', 'PSA', 'Vitamin A', 'Vitamin E', 'Zinc', 'Magnesium', 'Folate', 'Ferritin', 'TIBC']
  },
  {
    id: '2',
    name: "Women's Wellness Package",
    price: 599,
    testCount: 45,
    testsIncluded: ['CBC', 'Vitamin D', 'Thyroid Profile', 'Iron Studies', 'Vitamin B12', 'Folate', 'Calcium', 'FSH', 'LH', 'Estradiol', 'Progesterone', 'Prolactin', 'AMH', 'Ferritin']
  }
];

export function MyTestsProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CompareItem[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Load from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setItems(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load My Tests:', error);
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (error) {
      console.error('Failed to save My Tests:', error);
    }
  }, [items]);

  const addItem = (item: CompareItem) => {
    setItems(prev => {
      if (prev.find(i => i.id === item.id)) {
        return prev; // Already exists
      }
      return [...prev, item];
    });
  };

  const removeItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const clearItems = () => {
    setItems([]);
  };

  const getTotal = () => {
    return items.reduce((sum, item) => sum + item.price, 0);
  };

  const getItemCount = () => items.length;

  const isInList = (id: string) => items.some(item => item.id === id);

  const getRecommendedPackage = (): PackageRecommendation | null => {
    if (items.length === 0) return null;

    const cartTotal = getTotal();
    const cartTestNames = items.map(i => i.name.toLowerCase());

    // Find packages that include cart items
    let bestPackage: PackageRecommendation | null = null;

    for (const pkg of packages) {
      const pkgTestsLower = pkg.testsIncluded.map(t => t.toLowerCase());
      
      // Count how many cart items are in this package
      const matchedTests = cartTestNames.filter(cartTest => 
        pkgTestsLower.some(pkgTest => 
          pkgTest.includes(cartTest) || cartTest.includes(pkgTest)
        )
      ).length;

      // Only consider if package covers at least some cart items
      if (matchedTests > 0 || pkg.price <= cartTotal + 100) {
        const priceDiff = pkg.price - cartTotal;
        const pricePerTestCart = cartTotal / items.length;
        const pricePerTestPackage = pkg.price / pkg.testCount;
        const savings = Math.round((1 - pricePerTestPackage / pricePerTestCart) * 100);

        // Determine recommendation level based on cart total
        let recommendation: 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL' = 'INFO';
        if (cartTotal >= 600) {
          recommendation = 'CRITICAL';
        } else if (cartTotal >= 450) {
          recommendation = 'ALERT';
        } else if (cartTotal >= 200) {
          recommendation = 'WARNING';
        }

        const candidate: PackageRecommendation = {
          id: pkg.id,
          name: pkg.name,
          price: pkg.price,
          testCount: pkg.testCount,
          testsIncluded: pkg.testsIncluded,
          matchedTests,
          extraTests: pkg.testCount - matchedTests,
          priceDifference: priceDiff,
          pricePerTestCart: Math.round(pricePerTestCart),
          pricePerTestPackage: Math.round(pricePerTestPackage),
          recommendation,
          savings
        };

        // Pick the best package (smallest that covers needs and has good value)
        if (!bestPackage || 
            (priceDiff > -100 && priceDiff < 200 && pkg.testCount > bestPackage.testCount) ||
            (matchedTests > bestPackage.matchedTests && priceDiff < 100)) {
          bestPackage = candidate;
        }
      }
    }

    return bestPackage;
  };

  return (
    <MyTestsContext.Provider value={{
      items,
      addItem,
      removeItem,
      clearItems,
      getTotal,
      getItemCount,
      isInList,
      getRecommendedPackage,
      sidebarOpen,
      setSidebarOpen,
    }}>
      {children}
    </MyTestsContext.Provider>
  );
}

export function useMyTests() {
  const context = useContext(MyTestsContext);
  if (context === undefined) {
    throw new Error('useMyTests must be used within a MyTestsProvider');
  }
  return context;
}

// Helper function to get packages containing a test
export function getPackagesContainingTest(testName: string) {
  const testLower = testName.toLowerCase();
  return packages.filter(pkg => 
    pkg.testsIncluded.some(t => 
      t.toLowerCase().includes(testLower) || testLower.includes(t.toLowerCase())
    )
  ).map(pkg => ({
    id: pkg.id,
    name: pkg.name,
    price: pkg.price,
    testCount: pkg.testCount,
    pricePerTest: Math.round(pkg.price / pkg.testCount)
  }));
}
