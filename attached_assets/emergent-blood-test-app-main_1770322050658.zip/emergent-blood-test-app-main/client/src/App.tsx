import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider } from "@/contexts/CartContext";
import { MyTestsProvider } from "@/contexts/MyTestsContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { MyTestsSidebar } from "@/components/MyTestsSidebar";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import TestsPage from "@/pages/TestsPage";
import AuthPage from "@/pages/AuthPage";
import AdminLoginPage from "@/pages/AdminLoginPage";
import LabLoginPage from "@/pages/LabLoginPage";
import AdminDashboardPage from "@/pages/AdminDashboardPage";
import LabDashboardPage from "@/pages/LabDashboardPage";
import LabBookingsPage from "@/pages/LabBookingsPage";
import LabZonesPage from "@/pages/LabZonesPage";
import LabPricingPage from "@/pages/LabPricingPage";
import LabHoursPage from "@/pages/LabHoursPage";
import LabReportsPage from "@/pages/LabReportsPage";
import LabSettingsPage from "@/pages/LabSettingsPage";
import AdminBookingsPage from "@/pages/AdminBookingsPage";
import AdminCatalogPage from "@/pages/AdminCatalogPage";
import AdminLabsPage from "@/pages/AdminLabsPage";
import AdminUsersPage from "@/pages/AdminUsersPage";
import AdminAIRulesPage from "@/pages/AdminAIRulesPage";
import AdminReportsPage from "@/pages/AdminReportsPage";
import AdminSettingsPage from "@/pages/AdminSettingsPage";
import AdminCategoriesPage from "@/pages/AdminCategoriesPage";
import AIDiscoveryPage from "@/pages/AIDiscoveryPage";
import AIResultsPage from "@/pages/AIResultsPage";
import BundleDetailsPage from "@/pages/BundleDetailsPage";
import BookTestPage from "@/pages/BookTestPage";
import CheckoutPage from "@/pages/CheckoutPage";
import BookingHistoryPage from "@/pages/BookingHistoryPage";
import LabsPage from "@/pages/LabsPage";
import RoutineHealthPage from "@/pages/RoutineHealthPage";
import HeartHealthPage from "@/pages/HeartHealthPage";
import WomensHealthPage from "@/pages/WomensHealthPage";
import MensHealthPage from "@/pages/MensHealthPage";
import DiabetesHealthPage from "@/pages/DiabetesHealthPage";
import ThyroidHealthPage from "@/pages/ThyroidHealthPage";
import EnergyFatiguePage from "@/pages/EnergyFatiguePage";
import ProfilePage from "@/pages/ProfilePage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/admin" component={AdminLoginPage} />
      <Route path="/admin/login" component={AdminLoginPage} />
      <Route path="/admin/dashboard" component={AdminDashboardPage} />
      <Route path="/admin/bookings" component={AdminBookingsPage} />
      <Route path="/admin/catalog" component={AdminCatalogPage} />
      <Route path="/admin/categories" component={AdminCategoriesPage} />
      <Route path="/admin/labs" component={AdminLabsPage} />
      <Route path="/admin/users" component={AdminUsersPage} />
      <Route path="/admin/ai-rules" component={AdminAIRulesPage} />
      <Route path="/admin/reports" component={AdminReportsPage} />
      <Route path="/admin/settings" component={AdminSettingsPage} />
      <Route path="/lab" component={LabLoginPage} />
      <Route path="/lab/login" component={LabLoginPage} />
      <Route path="/lab/dashboard" component={LabDashboardPage} />
      <Route path="/lab/bookings" component={LabBookingsPage} />
      <Route path="/lab/zones" component={LabZonesPage} />
      <Route path="/lab/pricing" component={LabPricingPage} />
      <Route path="/lab/hours" component={LabHoursPage} />
      <Route path="/lab/reports" component={LabReportsPage} />
      <Route path="/lab/settings" component={LabSettingsPage} />
      <Route path="/ai-discovery" component={AIDiscoveryPage} />
      <Route path="/ai-results" component={AIResultsPage} />
      <Route path="/tests" component={TestsPage} />
      <Route path="/routine-health" component={RoutineHealthPage} />
      <Route path="/heart-health" component={HeartHealthPage} />
      <Route path="/womens-health" component={WomensHealthPage} />
      <Route path="/mens-health" component={MensHealthPage} />
      <Route path="/diabetes-health" component={DiabetesHealthPage} />
      <Route path="/thyroid-health" component={ThyroidHealthPage} />
      <Route path="/energy-fatigue" component={EnergyFatiguePage} />
      <Route path="/bundles/:id" component={BundleDetailsPage} />
      <Route path="/book/:id" component={BookTestPage} />
      <Route path="/checkout" component={CheckoutPage} />
      <Route path="/bookings" component={BookingHistoryPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/labs" component={LabsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <MyTestsProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
              <MyTestsSidebar />
            </TooltipProvider>
          </MyTestsProvider>
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
