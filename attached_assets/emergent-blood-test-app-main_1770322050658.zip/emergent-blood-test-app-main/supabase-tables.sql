-- =====================================================
-- MEDICONNECT DATABASE SETUP - RUN THIS IN SUPABASE SQL EDITOR
-- =====================================================

-- Test Categories table
CREATE TABLE IF NOT EXISTS test_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  color VARCHAR(50) DEFAULT 'blue',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bundle Categories table
CREATE TABLE IF NOT EXISTS bundle_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  color VARCHAR(50) DEFAULT 'blue',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Labs table
CREATE TABLE IF NOT EXISTS labs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  city VARCHAR(100),
  address TEXT,
  rating DECIMAL(2,1) DEFAULT 4.5,
  review_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tests table
CREATE TABLE IF NOT EXISTS tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  category_id UUID REFERENCES test_categories(id),
  category VARCHAR(100),
  base_price DECIMAL(10,2),
  sample_type VARCHAR(50) DEFAULT 'Blood',
  turnaround_hours INTEGER DEFAULT 24,
  biomarkers TEXT[],
  preparation TEXT,
  fasting_required BOOLEAN DEFAULT false,
  fasting_hours VARCHAR(20),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bundles table
CREATE TABLE IF NOT EXISTS bundles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  category_id UUID REFERENCES bundle_categories(id),
  category VARCHAR(100),
  base_price DECIMAL(10,2),
  original_price DECIMAL(10,2),
  tests_included INTEGER DEFAULT 0,
  turnaround_hours VARCHAR(20) DEFAULT '24-48',
  fasting_required BOOLEAN DEFAULT false,
  fasting_hours VARCHAR(20),
  home_collection BOOLEAN DEFAULT true,
  is_active BOOLEAN DEFAULT true,
  is_popular BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lab Test Pricing table
CREATE TABLE IF NOT EXISTS lab_test_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id UUID REFERENCES labs(id) ON DELETE CASCADE,
  test_id UUID REFERENCES tests(id) ON DELETE CASCADE,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  turnaround_hours INTEGER,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(lab_id, test_id)
);

-- Lab Bundle Pricing table
CREATE TABLE IF NOT EXISTS lab_bundle_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id UUID REFERENCES labs(id) ON DELETE CASCADE,
  bundle_id UUID REFERENCES bundles(id) ON DELETE CASCADE,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  turnaround_hours INTEGER,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(lab_id, bundle_id)
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  bundle_id UUID REFERENCES bundles(id),
  lab_id UUID REFERENCES labs(id),
  bundle_name VARCHAR(255),
  lab_name VARCHAR(255),
  price DECIMAL(10,2),
  status VARCHAR(50) DEFAULT 'Pending',
  appointment_date DATE,
  appointment_time VARCHAR(20),
  patient_name VARCHAR(255),
  patient_email VARCHAR(255),
  patient_phone VARCHAR(50),
  patient_address TEXT,
  payment_method VARCHAR(50) DEFAULT 'Pay at Home/Lab',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);
CREATE INDEX IF NOT EXISTS idx_tests_category ON tests(category);
CREATE INDEX IF NOT EXISTS idx_bundles_category ON bundles(category);
CREATE INDEX IF NOT EXISTS idx_lab_test_pricing_lab ON lab_test_pricing(lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_bundle_pricing_lab ON lab_bundle_pricing(lab_id);

-- User Addresses table (for multiple addresses per user)
CREATE TABLE IF NOT EXISTS user_addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  label VARCHAR(50) DEFAULT 'Home',
  name VARCHAR(255),
  phone VARCHAR(50),
  city VARCHAR(100) DEFAULT 'Dubai',
  area VARCHAR(255),
  building VARCHAR(255),
  flat_number VARCHAR(50),
  full_address TEXT,
  landmark TEXT,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_addresses_user_id ON user_addresses(user_id);
