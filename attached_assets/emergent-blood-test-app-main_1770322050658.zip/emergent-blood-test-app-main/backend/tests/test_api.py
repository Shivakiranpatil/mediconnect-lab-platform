"""
MediConnect API Tests
Tests for lab test booking platform APIs
"""
import pytest
import requests
import os

# Use localhost for testing since we're running inside the container
BASE_URL = "http://localhost:8001"


class TestBundlesAPI:
    """Test bundle endpoints"""
    
    def test_get_all_bundles(self):
        """GET /api/bundles - should return list of test bundles"""
        response = requests.get(f"{BASE_URL}/api/bundles")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0
        
        # Verify bundle structure
        bundle = data[0]
        assert "id" in bundle
        assert "name" in bundle
        assert "basePrice" in bundle
        assert "description" in bundle
        print(f"✅ Found {len(data)} bundles")
    
    def test_get_single_bundle(self):
        """GET /api/bundles/:id - should return single bundle"""
        response = requests.get(f"{BASE_URL}/api/bundles/1")
        assert response.status_code == 200
        
        data = response.json()
        assert data["id"] == "1"
        assert "name" in data
        assert "basePrice" in data
        print(f"✅ Bundle: {data['name']} - AED {data['basePrice']}")
    
    def test_get_nonexistent_bundle(self):
        """GET /api/bundles/:id - should return 404 for invalid ID"""
        response = requests.get(f"{BASE_URL}/api/bundles/99999")
        assert response.status_code == 404


class TestTestsAPI:
    """Test individual tests endpoints"""
    
    def test_get_all_tests(self):
        """GET /api/tests - should return list of individual tests"""
        response = requests.get(f"{BASE_URL}/api/tests")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0
        
        # Verify test structure
        test = data[0]
        assert "id" in test
        assert "name" in test
        assert "category" in test
        assert "price" in test
        print(f"✅ Found {len(data)} individual tests")
    
    def test_search_tests(self):
        """GET /api/tests?search=vitamin - should filter tests"""
        response = requests.get(f"{BASE_URL}/api/tests?search=vitamin")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        # Should find vitamin-related tests
        for test in data:
            assert "vitamin" in test["name"].lower() or "vitamin" in test["description"].lower()
        print(f"✅ Search returned {len(data)} vitamin-related tests")
    
    def test_filter_tests_by_category(self):
        """GET /api/tests?category=Diabetes - should filter by category"""
        response = requests.get(f"{BASE_URL}/api/tests?category=Diabetes")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        for test in data:
            assert test["category"] == "Diabetes"
        print(f"✅ Category filter returned {len(data)} Diabetes tests")


class TestAIChatAPI:
    """Test AI chat endpoints"""
    
    def test_ai_chat_basic(self):
        """POST /api/ai/chat - should return AI response"""
        payload = {
            "sessionId": "test-session-123",
            "message": "I'm feeling tired lately",
            "history": []
        }
        response = requests.post(
            f"{BASE_URL}/api/ai/chat",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        
        data = response.json()
        assert "response" in data
        assert len(data["response"]) > 0
        print(f"✅ AI responded: {data['response'][:100]}...")
    
    def test_ai_chat_with_history(self):
        """POST /api/ai/chat - should handle conversation history"""
        payload = {
            "sessionId": "test-session-456",
            "message": "I'm 35 years old",
            "history": [
                {"role": "assistant", "content": "Hello! What brings you here today?"},
                {"role": "user", "content": "I want to check my health"}
            ]
        }
        response = requests.post(
            f"{BASE_URL}/api/ai/chat",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        
        data = response.json()
        assert "response" in data
        print(f"✅ AI handled history, responded: {data['response'][:100]}...")
    
    def test_ai_chat_missing_fields(self):
        """POST /api/ai/chat - should handle missing required fields"""
        payload = {"message": "Hello"}  # Missing sessionId
        response = requests.post(
            f"{BASE_URL}/api/ai/chat",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        # Should return 400 for missing fields
        assert response.status_code == 400


class TestBookingsAPI:
    """Test booking endpoints"""
    
    def test_get_bookings_empty(self):
        """GET /api/bookings - should return empty list for new session"""
        response = requests.get(f"{BASE_URL}/api/bookings")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        print(f"✅ Bookings endpoint returned {len(data)} bookings")
    
    def test_create_booking(self):
        """POST /api/bookings - should create a new booking"""
        payload = {
            "bundleId": "1",
            "labId": "1",
            "collectionType": "lab",
            "date": "2026-02-01",
            "time": "10:00",
            "patientName": "TEST_John Doe",
            "patientPhone": "+971501234567",
            "patientEmail": "test@example.com"
        }
        
        # Create a session to persist cookies
        session = requests.Session()
        response = session.post(
            f"{BASE_URL}/api/bookings",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 201
        
        data = response.json()
        assert data["success"] == True
        assert "booking" in data
        assert data["booking"]["patientName"] == "TEST_John Doe"
        print(f"✅ Booking created: {data['booking']['id']}")


class TestAIRecommendationsAPI:
    """Test AI recommendations endpoint"""
    
    def test_get_recommendations(self):
        """POST /api/ai/recommend - should return test recommendations"""
        payload = {
            "context": "I'm a 35 year old woman feeling tired"
        }
        response = requests.post(
            f"{BASE_URL}/api/ai/recommend",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        
        data = response.json()
        assert "recommendations" in data
        assert isinstance(data["recommendations"], list)
        print(f"✅ Got {len(data['recommendations'])} recommendations")


class TestAuthAPI:
    """Test authentication endpoints"""
    
    def test_get_current_user_unauthenticated(self):
        """GET /api/auth/me - should return null when not logged in"""
        response = requests.get(f"{BASE_URL}/api/auth/me")
        assert response.status_code == 200
        # Should return null or empty for unauthenticated user
        print("✅ Auth endpoint accessible")
    
    @pytest.mark.skip(reason="Auth requires database connection - using mock data mode")
    def test_login_invalid_credentials(self):
        """POST /api/auth/login - should reject invalid credentials"""
        payload = {
            "username": "invalid_user",
            "password": "wrong_password"
        }
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 401
        print("✅ Invalid login rejected correctly")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
