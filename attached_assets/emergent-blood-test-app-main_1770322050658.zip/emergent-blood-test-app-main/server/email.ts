import { SendGridClient } from "@sendgrid/client";
import sgMail from "@sendgrid/mail";

// Initialize SendGrid with API key from environment
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

export class EmailService {
  private static senderEmail = process.env.SENDER_EMAIL || "noreply@mediconnect.ae";

  /**
   * Send booking confirmation email
   */
  static async sendBookingConfirmation(
    recipientEmail: string,
    recipientName: string,
    appointmentDetails: {
      bundleName: string;
      labName: string;
      appointmentTime: string;
      price: string;
      bookingId: string;
    }
  ): Promise<boolean> {
    if (!process.env.SENDGRID_API_KEY) {
      console.warn("SendGrid API key not configured. Email not sent.");
      return false;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; }
            .detail-box { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #2563eb; }
            .detail-label { font-weight: bold; color: #2563eb; margin-bottom: 5px; }
            .detail-value { font-size: 16px; }
            .footer { background: #1e293b; color: #94a3b8; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; font-size: 12px; }
            .button { display: inline-block; background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>✅ Booking Confirmed!</h1>
              <p>Your lab test appointment has been successfully booked</p>
            </div>
            <div class="content">
              <p>Dear ${recipientName},</p>
              <p>Thank you for choosing MediConnect. Your lab test appointment has been confirmed.</p>
              
              <div class="detail-box">
                <div class="detail-label">Test Package</div>
                <div class="detail-value">${appointmentDetails.bundleName}</div>
              </div>

              <div class="detail-box">
                <div class="detail-label">Laboratory</div>
                <div class="detail-value">${appointmentDetails.labName}</div>
              </div>

              <div class="detail-box">
                <div class="detail-label">Appointment Time</div>
                <div class="detail-value">${appointmentDetails.appointmentTime}</div>
              </div>

              <div class="detail-box">
                <div class="detail-label">Total Price</div>
                <div class="detail-value">AED ${appointmentDetails.price}</div>
              </div>

              <div class="detail-box">
                <div class="detail-label">Booking Reference</div>
                <div class="detail-value">#${appointmentDetails.bookingId}</div>
              </div>

              <p><strong>Important:</strong> Please arrive 10 minutes before your scheduled time. Bring a valid ID and your booking reference.</p>
            </div>
            <div class="footer">
              <p>MediConnect - AI-Driven Health Test Booking in Dubai</p>
              <p>This is an automated email. Please do not reply.</p>
              <p style="color: #f59e0b; margin-top: 10px;">⚠️ Educational only. Not medical advice. Confirm with a licensed clinician/lab.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    try {
      await sgMail.send({
        to: recipientEmail,
        from: this.senderEmail,
        subject: `Booking Confirmed - ${appointmentDetails.bundleName}`,
        html: htmlContent
      });
      console.log(`✉️  Booking confirmation email sent to ${recipientEmail}`);
      return true;
    } catch (error) {
      console.error("Failed to send booking confirmation email:", error);
      return false;
    }
  }

  /**
   * Send appointment reminder email
   */
  static async sendAppointmentReminder(
    recipientEmail: string,
    recipientName: string,
    appointmentDetails: {
      bundleName: string;
      labName: string;
      appointmentTime: string;
      bookingId: string;
    }
  ): Promise<boolean> {
    if (!process.env.SENDGRID_API_KEY) {
      console.warn("SendGrid API key not configured. Email not sent.");
      return false;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; }
            .reminder-box { background: #fef3c7; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #f59e0b; }
            .footer { background: #1e293b; color: #94a3b8; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>⏰ Appointment Reminder</h1>
              <p>Your lab test appointment is coming up soon!</p>
            </div>
            <div class="content">
              <p>Dear ${recipientName},</p>
              <p>This is a friendly reminder about your upcoming lab test appointment.</p>
              
              <div class="reminder-box">
                <h3>📋 ${appointmentDetails.bundleName}</h3>
                <p><strong>Lab:</strong> ${appointmentDetails.labName}</p>
                <p><strong>Time:</strong> ${appointmentDetails.appointmentTime}</p>
                <p><strong>Reference:</strong> #${appointmentDetails.bookingId}</p>
              </div>

              <p><strong>Please remember:</strong></p>
              <ul>
                <li>Arrive 10 minutes early</li>
                <li>Bring your booking reference and valid ID</li>
                <li>Follow any preparation instructions provided</li>
              </ul>
            </div>
            <div class="footer">
              <p>MediConnect - AI-Driven Health Test Booking in Dubai</p>
            </div>
          </div>
        </body>
      </html>
    `;

    try {
      await sgMail.send({
        to: recipientEmail,
        from: this.senderEmail,
        subject: `Reminder: Your appointment for ${appointmentDetails.bundleName}`,
        html: htmlContent
      });
      console.log(`✉️  Appointment reminder sent to ${recipientEmail}`);
      return true;
    } catch (error) {
      console.error("Failed to send appointment reminder:", error);
      return false;
    }
  }

  /**
   * Send test results notification
   */
  static async sendTestResultsReady(
    recipientEmail: string,
    recipientName: string,
    bundleName: string,
    bookingId: string
  ): Promise<boolean> {
    if (!process.env.SENDGRID_API_KEY) {
      console.warn("SendGrid API key not configured. Email not sent.");
      return false;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; }
            .results-box { background: #d1fae5; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #10b981; }
            .footer { background: #1e293b; color: #94a3b8; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; font-size: 12px; }
            .button { display: inline-block; background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Test Results Ready!</h1>
              <p>Your lab test results are now available</p>
            </div>
            <div class="content">
              <p>Dear ${recipientName},</p>
              <p>Good news! Your test results for <strong>${bundleName}</strong> are now ready.</p>
              
              <div class="results-box">
                <p><strong>Booking Reference:</strong> #${bookingId}</p>
                <p>Please contact the laboratory directly to collect your results or schedule a consultation with your healthcare provider.</p>
              </div>

              <p><strong>Important:</strong> These results should be reviewed by a qualified healthcare professional for proper interpretation and guidance.</p>
            </div>
            <div class="footer">
              <p>MediConnect - AI-Driven Health Test Booking in Dubai</p>
              <p style="color: #f59e0b; margin-top: 10px;">⚠️ For medical interpretation, consult with a licensed healthcare provider.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    try {
      await sgMail.send({
        to: recipientEmail,
        from: this.senderEmail,
        subject: `Test Results Ready - ${bundleName}`,
        html: htmlContent
      });
      console.log(`✉️  Test results notification sent to ${recipientEmail}`);
      return true;
    } catch (error) {
      console.error("Failed to send test results notification:", error);
      return false;
    }
  }
}
