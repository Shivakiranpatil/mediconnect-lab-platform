import { supabaseAdmin, TABLES } from './supabase';

// ==================== BOOKINGS ====================
export interface Booking {
  id?: string;
  user_id?: string;
  bundle_id?: string;
  lab_id?: string;
  bundle_name: string;
  lab_name: string;
  price: number;
  status?: string;
  appointment_date?: string;
  appointment_time?: string;
  patient_name?: string;
  patient_email?: string;
  patient_phone?: string;
  patient_address?: string;
  payment_method?: string;
  notes?: string;
  created_at?: string;
}

export const bookingsService = {
  async getAll() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async getById(id: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async getByUserId(userId: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async create(booking: Booking) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .insert([{
        ...booking,
        status: booking.status || 'Pending',
        payment_method: booking.payment_method || 'Pay at Home/Lab',
      }])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateStatus(id: string, status: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  },

  async deleteAll() {
    const { error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all
    if (error) throw error;
    return true;
  },

  async getStats() {
    const { data: bookings, error } = await supabaseAdmin
      .from(TABLES.BOOKINGS)
      .select('*');
    
    if (error) throw error;

    const totalRevenue = bookings?.reduce((sum, b) => sum + (b.price || 0), 0) || 0;
    const totalBookings = bookings?.length || 0;
    const statusCounts = bookings?.reduce((acc, b) => {
      acc[b.status || 'Pending'] = (acc[b.status || 'Pending'] || 0) + 1;
      return acc;
    }, {} as Record<string, number>) || {};

    return { totalRevenue, totalBookings, statusCounts, bookings };
  }
};

// ==================== USERS ====================
export interface User {
  id?: string;
  email: string;
  name?: string;
  phone?: string;
  password_hash?: string;
  role?: string;
  is_active?: boolean;
}

export const usersService = {
  async getAll() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .select('id, email, name, phone, role, is_active, created_at')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async getById(id: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async getByEmail(email: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .select('*')
      .eq('email', email)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async create(user: User) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .insert([{ ...user, role: user.role || 'user' }])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<User>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getCount() {
    const { count, error } = await supabaseAdmin
      .from(TABLES.USERS)
      .select('*', { count: 'exact', head: true });
    if (error) throw error;
    return count || 0;
  }
};

// ==================== LABS ====================
export interface Lab {
  id?: string;
  name: string;
  description?: string;
  city?: string;
  address?: string;
  rating?: number;
  review_count?: number;
  is_active?: boolean;
  logo_url?: string;
}

export const labsService = {
  async getAll() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.LABS)
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  async getById(id: string) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.LABS)
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async create(lab: Lab) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.LABS)
      .insert([lab])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Lab>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.LABS)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getActiveCount() {
    const { count, error } = await supabaseAdmin
      .from(TABLES.LABS)
      .select('*', { count: 'exact', head: true })
      .eq('is_active', true);
    if (error) throw error;
    return count || 0;
  }
};

// ==================== TESTS ====================
export interface Test {
  id?: string;
  name: string;
  description?: string;
  category_id?: string;
  category?: string;
  base_price?: number;
  sample_type?: string;
  turnaround_hours?: number;
  biomarkers?: string[];
  preparation?: string;
  fasting_required?: boolean;
  fasting_hours?: string;
  is_active?: boolean;
}

export const testsService = {
  async getAll() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TESTS)
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  async create(test: Test) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TESTS)
      .insert([test])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Test>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TESTS)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabaseAdmin
      .from(TABLES.TESTS)
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  }
};

// ==================== BUNDLES ====================
export interface Bundle {
  id?: string;
  name: string;
  description?: string;
  category_id?: string;
  category?: string;
  base_price?: number;
  original_price?: number;
  tests_included?: number;
  turnaround_hours?: string;
  fasting_required?: boolean;
  fasting_hours?: string;
  home_collection?: boolean;
  is_active?: boolean;
  is_popular?: boolean;
}

export const bundlesService = {
  async getAll() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLES)
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  async create(bundle: Bundle) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLES)
      .insert([bundle])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Bundle>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLES)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabaseAdmin
      .from(TABLES.BUNDLES)
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  }
};

// ==================== CATEGORIES ====================
export interface Category {
  id?: string;
  name: string;
  description?: string;
  color?: string;
  is_active?: boolean;
}

export const categoriesService = {
  async getTestCategories() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TEST_CATEGORIES)
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  async getBundleCategories() {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLE_CATEGORIES)
      .select('*')
      .order('name');
    if (error) throw error;
    return data;
  },

  async createTestCategory(category: Category) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TEST_CATEGORIES)
      .insert([category])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async createBundleCategory(category: Category) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLE_CATEGORIES)
      .insert([category])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateTestCategory(id: string, updates: Partial<Category>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.TEST_CATEGORIES)
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateBundleCategory(id: string, updates: Partial<Category>) {
    const { data, error } = await supabaseAdmin
      .from(TABLES.BUNDLE_CATEGORIES)
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteTestCategory(id: string) {
    const { error } = await supabaseAdmin
      .from(TABLES.TEST_CATEGORIES)
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  },

  async deleteBundleCategory(id: string) {
    const { error } = await supabaseAdmin
      .from(TABLES.BUNDLE_CATEGORIES)
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  }
};

// ==================== GUEST PROFILES ====================
export interface GuestProfile {
  id?: string;
  session_id?: string;
  device_id?: string;
  name?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  area?: string;
  building?: string;
  flat_number?: string;
  landmark?: string;
}

export const guestProfilesService = {
  async getBySessionId(sessionId: string) {
    const { data, error } = await supabaseAdmin
      .from('guest_profiles')
      .select('*')
      .eq('session_id', sessionId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async getByDeviceId(deviceId: string) {
    const { data, error } = await supabaseAdmin
      .from('guest_profiles')
      .select('*')
      .eq('device_id', deviceId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async getByEmail(email: string) {
    const { data, error } = await supabaseAdmin
      .from('guest_profiles')
      .select('*')
      .eq('email', email)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async upsert(profile: GuestProfile) {
    // Try to find existing profile
    let existingId = null;
    
    if (profile.session_id) {
      const existing = await this.getBySessionId(profile.session_id);
      if (existing) existingId = existing.id;
    }
    
    if (!existingId && profile.device_id) {
      const existing = await this.getByDeviceId(profile.device_id);
      if (existing) existingId = existing.id;
    }
    
    if (!existingId && profile.email) {
      const existing = await this.getByEmail(profile.email);
      if (existing) existingId = existing.id;
    }

    if (existingId) {
      // Update existing
      const { data, error } = await supabaseAdmin
        .from('guest_profiles')
        .update({ ...profile, updated_at: new Date().toISOString() })
        .eq('id', existingId)
        .select()
        .single();
      if (error) throw error;
      return data;
    } else {
      // Create new
      const { data, error } = await supabaseAdmin
        .from('guest_profiles')
        .insert([profile])
        .select()
        .single();
      if (error) throw error;
      return data;
    }
  },

  async create(profile: GuestProfile) {
    const { data, error } = await supabaseAdmin
      .from('guest_profiles')
      .insert([profile])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<GuestProfile>) {
    const { data, error } = await supabaseAdmin
      .from('guest_profiles')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  }
};

// ==================== USER ADDRESSES ====================
export interface UserAddress {
  id?: string;
  user_id: string;
  label?: string;
  name?: string;
  phone?: string;
  city?: string;
  area?: string;
  building?: string;
  flat_number?: string;
  full_address?: string;
  landmark?: string;
  is_default?: boolean;
}

export const userAddressesService = {
  async getByUserId(userId: string) {
    const { data, error } = await supabaseAdmin
      .from('user_addresses')
      .select('*')
      .eq('user_id', userId)
      .order('is_default', { ascending: false })
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getById(id: string) {
    const { data, error } = await supabaseAdmin
      .from('user_addresses')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async create(address: UserAddress) {
    // If this is the first address or marked as default, ensure only one default
    if (address.is_default) {
      await supabaseAdmin
        .from('user_addresses')
        .update({ is_default: false })
        .eq('user_id', address.user_id);
    }
    
    const { data, error } = await supabaseAdmin
      .from('user_addresses')
      .insert([address])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<UserAddress>) {
    // If setting as default, unset other defaults for this user
    if (updates.is_default) {
      const existing = await this.getById(id);
      if (existing) {
        await supabaseAdmin
          .from('user_addresses')
          .update({ is_default: false })
          .eq('user_id', existing.user_id);
      }
    }
    
    const { data, error } = await supabaseAdmin
      .from('user_addresses')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string) {
    const { error } = await supabaseAdmin
      .from('user_addresses')
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  },

  async setDefault(id: string, userId: string) {
    // First, unset all defaults for this user
    await supabaseAdmin
      .from('user_addresses')
      .update({ is_default: false })
      .eq('user_id', userId);
    
    // Then set the new default
    const { data, error } = await supabaseAdmin
      .from('user_addresses')
      .update({ is_default: true, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  }
};

export default {
  bookings: bookingsService,
  users: usersService,
  labs: labsService,
  tests: testsService,
  bundles: bundlesService,
  categories: categoriesService,
  guestProfiles: guestProfilesService,
  userAddresses: userAddressesService,
};
