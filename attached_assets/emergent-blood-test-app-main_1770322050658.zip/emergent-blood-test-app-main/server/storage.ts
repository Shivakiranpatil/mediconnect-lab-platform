import { 
  users, bundles, tests, appointments, partnerLabs, aiQuestions, aiRuleSets, aiMappingRules, bundleTests,
  type User, type InsertUser, type Bundle, type Test, type Appointment, type InsertAppointment, type PartnerLab, type AiQuestion, type AiRuleSet, type AiMappingRule
} from "@shared/schema";
import { db } from "./db";
import { eq, inArray } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bundles
  getBundles(): Promise<Bundle[]>;
  getBundle(id: string): Promise<Bundle | undefined>;
  getBundlesBySlug(slugs: string[]): Promise<Bundle[]>;
  createBundle(bundle: any): Promise<Bundle>; // Type loose for seeding

  // AI
  getAiQuestions(): Promise<AiQuestion[]>;
  getAiMappingRules(): Promise<AiMappingRule[]>;
  
  // Appointments
  createAppointment(appt: InsertAppointment): Promise<Appointment>;
  getAppointments(userId: string): Promise<Appointment[]>;
  
  // Seeding support
  createTest(test: any): Promise<Test>;
  createAiQuestion(q: any): Promise<AiQuestion>;
  createAiRuleSet(rs: any): Promise<AiRuleSet>;
  createAiMappingRule(rule: any): Promise<AiMappingRule>;
  createPartnerLab(lab: any): Promise<PartnerLab>;
}

export class DatabaseStorage implements IStorage {
  // Mock users for development when database is unavailable
  private mockUsers: User[] = [
    {
      id: "1",
      username: "admin",
      password: "admin123",
      role: "admin",
      name: "System Administrator",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: "2",
      username: "labadmin",
      password: "lab123",
      role: "lab_admin",
      name: "Lab Manager",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: "3",
      username: "user",
      password: "user123",
      role: "user",
      name: "Test User",
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ];

  async getUser(id: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      if (user) return user;
      throw new Error("No user found");
    } catch (error) {
      // Fall back to mock users
      return this.mockUsers.find(u => u.id === id);
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.username, username));
      if (user) return user;
      throw new Error("No user found");
    } catch (error) {
      // Fall back to mock users
      console.log("⚠️ Using mock user for:", username);
      return this.mockUsers.find(u => u.username === username);
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db.insert(users).values(insertUser).returning();
      return user;
    } catch (error) {
      // Create mock user
      console.log("⚠️ Creating mock user");
      const newUser: User = {
        id: String(this.mockUsers.length + 1),
        username: insertUser.username,
        password: insertUser.password || "",
        role: insertUser.role || "user",
        name: insertUser.name || insertUser.username,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.mockUsers.push(newUser);
      return newUser;
    }
  }

  async getBundles(): Promise<Bundle[]> {
    try {
      const result = await db.select().from(bundles).where(eq(bundles.isActive, true));
      if (result && result.length > 0) {
        return result;
      }
      // If no results, return mock data
      throw new Error("No bundles");
    } catch (error) {
      console.log("⚠️ Using mock bundles");
      return [
        {
          id: "1",
          name: "Full Body Checkup",
          slug: "full-body-checkup",
          description: "Complete health screening with 40+ parameters",
          shortDescription: "Complete health screening",
          category: "Premium",
          tags: ["Popular", "Comprehensive"],
          icon: "activity",
          color: "blue",
          basePrice: "699",
          isPopular: true,
          isActive: true,
          sortOrder: 1,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "2",
          name: "Women's Wellness Panel",
          slug: "womens-wellness",
          description: "Hormone balance, PCOS screening, and fertility markers",
          shortDescription: "Hormone & PCOS Panels",
          category: "Women's Health",
          tags: ["Women", "Hormones"],
          icon: "heart",
          color: "pink",
          basePrice: "599",
          isPopular: true,
          isActive: true,
          sortOrder: 2,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "3",
          name: "Heart & Cholesterol Panel",
          slug: "heart-cholesterol",
          description: "Comprehensive cardiovascular risk assessment",
          shortDescription: "Cardiac Risk Assessment",
          category: "Heart Health",
          tags: ["Heart", "Cholesterol"],
          icon: "heart",
          color: "red",
          basePrice: "299",
          isPopular: true,
          isActive: true,
          sortOrder: 3,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "4",
          name: "Energy & Fatigue Panel",
          slug: "energy-fatigue",
          description: "Identify nutritional deficiencies causing tiredness",
          shortDescription: "Vitamin & Energy Tests",
          category: "Energy",
          tags: ["Fatigue", "Vitamins"],
          icon: "zap",
          color: "amber",
          basePrice: "449",
          isPopular: false,
          isActive: true,
          sortOrder: 4,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "5",
          name: "Diabetes Monitoring Panel",
          slug: "diabetes-monitoring",
          description: "Complete diabetes screening and management",
          shortDescription: "Blood sugar monitoring",
          category: "Diabetes",
          tags: ["Diabetes", "Blood Sugar"],
          icon: "activity",
          color: "orange",
          basePrice: "249",
          isPopular: false,
          isActive: true,
          sortOrder: 5,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "6",
          name: "Essential Health Check",
          slug: "essential-health",
          description: "Basic health screening for routine checkups",
          shortDescription: "Routine health checkup",
          category: "General",
          tags: ["Basic", "Routine"],
          icon: "activity",
          color: "blue",
          basePrice: "199",
          isPopular: false,
          isActive: true,
          sortOrder: 6,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "7",
          name: "HbA1c Blood Sugar Test",
          slug: "hba1c-blood-sugar",
          description: "Affordable HbA1c test to monitor your blood sugar levels over the past 2-3 months. Essential for diabetes screening and management.",
          shortDescription: "Blood Sugar Monitoring",
          category: "Diabetes",
          tags: ["HbA1c", "Blood Sugar", "Diabetes", "Budget"],
          icon: "activity",
          color: "orange",
          basePrice: "99",
          isPopular: true,
          isActive: true,
          sortOrder: 7,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "8",
          name: "Senior Citizen Panel",
          slug: "senior-citizen-panel",
          description: "Specialized health screening for adults 60+ covering age-specific health markers including bone health, cardiac risk, and metabolic assessment.",
          shortDescription: "Complete checkup for 60+",
          category: "General",
          tags: ["Senior", "Complete", "Bone Health", "Cardiac"],
          icon: "users",
          color: "purple",
          basePrice: "799",
          isPopular: false,
          isActive: true,
          sortOrder: 8,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "9",
          name: "Advanced Cardiac Panel",
          slug: "advanced-cardiac-panel",
          description: "In-depth cardiac assessment with advanced biomarkers including NT-proBNP, Troponin, Apolipoprotein B, and Lipoprotein(a) for comprehensive heart health evaluation.",
          shortDescription: "Advanced heart assessment",
          category: "Heart Health",
          tags: ["Cardiac", "Advanced", "Biomarkers", "Heart"],
          icon: "heart",
          color: "red",
          basePrice: "599",
          isPopular: false,
          isActive: true,
          sortOrder: 9,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: "10",
          name: "Lipid Profile Basic",
          slug: "lipid-profile-basic",
          description: "Essential cholesterol screening to monitor your lipid levels including Total Cholesterol, LDL, HDL, Triglycerides, and VLDL.",
          shortDescription: "Basic cholesterol check",
          category: "Heart Health",
          tags: ["Cholesterol", "Lipid", "Basic", "Budget"],
          icon: "heart",
          color: "pink",
          basePrice: "89",
          isPopular: false,
          isActive: true,
          sortOrder: 10,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ] as Bundle[];
    }
  }

  async getBundle(id: string): Promise<Bundle | undefined> {
    try {
      const [bundle] = await db.select().from(bundles).where(eq(bundles.id, id));
      return bundle;
    } catch (error) {
      const mockBundles = await this.getBundles();
      return mockBundles.find(b => b.id === id || b.slug === id);
    }
  }
  
  async getBundlesBySlug(slugs: string[]): Promise<Bundle[]> {
    if (slugs.length === 0) return [];
    return await db.select().from(bundles).where(inArray(bundles.slug, slugs));
  }

  async createBundle(bundle: any): Promise<Bundle> {
    const [b] = await db.insert(bundles).values(bundle).returning();
    return b;
  }

  async getAiQuestions(): Promise<AiQuestion[]> {
    try {
      return await db.select().from(aiQuestions).orderBy(aiQuestions.sortOrder);
    } catch (error) {
      console.log("⚠️  Database not available, returning mock questions");
      return [];
    }
  }
  
  async getAiMappingRules(): Promise<AiMappingRule[]> {
    try {
      return await db.select().from(aiMappingRules).orderBy(aiMappingRules.priority);
    } catch (error) {
      console.log("⚠️  Database not available, returning mock rules");
      return [];
    }
  }

  async createAppointment(appt: InsertAppointment): Promise<Appointment> {
    const [a] = await db.insert(appointments).values(appt).returning();
    return a;
  }

  async getAppointments(userId: string): Promise<Appointment[]> {
    return await db.select().from(appointments).where(eq(appointments.userId, userId));
  }

  // Seeding helpers
  async createTest(test: any): Promise<Test> {
    const [t] = await db.insert(tests).values(test).returning();
    return t;
  }
  
  async createAiQuestion(q: any): Promise<AiQuestion> {
    const [res] = await db.insert(aiQuestions).values(q).returning();
    return res;
  }
  
  async createAiRuleSet(rs: any): Promise<AiRuleSet> {
    const [res] = await db.insert(aiRuleSets).values(rs).returning();
    return res;
  }
  
  async createAiMappingRule(rule: any): Promise<AiMappingRule> {
    const [res] = await db.insert(aiMappingRules).values(rule).returning();
    return res;
  }
  
  async createPartnerLab(lab: any): Promise<PartnerLab> {
    const [res] = await db.insert(partnerLabs).values(lab).returning();
    return res;
  }
}

export const storage = new DatabaseStorage();
