import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://vkyfwgdzmjxarhwuqiho.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZreWZ3Z2R6bWp4YXJod3VxaWhvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDI4MzIzMSwiZXhwIjoyMDg1ODU5MjMxfQ.IXMzvMmVvFrQp6sWQ4z-axQDikRZoKDGPWNEiXSAISs';

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

// Seed data
const testCategories = [
  { name: 'Blood', description: 'Blood-related tests including CBC, hemoglobin', color: 'red', is_active: true },
  { name: 'Heart', description: 'Cardiovascular health tests', color: 'pink', is_active: true },
  { name: 'Diabetes', description: 'Blood sugar and diabetes monitoring', color: 'orange', is_active: true },
  { name: 'Thyroid', description: 'Thyroid function tests', color: 'purple', is_active: true },
  { name: 'Liver', description: 'Liver function and health tests', color: 'green', is_active: true },
  { name: 'Kidney', description: 'Kidney function tests', color: 'blue', is_active: true },
  { name: 'Vitamins', description: 'Vitamin level tests', color: 'yellow', is_active: true },
  { name: 'Hormones', description: 'Hormone level tests', color: 'indigo', is_active: true },
  { name: 'Minerals', description: 'Mineral and electrolyte tests', color: 'teal', is_active: true },
  { name: 'Allergy', description: 'Allergy and sensitivity tests', color: 'amber', is_active: true },
  { name: 'Infection', description: 'Infection and immunity tests', color: 'rose', is_active: true },
  { name: 'Cancer Markers', description: 'Tumor markers and cancer screening', color: 'slate', is_active: true },
];

const bundleCategories = [
  { name: 'Premium', description: 'Comprehensive health checkup packages', color: 'blue', is_active: true },
  { name: 'Basic', description: 'Essential health screening packages', color: 'gray', is_active: true },
  { name: 'Heart Health', description: 'Cardiovascular health packages', color: 'red', is_active: true },
  { name: "Women's Health", description: 'Health packages designed for women', color: 'pink', is_active: true },
  { name: "Men's Health", description: 'Health packages designed for men', color: 'indigo', is_active: true },
  { name: 'Diabetes', description: 'Diabetes monitoring packages', color: 'orange', is_active: true },
  { name: 'Thyroid', description: 'Thyroid health packages', color: 'purple', is_active: true },
  { name: 'Energy', description: 'Energy and fatigue packages', color: 'yellow', is_active: true },
  { name: 'Senior Care', description: 'Health packages for seniors', color: 'teal', is_active: true },
  { name: 'Sports & Fitness', description: 'Athletic performance packages', color: 'green', is_active: true },
];

const labs = [
  { name: 'HealthFirst Diagnostics', description: 'Premier diagnostics center', city: 'Dubai', address: 'Dubai Healthcare City, Building 47', rating: 4.8, review_count: 245, is_active: true },
  { name: 'MedLab Plus', description: 'Advanced medical laboratory', city: 'Abu Dhabi', address: 'Al Reem Island, Tower 3', rating: 4.7, review_count: 189, is_active: true },
  { name: 'QuickTest UAE', description: 'Fast and accurate testing', city: 'Sharjah', address: 'Al Majaz, Business Center', rating: 4.5, review_count: 156, is_active: true },
  { name: 'Medicare Labs', description: 'Trusted healthcare partner', city: 'Abu Dhabi', address: 'Khalifa City A', rating: 4.6, review_count: 178, is_active: true },
  { name: 'Al Borg Diagnostics', description: 'Leading diagnostic services', city: 'Dubai', address: 'Jumeirah Beach Road', rating: 4.9, review_count: 312, is_active: true },
  { name: 'NMC Healthcare', description: 'Best price guarantee', city: 'Dubai', address: 'Al Nahda, Street 15', rating: 4.7, review_count: 203, is_active: true },
  { name: 'Aster Labs', description: 'Quality healthcare services', city: 'Dubai', address: 'Al Qusais', rating: 4.8, review_count: 267, is_active: true },
  { name: 'Mediclinic', description: 'International standards', city: 'Dubai', address: 'City Walk', rating: 4.8, review_count: 289, is_active: true },
];

const tests = [
  { name: 'Complete Blood Count (CBC)', description: 'Measures various blood components including red cells, white cells, and platelets', category: 'Blood', base_price: 49, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['RBC', 'WBC', 'Platelets', 'Hemoglobin', 'Hematocrit'], preparation: 'Fasting not required', fasting_required: false, is_active: true },
  { name: 'Lipid Panel', description: 'Comprehensive cholesterol and triglyceride assessment for heart health', category: 'Heart', base_price: 89, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['LDL', 'HDL', 'Triglycerides', 'Total Cholesterol', 'VLDL'], preparation: '12-hour fasting required', fasting_required: true, fasting_hours: '10-12', is_active: true },
  { name: 'Thyroid Function Panel', description: 'Complete thyroid hormone assessment', category: 'Thyroid', base_price: 149, sample_type: 'Blood', turnaround_hours: 48, biomarkers: ['TSH', 'Free T3', 'Free T4'], preparation: 'Morning sample preferred', fasting_required: false, is_active: true },
  { name: 'HbA1c (Glycated Hemoglobin)', description: '3-month average blood sugar level indicator', category: 'Diabetes', base_price: 79, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['HbA1c'], preparation: 'Fasting not required', fasting_required: false, is_active: true },
  { name: 'Vitamin D (25-OH)', description: 'Measures vitamin D levels for bone health assessment', category: 'Vitamins', base_price: 99, sample_type: 'Blood', turnaround_hours: 48, biomarkers: ['25-OH Vitamin D'], preparation: 'Fasting not required', fasting_required: false, is_active: true },
  { name: 'Liver Function Test (LFT)', description: 'Comprehensive liver health panel', category: 'Liver', base_price: 129, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['ALT', 'AST', 'ALP', 'Bilirubin', 'Albumin', 'GGT'], preparation: 'Fasting preferred', fasting_required: true, fasting_hours: '8-10', is_active: true },
  { name: 'Kidney Function Test (KFT)', description: 'Assesses kidney health and function', category: 'Kidney', base_price: 99, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['Creatinine', 'BUN', 'Uric Acid', 'eGFR'], preparation: 'Fasting not required', fasting_required: false, is_active: true },
  { name: 'Vitamin B12', description: 'Essential vitamin for nerve function and blood cell formation', category: 'Vitamins', base_price: 89, sample_type: 'Blood', turnaround_hours: 48, biomarkers: ['Vitamin B12'], preparation: 'Fasting not required', fasting_required: false, is_active: true },
  { name: 'Iron Studies', description: 'Complete iron panel for anemia assessment', category: 'Minerals', base_price: 119, sample_type: 'Blood', turnaround_hours: 24, biomarkers: ['Serum Iron', 'Ferritin', 'TIBC', 'Transferrin Saturation'], preparation: 'Morning fasting sample', fasting_required: true, fasting_hours: '8-12', is_active: true },
  { name: 'Fasting Glucose', description: 'Blood sugar level after fasting', category: 'Diabetes', base_price: 29, sample_type: 'Blood', turnaround_hours: 12, biomarkers: ['Fasting Blood Glucose'], preparation: '8-12 hours fasting required', fasting_required: true, fasting_hours: '8-12', is_active: true },
];

const bundles = [
  { name: 'Full Body Checkup', description: 'Complete health screening with 40+ parameters covering all major organ systems', category: 'Premium', base_price: 699, original_price: 899, tests_included: 42, turnaround_hours: '24-48', fasting_required: true, fasting_hours: '10-12', home_collection: true, is_active: true, is_popular: true },
  { name: "Women's Wellness Panel", description: 'Hormone balance, PCOS screening, and fertility markers', category: "Women's Health", base_price: 599, original_price: 749, tests_included: 35, turnaround_hours: '24-48', fasting_required: true, fasting_hours: '10-12', home_collection: true, is_active: true, is_popular: true },
  { name: 'Heart & Cholesterol Panel', description: 'Comprehensive cardiovascular risk assessment', category: 'Heart Health', base_price: 299, original_price: 399, tests_included: 15, turnaround_hours: '24', fasting_required: true, fasting_hours: '10-12', home_collection: true, is_active: true, is_popular: true },
  { name: 'Energy & Fatigue Panel', description: 'Identify nutritional deficiencies causing tiredness', category: 'Energy', base_price: 449, original_price: 549, tests_included: 25, turnaround_hours: '24-48', fasting_required: false, home_collection: true, is_active: true, is_popular: false },
  { name: 'Diabetes Monitoring Panel', description: 'Complete diabetes screening and management', category: 'Diabetes', base_price: 249, original_price: 329, tests_included: 12, turnaround_hours: '24', fasting_required: true, fasting_hours: '8-10', home_collection: true, is_active: true, is_popular: false },
  { name: 'Essential Health Check', description: 'Basic health screening for routine checkups', category: 'Basic', base_price: 199, original_price: 279, tests_included: 20, turnaround_hours: '24', fasting_required: true, fasting_hours: '8-10', home_collection: true, is_active: true, is_popular: false },
  { name: 'Senior Citizen Package', description: 'Comprehensive screening for ages 60+', category: 'Senior Care', base_price: 799, original_price: 999, tests_included: 50, turnaround_hours: '48', fasting_required: true, fasting_hours: '10-12', home_collection: true, is_active: true, is_popular: false },
  { name: 'Thyroid Complete Panel', description: 'Full thyroid function assessment', category: 'Thyroid', base_price: 349, original_price: 449, tests_included: 8, turnaround_hours: '24-48', fasting_required: false, home_collection: true, is_active: true, is_popular: false },
];

async function seedDatabase() {
  console.log('Starting database seeding...\n');

  try {
    // Seed test categories
    console.log('Seeding test categories...');
    const { data: testCats, error: testCatError } = await supabase
      .from('test_categories')
      .upsert(testCategories, { onConflict: 'name' })
      .select();
    if (testCatError) throw testCatError;
    console.log(`✓ Inserted ${testCats?.length || 0} test categories`);

    // Seed bundle categories
    console.log('Seeding bundle categories...');
    const { data: bundleCats, error: bundleCatError } = await supabase
      .from('bundle_categories')
      .upsert(bundleCategories, { onConflict: 'name' })
      .select();
    if (bundleCatError) throw bundleCatError;
    console.log(`✓ Inserted ${bundleCats?.length || 0} bundle categories`);

    // Seed labs
    console.log('Seeding labs...');
    const { data: labsData, error: labsError } = await supabase
      .from('labs')
      .upsert(labs, { onConflict: 'name' })
      .select();
    if (labsError) throw labsError;
    console.log(`✓ Inserted ${labsData?.length || 0} labs`);

    // Seed tests
    console.log('Seeding tests...');
    const { data: testsData, error: testsError } = await supabase
      .from('tests')
      .upsert(tests, { onConflict: 'name' })
      .select();
    if (testsError) throw testsError;
    console.log(`✓ Inserted ${testsData?.length || 0} tests`);

    // Seed bundles
    console.log('Seeding bundles...');
    const { data: bundlesData, error: bundlesError } = await supabase
      .from('bundles')
      .upsert(bundles, { onConflict: 'name' })
      .select();
    if (bundlesError) throw bundlesError;
    console.log(`✓ Inserted ${bundlesData?.length || 0} bundles`);

    // Create lab pricing for bundles
    console.log('Creating lab-bundle pricing...');
    if (labsData && bundlesData) {
      const labBundlePricing = [];
      for (const lab of labsData) {
        for (const bundle of bundlesData) {
          // Random price variation per lab (±10%)
          const variation = 0.9 + Math.random() * 0.2;
          labBundlePricing.push({
            lab_id: lab.id,
            bundle_id: bundle.id,
            price: Math.round((bundle.base_price || 0) * variation),
            original_price: bundle.original_price,
            turnaround_hours: parseInt(bundle.turnaround_hours?.split('-')[0] || '24'),
            is_available: true,
          });
        }
      }
      const { error: pricingError } = await supabase
        .from('lab_bundle_pricing')
        .upsert(labBundlePricing, { onConflict: 'lab_id,bundle_id' });
      if (pricingError) console.log('Lab pricing error (may exist):', pricingError.message);
      else console.log(`✓ Created ${labBundlePricing.length} lab-bundle pricing entries`);
    }

    // Create lab pricing for tests
    console.log('Creating lab-test pricing...');
    if (labsData && testsData) {
      const labTestPricing = [];
      for (const lab of labsData) {
        for (const test of testsData) {
          const variation = 0.9 + Math.random() * 0.2;
          labTestPricing.push({
            lab_id: lab.id,
            test_id: test.id,
            price: Math.round((test.base_price || 0) * variation),
            original_price: Math.round((test.base_price || 0) * 1.2),
            turnaround_hours: test.turnaround_hours,
            is_available: true,
          });
        }
      }
      const { error: testPricingError } = await supabase
        .from('lab_test_pricing')
        .upsert(labTestPricing, { onConflict: 'lab_id,test_id' });
      if (testPricingError) console.log('Test pricing error (may exist):', testPricingError.message);
      else console.log(`✓ Created ${labTestPricing.length} lab-test pricing entries`);
    }

    console.log('\n✅ Database seeding completed successfully!');
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
}

seedDatabase();
