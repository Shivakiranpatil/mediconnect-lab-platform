import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || '';
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseServiceKey) {
  console.warn('Supabase credentials not found. Database features will be disabled.');
}

// Admin client with service role key (for server-side operations)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

// Public client with anon key (for client-side safe operations)
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database table names
export const TABLES = {
  BOOKINGS: 'bookings',
  USERS: 'users',
  TESTS: 'tests',
  BUNDLES: 'bundles',
  LABS: 'labs',
  TEST_CATEGORIES: 'test_categories',
  BUNDLE_CATEGORIES: 'bundle_categories',
  LAB_TEST_PRICING: 'lab_test_pricing',
  LAB_BUNDLE_PRICING: 'lab_bundle_pricing',
};

// Initialize database tables
export async function initializeDatabase() {
  console.log('Initializing Supabase database...');
  
  try {
    // Check connection
    const { data, error } = await supabaseAdmin.from('bookings').select('count').limit(1);
    
    if (error && error.code === '42P01') {
      // Table doesn't exist, create tables
      console.log('Tables not found. Please run the SQL migration in Supabase dashboard.');
      return false;
    }
    
    if (error) {
      console.error('Supabase connection error:', error.message);
      return false;
    }
    
    console.log('Supabase connected successfully!');
    return true;
  } catch (err) {
    console.error('Failed to initialize database:', err);
    return false;
  }
}

// Export SQL for creating tables (run this in Supabase SQL Editor)
export const CREATE_TABLES_SQL = `
-- Users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  phone VARCHAR(50),
  password_hash VARCHAR(255),
  role VARCHAR(50) DEFAULT 'user',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Test Categories table
CREATE TABLE IF NOT EXISTS test_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  color VARCHAR(50) DEFAULT 'blue',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bundle Categories table
CREATE TABLE IF NOT EXISTS bundle_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  color VARCHAR(50) DEFAULT 'blue',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Labs table
CREATE TABLE IF NOT EXISTS labs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  city VARCHAR(100),
  address TEXT,
  rating DECIMAL(2,1) DEFAULT 4.5,
  review_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tests table
CREATE TABLE IF NOT EXISTS tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category_id UUID REFERENCES test_categories(id),
  category VARCHAR(100),
  base_price DECIMAL(10,2),
  sample_type VARCHAR(50) DEFAULT 'Blood',
  turnaround_hours INTEGER DEFAULT 24,
  biomarkers TEXT[],
  preparation TEXT,
  fasting_required BOOLEAN DEFAULT false,
  fasting_hours VARCHAR(20),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bundles table
CREATE TABLE IF NOT EXISTS bundles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category_id UUID REFERENCES bundle_categories(id),
  category VARCHAR(100),
  base_price DECIMAL(10,2),
  original_price DECIMAL(10,2),
  tests_included INTEGER DEFAULT 0,
  turnaround_hours VARCHAR(20) DEFAULT '24-48',
  fasting_required BOOLEAN DEFAULT false,
  fasting_hours VARCHAR(20),
  home_collection BOOLEAN DEFAULT true,
  is_active BOOLEAN DEFAULT true,
  is_popular BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lab Test Pricing table
CREATE TABLE IF NOT EXISTS lab_test_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id UUID REFERENCES labs(id) ON DELETE CASCADE,
  test_id UUID REFERENCES tests(id) ON DELETE CASCADE,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  turnaround_hours INTEGER,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(lab_id, test_id)
);

-- Lab Bundle Pricing table
CREATE TABLE IF NOT EXISTS lab_bundle_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_id UUID REFERENCES labs(id) ON DELETE CASCADE,
  bundle_id UUID REFERENCES bundles(id) ON DELETE CASCADE,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  turnaround_hours INTEGER,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(lab_id, bundle_id)
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  bundle_id UUID REFERENCES bundles(id),
  lab_id UUID REFERENCES labs(id),
  bundle_name VARCHAR(255),
  lab_name VARCHAR(255),
  price DECIMAL(10,2),
  status VARCHAR(50) DEFAULT 'Pending',
  appointment_date DATE,
  appointment_time VARCHAR(20),
  patient_name VARCHAR(255),
  patient_email VARCHAR(255),
  patient_phone VARCHAR(50),
  patient_address TEXT,
  payment_method VARCHAR(50) DEFAULT 'Pay at Home/Lab',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);
CREATE INDEX IF NOT EXISTS idx_tests_category ON tests(category);
CREATE INDEX IF NOT EXISTS idx_bundles_category ON bundles(category);
CREATE INDEX IF NOT EXISTS idx_lab_test_pricing_lab ON lab_test_pricing(lab_id);
CREATE INDEX IF NOT EXISTS idx_lab_bundle_pricing_lab ON lab_bundle_pricing(lab_id);

-- Enable Row Level Security (optional - disable for now for easier development)
-- ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
`;

export default supabaseAdmin;
