import { db } from "./db";
import { bundles } from "@shared/schema";

const API_KEY = process.env.EMERGENT_LLM_KEY || "";

// Stub for AI service - can be implemented with direct OpenAI API calls if needed
export class AIDiscoveryService {
  /**
   * Create a chat session (placeholder for now)
   */
  static createChatSession(sessionId: string): any {
    return { sessionId };
  }

  /**
   * Get bundle recommendations based on user input
   */
  static async getBundleRecommendations(
    userContext: string
  ): Promise<Array<{ id: string; name: string; reason: string; price: string }>> {
    // Fetch all bundles from database
    const allBundles = await db.select().from(bundles).where({ isActive: true });

    // Simple keyword-based recommendation (can be enhanced with actual OpenAI API)
    const lowerContext = userContext.toLowerCase();
    const recommendations: any[] = [];

    // Women's health
    if (lowerContext.includes('woman') || lowerContext.includes('female') || 
        lowerContext.includes('pcos') || lowerContext.includes('hormone')) {
      const bundle = allBundles.find(b => b.slug === 'womens-wellness');
      if (bundle) recommendations.push({
        id: bundle.id,
        name: bundle.name,
        reason: "Tailored for women's health needs including hormone balance and PCOS screening",
        price: bundle.basePrice
      });
    }

    // Heart health
    if (lowerContext.includes('heart') || lowerContext.includes('cholesterol') || 
        lowerContext.includes('blood pressure') || lowerContext.includes('cardiac')) {
      const bundle = allBundles.find(b => b.slug === 'heart-cholesterol');
      if (bundle) recommendations.push({
        id: bundle.id,
        name: bundle.name,
        reason: "Essential for cardiovascular health and cholesterol monitoring",
        price: bundle.basePrice
      });
    }

    // Energy/Fatigue
    if (lowerContext.includes('tired') || lowerContext.includes('fatigue') || 
        lowerContext.includes('energy') || lowerContext.includes('vitamin')) {
      const bundle = allBundles.find(b => b.slug === 'energy-fatigue');
      if (bundle) recommendations.push({
        id: bundle.id,
        name: bundle.name,
        reason: "Helps identify nutritional deficiencies causing tiredness and low energy",
        price: bundle.basePrice
      });
    }

    // Diabetes
    if (lowerContext.includes('diabetes') || lowerContext.includes('blood sugar') || 
        lowerContext.includes('glucose')) {
      const bundle = allBundles.find(b => b.slug === 'diabetes-monitoring');
      if (bundle) recommendations.push({
        id: bundle.id,
        name: bundle.name,
        reason: "Important for diabetes management and blood sugar monitoring",
        price: bundle.basePrice
      });
    }

    // Routine checkup
    if (lowerContext.includes('routine') || lowerContext.includes('checkup') || 
        lowerContext.includes('general') || lowerContext.includes('annual')) {
      const bundle = allBundles.find(b => b.slug === 'full-body-checkup');
      if (bundle) recommendations.push({
        id: bundle.id,
        name: bundle.name,
        reason: "Comprehensive health screening for routine checkups",
        price: bundle.basePrice
      });
    }

    // If no specific matches, return popular bundles
    if (recommendations.length === 0) {
      return allBundles
        .filter(b => b.isPopular)
        .slice(0, 3)
        .map(b => ({
          id: b.id,
          name: b.name,
          reason: "Popular choice recommended based on your health profile",
          price: b.basePrice
        }));
    }

    return recommendations.slice(0, 3);
  }

  /**
   * Send a message (placeholder - returns canned responses for now)
   */
  static async sendMessage(
    sessionId: string,
    userMessage: string,
    conversationHistory: Array<{ role: string; content: string }>
  ): Promise<string> {
    const messageCount = conversationHistory.length;

    // Simple conversation flow
    if (messageCount === 0) {
      return "Thank you for sharing! 🙏\n\nHave you been diagnosed with any medical conditions? (Such as diabetes, high blood pressure, PCOS, thyroid issues, or others - or just type 'none')";
    } else if (messageCount === 1) {
      return "Got it, thanks! 📋\n\nWhat's your age range?\n• 18-30 years\n• 31-45 years\n• 46-60 years\n• 60+ years";
    } else if (messageCount === 2) {
      return "Perfect! 📍\n\nWhat is your gender? This helps us provide more relevant recommendations.\n• Male\n• Female\n• Prefer not to say";
    } else {
      // After collecting information, provide recommendations
      return "Based on what you've shared, I'll recommend some test bundles that would be most suitable for you. These recommendations appear below! \n\n✨ Click on any bundle to see full details and book!\n\nRemember, these are discovery suggestions. Please consult your healthcare provider for personalized medical advice.";
    }
  }
}

