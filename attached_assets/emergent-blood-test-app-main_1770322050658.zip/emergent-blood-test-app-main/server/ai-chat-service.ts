import OpenAI from "openai";
import "dotenv/config";

// Initialize OpenAI client - use user's OpenAI key first, then Emergent LLM Key as fallback
function getOpenAIClient(): OpenAI | null {
  const apiKey = process.env.OPENAI_API_KEY || process.env.EMERGENT_LLM_KEY;
  
  if (!apiKey) {
    console.warn("⚠️  No LLM API key found in environment");
    return null;
  }
  
  try {
    const client = new OpenAI({
      apiKey: apiKey,
    });
    console.log("✅ OpenAI client initialized with Emergent LLM Key");
    return client;
  } catch (error) {
    console.error("❌ Failed to initialize OpenAI:", error);
    return null;
  }
}

let openaiClient: OpenAI | null = null;

/**
 * Simple AI Chat Service with OpenAI GPT-4o-mini
 */
export async function sendAIMessage(
  sessionId: string,
  userMessage: string,
  conversationHistory: Array<{ role: string; content: string }>
): Promise<string> {
  
  // Lazy-initialize OpenAI client
  if (!openaiClient) {
    openaiClient = getOpenAIClient();
  }
  
  // If still no OpenAI client, return mock response
  if (!openaiClient) {
    console.log("Using mock AI response (no API key available)");
    return getMockResponse(conversationHistory.length);
  }

  try {
    // Build messages array
    const messages: any[] = [
      {
        role: "system",
        content: `You are a helpful AI health assistant for MediConnect, a lab test booking platform in Dubai, UAE.

Your role:
- Ask users about their health goals, symptoms, age, gender, and existing conditions
- Based on their answers, recommend appropriate lab test bundles
- Be empathetic, professional, and clear
- Ask ONE question at a time
- After 3-4 questions, provide recommendations

Available Test Bundles:
1. Full Body Checkup (AED 699) - Comprehensive health screening
2. Women's Wellness Panel (AED 599) - Hormone balance, PCOS screening
3. Heart & Cholesterol Panel (AED 299) - Cardiovascular risk assessment
4. Energy & Fatigue Panel (AED 449) - Vitamin deficiencies, thyroid
5. Diabetes Monitoring Panel (AED 249) - Blood sugar and kidney tests
6. Essential Health Check (AED 199) - Basic routine checkup

Ask about: health goals, symptoms, age range, gender, existing conditions.
Recommend 2-3 bundles with reasons.
Always add: "These are discovery suggestions. Consult your healthcare provider."`
      }
    ];

    // Add conversation history
    conversationHistory.forEach(msg => {
      messages.push({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      });
    });

    // Add current user message
    messages.push({
      role: 'user',
      content: userMessage
    });

    console.log(`Calling OpenAI API for session: ${sessionId}`);

    // Call OpenAI API
    const completion = await openaiClient.chat.completions.create({
      model: "gpt-4o-mini",
      messages: messages,
      temperature: 0.7,
      max_tokens: 400,
    });

    const response = completion.choices[0]?.message?.content || "I apologize, I couldn't generate a response. Please try again.";
    
    console.log(`✅ OpenAI response received (${response.length} chars)`);
    
    return response;

  } catch (error: any) {
    console.error("❌ OpenAI API Error:", error.message);
    
    // Return mock response as fallback
    return getMockResponse(conversationHistory.length);
  }
}

/**
 * Get bundle recommendations
 */
export async function getAIRecommendations(
  conversationContext: string
): Promise<Array<{ id: string; name: string; reason: string; price: string }>> {
  
  // Simple rule-based recommendations
  const lowerContext = conversationContext.toLowerCase();
  const recommendations: any[] = [];

  if (lowerContext.includes('woman') || lowerContext.includes('female') || lowerContext.includes('pcos')) {
    recommendations.push({
      id: "2",
      name: "Women's Wellness Panel",
      reason: "Tailored for women's health including hormone balance",
      price: "599"
    });
  }

  if (lowerContext.includes('heart') || lowerContext.includes('cholesterol') || lowerContext.includes('blood pressure')) {
    recommendations.push({
      id: "3",
      name: "Heart & Cholesterol Panel",
      reason: "Essential for cardiovascular health monitoring",
      price: "299"
    });
  }

  if (lowerContext.includes('tired') || lowerContext.includes('fatigue') || lowerContext.includes('energy')) {
    recommendations.push({
      id: "4",
      name: "Energy & Fatigue Panel",
      reason: "Helps identify vitamin deficiencies causing tiredness",
      price: "449"
    });
  }

  if (lowerContext.includes('diabetes') || lowerContext.includes('blood sugar')) {
    recommendations.push({
      id: "5",
      name: "Diabetes Monitoring Panel",
      reason: "Important for diabetes management",
      price: "249"
    });
  }

  // Default recommendations
  if (recommendations.length === 0) {
    recommendations.push(
      {
        id: "1",
        name: "Full Body Checkup",
        reason: "Comprehensive health screening recommended for routine checkups",
        price: "699"
      },
      {
        id: "6",
        name: "Essential Health Check",
        reason: "Good starting point for basic health assessment",
        price: "199"
      }
    );
  }

  return recommendations.slice(0, 3);
}

/**
 * Mock response fallback
 */
function getMockResponse(messageCount: number): string {
  if (messageCount === 0 || messageCount === 1) {
    return "Thank you for sharing! 🙏\n\nHave you been diagnosed with any medical conditions? (Such as diabetes, high blood pressure, PCOS, thyroid issues, or others - or just type 'none')";
  } else if (messageCount === 2 || messageCount === 3) {
    return "Got it, thanks! 📋\n\nWhat's your age range?\n• 18-30 years\n• 31-45 years\n• 46-60 years\n• 60+ years";
  } else if (messageCount === 4 || messageCount === 5) {
    return "Perfect! 📍\n\nWhat is your gender? This helps us provide more relevant recommendations.\n• Male\n• Female\n• Prefer not to say";
  } else {
    return "Based on what you've shared, I'll recommend some test bundles that would be most suitable for you! \n\n✨ Check the recommendations below!\n\nRemember: These are discovery suggestions. Please consult your healthcare provider for personalized medical advice.";
  }
}
