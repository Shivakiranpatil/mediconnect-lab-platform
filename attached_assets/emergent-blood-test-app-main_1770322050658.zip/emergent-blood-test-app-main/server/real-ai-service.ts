import OpenAI from "openai";

const API_KEY = process.env.OPENAI_API_KEY || process.env.EMERGENT_LLM_KEY || "";

// Initialize OpenAI with provided API key
let openai: OpenAI | null = null;
if (API_KEY) {
  openai = new OpenAI({
    apiKey: API_KEY,
  });
  console.log("✅ OpenAI initialized successfully");
} else {
  console.warn("⚠️  No OpenAI API key found. AI chat will use mock responses.");
}

export class RealAIService {
  /**
   * Send a message and get real AI response from OpenAI GPT-4
   */
  static async sendMessage(
    sessionId: string,
    userMessage: string,
    conversationHistory: Array<{ role: string; content: string }>
  ): Promise<string> {
    if (!openai) {
      // Fallback to mock if no API key
      return this.getMockResponse(conversationHistory.length);
    }

    try {
      // Build messages for OpenAI
      const messages: any[] = [
        {
          role: "system",
          content: `You are a helpful AI health assistant for MediConnect, a lab test booking platform in Dubai, UAE.

Your role:
- Ask users about their health goals, symptoms, age, gender, and existing conditions
- Based on their answers, recommend appropriate lab test bundles
- Always be empathetic, professional, and clear
- Ask ONE question at a time
- After 3-4 questions, provide recommendations

Available Test Bundles:
1. Full Body Checkup (AED 699) - Comprehensive health screening with 40+ parameters
2. Women's Wellness Panel (AED 599) - Hormone balance, PCOS screening, fertility markers
3. Heart & Cholesterol Panel (AED 299) - Cardiovascular risk assessment
4. Energy & Fatigue Panel (AED 449) - Vitamin deficiencies, thyroid function
5. Diabetes Monitoring Panel (AED 249) - Blood sugar and kidney function tests
6. Essential Health Check (AED 199) - Basic routine checkup tests

Guidelines:
- Ask about: health goals, symptoms, age range, gender, existing conditions
- Recommend 2-3 most relevant bundles based on their answers
- Explain WHY each bundle is recommended
- Always add disclaimer: "These are discovery suggestions. Please consult your healthcare provider for personalized medical advice."
- Be conversational and friendly but professional
- Use emojis sparingly (only 1-2 per message)

Start by greeting the user and asking what brings them to MediConnect today.`
        }
      ];

      // Add conversation history
      for (const msg of conversationHistory) {
        messages.push({
          role: msg.role === 'user' ? 'user' : 'assistant',
          content: msg.content
        });
      }

      // Add current user message
      messages.push({
        role: 'user',
        content: userMessage
      });

      // Call OpenAI API
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: messages,
        temperature: 0.7,
        max_tokens: 500
      });

      return completion.choices[0]?.message?.content || "I apologize, but I couldn't generate a response. Please try again.";
    } catch (error: any) {
      console.error("OpenAI API error:", error);
      
      // Fallback to mock if API fails
      if (error?.status === 401) {
        console.error("❌ Invalid API key");
      } else if (error?.status === 429) {
        console.error("❌ Rate limit exceeded");
      }
      
      return this.getMockResponse(conversationHistory.length);
    }
  }

  /**
   * Get mock response as fallback
   */
  private static getMockResponse(messageCount: number): string {
    if (messageCount === 0 || messageCount === 1) {
      return "Thank you for sharing! 🙏\n\nHave you been diagnosed with any medical conditions? (Such as diabetes, high blood pressure, PCOS, thyroid issues, or others - or just type 'none')";
    } else if (messageCount === 2 || messageCount === 3) {
      return "Got it, thanks! 📋\n\nWhat's your age range?\n• 18-30 years\n• 31-45 years\n• 46-60 years\n• 60+ years";
    } else if (messageCount === 4 || messageCount === 5) {
      return "Perfect! 📍\n\nWhat is your gender? This helps us provide more relevant recommendations.\n• Male\n• Female\n• Prefer not to say";
    } else {
      return "Based on what you've shared, I'll recommend some test bundles that would be most suitable for you. Let me analyze your responses and provide personalized recommendations! \n\n✨ Please check the recommendations below!\n\nRemember, these are discovery suggestions. Please consult your healthcare provider for personalized medical advice.";
    }
  }

  /**
   * Get bundle recommendations based on conversation context
   */
  static async getBundleRecommendations(
    conversationContext: string
  ): Promise<Array<{ id: string; name: string; reason: string; price: string }>> {
    if (!openai) {
      // Return mock recommendations
      return [
        {
          id: "1",
          name: "Full Body Checkup",
          reason: "Comprehensive health screening recommended based on your profile",
          price: "699"
        },
        {
          id: "2",
          name: "Heart & Cholesterol Panel",
          reason: "Important for cardiovascular health monitoring",
          price: "299"
        },
        {
          id: "3",
          name: "Essential Health Check",
          reason: "Good starting point for routine health assessment",
          price: "199"
        }
      ];
    }

    try {
      const prompt = `Based on this conversation with a user, recommend 2-3 most suitable lab test bundles from the list below. Return ONLY a JSON array.

Available bundles:
- Full Body Checkup (AED 699): Complete health screening with 40+ parameters
- Women's Wellness Panel (AED 599): Hormone balance, PCOS screening, fertility markers
- Heart & Cholesterol Panel (AED 299): Cardiovascular risk assessment
- Energy & Fatigue Panel (AED 449): Vitamin deficiencies, thyroid function
- Diabetes Monitoring Panel (AED 249): Blood sugar and kidney function tests
- Essential Health Check (AED 199): Basic routine checkup tests

Conversation context:
${conversationContext}

Return format: [{"id": "1", "name": "Bundle Name", "reason": "Why this is recommended", "price": "699"}]`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a healthcare recommendation system. Return only valid JSON." },
          { role: "user", content: prompt }
        ],
        temperature: 0.5,
        max_tokens: 300
      });

      const response = completion.choices[0]?.message?.content || "[]";
      const jsonMatch = response.match(/\[.*\]/s);
      
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (error) {
      console.error("Failed to get AI recommendations:", error);
    }

    // Fallback recommendations
    return [
      {
        id: "1",
        name: "Full Body Checkup",
        reason: "Comprehensive health screening recommended based on your profile",
        price: "699"
      },
      {
        id: "2",
        name: "Heart & Cholesterol Panel",
        reason: "Important for cardiovascular health monitoring",
        price: "299"
      }
    ];
  }
}
