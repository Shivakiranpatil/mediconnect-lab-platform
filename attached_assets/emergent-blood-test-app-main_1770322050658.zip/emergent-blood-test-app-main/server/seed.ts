import { db } from "./db";
import { 
  users, bundles, tests, partnerLabs, aiRuleSets, 
  aiQuestions, aiMappingRules, bundleTests, labBundlePricing, labZones, labHours
} from "@shared/schema";
import { sql } from "drizzle-orm";

export async function resetAndSeedDatabase() {
  console.log("🗑️  Dropping existing tables...");
  
  // Drop tables in correct order (respecting foreign keys)
  await db.execute(sql`DROP TABLE IF EXISTS session CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS lab_hours CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS lab_zones CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS lab_bundle_pricing CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS bundle_tests CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS ai_mapping_rules CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS ai_questions CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS ai_rule_sets CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS appointments CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS tests CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS bundles CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS partner_labs CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS users CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS messages CASCADE`);
  await db.execute(sql`DROP TABLE IF EXISTS conversations CASCADE`);

  console.log("✅ Tables dropped");
  console.log("📦 Running migrations...");
  
  // Import and run migrations
  const { migrate } = await import("drizzle-orm/node-postgres/migrator");
  await migrate(db, { migrationsFolder: "./migrations" });
  
  console.log("✅ Migrations complete");
  console.log("🌱 Seeding database...");

  // 1. Create Users
  const [adminUser] = await db.insert(users).values({
    username: "admin",
    password: "admin123",
    role: "admin",
    name: "System Administrator"
  }).returning();

  const [labUser] = await db.insert(users).values({
    username: "labadmin",
    password: "lab123",
    role: "lab_admin",
    name: "Lab Manager"
  }).returning();

  const [testUser] = await db.insert(users).values({
    username: "user",
    password: "user123",
    role: "user",
    name: "Test User"
  }).returning();

  console.log("✅ Users created");

  // 2. Create Partner Labs
  const mediclinic = await db.insert(partnerLabs).values({
    name: "MEDICLINIC",
    slug: "mediclinic",
    description: "Leading healthcare provider in the UAE",
    emirate: "Dubai",
    status: "active",
    rating: "4.8",
    totalReviews: 1250
  }).returning();

  const nmc = await db.insert(partnerLabs).values({
    name: "NMC Healthcare",
    slug: "nmc-healthcare",
    description: "Comprehensive healthcare services",
    emirate: "Dubai",
    status: "active",
    rating: "4.7",
    totalReviews: 980
  }).returning();

  const alborg = await db.insert(partnerLabs).values({
    name: "Al Borg",
    slug: "al-borg",
    description: "Specialized diagnostic services",
    emirate: "Dubai",
    status: "active",
    rating: "4.6",
    totalReviews: 750
  }).returning();

  const primeHealth = await db.insert(partnerLabs).values({
    name: "Prime Health",
    slug: "prime-health",
    description: "Premium health screening services",
    emirate: "Dubai",
    status: "active",
    rating: "4.9",
    totalReviews: 560
  }).returning();

  const diner = await db.insert(partnerLabs).values({
    name: "DINER",
    slug: "diner",
    description: "Advanced laboratory diagnostics",
    emirate: "Dubai",
    status: "active",
    rating: "4.5",
    totalReviews: 430
  }).returning();

  console.log("✅ Partner labs created");

  // 3. Create Tests
  const hba1cTest = await db.insert(tests).values({
    name: "HbA1c (Blood Sugar)",
    description: "3-month average blood glucose level",
    category: "Diabetes",
    biomarkers: ["HbA1c"],
    preparation: "No fasting required",
    turnaroundHours: 24
  }).returning();

  const cholesterolTest = await db.insert(tests).values({
    name: "Lipid Profile",
    description: "Complete cholesterol panel",
    category: "Heart Health",
    biomarkers: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"],
    preparation: "12-hour fasting required",
    turnaroundHours: 24
  }).returning();

  const vitaminDTest = await db.insert(tests).values({
    name: "Vitamin D",
    description: "25-hydroxy vitamin D levels",
    category: "Vitamins",
    biomarkers: ["25-OH Vitamin D"],
    preparation: "No fasting required",
    turnaroundHours: 48
  }).returning();

  const thyroidTest = await db.insert(tests).values({
    name: "Thyroid Function Panel",
    description: "TSH, T3, T4 levels",
    category: "Endocrine",
    biomarkers: ["TSH", "Free T3", "Free T4"],
    preparation: "No fasting required",
    turnaroundHours: 24
  }).returning();

  const cbcTest = await db.insert(tests).values({
    name: "Complete Blood Count (CBC)",
    description: "Comprehensive blood cell analysis",
    category: "General",
    biomarkers: ["WBC", "RBC", "Hemoglobin", "Platelets"],
    preparation: "No fasting required",
    turnaroundHours: 24
  }).returning();

  const liverTest = await db.insert(tests).values({
    name: "Liver Function Test",
    description: "ALT, AST, Bilirubin, Albumin",
    category: "Liver",
    biomarkers: ["ALT", "AST", "Bilirubin", "Albumin", "ALP"],
    preparation: "No fasting required",
    turnaroundHours: 24
  }).returning();

  const kidneyTest = await db.insert(tests).values({
    name: "Kidney Function Test",
    description: "Creatinine, BUN, eGFR",
    category: "Kidney",
    biomarkers: ["Creatinine", "BUN", "eGFR"],
    preparation: "No fasting required",
    turnaroundHours: 24
  }).returning();

  const ironTest = await db.insert(tests).values({
    name: "Iron Studies",
    description: "Serum iron, TIBC, Ferritin",
    category: "Minerals",
    biomarkers: ["Serum Iron", "TIBC", "Ferritin", "Transferrin Saturation"],
    preparation: "12-hour fasting recommended",
    turnaroundHours: 48
  }).returning();

  console.log("✅ Tests created");

  // 4. Create Bundles
  const fullBodyBundle = await db.insert(bundles).values({
    name: "Full Body Checkup",
    slug: "full-body-checkup",
    description: "Complete health screening with 40+ parameters",
    shortDescription: "Complete health screening",
    category: "Premium",
    tags: ["Popular", "Comprehensive"],
    icon: "activity",
    color: "blue",
    basePrice: "699",
    isPopular: true,
    sortOrder: 1
  }).returning();

  const womensBundle = await db.insert(bundles).values({
    name: "Women's Wellness Panel",
    slug: "womens-wellness",
    description: "Hormone balance, PCOS screening, and fertility markers",
    shortDescription: "Hormone & PCOS Panels",
    category: "Women's Health",
    tags: ["Women", "Hormones"],
    icon: "heart",
    color: "pink",
    basePrice: "599",
    isPopular: true,
    sortOrder: 2
  }).returning();

  const heartBundle = await db.insert(bundles).values({
    name: "Heart & Cholesterol Panel",
    slug: "heart-cholesterol",
    description: "Comprehensive cardiovascular risk assessment and monitoring",
    shortDescription: "Cardiac Risk Assessment",
    category: "Heart Health",
    tags: ["Heart", "Cholesterol"],
    icon: "heart",
    color: "red",
    basePrice: "299",
    isPopular: true,
    sortOrder: 3
  }).returning();

  const energyBundle = await db.insert(bundles).values({
    name: "Energy & Fatigue Panel",
    slug: "energy-fatigue",
    description: "Identify nutritional deficiencies causing tiredness and low energy",
    shortDescription: "Vitamin & Energy Tests",
    category: "Energy",
    tags: ["Fatigue", "Vitamins"],
    icon: "zap",
    color: "amber",
    basePrice: "449",
    isPopular: false,
    sortOrder: 4
  }).returning();

  const diabetesBundle = await db.insert(bundles).values({
    name: "Diabetes Monitoring Panel",
    slug: "diabetes-monitoring",
    description: "Complete diabetes screening and management tests",
    shortDescription: "Blood sugar monitoring",
    category: "Diabetes",
    tags: ["Diabetes", "Blood Sugar"],
    icon: "activity",
    color: "orange",
    basePrice: "249",
    isPopular: false,
    sortOrder: 5
  }).returning();

  const essentialBundle = await db.insert(bundles).values({
    name: "Essential Health Check",
    slug: "essential-health",
    description: "Basic health screening for routine checkups",
    shortDescription: "Routine health checkup",
    category: "General",
    tags: ["Basic", "Routine"],
    icon: "activity",
    color: "blue",
    basePrice: "199",
    isPopular: false,
    sortOrder: 6
  }).returning();

  console.log("✅ Bundles created");

  // 5. Link Tests to Bundles
  // Full Body Checkup - comprehensive
  await db.insert(bundleTests).values([
    { bundleId: fullBodyBundle[0].id, testId: cbcTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: cholesterolTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: hba1cTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: thyroidTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: vitaminDTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: liverTest[0].id },
    { bundleId: fullBodyBundle[0].id, testId: kidneyTest[0].id },
  ]);

  // Women's Wellness
  await db.insert(bundleTests).values([
    { bundleId: womensBundle[0].id, testId: thyroidTest[0].id },
    { bundleId: womensBundle[0].id, testId: ironTest[0].id },
    { bundleId: womensBundle[0].id, testId: vitaminDTest[0].id },
  ]);

  // Heart & Cholesterol
  await db.insert(bundleTests).values([
    { bundleId: heartBundle[0].id, testId: cholesterolTest[0].id },
    { bundleId: heartBundle[0].id, testId: hba1cTest[0].id },
  ]);

  // Energy & Fatigue
  await db.insert(bundleTests).values([
    { bundleId: energyBundle[0].id, testId: vitaminDTest[0].id },
    { bundleId: energyBundle[0].id, testId: thyroidTest[0].id },
    { bundleId: energyBundle[0].id, testId: ironTest[0].id },
    { bundleId: energyBundle[0].id, testId: cbcTest[0].id },
  ]);

  // Diabetes Monitoring
  await db.insert(bundleTests).values([
    { bundleId: diabetesBundle[0].id, testId: hba1cTest[0].id },
    { bundleId: diabetesBundle[0].id, testId: kidneyTest[0].id },
  ]);

  // Essential Health
  await db.insert(bundleTests).values([
    { bundleId: essentialBundle[0].id, testId: cbcTest[0].id },
    { bundleId: essentialBundle[0].id, testId: cholesterolTest[0].id },
  ]);

  console.log("✅ Tests linked to bundles");

  // 6. Create AI Rule Set
  const [ruleSet] = await db.insert(aiRuleSets).values({
    name: "Health Discovery Flow v1",
    isActive: true,
    maxBundles: 3,
    disclaimerText: "These are discovery suggestions. Please consult your healthcare provider for personalized medical advice."
  }).returning();

  // 7. Create AI Questions
  await db.insert(aiQuestions).values([
    {
      ruleSetId: ruleSet.id,
      questionKey: "health_goal",
      questionText: "What brings you here today?",
      questionType: "single",
      options: JSON.stringify(["Routine checkup", "Feeling fatigued", "Monitoring a condition", "Weight management", "Other"]),
      helperText: "For example: routine checkup, feeling fatigued, monitoring a condition",
      sortOrder: 1
    },
    {
      ruleSetId: ruleSet.id,
      questionKey: "conditions",
      questionText: "Have you been diagnosed with any medical conditions?",
      questionType: "multi",
      options: JSON.stringify(["Diabetes", "High blood pressure", "PCOS", "Thyroid issues", "None"]),
      helperText: "Such as diabetes, high blood pressure, PCOS, thyroid issues, or others",
      sortOrder: 2
    },
    {
      ruleSetId: ruleSet.id,
      questionKey: "age_range",
      questionText: "What's your age range?",
      questionType: "single",
      options: JSON.stringify(["18-30 years", "31-45 years", "46-60 years", "60+ years"]),
      helperText: "Select your age group",
      sortOrder: 3
    },
    {
      ruleSetId: ruleSet.id,
      questionKey: "gender",
      questionText: "What is your gender?",
      questionType: "single",
      options: JSON.stringify(["Male", "Female", "Prefer not to say"]),
      helperText: "This helps us provide relevant recommendations",
      sortOrder: 4
    }
  ]);

  console.log("✅ AI questions created");

  // 8. Create AI Mapping Rules
  await db.insert(aiMappingRules).values([
    {
      ruleSetId: ruleSet.id,
      name: "Routine Checkup - Full Body",
      conditions: JSON.stringify({ health_goal: "Routine checkup", age_range: "31-45 years" }),
      recommendedBundleIds: JSON.stringify([fullBodyBundle[0].id]),
      reasonTemplate: "Recommended for comprehensive health screening",
      priority: 1
    },
    {
      ruleSetId: ruleSet.id,
      name: "Women's Health Focus",
      conditions: JSON.stringify({ gender: "Female" }),
      recommendedBundleIds: JSON.stringify([womensBundle[0].id]),
      reasonTemplate: "Tailored for women's health needs",
      priority: 2
    },
    {
      ruleSetId: ruleSet.id,
      name: "Diabetes Monitoring",
      conditions: JSON.stringify({ conditions: ["Diabetes"] }),
      recommendedBundleIds: JSON.stringify([diabetesBundle[0].id, heartBundle[0].id]),
      reasonTemplate: "Important for diabetes management",
      priority: 3
    },
    {
      ruleSetId: ruleSet.id,
      name: "Fatigue Management",
      conditions: JSON.stringify({ health_goal: "Feeling fatigued" }),
      recommendedBundleIds: JSON.stringify([energyBundle[0].id]),
      reasonTemplate: "Helps identify causes of fatigue",
      priority: 4
    },
    {
      ruleSetId: ruleSet.id,
      name: "Heart Health",
      conditions: JSON.stringify({ conditions: ["High blood pressure"] }),
      recommendedBundleIds: JSON.stringify([heartBundle[0].id]),
      reasonTemplate: "Essential for cardiovascular health monitoring",
      priority: 5
    }
  ]);

  console.log("✅ AI mapping rules created");

  console.log("🎉 Database seeded successfully!");
  console.log("\n📝 Login Credentials:");
  console.log("Admin - username: admin, password: admin123");
  console.log("Lab Admin - username: labadmin, password: lab123");
  console.log("User - username: user, password: user123");
}
