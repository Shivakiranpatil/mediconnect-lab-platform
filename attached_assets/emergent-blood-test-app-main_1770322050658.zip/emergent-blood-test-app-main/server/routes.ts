import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { db } from "./db";
import { users, bundles, tests, partnerLabs, appointments, aiRuleSets, aiQuestions, aiMappingRules, labBundlePricing, labTests, packageTests } from "@shared/schema";
import { eq, like, or, ilike, and, inArray, sql, desc, asc } from "drizzle-orm";
import { sendAIMessage, getAIRecommendations } from "./ai-chat-service";
import { EmailService } from "./email";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register AI Integration Routes
  registerChatRoutes(app);
  registerImageRoutes(app);

  // --- Auth (Mock for now, real auth via integration later if needed) ---
  app.post(api.auth.login.path, async (req, res) => {
    const { username, password } = req.body;
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    req.session.userId = user.id;
    res.json(user);
  });

  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      // Check if user exists
      const existing = await storage.getUserByUsername(input.username);
      if (existing) {
        return res.status(400).json({ message: "Username already exists" });
      }
      const user = await storage.createUser(input);
      req.session.userId = user.id;
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.auth.me.path, async (req, res) => {
    if (!req.session || !req.session.userId) return res.json(null);
    const user = await storage.getUser(req.session.userId);
    res.json(user || null);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "Logged out successfully" });
    });
  });

  // --- Tests Catalog (Public) with Lab-Specific Pricing ---
  
  // Mock data for tests with lab pricing
  const mockTestsWithLabs = [
    {
      id: "1",
      name: "HbA1c (Blood Sugar)",
      description: "Measures your average blood sugar levels over the past 2-3 months. Essential for diabetes screening, diagnosis, and monitoring.",
      category: "Diabetes",
      biomarkers: ["HbA1c"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 65,
      highestPrice: 99,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 65, originalPrice: 79, discountPercent: 18, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 75, originalPrice: 79, discountPercent: 5, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 79, originalPrice: 79, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 99, originalPrice: 99, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "5", "6"]
    },
    {
      id: "2",
      name: "Lipid Profile",
      description: "Complete cholesterol panel measuring total cholesterol, LDL, HDL, and triglycerides. Critical for cardiovascular risk assessment.",
      category: "Heart Health",
      biomarkers: ["Total Cholesterol", "LDL", "HDL", "Triglycerides"],
      preparation: "12-hour fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 75,
      highestPrice: 120,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 75, originalPrice: 89, discountPercent: 16, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 85, originalPrice: 89, discountPercent: 4, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 89, originalPrice: 89, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 120, originalPrice: 120, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "3", "6", "9", "10"]
    },
    {
      id: "3",
      name: "Vitamin D",
      description: "Measures 25-hydroxy vitamin D levels. Essential for bone health and immune function.",
      category: "Vitamins",
      biomarkers: ["25-OH Vitamin D"],
      preparation: "No fasting required",
      turnaroundHours: 48,
      isActive: true,
      lowestPrice: 85,
      highestPrice: 129,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 85, originalPrice: 99, discountPercent: 14, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 95, originalPrice: 99, discountPercent: 4, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 99, originalPrice: 99, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 129, originalPrice: 129, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "4"]
    },
    {
      id: "4",
      name: "Thyroid Function Panel",
      description: "Comprehensive thyroid assessment measuring TSH, Free T3, and Free T4.",
      category: "Endocrine",
      biomarkers: ["TSH", "Free T3", "Free T4"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 125,
      highestPrice: 179,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 125, originalPrice: 149, discountPercent: 16, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 139, originalPrice: 149, discountPercent: 7, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 149, originalPrice: 149, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 179, originalPrice: 179, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "2", "4"]
    },
    {
      id: "5",
      name: "Complete Blood Count (CBC)",
      description: "Evaluates overall health by measuring red blood cells, white blood cells, hemoglobin, and platelets.",
      category: "General",
      biomarkers: ["WBC", "RBC", "Hemoglobin", "Platelets", "Hematocrit"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 35,
      highestPrice: 65,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 35, originalPrice: 49, discountPercent: 29, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 45, originalPrice: 49, discountPercent: 8, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 49, originalPrice: 49, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 65, originalPrice: 65, discountPercent: 0, turnaroundHours: 6, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "6", "8"]
    },
    {
      id: "6",
      name: "Liver Function Test",
      description: "Assesses liver health by measuring enzymes and proteins including ALT, AST, Bilirubin.",
      category: "Liver",
      biomarkers: ["ALT", "AST", "Bilirubin", "Albumin", "ALP"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 99,
      highestPrice: 159,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 99, originalPrice: 129, discountPercent: 23, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 119, originalPrice: 129, discountPercent: 8, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 129, originalPrice: 129, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 159, originalPrice: 159, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "6", "8"]
    },
    {
      id: "7",
      name: "Kidney Function Test",
      description: "Evaluates kidney health by measuring creatinine, BUN, and eGFR.",
      category: "Kidney",
      biomarkers: ["Creatinine", "BUN", "eGFR", "Uric Acid"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 79,
      highestPrice: 129,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 79, originalPrice: 99, discountPercent: 20, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 89, originalPrice: 99, discountPercent: 10, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 99, originalPrice: 99, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 129, originalPrice: 129, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "6", "8"]
    },
    {
      id: "8",
      name: "Iron Studies",
      description: "Comprehensive iron panel measuring serum iron, TIBC, and ferritin.",
      category: "Minerals",
      biomarkers: ["Serum Iron", "TIBC", "Ferritin", "Transferrin Saturation"],
      preparation: "12-hour fasting recommended",
      turnaroundHours: 48,
      isActive: true,
      lowestPrice: 95,
      highestPrice: 149,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 95, originalPrice: 119, discountPercent: 20, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 109, originalPrice: 119, discountPercent: 8, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 119, originalPrice: 119, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 149, originalPrice: 149, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "4"]
    },
    {
      id: "9",
      name: "Vitamin B12",
      description: "Measures vitamin B12 levels essential for nerve function and red blood cell production.",
      category: "Vitamins",
      biomarkers: ["Vitamin B12", "Folate"],
      preparation: "No fasting required",
      turnaroundHours: 24,
      isActive: true,
      lowestPrice: 75,
      highestPrice: 119,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 75, originalPrice: 89, discountPercent: 16, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 85, originalPrice: 89, discountPercent: 4, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 89, originalPrice: 89, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 119, originalPrice: 119, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["1", "4"]
    },
    {
      id: "10",
      name: "Testosterone",
      description: "Measures total testosterone levels. Important for men with fatigue or low libido.",
      category: "Hormones",
      biomarkers: ["Total Testosterone", "Free Testosterone"],
      preparation: "Morning sample preferred (before 10 AM)",
      turnaroundHours: 48,
      isActive: true,
      lowestPrice: 105,
      highestPrice: 159,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 105, originalPrice: 129, discountPercent: 19, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "2", labName: "MedLab Plus", price: 119, originalPrice: 129, discountPercent: 8, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "3", labName: "Al Borg Laboratories", price: 129, originalPrice: 129, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
        { labId: "4", labName: "Prime Diagnostics", price: 159, originalPrice: 159, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
      ],
      includedInPackages: ["2"]
    }
  ];

  // Mock data for packages with lab pricing
  const mockPackagesWithLabs = [
    {
      id: "1",
      name: "Full Body Checkup",
      description: "Complete health screening with 40+ parameters including CBC, lipid profile, liver, kidney, thyroid function, and vitamins.",
      category: "Premium",
      testCount: 42,
      tags: ["Popular", "Comprehensive"],
      lowestPrice: 599,
      highestPrice: 899,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 599, originalPrice: 699, discountPercent: 14, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 14 },
        { labId: "2", labName: "MedLab Plus", price: 649, originalPrice: 699, discountPercent: 7, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 15 },
        { labId: "3", labName: "Al Borg Laboratories", price: 699, originalPrice: 699, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 17 },
        { labId: "4", labName: "Prime Diagnostics", price: 899, originalPrice: 899, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 21 }
      ],
      testsPreview: ["CBC", "Lipid Profile", "Liver Function", "Kidney Function", "Thyroid Panel", "Vitamin D", "B12"]
    },
    {
      id: "2",
      name: "Women's Wellness Panel",
      description: "Comprehensive hormone assessment including thyroid, reproductive hormones, and PCOS markers.",
      category: "Women's Health",
      testCount: 25,
      tags: ["Women", "Hormones"],
      lowestPrice: 499,
      highestPrice: 749,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 499, originalPrice: 599, discountPercent: 17, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 20 },
        { labId: "2", labName: "MedLab Plus", price: 549, originalPrice: 599, discountPercent: 8, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 22 },
        { labId: "3", labName: "Al Borg Laboratories", price: 599, originalPrice: 599, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 24 },
        { labId: "4", labName: "Prime Diagnostics", price: 749, originalPrice: 749, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 30 }
      ],
      testsPreview: ["Thyroid Panel", "FSH", "LH", "Estrogen", "Testosterone", "Prolactin"]
    },
    {
      id: "3",
      name: "Heart & Cholesterol Panel",
      description: "Comprehensive cardiovascular risk assessment including lipid profile and cardiac markers.",
      category: "Heart Health",
      testCount: 15,
      tags: ["Heart", "Cholesterol"],
      lowestPrice: 249,
      highestPrice: 399,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 249, originalPrice: 299, discountPercent: 17, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 17 },
        { labId: "2", labName: "MedLab Plus", price: 279, originalPrice: 299, discountPercent: 7, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 19 },
        { labId: "3", labName: "Al Borg Laboratories", price: 299, originalPrice: 299, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 20 },
        { labId: "4", labName: "Prime Diagnostics", price: 399, originalPrice: 399, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 27 }
      ],
      testsPreview: ["Lipid Profile", "CRP", "Homocysteine", "Lipoprotein(a)"]
    },
    {
      id: "4",
      name: "Energy & Fatigue Panel",
      description: "Identify nutritional deficiencies causing tiredness including vitamins and thyroid.",
      category: "Energy",
      testCount: 20,
      tags: ["Fatigue", "Vitamins"],
      lowestPrice: 379,
      highestPrice: 549,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 379, originalPrice: 449, discountPercent: 16, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 19 },
        { labId: "2", labName: "MedLab Plus", price: 419, originalPrice: 449, discountPercent: 7, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 21 },
        { labId: "3", labName: "Al Borg Laboratories", price: 449, originalPrice: 449, discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 22 },
        { labId: "4", labName: "Prime Diagnostics", price: 549, originalPrice: 549, discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 27 }
      ],
      testsPreview: ["Thyroid Panel", "Vitamin D", "B12", "Iron Studies", "CBC"]
    },
    {
      id: "5",
      name: "Diabetes Monitoring Panel",
      description: "Complete diabetes screening and management including HbA1c and blood sugar markers.",
      category: "Diabetes",
      testCount: 12,
      tags: ["Diabetes", "Blood Sugar"],
      lowestPrice: 199,
      highestPrice: 329,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 199, originalPrice: 249, discountPercent: 20, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 17 },
        { labId: "2", labName: "MedLab Plus", price: 229, originalPrice: 249, discountPercent: 8, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 19 },
        { labId: "3", labName: "Al Borg Laboratories", price: 249, originalPrice: 249, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 21 },
        { labId: "4", labName: "Prime Diagnostics", price: 329, originalPrice: 329, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 27 }
      ],
      testsPreview: ["HbA1c", "Fasting Glucose", "Post-Prandial Glucose", "Insulin"]
    },
    {
      id: "6",
      name: "Essential Health Check",
      description: "Basic health screening for routine checkups covering essential parameters.",
      category: "General",
      testCount: 18,
      tags: ["Basic", "Routine"],
      lowestPrice: 169,
      highestPrice: 279,
      availableLabsCount: 4,
      labs: [
        { labId: "1", labName: "HealthFirst Diagnostics", price: 169, originalPrice: 199, discountPercent: 15, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 9 },
        { labId: "2", labName: "MedLab Plus", price: 189, originalPrice: 199, discountPercent: 5, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 11 },
        { labId: "3", labName: "Al Borg Laboratories", price: 199, originalPrice: 199, discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 11 },
        { labId: "4", labName: "Prime Diagnostics", price: 279, originalPrice: 279, discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: 15 }
      ],
      testsPreview: ["CBC", "Lipid Profile", "HbA1c", "Liver Function", "Kidney Function"]
    }
  ];

  // Package to test mapping for recommendations
  const packageTestMapping: Record<string, string[]> = {
    "1": ["1", "2", "3", "4", "5", "6", "7", "8", "9"], // Full Body
    "2": ["4", "10"], // Women's Wellness
    "3": ["2"], // Heart & Cholesterol
    "4": ["3", "4", "8", "9"], // Energy & Fatigue
    "5": ["1"], // Diabetes
    "6": ["1", "2", "5", "6", "7"] // Essential Health
  };

  // GET /api/tests - List all tests with lab pricing (tries Supabase first, falls back to mock)
  app.get('/api/tests', async (req, res) => {
    try {
      const { search, category, labId, source } = req.query;
      
      // Try Supabase first if not explicitly requesting mock data
      if (source !== 'mock') {
        try {
          const supabaseTests = await testsService.getAll();
          if (supabaseTests && supabaseTests.length > 0) {
            // Transform Supabase data to match the expected format
            let filteredTests = supabaseTests.map((test: any) => ({
              id: test.id,
              name: test.name,
              description: test.description || '',
              category: test.category || 'General',
              biomarkers: test.biomarkers || [],
              preparation: test.preparation || '',
              turnaroundHours: test.turnaround_hours || 24,
              isActive: test.is_active,
              lowestPrice: test.base_price || 99,
              highestPrice: Math.round((test.base_price || 99) * 1.5),
              price: test.base_price?.toString() || '99',
              availableLabsCount: 4,
              labs: [
                { labId: "1", labName: "HealthFirst Diagnostics", price: test.base_price || 99, originalPrice: Math.round((test.base_price || 99) * 1.2), discountPercent: 17, turnaroundHours: 24, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0 },
                { labId: "2", labName: "MedLab Plus", price: Math.round((test.base_price || 99) * 1.1), originalPrice: Math.round((test.base_price || 99) * 1.2), discountPercent: 8, turnaroundHours: 24, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0 },
                { labId: "3", labName: "Al Borg Laboratories", price: Math.round((test.base_price || 99) * 1.2), originalPrice: Math.round((test.base_price || 99) * 1.2), discountPercent: 0, turnaroundHours: 24, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0 },
                { labId: "4", labName: "Prime Diagnostics", price: Math.round((test.base_price || 99) * 1.5), originalPrice: Math.round((test.base_price || 99) * 1.5), discountPercent: 0, turnaroundHours: 12, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0 }
              ],
              includedInPackages: []
            }));
            
            // Apply filters
            if (search && typeof search === 'string') {
              const searchLower = search.toLowerCase();
              filteredTests = filteredTests.filter((test: any) =>
                test.name.toLowerCase().includes(searchLower) ||
                test.description.toLowerCase().includes(searchLower) ||
                test.category.toLowerCase().includes(searchLower)
              );
            }
            
            if (category && typeof category === 'string') {
              filteredTests = filteredTests.filter((test: any) => test.category === category);
            }
            
            return res.json(filteredTests);
          }
        } catch (supabaseError) {
          console.log('Supabase tests fetch failed, using mock data:', supabaseError);
        }
      }
      
      // Fall back to mock data
      let filteredTests = [...mockTestsWithLabs];
      
      // Search filter
      if (search && typeof search === 'string') {
        const searchLower = search.toLowerCase();
        filteredTests = filteredTests.filter(test =>
          test.name.toLowerCase().includes(searchLower) ||
          test.description.toLowerCase().includes(searchLower) ||
          test.category.toLowerCase().includes(searchLower)
        );
      }
      
      // Category filter
      if (category && typeof category === 'string') {
        filteredTests = filteredTests.filter(test => test.category === category);
      }
      
      // If labId provided, sort by that lab's price
      if (labId && typeof labId === 'string') {
        filteredTests = filteredTests.map(test => {
          const labPricing = test.labs.find(l => l.labId === labId);
          return {
            ...test,
            selectedLabPrice: labPricing?.price || test.lowestPrice
          };
        }).sort((a, b) => (a.selectedLabPrice as number) - (b.selectedLabPrice as number));
      }
      
      res.json(filteredTests);
    } catch (error) {
      console.error("Tests fetch error:", error);
      res.status(500).json({ message: "Failed to fetch tests" });
    }
  });

  // GET /api/tests/:testId - Get single test with detailed lab pricing
  app.get('/api/tests/:testId', async (req, res) => {
    try {
      const { testId } = req.params;
      const test = mockTestsWithLabs.find(t => t.id === testId);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Get packages that include this test
      const packagesWithTest = mockPackagesWithLabs.filter(pkg => 
        packageTestMapping[pkg.id]?.includes(testId)
      ).map(pkg => ({
        id: pkg.id,
        name: pkg.name,
        testCount: pkg.testCount,
        lowestPrice: pkg.lowestPrice,
        savingsVsIndividual: Math.round((test.lowestPrice * pkg.testCount * 0.3)) // Estimate 30% savings
      }));
      
      res.json({
        ...test,
        packagesIncludingTest: packagesWithTest
      });
    } catch (error) {
      console.error("Test fetch error:", error);
      res.status(500).json({ message: "Failed to fetch test" });
    }
  });

  // GET /api/packages - List all packages with lab pricing (tries Supabase first)
  app.get('/api/packages', async (req, res) => {
    try {
      const { category, labId, sort, source } = req.query;
      
      // Try Supabase first
      if (source !== 'mock') {
        try {
          const supabaseBundles = await bundlesService.getAll();
          if (supabaseBundles && supabaseBundles.length > 0) {
            let filteredPackages = supabaseBundles.map((bundle: any) => ({
              id: bundle.id,
              name: bundle.name,
              description: bundle.description || '',
              category: bundle.category || 'General',
              testCount: bundle.tests_included || 20,
              tags: bundle.is_popular ? ['Popular'] : [],
              lowestPrice: bundle.base_price || 299,
              highestPrice: Math.round((bundle.base_price || 299) * 1.5),
              availableLabsCount: 4,
              labs: [
                { labId: "1", labName: "HealthFirst Diagnostics", price: bundle.base_price || 299, originalPrice: bundle.original_price || Math.round((bundle.base_price || 299) * 1.2), discountPercent: 17, turnaroundHours: 48, rating: 4.8, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: Math.round((bundle.base_price || 299) / (bundle.tests_included || 20)) },
                { labId: "2", labName: "MedLab Plus", price: Math.round((bundle.base_price || 299) * 1.1), originalPrice: bundle.original_price || Math.round((bundle.base_price || 299) * 1.2), discountPercent: 8, turnaroundHours: 48, rating: 4.7, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: Math.round((bundle.base_price || 299) * 1.1 / (bundle.tests_included || 20)) },
                { labId: "3", labName: "Al Borg Laboratories", price: Math.round((bundle.base_price || 299) * 1.2), originalPrice: bundle.original_price || Math.round((bundle.base_price || 299) * 1.2), discountPercent: 0, turnaroundHours: 48, rating: 4.6, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: Math.round((bundle.base_price || 299) * 1.2 / (bundle.tests_included || 20)) },
                { labId: "4", labName: "Prime Diagnostics", price: Math.round((bundle.base_price || 299) * 1.5), originalPrice: Math.round((bundle.base_price || 299) * 1.5), discountPercent: 0, turnaroundHours: 24, rating: 4.9, homeCollectionAvailable: true, homeCollectionFee: 0, pricePerTest: Math.round((bundle.base_price || 299) * 1.5 / (bundle.tests_included || 20)) }
              ],
              testsPreview: ["CBC", "Lipid Profile", "Liver Function", "Kidney Function"]
            }));
            
            // Category filter
            if (category && typeof category === 'string') {
              filteredPackages = filteredPackages.filter((pkg: any) => pkg.category === category);
            }
            
            // Sorting
            if (sort === 'price_asc') {
              filteredPackages.sort((a: any, b: any) => a.lowestPrice - b.lowestPrice);
            } else if (sort === 'price_desc') {
              filteredPackages.sort((a: any, b: any) => b.lowestPrice - a.lowestPrice);
            } else if (sort === 'tests_count') {
              filteredPackages.sort((a: any, b: any) => b.testCount - a.testCount);
            }
            
            return res.json(filteredPackages);
          }
        } catch (supabaseError) {
          console.log('Supabase bundles fetch failed, using mock data:', supabaseError);
        }
      }
      
      // Fall back to mock data
      let filteredPackages = [...mockPackagesWithLabs];
      
      // Category filter
      if (category && typeof category === 'string') {
        filteredPackages = filteredPackages.filter(pkg => pkg.category === category);
      }
      
      // Sorting
      if (sort === 'price_asc') {
        filteredPackages.sort((a, b) => a.lowestPrice - b.lowestPrice);
      } else if (sort === 'price_desc') {
        filteredPackages.sort((a, b) => b.lowestPrice - a.lowestPrice);
      } else if (sort === 'tests_count') {
        filteredPackages.sort((a, b) => b.testCount - a.testCount);
      }
      
      res.json(filteredPackages);
    } catch (error) {
      console.error("Packages fetch error:", error);
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  // GET /api/packages/:packageId - Get single package with detailed lab pricing
  app.get('/api/packages/:packageId', async (req, res) => {
    try {
      const { packageId } = req.params;
      const pkg = mockPackagesWithLabs.find(p => p.id === packageId);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      // Get tests included in this package
      const testIds = packageTestMapping[packageId] || [];
      const includedTests = mockTestsWithLabs
        .filter(t => testIds.includes(t.id))
        .map(t => ({
          id: t.id,
          name: t.name,
          category: t.category,
          lowestPrice: t.lowestPrice
        }));
      
      // Calculate individual test total
      const individualTestTotal = includedTests.reduce((sum, t) => sum + t.lowestPrice, 0);
      
      res.json({
        ...pkg,
        includedTests,
        individualTestTotal,
        savings: individualTestTotal - pkg.lowestPrice,
        savingsPercent: Math.round(((individualTestTotal - pkg.lowestPrice) / individualTestTotal) * 100)
      });
    } catch (error) {
      console.error("Package fetch error:", error);
      res.status(500).json({ message: "Failed to fetch package" });
    }
  });

  // GET /api/tests/:testId/packages - Get packages that include a specific test
  app.get('/api/tests/:testId/packages', async (req, res) => {
    try {
      const { testId } = req.params;
      const { labId } = req.query;
      
      const test = mockTestsWithLabs.find(t => t.id === testId);
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      // Find packages containing this test
      const packagesWithTest = mockPackagesWithLabs.filter(pkg => 
        packageTestMapping[pkg.id]?.includes(testId)
      ).map(pkg => {
        const labPrice = labId && typeof labId === 'string'
          ? pkg.labs.find(l => l.labId === labId)?.price || pkg.lowestPrice
          : pkg.lowestPrice;
        
        return {
          id: pkg.id,
          name: pkg.name,
          description: pkg.description,
          testCount: pkg.testCount,
          price: labPrice,
          lowestPrice: pkg.lowestPrice,
          savingsVsIndividual: test.lowestPrice - (labPrice / pkg.testCount),
          labs: pkg.labs
        };
      });
      
      res.json({
        test: {
          id: test.id,
          name: test.name,
          lowestPrice: test.lowestPrice
        },
        packages: packagesWithTest
      });
    } catch (error) {
      console.error("Test packages fetch error:", error);
      res.status(500).json({ message: "Failed to fetch packages for test" });
    }
  });

  // POST /api/cart/analyze - Smart package recommendations for cart
  app.post('/api/cart/analyze', async (req, res) => {
    try {
      const { testIds, labId } = req.body;
      
      if (!testIds || !Array.isArray(testIds) || testIds.length === 0) {
        return res.status(400).json({ message: "testIds array is required" });
      }
      
      // Get selected tests
      const selectedTests = mockTestsWithLabs.filter(t => testIds.includes(t.id));
      
      if (selectedTests.length === 0) {
        return res.status(400).json({ message: "No valid tests found" });
      }
      
      // Calculate cart total (using lowest prices or specific lab prices)
      let cartTotal = 0;
      const cartItems = selectedTests.map(test => {
        const price = labId 
          ? test.labs.find(l => l.labId === labId)?.price || test.lowestPrice
          : test.lowestPrice;
        cartTotal += price;
        return {
          testId: test.id,
          name: test.name,
          price
        };
      });
      
      // Find packages that contain ALL selected tests
      const matchingPackages = mockPackagesWithLabs.filter(pkg => {
        const pkgTestIds = packageTestMapping[pkg.id] || [];
        return testIds.every(tid => pkgTestIds.includes(tid));
      });
      
      // Calculate recommendation for each package
      const recommendations = matchingPackages.map(pkg => {
        const pkgPrice = labId
          ? pkg.labs.find(l => l.labId === labId)?.price || pkg.lowestPrice
          : pkg.lowestPrice;
        
        const pkgTestIds = packageTestMapping[pkg.id] || [];
        const extraTests = pkgTestIds.length - testIds.length;
        const priceDiff = pkgPrice - cartTotal;
        
        // Calculate strength
        let strength: 'high' | 'medium' | 'low' = 'low';
        if (priceDiff <= 0) {
          strength = 'high'; // Package is cheaper!
        } else if (priceDiff <= 50 && extraTests >= 5) {
          strength = 'high';
        } else if (priceDiff <= 100 && extraTests >= 3) {
          strength = 'medium';
        }
        
        return {
          packageId: pkg.id,
          packageName: pkg.name,
          packagePrice: pkgPrice,
          cartTestsCount: testIds.length,
          packageTestsCount: pkgTestIds.length,
          extraTests,
          priceDifference: priceDiff,
          strength,
          savingsPercent: priceDiff < 0 ? Math.round(Math.abs(priceDiff / cartTotal) * 100) : 0,
          recommendation: priceDiff <= 0 
            ? `Save AED ${Math.abs(priceDiff)} by choosing this package!`
            : priceDiff <= 50
              ? `Add AED ${priceDiff} more and get ${extraTests} extra tests!`
              : `Upgrade to get ${extraTests} additional tests`,
          testsPreview: pkg.testsPreview
        };
      }).sort((a, b) => {
        // Sort by strength then by price difference
        const strengthOrder = { high: 0, medium: 1, low: 2 };
        if (strengthOrder[a.strength] !== strengthOrder[b.strength]) {
          return strengthOrder[a.strength] - strengthOrder[b.strength];
        }
        return a.priceDifference - b.priceDifference;
      });
      
      // Best recommendation
      const bestRecommendation = recommendations.length > 0 ? recommendations[0] : null;
      
      res.json({
        cartSummary: {
          items: cartItems,
          itemCount: cartItems.length,
          total: cartTotal
        },
        recommendation: bestRecommendation,
        allRecommendations: recommendations,
        message: bestRecommendation 
          ? (bestRecommendation.strength === 'high' 
              ? "Great value package found!" 
              : "Consider upgrading to a package for better value")
          : "No package recommendations for your selection"
      });
    } catch (error) {
      console.error("Cart analyze error:", error);
      res.status(500).json({ message: "Failed to analyze cart" });
    }
  });

  // GET /api/labs - Get all labs with their details
  app.get('/api/labs', async (req, res) => {
    try {
      const mockLabs = [
        {
          id: "1",
          name: "HealthFirst Diagnostics",
          slug: "healthfirst",
          location: "Dubai Marina",
          emirate: "Dubai",
          rating: 4.8,
          totalReviews: 1250,
          homeCollectionAvailable: true,
          homeCollectionFee: 0,
          avgTurnaroundHours: 24,
          status: "active"
        },
        {
          id: "2",
          name: "MedLab Plus",
          slug: "medlab-plus",
          location: "Downtown Dubai",
          emirate: "Dubai",
          rating: 4.7,
          totalReviews: 890,
          homeCollectionAvailable: true,
          homeCollectionFee: 0,
          avgTurnaroundHours: 24,
          status: "active"
        },
        {
          id: "3",
          name: "Al Borg Laboratories",
          slug: "al-borg",
          location: "Deira",
          emirate: "Dubai",
          rating: 4.6,
          totalReviews: 2100,
          homeCollectionAvailable: true,
          homeCollectionFee: 0,
          avgTurnaroundHours: 24,
          status: "active"
        },
        {
          id: "4",
          name: "Prime Diagnostics",
          slug: "prime",
          location: "JLT",
          emirate: "Dubai",
          rating: 4.9,
          totalReviews: 650,
          homeCollectionAvailable: true,
          homeCollectionFee: 0,
          avgTurnaroundHours: 12,
          status: "active"
        }
      ];
      
      res.json(mockLabs);
    } catch (error) {
      console.error("Labs fetch error:", error);
      res.status(500).json({ message: "Failed to fetch labs" });
    }
  });

  // --- Email Notifications ---
  app.post('/api/send-booking-confirmation', async (req, res) => {
    try {
      const { recipientEmail, recipientName, appointmentDetails } = req.body;
      
      const success = await EmailService.sendBookingConfirmation(
        recipientEmail,
        recipientName,
        appointmentDetails
      );
      
      res.json({ success });
    } catch (error) {
      console.error("Email send error:", error);
      res.status(500).json({ message: "Failed to send email" });
    }
  });

  // --- Bundles (Public API - tries Supabase first) ---
  app.get('/api/bundles', async (req, res) => {
    try {
      // Try Supabase first
      try {
        const supabaseBundles = await bundlesService.getAll();
        if (supabaseBundles && supabaseBundles.length > 0) {
          // Transform to match expected format
          const formattedBundles = supabaseBundles.map((bundle: any) => ({
            id: bundle.id,
            name: bundle.name,
            description: bundle.description || '',
            shortDescription: bundle.description?.substring(0, 100) || '',
            basePrice: bundle.base_price?.toString() || '299',
            category: bundle.category || 'General',
            icon: 'Activity',
            color: 'blue',
            isPopular: bundle.is_popular || false,
            testsIncluded: bundle.tests_included || 20,
            turnaroundHours: bundle.turnaround_hours || '24-48',
            fastingRequired: bundle.fasting_required || false,
            homeCollection: bundle.home_collection !== false,
          }));
          return res.json(formattedBundles);
        }
      } catch (supabaseError) {
        console.log('Supabase bundles fetch failed, using storage:', supabaseError);
      }
      
      // Fall back to storage
      const bundlesList = await storage.getBundles();
      res.json(bundlesList);
    } catch (error) {
      console.error("Bundles fetch error:", error);
      res.status(500).json({ message: "Failed to fetch bundles" });
    }
  });

  app.get(api.bundles.list.path, async (req, res) => {
    try {
      const bundlesList = await storage.getBundles();
      res.json(bundlesList);
    } catch (error) {
      console.error("Bundles fetch error:", error);
      res.status(500).json({ message: "Failed to fetch bundles" });
    }
  });

  app.get(api.bundles.get.path, async (req, res) => {
    const bundle = await storage.getBundle(req.params.id);
    if (!bundle) return res.status(404).json({ message: "Bundle not found" });
    res.json(bundle);
  });

  // --- AI Chat Endpoint ---
  app.post('/api/ai/chat', async (req, res) => {
    try {
      console.log("📥 AI Chat request received");
      
      const { sessionId, message, history } = req.body;
      
      // Validate input
      if (!sessionId || !message) {
        console.error("❌ Missing required fields");
        return res.status(400).json({ 
          error: "Session ID and message are required" 
        });
      }

      console.log(`📝 Session: ${sessionId}, Message length: ${message.length}`);

      // Call AI service
      const response = await sendAIMessage(sessionId, message, history || []);
      
      console.log(`✅ AI response ready (${response.length} chars)`);
      
      // Return successful response
      return res.status(200).json({ response });
      
    } catch (error: any) {
      console.error("❌ AI Chat error:", error.message);
      
      // Return fallback response
      return res.status(200).json({ 
        response: "Thank you for your message! I'm here to help you find the right lab tests. Could you tell me more about what brings you here today?"
      });
    }
  });

  app.get(api.ai.questions.path, async (req, res) => {
    try {
      const questions = await storage.getAiQuestions();
      res.json(questions);
    } catch (error) {
      console.log("Using mock questions");
      res.json([
        {
          id: "1",
          questionKey: "health_goal",
          questionText: "What brings you here today?",
          questionType: "single",
          options: JSON.stringify(["Routine checkup", "Feeling fatigued", "Monitoring a condition", "Weight management", "Other"]),
          sortOrder: 1
        }
      ]);
    }
  });

  app.post(api.ai.recommend.path, async (req, res) => {
    try {
      const { context } = req.body;
      
      // Get AI recommendations
      const recommendations = await getAIRecommendations(context || "");
      
      return res.status(200).json({ recommendations });
    } catch (error: any) {
      console.error("AI Recommendation error:", error);
      return res.status(200).json({ 
        recommendations: [
          {
            id: "1",
            name: "Full Body Checkup",
            reason: "Comprehensive health screening",
            price: "699"
          }
        ]
      });
    }
  });

  // --- Appointments ---
  app.post(api.appointments.create.path, async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.appointments.create.input.parse(req.body);
      const appt = await storage.createAppointment({
        ...input,
        userId: req.session.userId
      });
      res.status(201).json(appt);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // --- User Bookings (Public API for logged-in users) ---
  
  // Create a booking (no auth required - guest booking supported)
  app.post('/api/bookings', async (req, res) => {
    try {
      const { bundleId, labId, collectionType, date, time, patientName, patientPhone, patientEmail, address } = req.body;
      
      // Generate booking reference
      const bookingRef = `MC-${Date.now().toString(36).toUpperCase()}`;
      
      // Store in mock bookings (in production, save to database)
      const booking = {
        id: bookingRef,
        bundleId,
        labId,
        collectionType,
        date,
        time,
        patientName,
        patientPhone,
        patientEmail,
        address: address || null,
        status: 'confirmed',
        userId: req.session?.userId || null,
        createdAt: new Date().toISOString()
      };
      
      // Store booking in session for demo (in production, save to database)
      if (!req.session.bookings) {
        req.session.bookings = [];
      }
      req.session.bookings.push(booking);
      
      res.status(201).json({ 
        success: true, 
        booking,
        message: "Booking confirmed successfully" 
      });
    } catch (error) {
      console.error("Booking error:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Reset all bookings (Admin only)
  app.post('/api/bookings/reset', async (req, res) => {
    try {
      // Clear session bookings
      if (req.session) {
        req.session.bookings = [];
      }
      res.json({ success: true, message: "All booking data has been reset" });
    } catch (error) {
      console.error("Reset bookings error:", error);
      res.status(500).json({ message: "Failed to reset bookings" });
    }
  });

  // Get user's booking history
  app.get('/api/bookings', async (req, res) => {
    try {
      // Return bookings from session (in production, query from database)
      const bookings = req.session?.bookings || [];
      res.json(bookings);
    } catch (error) {
      console.error("Get bookings error:", error);
      res.status(500).json({ message: "Failed to get bookings" });
    }
  });

  // Get single booking by reference
  app.get('/api/bookings/:ref', async (req, res) => {
    try {
      const { ref } = req.params;
      const bookings = req.session?.bookings || [];
      const booking = bookings.find((b: any) => b.id === ref);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      console.error("Get booking error:", error);
      res.status(500).json({ message: "Failed to get booking" });
    }
  });

  // --- Database Reset and Seed Endpoint ---
  app.post('/api/admin/reset-database', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    
    try {
      const { resetAndSeedDatabase } = await import("./seed");
      await resetAndSeedDatabase();
      res.json({ message: "Database reset and seeded successfully" });
    } catch (err) {
      console.error("Database reset error:", err);
      res.status(500).json({ message: "Failed to reset database", error: String(err) });
    }
  });

  // --- Admin API Routes ---
  
  // Admin auth middleware helper
  const requireAdmin = async (req: any, res: any): Promise<boolean> => {
    if (!req.session?.userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return false;
    }
    const user = await storage.getUser(req.session.userId);
    if (!user || user.role !== 'admin') {
      res.status(403).json({ message: 'Admin access required' });
      return false;
    }
    return true;
  };
  
  // Bookings
  app.get('/api/admin/bookings', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allAppointments = await db.select().from(appointments);
    res.json(allAppointments);
  });

  app.patch('/api/admin/bookings/:id/status', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { status } = req.body;
    if (!status || !['pending', 'confirmed', 'collected', 'completed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    await db.update(appointments).set({ status }).where(eq(appointments.id, id));
    res.json({ success: true });
  });

  // Tests
  app.get('/api/admin/tests', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allTests = await db.select().from(tests);
    res.json(allTests);
  });

  app.post('/api/admin/tests', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { name, description, category, preparation, turnaroundHours, isActive } = req.body;
    if (!name) return res.status(400).json({ message: 'Name is required' });
    const [newTest] = await db.insert(tests).values({ name, description, category, preparation, turnaroundHours, isActive }).returning();
    res.status(201).json(newTest);
  });

  app.patch('/api/admin/tests/:id', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { name, description, category, preparation, turnaroundHours, isActive } = req.body;
    const [updated] = await db.update(tests).set({ name, description, category, preparation, turnaroundHours, isActive }).where(eq(tests.id, id)).returning();
    res.json(updated);
  });

  // Bundles (admin)
  app.post('/api/admin/bundles', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { name, description, basePrice, category, isActive, isPopular } = req.body;
    if (!name || !basePrice) return res.status(400).json({ message: 'Name and base price are required' });
    const slug = name.toLowerCase().replace(/\s+/g, '-');
    const [newBundle] = await db.insert(bundles).values({ name, description, basePrice, category, isActive, isPopular, slug }).returning();
    res.status(201).json(newBundle);
  });

  app.patch('/api/admin/bundles/:id', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { name, description, basePrice, category, isActive, isPopular } = req.body;
    const [updated] = await db.update(bundles).set({ name, description, basePrice, category, isActive, isPopular }).where(eq(bundles.id, id)).returning();
    res.json(updated);
  });

  // Labs
  app.get('/api/admin/labs', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allLabs = await db.select().from(partnerLabs);
    res.json(allLabs);
  });

  app.post('/api/admin/labs', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { name, description, emirate, status, avgConfirmationHours } = req.body;
    if (!name) return res.status(400).json({ message: 'Name is required' });
    const slug = name.toLowerCase().replace(/\s+/g, '-');
    const [newLab] = await db.insert(partnerLabs).values({ name, description, emirate, status, avgConfirmationHours, slug }).returning();
    res.status(201).json(newLab);
  });

  app.patch('/api/admin/labs/:id', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { name, description, emirate, status, avgConfirmationHours } = req.body;
    const [updated] = await db.update(partnerLabs).set({ name, description, emirate, status, avgConfirmationHours }).where(eq(partnerLabs.id, id)).returning();
    res.json(updated);
  });

  // Users
  app.get('/api/admin/users', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allUsers = await db.select().from(users);
    res.json(allUsers.map(u => ({ ...u, password: '***' })));
  });

  app.post('/api/admin/users', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { name, username, password, role } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'Username and password are required' });
    const [newUser] = await db.insert(users).values({ name, username, password, role }).returning();
    res.status(201).json({ ...newUser, password: '***' });
  });

  app.patch('/api/admin/users/:id', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { name, role } = req.body;
    const [updated] = await db.update(users).set({ name, role }).where(eq(users.id, id)).returning();
    res.json({ ...updated, password: '***' });
  });

  // AI Rule Sets
  app.get('/api/admin/ai-rule-sets', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allRuleSets = await db.select().from(aiRuleSets);
    res.json(allRuleSets);
  });

  app.post('/api/admin/ai-rule-sets', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { name, maxBundles, disclaimerText, isActive } = req.body;
    if (!name) return res.status(400).json({ message: 'Name is required' });
    const [newRuleSet] = await db.insert(aiRuleSets).values({ name, maxBundles, disclaimerText, isActive }).returning();
    res.status(201).json(newRuleSet);
  });

  app.patch('/api/admin/ai-rule-sets/:id', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const { id } = req.params;
    const { name, maxBundles, disclaimerText, isActive } = req.body;
    const [updated] = await db.update(aiRuleSets).set({ name, maxBundles, disclaimerText, isActive }).where(eq(aiRuleSets.id, id)).returning();
    res.json(updated);
  });

  // AI Mapping Rules
  app.get('/api/admin/ai-mapping-rules', async (req, res) => {
    if (!await requireAdmin(req, res)) return;
    const allMappingRules = await db.select().from(aiMappingRules);
    res.json(allMappingRules);
  });

  // --- Lab Portal API Routes ---
  
  // Lab auth middleware helper
  const requireLabAdmin = async (req: any, res: any): Promise<boolean> => {
    if (!req.session?.userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return false;
    }
    const user = await storage.getUser(req.session.userId);
    if (!user || user.role !== 'lab_admin') {
      res.status(403).json({ message: 'Lab admin access required' });
      return false;
    }
    return true;
  };

  // Lab Bookings
  app.get('/api/lab/bookings', async (req, res) => {
    if (!await requireLabAdmin(req, res)) return;
    const allAppointments = await db.select().from(appointments);
    res.json(allAppointments);
  });

  app.patch('/api/lab/bookings/:id/status', async (req, res) => {
    if (!await requireLabAdmin(req, res)) return;
    const { id } = req.params;
    const { status } = req.body;
    if (!status || !['pending', 'confirmed', 'collected', 'completed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    await db.update(appointments).set({ status }).where(eq(appointments.id, id));
    res.json({ success: true });
  });

  // ==================== SUPABASE DATABASE ROUTES ====================
  // These routes use Supabase for persistent storage
  
  const { bookingsService, usersService, labsService, testsService, bundlesService, categoriesService, guestProfilesService, userAddressesService } = await import('./db-service');
  const { initializeDatabase, CREATE_TABLES_SQL } = await import('./supabase');
  
  // Initialize Supabase on startup
  initializeDatabase().catch(err => console.error('Supabase init failed:', err));

  // --- Supabase Bookings ---
  app.get('/api/supabase/bookings', async (req, res) => {
    try {
      const bookings = await bookingsService.getAll();
      res.json(bookings || []);
    } catch (error: any) {
      console.error('Get bookings error:', error);
      res.status(500).json({ message: error.message || 'Failed to get bookings' });
    }
  });

  app.post('/api/supabase/bookings', async (req, res) => {
    try {
      const booking = await bookingsService.create(req.body);
      res.status(201).json(booking);
    } catch (error: any) {
      console.error('Create booking error:', error);
      res.status(500).json({ message: error.message || 'Failed to create booking' });
    }
  });

  app.patch('/api/supabase/bookings/:id/status', async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const booking = await bookingsService.updateStatus(id, status);
      res.json(booking);
    } catch (error: any) {
      console.error('Update booking status error:', error);
      res.status(500).json({ message: error.message || 'Failed to update booking' });
    }
  });

  app.delete('/api/supabase/bookings/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await bookingsService.delete(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete booking error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete booking' });
    }
  });

  app.post('/api/supabase/bookings/reset', async (req, res) => {
    try {
      await bookingsService.deleteAll();
      res.json({ success: true, message: 'All bookings have been reset' });
    } catch (error: any) {
      console.error('Reset bookings error:', error);
      res.status(500).json({ message: error.message || 'Failed to reset bookings' });
    }
  });

  app.get('/api/supabase/bookings/stats', async (req, res) => {
    try {
      const stats = await bookingsService.getStats();
      res.json(stats);
    } catch (error: any) {
      console.error('Get booking stats error:', error);
      res.status(500).json({ message: error.message || 'Failed to get stats' });
    }
  });

  // --- Supabase Users ---
  app.get('/api/supabase/users', async (req, res) => {
    try {
      const allUsers = await usersService.getAll();
      res.json(allUsers || []);
    } catch (error: any) {
      console.error('Get users error:', error);
      res.status(500).json({ message: error.message || 'Failed to get users' });
    }
  });

  app.post('/api/supabase/users', async (req, res) => {
    try {
      const user = await usersService.create(req.body);
      res.status(201).json(user);
    } catch (error: any) {
      console.error('Create user error:', error);
      res.status(500).json({ message: error.message || 'Failed to create user' });
    }
  });

  app.get('/api/supabase/users/count', async (req, res) => {
    try {
      const count = await usersService.getCount();
      res.json({ count });
    } catch (error: any) {
      res.json({ count: 0 });
    }
  });

  // --- Supabase Labs ---
  app.get('/api/supabase/labs', async (req, res) => {
    try {
      const labs = await labsService.getAll();
      res.json(labs || []);
    } catch (error: any) {
      console.error('Get labs error:', error);
      res.status(500).json({ message: error.message || 'Failed to get labs' });
    }
  });

  app.post('/api/supabase/labs', async (req, res) => {
    try {
      const lab = await labsService.create(req.body);
      res.status(201).json(lab);
    } catch (error: any) {
      console.error('Create lab error:', error);
      res.status(500).json({ message: error.message || 'Failed to create lab' });
    }
  });

  app.put('/api/supabase/labs/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const lab = await labsService.update(id, req.body);
      res.json(lab);
    } catch (error: any) {
      console.error('Update lab error:', error);
      res.status(500).json({ message: error.message || 'Failed to update lab' });
    }
  });

  // --- Supabase Tests ---
  app.get('/api/supabase/tests', async (req, res) => {
    try {
      const allTests = await testsService.getAll();
      res.json(allTests || []);
    } catch (error: any) {
      console.error('Get tests error:', error);
      res.status(500).json({ message: error.message || 'Failed to get tests' });
    }
  });

  app.post('/api/supabase/tests', async (req, res) => {
    try {
      const test = await testsService.create(req.body);
      res.status(201).json(test);
    } catch (error: any) {
      console.error('Create test error:', error);
      res.status(500).json({ message: error.message || 'Failed to create test' });
    }
  });

  app.put('/api/supabase/tests/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const test = await testsService.update(id, req.body);
      res.json(test);
    } catch (error: any) {
      console.error('Update test error:', error);
      res.status(500).json({ message: error.message || 'Failed to update test' });
    }
  });

  app.delete('/api/supabase/tests/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await testsService.delete(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete test error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete test' });
    }
  });

  // --- Supabase Bundles ---
  app.get('/api/supabase/bundles', async (req, res) => {
    try {
      const allBundles = await bundlesService.getAll();
      res.json(allBundles || []);
    } catch (error: any) {
      console.error('Get bundles error:', error);
      res.status(500).json({ message: error.message || 'Failed to get bundles' });
    }
  });

  app.post('/api/supabase/bundles', async (req, res) => {
    try {
      const bundle = await bundlesService.create(req.body);
      res.status(201).json(bundle);
    } catch (error: any) {
      console.error('Create bundle error:', error);
      res.status(500).json({ message: error.message || 'Failed to create bundle' });
    }
  });

  app.put('/api/supabase/bundles/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const bundle = await bundlesService.update(id, req.body);
      res.json(bundle);
    } catch (error: any) {
      console.error('Update bundle error:', error);
      res.status(500).json({ message: error.message || 'Failed to update bundle' });
    }
  });

  app.delete('/api/supabase/bundles/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await bundlesService.delete(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete bundle error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete bundle' });
    }
  });

  // --- Supabase Categories ---
  app.get('/api/supabase/categories/tests', async (req, res) => {
    try {
      const categories = await categoriesService.getTestCategories();
      res.json(categories || []);
    } catch (error: any) {
      console.error('Get test categories error:', error);
      res.status(500).json({ message: error.message || 'Failed to get categories' });
    }
  });

  app.get('/api/supabase/categories/bundles', async (req, res) => {
    try {
      const categories = await categoriesService.getBundleCategories();
      res.json(categories || []);
    } catch (error: any) {
      console.error('Get bundle categories error:', error);
      res.status(500).json({ message: error.message || 'Failed to get categories' });
    }
  });

  app.post('/api/supabase/categories/tests', async (req, res) => {
    try {
      const category = await categoriesService.createTestCategory(req.body);
      res.status(201).json(category);
    } catch (error: any) {
      console.error('Create test category error:', error);
      res.status(500).json({ message: error.message || 'Failed to create category' });
    }
  });

  app.post('/api/supabase/categories/bundles', async (req, res) => {
    try {
      const category = await categoriesService.createBundleCategory(req.body);
      res.status(201).json(category);
    } catch (error: any) {
      console.error('Create bundle category error:', error);
      res.status(500).json({ message: error.message || 'Failed to create category' });
    }
  });

  app.put('/api/supabase/categories/tests/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const category = await categoriesService.updateTestCategory(id, req.body);
      res.json(category);
    } catch (error: any) {
      console.error('Update test category error:', error);
      res.status(500).json({ message: error.message || 'Failed to update category' });
    }
  });

  app.put('/api/supabase/categories/bundles/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const category = await categoriesService.updateBundleCategory(id, req.body);
      res.json(category);
    } catch (error: any) {
      console.error('Update bundle category error:', error);
      res.status(500).json({ message: error.message || 'Failed to update category' });
    }
  });

  app.delete('/api/supabase/categories/tests/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await categoriesService.deleteTestCategory(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete test category error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete category' });
    }
  });

  app.delete('/api/supabase/categories/bundles/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await categoriesService.deleteBundleCategory(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete bundle category error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete category' });
    }
  });

  // --- Get SQL for table creation ---
  app.get('/api/supabase/init-sql', async (req, res) => {
    res.json({ sql: CREATE_TABLES_SQL });
  });

  // --- Guest Profiles (for saving guest user addresses) ---
  app.get('/api/supabase/guest-profile', async (req, res) => {
    try {
      const { session_id, device_id, email } = req.query;
      let profile = null;
      
      if (session_id) {
        profile = await guestProfilesService.getBySessionId(session_id as string);
      }
      if (!profile && device_id) {
        profile = await guestProfilesService.getByDeviceId(device_id as string);
      }
      if (!profile && email) {
        profile = await guestProfilesService.getByEmail(email as string);
      }
      
      res.json(profile || null);
    } catch (error: any) {
      console.error('Get guest profile error:', error);
      res.status(500).json({ message: error.message || 'Failed to get guest profile' });
    }
  });

  app.post('/api/supabase/guest-profile', async (req, res) => {
    try {
      const profile = await guestProfilesService.upsert(req.body);
      res.status(201).json(profile);
    } catch (error: any) {
      console.error('Save guest profile error:', error);
      res.status(500).json({ message: error.message || 'Failed to save guest profile' });
    }
  });

  app.put('/api/supabase/guest-profile/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await guestProfilesService.update(id, req.body);
      res.json(profile);
    } catch (error: any) {
      console.error('Update guest profile error:', error);
      res.status(500).json({ message: error.message || 'Failed to update guest profile' });
    }
  });

  // --- Update user address (for logged-in users) ---
  app.put('/api/supabase/users/:id/address', async (req, res) => {
    try {
      const { id } = req.params;
      const { address, city, area, building, flat_number, landmark, phone } = req.body;
      const user = await usersService.update(id, { 
        address, city, area, building, flat_number, landmark, phone 
      });
      res.json(user);
    } catch (error: any) {
      console.error('Update user address error:', error);
      res.status(500).json({ message: error.message || 'Failed to update address' });
    }
  });

  // --- Sync Firebase user to Supabase ---
  app.post('/api/supabase/users/sync', async (req, res) => {
    try {
      const { email, name, phone, role, firebase_uid } = req.body;
      
      // Check if user exists
      let user = await usersService.getByEmail(email);
      
      if (user) {
        // Update existing user with Firebase UID
        user = await usersService.update(user.id, { 
          name: name || user.name,
          firebase_uid 
        });
      } else {
        // Create new user
        user = await usersService.create({
          email,
          name,
          phone,
          role: role || 'user',
        });
      }
      
      res.json(user);
    } catch (error: any) {
      console.error('Sync user error:', error);
      res.status(500).json({ message: error.message || 'Failed to sync user' });
    }
  });

  // --- Get user by email ---
  app.get('/api/supabase/users/email/:email', async (req, res) => {
    try {
      const { email } = req.params;
      const user = await usersService.getByEmail(email);
      res.json(user || null);
    } catch (error: any) {
      console.error('Get user by email error:', error);
      res.status(500).json({ message: error.message || 'Failed to get user' });
    }
  });

  // --- User Addresses (Multiple addresses per user) ---
  
  app.get('/api/supabase/users/:userId/addresses', async (req, res) => {
    try {
      const { userId } = req.params;
      const addresses = await userAddressesService.getByUserId(userId);
      res.json(addresses || []);
    } catch (error: any) {
      console.error('Get user addresses error:', error);
      res.status(500).json({ message: error.message || 'Failed to get addresses' });
    }
  });

  app.post('/api/supabase/users/:userId/addresses', async (req, res) => {
    try {
      const { userId } = req.params;
      const address = await userAddressesService.create({ ...req.body, user_id: userId });
      res.status(201).json(address);
    } catch (error: any) {
      console.error('Create address error:', error);
      res.status(500).json({ message: error.message || 'Failed to create address' });
    }
  });

  app.put('/api/supabase/addresses/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const address = await userAddressesService.update(id, req.body);
      res.json(address);
    } catch (error: any) {
      console.error('Update address error:', error);
      res.status(500).json({ message: error.message || 'Failed to update address' });
    }
  });

  app.delete('/api/supabase/addresses/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await userAddressesService.delete(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Delete address error:', error);
      res.status(500).json({ message: error.message || 'Failed to delete address' });
    }
  });

  app.put('/api/supabase/addresses/:id/default', async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      const address = await userAddressesService.setDefault(id, userId);
      res.json(address);
    } catch (error: any) {
      console.error('Set default address error:', error);
      res.status(500).json({ message: error.message || 'Failed to set default address' });
    }
  });

  return httpServer;
}
