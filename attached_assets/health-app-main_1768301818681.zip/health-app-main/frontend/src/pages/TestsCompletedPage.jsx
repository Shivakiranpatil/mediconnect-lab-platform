import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, CheckCircle, Calendar, FileText, Activity, User,
  ChevronDown, ChevronUp, Download
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { healthService } from '@/config/supabase';

const TestsCompletedPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [testsData, setTestsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expandedCategories, setExpandedCategories] = useState(['Blood', 'Heart']);

  useEffect(() => {
    fetchTestsCompleted();
  }, [user]);

  const fetchTestsCompleted = async () => {
    try {
      if (user?.id) {
        const biomarkers = await healthService.getBiomarkers(user.id);
        setTestsData(biomarkers);
      }
    } catch (error) {
      console.error('Failed to fetch tests:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleCategory = (category) => {
    setExpandedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const getStatusColor = (status) => {
    const colors = {
      'Excellent': 'text-emerald-600 bg-emerald-50',
      'Optimal': 'text-emerald-600 bg-emerald-50',
      'Normal': 'text-cyan-600 bg-cyan-50',
      'Slightly Low': 'text-amber-600 bg-amber-50',
      'Slightly High': 'text-amber-600 bg-amber-50',
      'Low': 'text-rose-600 bg-rose-50',
      'High': 'text-rose-600 bg-rose-50'
    };
    return colors[status] || 'text-slate-600 bg-slate-50';
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Blood': '🩸',
      'Heart': '❤️',
      'Vitamins': '☀️',
      'Metabolic': '⚡'
    };
    return icons[category] || '📋';
  };

  if (loading) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-slate-500">Loading tests...</p>
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-100">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Tests Completed</h1>
            <p className="text-sm text-slate-500">{testsData?.total_tests || 0} parameters tested</p>
          </div>
        </div>
      </div>

      {/* Summary Card */}
      <div className="px-6 py-4">
        <div className="health-card p-4 bg-gradient-to-br from-teal-600 to-teal-700 text-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white/70 text-sm">Total Tests</p>
              <p className="text-4xl font-bold">{testsData?.total_tests || 0}</p>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center">
              <CheckCircle className="w-7 h-7 text-white" />
            </div>
          </div>
          <p className="text-white/80 text-sm">
            Last test: {testsData?.reports?.[0]?.test_date || 'No tests yet'}
          </p>
        </div>
      </div>

      {/* Tests by Category */}
      <div className="px-6 space-y-3">
        {testsData?.tests_by_category && Object.entries(testsData.tests_by_category).map(([category, tests]) => (
          <div key={category} className="health-card overflow-hidden" data-testid={`category-${category.toLowerCase()}`}>
            {/* Category Header */}
            <button
              onClick={() => toggleCategory(category)}
              className="w-full p-4 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{getCategoryIcon(category)}</span>
                <div className="text-left">
                  <h3 className="font-semibold text-slate-900">{category}</h3>
                  <p className="text-slate-500 text-sm">{tests.length} tests</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 bg-emerald-50 text-emerald-600 text-xs font-medium rounded-full">
                  Done
                </span>
                {expandedCategories.includes(category) ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </button>

            {/* Expanded Tests */}
            {expandedCategories.includes(category) && (
              <div className="px-4 pb-4 border-t border-slate-100 space-y-2 pt-3">
                {tests.map((test, index) => (
                  <div key={index} className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-500" />
                        <span className="font-medium text-slate-900 text-sm">{test.name}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(test.status)}`}>
                        {test.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm pl-6">
                      <span className="text-slate-600">Result: <strong>{test.value} {test.unit}</strong></span>
                      <span className="text-slate-400 text-xs">{test.reference_range}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Recent Reports */}
      <div className="px-6 py-4">
        <h2 className="font-semibold text-slate-900 mb-3">Recent Reports</h2>
        <div className="space-y-3">
          {testsData?.reports?.slice(0, 3).map((report) => (
            <div key={report.id} className="health-card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-violet-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-sm">{report.test_name}</h3>
                    <p className="text-slate-500 text-xs">{report.test_date}</p>
                  </div>
                </div>
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <Download className="w-5 h-5 text-slate-400" />
                </button>
              </div>
              <p className="text-slate-600 text-sm">{report.biomarkers?.length || 0} parameters tested</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="bottom-nav h-20 flex items-center justify-around">
        <NavItem icon={Activity} label="Home" onClick={() => navigate('/home')} />
        <NavItem icon={FileText} label="Reports" onClick={() => navigate('/reports')} />
        <NavItem icon={Calendar} label="Schedule" onClick={() => navigate('/schedule')} />
        <NavItem icon={User} label="Profile" onClick={() => navigate('/profile')} />
      </div>
    </div>
  );
};

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button 
    data-testid={`nav-${label.toLowerCase()}`}
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 p-2 min-w-[60px] ${
      active ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
    } transition-colors`}
  >
    <Icon className="w-5 h-5" strokeWidth={active ? 2 : 1.5} />
    <span className="text-xs font-medium">{label}</span>
  </button>
);

export default TestsCompletedPage;
