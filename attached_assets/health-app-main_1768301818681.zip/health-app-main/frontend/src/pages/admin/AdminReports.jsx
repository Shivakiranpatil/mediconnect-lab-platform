import React, { useState, useEffect } from 'react';
import { 
  Users, TrendingUp, Calendar, Activity, 
  ArrowUp, FileText, Building2, RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { adminService } from '@/config/supabase';

const AdminReports = () => {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const data = await adminService.getAnalytics();
      setAnalytics(data);
    } catch (error) {
      console.error('Analytics error:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Reports & Analytics</h1>
          <p className="text-slate-400 mt-1">Overview of platform metrics</p>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          label="Total Users"
          value={analytics?.total_users || 0}
          subtext="Registered users"
          icon={Users}
          color="from-blue-500 to-cyan-500"
        />
        <MetricCard
          label="Appointments"
          value={analytics?.total_appointments || 0}
          subtext="Total booked"
          icon={Calendar}
          color="from-green-500 to-emerald-500"
        />
        <MetricCard
          label="Reports"
          value={analytics?.total_reports || 0}
          subtext="Completed reports"
          icon={FileText}
          color="from-purple-500 to-pink-500"
        />
        <MetricCard
          label="Partner Labs"
          value={analytics?.total_labs || 0}
          subtext="Active partners"
          icon={Building2}
          color="from-orange-500 to-amber-500"
        />
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Platform Overview */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">Platform Overview</h3>
          <div className="space-y-4">
            <StatRow label="Total Users" value={analytics?.total_users || 0} />
            <StatRow label="Total Appointments" value={analytics?.total_appointments || 0} />
            <StatRow label="Total Reports" value={analytics?.total_reports || 0} />
            <StatRow label="Partner Labs" value={analytics?.total_labs || 0} />
          </div>
        </div>

        {/* System Status */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">System Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Database</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Supabase Connected
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Authentication</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Firebase Active
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">API Status</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Operational
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Last Updated</span>
              <span className="text-slate-300 text-sm">
                {new Date().toLocaleTimeString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-white font-semibold mb-2">Analytics Note</h3>
        <p className="text-slate-400 text-sm">
          Advanced analytics features like user growth trends, revenue tracking, and subscription distribution 
          will be available once more data is collected. Current metrics are pulled directly from Supabase.
        </p>
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, subtext, icon: Icon, color }) => (
  <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-slate-400 text-sm">{label}</p>
        <p className="text-2xl font-bold text-white mt-1">{value}</p>
        <div className="flex items-center gap-1 mt-2">
          <ArrowUp className="w-4 h-4 text-green-400" />
          <span className="text-xs text-green-400">{subtext}</span>
        </div>
      </div>
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
    </div>
  </div>
);

const StatRow = ({ label, value }) => (
  <div className="flex items-center justify-between">
    <span className="text-slate-400">{label}</span>
    <span className="text-white font-medium">{value}</span>
  </div>
);

export default AdminReports;
