import React from 'react';
import { TestTube, Info } from 'lucide-react';

const AdminTests = () => {
  // Default test types - these would typically come from the database
  const testTypes = [
    {
      name: 'Complete Blood Count (CBC)',
      category: 'Blood',
      biomarkers: ['Hemoglobin', 'WBC Count', 'Platelet Count', 'RBC Count'],
      description: 'Comprehensive blood panel for overall health assessment'
    },
    {
      name: 'Lipid Profile',
      category: 'Heart',
      biomarkers: ['Total Cholesterol', 'HDL', 'LDL', 'Triglycerides'],
      description: 'Heart health and cholesterol levels'
    },
    {
      name: 'Liver Function Test',
      category: 'Liver',
      biomarkers: ['ALT', 'AST', 'Bilirubin', 'Albumin'],
      description: 'Assess liver health and function'
    },
    {
      name: 'Kidney Function Test',
      category: 'Kidney',
      biomarkers: ['Creatinine', 'BUN', 'eGFR', 'Uric Acid'],
      description: 'Monitor kidney health and function'
    },
    {
      name: 'Thyroid Panel',
      category: 'Hormones',
      biomarkers: ['TSH', 'T3', 'T4', 'Free T4'],
      description: 'Thyroid function assessment'
    },
    {
      name: 'Vitamin Panel',
      category: 'Vitamins',
      biomarkers: ['Vitamin D', 'Vitamin B12', 'Iron', 'Ferritin'],
      description: 'Essential vitamin and mineral levels'
    },
    {
      name: 'Diabetes Panel',
      category: 'Metabolic',
      biomarkers: ['Fasting Glucose', 'HbA1c', 'Insulin'],
      description: 'Blood sugar and diabetes risk assessment'
    }
  ];

  const categoryColors = {
    'Blood': 'from-red-500 to-rose-500',
    'Heart': 'from-pink-500 to-red-500',
    'Liver': 'from-amber-500 to-orange-500',
    'Kidney': 'from-purple-500 to-violet-500',
    'Hormones': 'from-blue-500 to-indigo-500',
    'Vitamins': 'from-green-500 to-emerald-500',
    'Metabolic': 'from-teal-500 to-cyan-500'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Test Types</h1>
        <p className="text-slate-400 mt-1">Available health test categories and biomarkers</p>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
        <p className="text-blue-400 text-sm">
          These are the standard test types available in the platform. Lab partners can upload reports with these biomarkers.
        </p>
      </div>

      {/* Tests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {testTypes.map((test, idx) => (
          <div 
            key={idx} 
            className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden"
          >
            {/* Test Header */}
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-white">{test.name}</h3>
                  <p className="text-slate-400 text-sm mt-1">{test.description}</p>
                </div>
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${categoryColors[test.category] || 'from-slate-500 to-slate-600'} flex items-center justify-center`}>
                  <TestTube className="w-5 h-5 text-white" />
                </div>
              </div>
              
              <div className="mt-3">
                <span className="px-2 py-1 bg-slate-700 text-slate-300 rounded text-xs">
                  {test.category}
                </span>
              </div>
            </div>

            {/* Biomarkers */}
            <div className="p-6">
              <p className="text-slate-400 text-sm mb-3">Biomarkers included:</p>
              <div className="flex flex-wrap gap-2">
                {test.biomarkers.map((biomarker, bidx) => (
                  <span 
                    key={bidx}
                    className="px-2 py-1 bg-slate-700/50 text-slate-300 rounded-lg text-sm"
                  >
                    {biomarker}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Info Box */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-white font-semibold mb-2">Adding Custom Tests</h3>
        <p className="text-slate-400 text-sm">
          To add custom test types or biomarkers, create a <code className="bg-slate-700 px-1 rounded">test_types</code> table 
          in Supabase and update this page to fetch from the database.
        </p>
      </div>
    </div>
  );
};

export default AdminTests;
