import React, { useState, useEffect } from 'react';
import { 
  Search, Plus, Edit2, Trash2, Phone, Mail, Users as UsersIcon,
  ChevronLeft, ChevronRight, X, User, Calendar
} from 'lucide-react';
import { toast } from 'sonner';
import { adminService } from '@/config/supabase';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  
  const [formData, setFormData] = useState({
    phone: '',
    name: '',
    email: '',
    age: '',
    emirate: 'Dubai',
    plan_type: '',
    family_members: []
  });

  const [newMember, setNewMember] = useState({ name: '', age: '', relationship: '' });

  const emirates = ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah', 'Fujairah', 'Umm Al Quwain'];
  const plans = ['individual-starter', 'preventive-starter', 'preventive-plus', 'elderly-care', 'family-of-2', 'family-of-3', 'family-of-4'];
  const relationships = ['wife', 'husband', 'father', 'mother', 'son', 'daughter', 'brother', 'sister', 'other'];

  const fetchUsers = async () => {
    try {
      const allUsers = await adminService.getUsers();
      // Filter by search if needed
      let filteredUsers = allUsers;
      if (search) {
        const searchLower = search.toLowerCase();
        filteredUsers = allUsers.filter(u => 
          (u.name || '').toLowerCase().includes(searchLower) ||
          (u.email || '').toLowerCase().includes(searchLower) ||
          (u.phone_number || '').includes(search)
        );
      }
      setUsers(filteredUsers);
      setTotalPages(Math.ceil(filteredUsers.length / 10) || 1);
    } catch (error) {
      console.error('Fetch users error:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [search, page]);

  const handleAddMember = () => {
    if (!newMember.name || !newMember.age || !newMember.relationship) {
      toast.error('Please fill all member fields');
      return;
    }
    setFormData(prev => ({
      ...prev,
      family_members: [...prev.family_members, { ...newMember, id: Date.now() }]
    }));
    setNewMember({ name: '', age: '', relationship: '' });
  };

  const handleRemoveMember = (id) => {
    setFormData(prev => ({
      ...prev,
      family_members: prev.family_members.filter(m => m.id !== id)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // User creation/edit via admin panel - simplified for now
    toast.info('User management requires direct database access');
    setShowModal(false);
    setEditingUser(null);
    resetForm();
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    setFormData({
      phone: user.phone_number || '',
      name: user.name || '',
      email: user.email || '',
      age: user.age || '',
      emirate: user.emirate || 'Dubai',
      plan_type: user.plan_type || '',
      family_members: user.family_members || []
    });
    setShowModal(true);
  };

  const handleDelete = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    toast.info('User deletion requires direct database access');
  };

  const viewUserDetails = async (userId) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setSelectedUser({ user, appointments: [] });
    }
  };

  const resetForm = () => {
    setFormData({
      phone: '',
      name: '',
      email: '',
      age: '',
      emirate: 'Dubai',
      plan_type: '',
      family_members: []
    });
    setNewMember({ name: '', age: '', relationship: '' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Users CRM</h1>
          <p className="text-slate-400 mt-1">Manage users and their family details</p>
        </div>
        <button
          onClick={() => { resetForm(); setEditingUser(null); setShowModal(true); }}
          data-testid="add-user-btn"
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          Add User
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by phone, name, or email..."
          className="w-full h-10 pl-10 pr-4 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
          data-testid="search-users"
        />
      </div>

      {/* Users Table */}
      <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">User</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Contact</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Plan</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Family</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-slate-700/30 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center text-white font-medium">
                      {(user.name || user.phone)?.[0]?.toUpperCase() || 'U'}
                    </div>
                    <div>
                      <p className="text-white font-medium">{user.name || 'N/A'}</p>
                      <p className="text-slate-400 text-sm">{user.emirate || 'Dubai'}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Phone className="w-3 h-3" />
                      <span className="text-sm">{user.phone_number || 'N/A'}</span>
                    </div>
                    {user.email && (
                      <div className="flex items-center gap-2 text-slate-400">
                        <Mail className="w-3 h-3" />
                        <span className="text-sm">{user.email}</span>
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                    user.plan_type 
                      ? 'bg-teal-500/20 text-teal-400' 
                      : 'bg-slate-600 text-slate-400'
                  }`}>
                    {user.plan_type?.replace(/-/g, ' ') || 'No Plan'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1">
                    <UsersIcon className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-300">{user.family_members?.length || 0}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => viewUserDetails(user.id)}
                      className="p-2 hover:bg-slate-600 rounded-lg text-slate-400 hover:text-white transition-all"
                      title="View Details"
                    >
                      <User className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEdit(user)}
                      className="p-2 hover:bg-slate-600 rounded-lg text-slate-400 hover:text-white transition-all"
                      title="Edit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(user.id)}
                      className="p-2 hover:bg-red-500/20 rounded-lg text-slate-400 hover:text-red-400 transition-all"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {users.length === 0 && (
          <div className="text-center py-12 text-slate-400">
            No users found
          </div>
        )}

        {/* Pagination */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-700">
          <p className="text-sm text-slate-400">Page {page} of {totalPages}</p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 hover:bg-slate-700 rounded-lg text-slate-400 disabled:opacity-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 hover:bg-slate-700 rounded-lg text-slate-400 disabled:opacity-50"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h2 className="text-xl font-bold text-white">User Details</h2>
              <button onClick={() => setSelectedUser(null)} className="p-2 hover:bg-slate-700 rounded-lg text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              {/* User Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-slate-400 text-sm">Name</p>
                  <p className="text-white font-medium">{selectedUser.user?.name || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Phone</p>
                  <p className="text-white font-medium">{selectedUser.user?.phone}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Email</p>
                  <p className="text-white font-medium">{selectedUser.user?.email || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Plan</p>
                  <p className="text-white font-medium capitalize">{selectedUser.user?.plan_type?.replace(/-/g, ' ') || 'None'}</p>
                </div>
              </div>

              {/* Family Members */}
              {selectedUser.user?.family_members?.length > 0 && (
                <div>
                  <h3 className="text-white font-semibold mb-3">Family Members</h3>
                  <div className="space-y-2">
                    {selectedUser.user.family_members.map((member, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 text-sm">
                          {member.name?.[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="text-white">{member.name}</p>
                          <p className="text-slate-400 text-sm">{member.relationship} • {member.age} years</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Appointments */}
              <div>
                <h3 className="text-white font-semibold mb-3">Appointments ({selectedUser.appointments?.length || 0})</h3>
                {selectedUser.appointments?.length > 0 ? (
                  <div className="space-y-2">
                    {selectedUser.appointments.slice(0, 5).map((apt, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Calendar className="w-4 h-4 text-teal-400" />
                          <span className="text-white">{apt.date} at {apt.time}</span>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs ${
                          apt.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          apt.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-slate-600 text-slate-400'
                        }`}>{apt.status}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 text-sm">No appointments</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit User Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h2 className="text-xl font-bold text-white">
                {editingUser ? 'Edit User' : 'Add New User'}
              </h2>
              <button onClick={() => { setShowModal(false); setEditingUser(null); }} className="p-2 hover:bg-slate-700 rounded-lg text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Phone *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="501234567"
                    required
                    disabled={!!editingUser}
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none disabled:opacity-50"
                    data-testid="user-phone"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="John Doe"
                    required
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                    data-testid="user-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="john@example.com"
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                    data-testid="user-email"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Age</label>
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="35"
                    min="1"
                    max="120"
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                    data-testid="user-age"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Emirate</label>
                  <select
                    value={formData.emirate}
                    onChange={(e) => setFormData(prev => ({ ...prev, emirate: e.target.value }))}
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                  >
                    {emirates.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Plan</label>
                  <select
                    value={formData.plan_type}
                    onChange={(e) => setFormData(prev => ({ ...prev, plan_type: e.target.value }))}
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="">No Plan</option>
                    {plans.map(p => <option key={p} value={p}>{p.replace(/-/g, ' ')}</option>)}
                  </select>
                </div>
              </div>

              {/* Family Members */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-3">Family Members</label>
                
                {formData.family_members.length > 0 && (
                  <div className="space-y-2 mb-4">
                    {formData.family_members.map((member) => (
                      <div key={member.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                        <div>
                          <p className="text-white">{member.name}</p>
                          <p className="text-slate-400 text-sm">{member.relationship} • {member.age} years</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveMember(member.id)}
                          className="p-1 hover:bg-red-500/20 rounded text-red-400"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="grid grid-cols-4 gap-2">
                  <input
                    type="text"
                    value={newMember.name}
                    onChange={(e) => setNewMember(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Name"
                    className="col-span-1 h-10 px-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none text-sm"
                  />
                  <input
                    type="number"
                    value={newMember.age}
                    onChange={(e) => setNewMember(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="Age"
                    min="1"
                    max="120"
                    className="col-span-1 h-10 px-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none text-sm"
                  />
                  <select
                    value={newMember.relationship}
                    onChange={(e) => setNewMember(prev => ({ ...prev, relationship: e.target.value }))}
                    className="col-span-1 h-10 px-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none text-sm"
                  >
                    <option value="">Relation</option>
                    {relationships.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                  <button
                    type="button"
                    onClick={handleAddMember}
                    className="h-10 px-4 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm transition-all"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Submit */}
              <div className="flex justify-end gap-3 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => { setShowModal(false); setEditingUser(null); }}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  data-testid="save-user-btn"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-all"
                >
                  {editingUser ? 'Update User' : 'Create User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminUsers;
