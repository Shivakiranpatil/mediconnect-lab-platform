import React, { useState, useEffect } from 'react';
import { 
  Plus, Edit2, Trash2, X, Building2, Phone, Mail, MapPin, 
  Users, Activity, UserPlus, AlertTriangle, Check
} from 'lucide-react';
import { toast } from 'sonner';
import { adminService } from '@/config/supabase';

const AdminLabs = () => {
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [editingLab, setEditingLab] = useState(null);
  const [selectedLab, setSelectedLab] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [users, setUsers] = useState([]);
  
  const [formData, setFormData] = useState({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
    emirate: 'Dubai',
    area: '',
    capacity_per_day: 50,
    status: 'active'
  });

  const [assignData, setAssignData] = useState({
    user_id: '',
    lab_id: '',
    reason: 'emergency',
    priority: 'urgent'
  });

  const emirates = ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah', 'Fujairah', 'Umm Al Quwain'];
  const priorities = [
    { value: 'normal', label: 'Normal', color: 'bg-slate-500' },
    { value: 'urgent', label: 'Urgent', color: 'bg-yellow-500' },
    { value: 'emergency', label: 'Emergency', color: 'bg-red-500' }
  ];

  const fetchLabs = async () => {
    try {
      const allLabs = await adminService.getLabs();
      setLabs(allLabs);
    } catch (error) {
      console.error('Fetch labs error:', error);
      toast.error('Failed to load labs');
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const allUsers = await adminService.getUsers();
      setUsers(allUsers);
    } catch (error) {
      console.error('Failed to load users');
    }
  };

  const fetchAssignments = async (labId) => {
    // Assignments feature - simplified for now
    setAssignments([]);
  };

  useEffect(() => {
    fetchLabs();
    fetchUsers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Lab creation/edit functionality requires backend API
    toast.info('Lab management requires backend API setup');
    setShowModal(false);
    setEditingLab(null);
    resetForm();
  };

  const handleAssign = async (e) => {
    e.preventDefault();
    // Assignment functionality requires backend API
    toast.info('Assignment requires backend API setup');
    setShowAssignModal(false);
    setAssignData({ user_id: '', lab_id: '', reason: 'emergency', priority: 'urgent' });
  };

  const handleEdit = (lab) => {
    setEditingLab(lab);
    setFormData({
      name: lab.name || '',
      contact_person: lab.contact_person || '',
      email: lab.email || '',
      phone: lab.phone || '',
      address: lab.address || '',
      emirate: lab.emirate || 'Dubai',
      area: lab.area || '',
      capacity_per_day: lab.capacity_per_day || 50,
      status: lab.status || 'active'
    });
    setShowModal(true);
  };

  const handleDelete = async (labId) => {
    if (!window.confirm('Are you sure you want to delete this lab?')) return;
    
    const token = localStorage.getItem('adminToken');
    try {
      await axios.delete(`${API}/admin/labs/${labId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success('Lab deleted');
      fetchLabs();
    } catch (error) {
      toast.error('Failed to delete lab');
    }
  };

  const viewLabDetails = async (lab) => {
    setSelectedLab(lab);
    await fetchAssignments(lab.id);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      contact_person: '',
      email: '',
      phone: '',
      address: '',
      emirate: 'Dubai',
      area: '',
      capacity_per_day: 50,
      status: 'active'
    });
  };

  const getCapacityColor = (lab) => {
    const usage = (lab.current_load || 0) / (lab.capacity_per_day || 50);
    if (usage >= 0.9) return 'text-red-400';
    if (usage >= 0.7) return 'text-yellow-400';
    return 'text-green-400';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Partner Labs</h1>
          <p className="text-slate-400 mt-1">Manage laboratory partners and assignments</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowAssignModal(true)}
            data-testid="emergency-assign-btn"
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-all"
          >
            <AlertTriangle className="w-4 h-4" />
            Emergency Assign
          </button>
          <button
            onClick={() => { resetForm(); setEditingLab(null); setShowModal(true); }}
            data-testid="add-lab-btn"
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Lab
          </button>
        </div>
      </div>

      {/* Labs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {labs.map((lab) => (
          <div key={lab.id} className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                  lab.status === 'active' 
                    ? 'bg-green-500/20 text-green-400' 
                    : 'bg-slate-600 text-slate-400'
                }`}>
                  {lab.status}
                </span>
              </div>
            </div>
            
            <h3 className="text-lg font-semibold text-white mb-1">{lab.name}</h3>
            <p className="text-teal-400 text-sm mb-3">{lab.emirate} {lab.area && `• ${lab.area}`}</p>
            
            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Phone className="w-3 h-3" />
                <span>{lab.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Mail className="w-3 h-3" />
                <span>{lab.email}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <MapPin className="w-3 h-3" />
                <span className="truncate">{lab.address}</span>
              </div>
            </div>

            {/* Capacity Indicator */}
            <div className="mb-4 p-3 bg-slate-700/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400 text-sm">Daily Capacity</span>
                <span className={`text-sm font-medium ${getCapacityColor(lab)}`}>
                  {lab.current_load || 0} / {lab.capacity_per_day || 50}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-600 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${
                    getCapacityColor(lab) === 'text-red-400' ? 'bg-red-500' :
                    getCapacityColor(lab) === 'text-yellow-400' ? 'bg-yellow-500' :
                    'bg-green-500'
                  }`}
                  style={{ width: `${Math.min(((lab.current_load || 0) / (lab.capacity_per_day || 50)) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
            
            <p className="text-slate-400 text-sm mb-4">
              Contact: {lab.contact_person}
            </p>

            <div className="flex items-center gap-2 pt-4 border-t border-slate-700">
              <button
                onClick={() => viewLabDetails(lab)}
                className="flex-1 flex items-center justify-center gap-2 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm transition-all"
              >
                <Activity className="w-4 h-4" />
                View
              </button>
              <button
                onClick={() => handleEdit(lab)}
                className="flex-1 flex items-center justify-center gap-2 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm transition-all"
              >
                <Edit2 className="w-4 h-4" />
                Edit
              </button>
              <button
                onClick={() => handleDelete(lab.id)}
                className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {labs.length === 0 && (
          <div className="col-span-full text-center py-12 text-slate-400">
            <Building2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No partner labs yet</p>
            <p className="text-sm">Click "Add Lab" to register your first partner</p>
          </div>
        )}
      </div>

      {/* Lab Details Modal */}
      {selectedLab && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <div>
                <h2 className="text-xl font-bold text-white">{selectedLab.name}</h2>
                <p className="text-slate-400 text-sm">{selectedLab.emirate} • {selectedLab.area}</p>
              </div>
              <button onClick={() => setSelectedLab(null)} className="p-2 hover:bg-slate-700 rounded-lg text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Lab Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-white">{assignments.length}</p>
                  <p className="text-slate-400 text-sm">Total Assigned</p>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-yellow-400">
                    {assignments.filter(a => a.status === 'pending').length}
                  </p>
                  <p className="text-slate-400 text-sm">Pending</p>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-green-400">
                    {assignments.filter(a => a.status === 'completed').length}
                  </p>
                  <p className="text-slate-400 text-sm">Completed</p>
                </div>
              </div>

              {/* Assigned Users */}
              <div>
                <h3 className="text-white font-semibold mb-3">Current Assignments</h3>
                {assignments.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {assignments.map((apt) => (
                      <div key={apt.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                        <div>
                          <p className="text-white">{apt.user_name || 'Unknown User'}</p>
                          <p className="text-slate-400 text-sm">{apt.user_phone} • {apt.user_emirate}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            apt.assignment_type === 'manual' ? 'bg-orange-500/20 text-orange-400' :
                            apt.assignment_type === 'reassigned' ? 'bg-purple-500/20 text-purple-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {apt.assignment_type || 'auto'}
                          </span>
                          <span className={`px-2 py-1 rounded text-xs ${
                            apt.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                            apt.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-slate-600 text-slate-400'
                          }`}>{apt.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-sm">No assignments yet</p>
                )}
              </div>

              {/* Quick Assign Button */}
              <button
                onClick={() => {
                  setAssignData(prev => ({ ...prev, lab_id: selectedLab.id }));
                  setSelectedLab(null);
                  setShowAssignModal(true);
                }}
                className="w-full py-3 bg-teal-600 hover:bg-teal-500 text-white rounded-xl font-medium transition-all flex items-center justify-center gap-2"
              >
                <UserPlus className="w-5 h-5" />
                Assign User to This Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit Lab Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h2 className="text-xl font-bold text-white">
                {editingLab ? 'Edit Lab' : 'Add Partner Lab'}
              </h2>
              <button onClick={() => { setShowModal(false); setEditingLab(null); }} className="p-2 hover:bg-slate-700 rounded-lg text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Lab Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="ABC Diagnostics"
                  required
                  className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Contact Person *</label>
                <input
                  type="text"
                  value={formData.contact_person}
                  onChange={(e) => setFormData(prev => ({ ...prev, contact_person: e.target.value }))}
                  placeholder="Dr. Ahmed Khan"
                  required
                  className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Email *</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="lab@example.com"
                    required
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Phone *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+971501234567"
                    required
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Emirate *</label>
                  <select
                    value={formData.emirate}
                    onChange={(e) => setFormData(prev => ({ ...prev, emirate: e.target.value }))}
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                  >
                    {emirates.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Area</label>
                  <input
                    type="text"
                    value={formData.area}
                    onChange={(e) => setFormData(prev => ({ ...prev, area: e.target.value }))}
                    placeholder="e.g., Al Barsha, JLT"
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Address *</label>
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  placeholder="Building, Street, Area, City"
                  required
                  rows={2}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Daily Capacity</label>
                  <input
                    type="number"
                    value={formData.capacity_per_day}
                    onChange={(e) => setFormData(prev => ({ ...prev, capacity_per_day: parseInt(e.target.value) }))}
                    min="1"
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => { setShowModal(false); setEditingLab(null); }}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-all"
                >
                  {editingLab ? 'Update Lab' : 'Create Lab'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Emergency Assign Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Emergency Lab Assignment</h2>
                  <p className="text-slate-400 text-sm">Manually assign a lab to a user</p>
                </div>
              </div>
              <button onClick={() => setShowAssignModal(false)} className="p-2 hover:bg-slate-700 rounded-lg text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAssign} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Select User *</label>
                <select
                  value={assignData.user_id}
                  onChange={(e) => setAssignData(prev => ({ ...prev, user_id: e.target.value }))}
                  required
                  className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">Choose a user...</option>
                  {users.map(user => (
                    <option key={user.id} value={user.id}>
                      {user.name || user.phone} ({user.emirate || 'Dubai'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Assign to Lab *</label>
                <select
                  value={assignData.lab_id}
                  onChange={(e) => setAssignData(prev => ({ ...prev, lab_id: e.target.value }))}
                  required
                  className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white focus:border-teal-500 focus:outline-none"
                >
                  <option value="">Choose a lab...</option>
                  {labs.filter(l => l.status === 'active').map(lab => (
                    <option key={lab.id} value={lab.id}>
                      {lab.name} ({lab.emirate}) - {lab.current_load || 0}/{lab.capacity_per_day} capacity
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Priority *</label>
                <div className="grid grid-cols-3 gap-2">
                  {priorities.map(p => (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => setAssignData(prev => ({ ...prev, priority: p.value }))}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                        assignData.priority === p.value
                          ? `${p.color} text-white`
                          : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Reason</label>
                <input
                  type="text"
                  value={assignData.reason}
                  onChange={(e) => setAssignData(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="e.g., Emergency, Nearest available, User request"
                  className="w-full h-10 px-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
                <p className="text-yellow-400 text-sm">
                  <strong>Note:</strong> This will override any automatic lab assignment for this user's pending appointment.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowAssignModal(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-all flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Assign Lab
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminLabs;
