import React, { useState, useEffect } from 'react';
import { Plus, Edit2, X, CreditCard, Check, Star, DollarSign } from 'lucide-react';
import { toast } from 'sonner';
import { planService } from '@/config/supabase';

const AdminPlans = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPlans = async () => {
    try {
      const data = await planService.getPlans();
      setPlans(data);
    } catch (error) {
      console.error('Fetch plans error:', error);
      toast.error('Failed to load plans');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Subscription Plans</h1>
          <p className="text-slate-400 mt-1">Manage subscription plans and pricing</p>
        </div>
        <button
          onClick={() => toast.info('Plan management requires direct database access')}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          Add Plan
        </button>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div 
            key={plan.id} 
            className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden"
          >
            {/* Plan Header */}
            <div className="p-6 border-b border-slate-700">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
                    {plan.type === 'family' && (
                      <span className="px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded text-xs">
                        Family
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400 text-sm mt-1">
                    {plan.type === 'individual' ? 'Individual Plan' : 'Family Plan'}
                  </p>
                </div>
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${
                  plan.type === 'family' 
                    ? 'from-purple-500 to-pink-500' 
                    : 'from-teal-500 to-emerald-500'
                } flex items-center justify-center`}>
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
              </div>
              
              <div className="mt-4">
                <span className="text-3xl font-bold text-white">AED {plan.price}</span>
                <span className="text-slate-400 text-sm ml-1">
                  / {plan.duration_days || 30} days
                </span>
              </div>
            </div>

            {/* Plan Features */}
            <div className="p-6">
              <p className="text-slate-400 text-sm mb-3">Includes:</p>
              <ul className="space-y-2">
                {(plan.features || []).map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                    <span className="text-slate-300">{feature}</span>
                  </li>
                ))}
                <li className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-teal-400 mt-0.5 shrink-0" />
                  <span className="text-slate-300">{plan.tests_included || 1} test(s) included</span>
                </li>
              </ul>
            </div>

            {/* Plan Actions */}
            <div className="px-6 pb-6 flex gap-2">
              <button
                onClick={() => toast.info('Edit requires direct database access')}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all text-sm"
              >
                <Edit2 className="w-4 h-4" />
                Edit
              </button>
              <span className={`px-3 py-2 rounded-lg text-sm font-medium ${
                plan.is_active !== false
                  ? 'bg-green-500/20 text-green-400'
                  : 'bg-red-500/20 text-red-400'
              }`}>
                {plan.is_active !== false ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {plans.length === 0 && (
        <div className="text-center py-12">
          <CreditCard className="w-12 h-12 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400">No subscription plans found</p>
          <p className="text-slate-500 text-sm mt-1">
            Run the database schema to add default plans
          </p>
        </div>
      )}

      {/* Info Box */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-white font-semibold mb-2">Managing Plans</h3>
        <p className="text-slate-400 text-sm">
          Subscription plans are stored in the <code className="bg-slate-700 px-1 rounded">subscription_plans</code> table in Supabase. 
          To add or modify plans, use the Supabase dashboard SQL editor or table editor.
        </p>
      </div>
    </div>
  );
};

export default AdminPlans;
