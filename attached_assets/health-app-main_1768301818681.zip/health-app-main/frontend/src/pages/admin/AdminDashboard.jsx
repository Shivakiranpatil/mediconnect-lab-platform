import React, { useState, useEffect } from 'react';
import { 
  Users, TrendingUp, Calendar, DollarSign, Activity, 
  ArrowUp, ArrowDown, FileText, Building2, RefreshCw, Clock
} from 'lucide-react';
import { toast } from 'sonner';
import { adminService } from '@/config/supabase';

const AdminDashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const [analyticsData, appointmentsData] = await Promise.all([
        adminService.getAnalytics(),
        adminService.getAllAppointments()
      ]);
      setAnalytics(analyticsData);
      setAppointments(appointmentsData.slice(0, 5)); // Show last 5
    } catch (error) {
      console.error('Dashboard error:', error);
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const stats = [
    {
      label: 'Total Users',
      value: analytics?.total_users || 0,
      change: 'Registered users',
      trend: 'up',
      icon: Users,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      label: 'Appointments',
      value: analytics?.total_appointments || 0,
      change: 'Total booked',
      trend: 'up',
      icon: Calendar,
      color: 'from-green-500 to-emerald-500'
    },
    {
      label: 'Reports',
      value: analytics?.total_reports || 0,
      change: 'Completed reports',
      trend: 'up',
      icon: FileText,
      color: 'from-purple-500 to-pink-500'
    },
    {
      label: 'Partner Labs',
      value: analytics?.total_labs || 0,
      change: 'Active labs',
      trend: 'up',
      icon: Building2,
      color: 'from-orange-500 to-amber-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 mt-1">Welcome back! Here's your business overview.</p>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-slate-400 text-sm">{stat.label}</p>
                <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                <div className="flex items-center gap-1 mt-2">
                  {stat.trend === 'up' ? (
                    <ArrowUp className="w-4 h-4 text-green-400" />
                  ) : (
                    <ArrowDown className="w-4 h-4 text-red-400" />
                  )}
                  <span className={`text-xs ${stat.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                    {stat.change}
                  </span>
                </div>
              </div>
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Status Card */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">System Overview</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Users</span>
              <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded-lg text-sm font-medium">
                {analytics?.total_users || 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Appointments</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                {analytics?.total_appointments || 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total Reports</span>
              <span className="px-2 py-1 bg-purple-500/20 text-purple-400 rounded-lg text-sm font-medium">
                {analytics?.total_reports || 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Partner Labs</span>
              <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded-lg text-sm font-medium">
                {analytics?.total_labs || 0}
              </span>
            </div>
          </div>
        </div>

        {/* Database Status */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">Database Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Database</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Supabase Connected
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Authentication</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Firebase Active
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">API Status</span>
              <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium">
                Operational
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button 
            onClick={() => window.location.href = '/admin/users'}
            className="p-4 bg-slate-700 hover:bg-slate-600 rounded-xl text-left transition-all"
          >
            <Users className="w-6 h-6 text-blue-400 mb-2" />
            <p className="text-white font-medium">View Users</p>
            <p className="text-slate-400 text-sm">Manage users</p>
          </button>
          <button 
            onClick={() => window.location.href = '/admin/labs'}
            className="p-4 bg-slate-700 hover:bg-slate-600 rounded-xl text-left transition-all"
          >
            <Building2 className="w-6 h-6 text-purple-400 mb-2" />
            <p className="text-white font-medium">Partner Labs</p>
            <p className="text-slate-400 text-sm">Manage labs</p>
          </button>
          <button 
            onClick={() => window.location.href = '/admin/plans'}
            className="p-4 bg-slate-700 hover:bg-slate-600 rounded-xl text-left transition-all"
          >
            <DollarSign className="w-6 h-6 text-green-400 mb-2" />
            <p className="text-white font-medium">Manage Plans</p>
            <p className="text-slate-400 text-sm">Edit pricing</p>
          </button>
          <button 
            onClick={() => window.location.href = '/admin/reports'}
            className="p-4 bg-slate-700 hover:bg-slate-600 rounded-xl text-left transition-all"
          >
            <FileText className="w-6 h-6 text-orange-400 mb-2" />
            <p className="text-white font-medium">View Reports</p>
            <p className="text-slate-400 text-sm">Analytics & insights</p>
          </button>
        </div>
      </div>

      {/* Recent Appointments */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-green-400" />
            Recent Appointments
          </h3>
          <span className="text-slate-400 text-sm">
            Total: {analytics?.total_appointments || 0}
          </span>
        </div>
        
        {appointments.length > 0 ? (
          <div className="space-y-3">
            {appointments.map((apt) => (
              <div key={apt.id} className="flex items-center justify-between p-4 bg-slate-700/50 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white font-semibold">
                    {apt.user_name?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <div>
                    <p className="text-white font-medium">{apt.user_name}</p>
                    <p className="text-slate-400 text-sm">{apt.user_phone || apt.user_email}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-white">{apt.date} • {apt.time}</p>
                  <div className="flex items-center gap-2 justify-end mt-1">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      apt.status === 'booked' ? 'bg-yellow-500/20 text-yellow-400' :
                      apt.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                      apt.status === 'sample_collected' ? 'bg-purple-500/20 text-purple-400' :
                      apt.status === 'processing' ? 'bg-orange-500/20 text-orange-400' :
                      apt.status === 'report_ready' ? 'bg-green-500/20 text-green-400' :
                      'bg-slate-500/20 text-slate-400'
                    }`}>
                      {apt.status?.replace(/_/g, ' ')}
                    </span>
                    <span className="text-slate-500 text-xs">{apt.lab_name}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400">
            <Clock className="w-10 h-10 mx-auto mb-3 opacity-50" />
            <p>No appointments yet</p>
            <p className="text-sm text-slate-500 mt-1">Appointments will appear here when users book tests</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
