import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, Key, Eye, EyeOff, Save, 
  Bot, MessageSquare, Map, Mail, CreditCard, Phone, Database, Shield
} from 'lucide-react';
import { toast } from 'sonner';

const AdminSettings = () => {
  const [showKeys, setShowKeys] = useState({});

  const settings = [
    {
      id: 'firebase',
      provider: 'Firebase Authentication',
      description: 'User authentication via email/password',
      icon: Shield,
      color: 'from-yellow-500 to-orange-500',
      status: 'configured',
      fields: [
        { key: 'REACT_APP_FIREBASE_API_KEY', label: 'API Key', value: process.env.REACT_APP_FIREBASE_API_KEY ? '••••••••' : 'Not set' },
        { key: 'REACT_APP_FIREBASE_PROJECT_ID', label: 'Project ID', value: process.env.REACT_APP_FIREBASE_PROJECT_ID || 'Not set' }
      ]
    },
    {
      id: 'supabase',
      provider: 'Supabase Database',
      description: 'PostgreSQL database for all app data',
      icon: Database,
      color: 'from-green-500 to-emerald-500',
      status: 'configured',
      fields: [
        { key: 'REACT_APP_SUPABASE_URL', label: 'URL', value: process.env.REACT_APP_SUPABASE_URL ? '••••••••' : 'Not set' },
        { key: 'REACT_APP_SUPABASE_ANON_KEY', label: 'Anon Key', value: process.env.REACT_APP_SUPABASE_ANON_KEY ? '••••••••' : 'Not set' }
      ]
    },
    {
      id: 'openai',
      provider: 'OpenAI',
      description: 'AI-powered health insights and report analysis',
      icon: Bot,
      color: 'from-green-500 to-teal-500',
      status: 'not_configured',
      fields: [
        { key: 'OPENAI_API_KEY', label: 'API Key', value: 'Not configured' }
      ]
    },
    {
      id: 'whatsapp',
      provider: 'WhatsApp Notifications',
      description: 'Send notifications and reminders via WhatsApp',
      icon: MessageSquare,
      color: 'from-green-600 to-green-500',
      status: 'not_configured',
      fields: []
    },
    {
      id: 'google-maps',
      provider: 'Google Maps',
      description: 'Address autocomplete and location services',
      icon: Map,
      color: 'from-blue-500 to-blue-600',
      status: 'not_configured',
      fields: []
    }
  ];

  const toggleShowKey = (id) => {
    setShowKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 mt-1">Manage integrations and API configurations</p>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
        <p className="text-blue-400 text-sm">
          <strong>Note:</strong> API keys are configured via environment variables in Vercel dashboard. 
          This page shows the current configuration status.
        </p>
      </div>

      {/* Settings Cards */}
      <div className="space-y-4">
        {settings.map((setting) => {
          const Icon = setting.icon;
          
          return (
            <div key={setting.id} className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${setting.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{setting.provider}</h3>
                    <p className="text-slate-400 text-sm">{setting.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    setting.status === 'configured' 
                      ? 'bg-green-500/20 text-green-400' 
                      : 'bg-slate-600 text-slate-400'
                  }`}>
                    {setting.status === 'configured' ? 'Configured' : 'Not Configured'}
                  </span>
                </div>
              </div>

              {/* Fields */}
              {setting.fields.length > 0 && (
                <div className="px-6 pb-6 space-y-3">
                  {setting.fields.map((field, idx) => (
                    <div key={idx} className="flex items-center justify-between py-2 border-t border-slate-700 first:border-t-0">
                      <span className="text-slate-400 text-sm">{field.label}</span>
                      <div className="flex items-center gap-2">
                        <code className="text-slate-300 text-sm bg-slate-700/50 px-2 py-1 rounded">
                          {showKeys[`${setting.id}-${idx}`] ? field.value : (field.value.includes('••') ? field.value : '••••••••')}
                        </code>
                        <button
                          onClick={() => toggleShowKey(`${setting.id}-${idx}`)}
                          className="p-1.5 hover:bg-slate-600 rounded text-slate-400"
                        >
                          {showKeys[`${setting.id}-${idx}`] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* How to Configure */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-white font-semibold mb-4">How to Configure API Keys</h3>
        <ol className="space-y-3 text-slate-400 text-sm">
          <li className="flex gap-3">
            <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-xs font-bold shrink-0">1</span>
            <span>Go to your <strong className="text-white">Vercel Dashboard</strong> → Select your project</span>
          </li>
          <li className="flex gap-3">
            <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-xs font-bold shrink-0">2</span>
            <span>Navigate to <strong className="text-white">Settings</strong> → <strong className="text-white">Environment Variables</strong></span>
          </li>
          <li className="flex gap-3">
            <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-xs font-bold shrink-0">3</span>
            <span>Add the required keys (e.g., REACT_APP_FIREBASE_API_KEY, REACT_APP_SUPABASE_URL)</span>
          </li>
          <li className="flex gap-3">
            <span className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-xs font-bold shrink-0">4</span>
            <span>Redeploy your application for changes to take effect</span>
          </li>
        </ol>
      </div>
    </div>
  );
};

export default AdminSettings;
