import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, Clock, Bell, Sparkles, Phone, MessageCircle, User,
  Calendar, MapPin, CircleCheck
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { appointmentService } from '@/config/supabase';

const BookingStatusPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookingStatus();
  }, [user]);

  const fetchBookingStatus = async () => {
    try {
      if (user?.id) {
        const appointments = await appointmentService.getUserAppointments(user.id);
        if (appointments?.upcoming?.length > 0) {
          const latest = appointments.upcoming[0];
          setBooking({
            status: latest.status || 'booked',
            date: latest.date,
            time: latest.time,
            address: latest.address?.full_address || 'Home Collection',
            lab_phone: '+971501234567',
            assigned_lab_name: latest.assigned_lab_name
          });
        } else {
          // Set default booking for demo
          setBooking({
            status: 'booked',
            date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
            time: '10:00 AM',
            address: 'Home Collection',
            lab_phone: '+971501234567'
          });
        }
      } else {
        // Set default booking for demo
        setBooking({
          status: 'booked',
          date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
          time: '10:00 AM',
          address: 'Home Collection',
          lab_phone: '+971501234567'
        });
      }
    } catch (error) {
      console.error('Fetch booking error:', error);
      // Set default booking for demo
      setBooking({
        status: 'booked',
        date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        time: '10:00 AM',
        address: 'Home Collection',
        lab_phone: '+971501234567'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCallLab = () => {
    window.location.href = `tel:${booking?.lab_phone || '+971501234567'}`;
  };

  const handleWhatsAppLab = () => {
    const phone = booking?.lab_phone?.replace(/\+/g, '') || '971501234567';
    window.open(`https://wa.me/${phone}?text=Hello, I have a question about my booking.`, '_blank');
  };

  const getStatusSteps = () => {
    const status = booking?.status || 'booked';
    
    return [
      {
        name: 'Booked',
        description: status === 'booked' ? 'Waiting for confirmation' : 'Confirmed successfully',
        status: status === 'booked' ? 'current' : 'done',
        icon: CheckCircle2
      },
      {
        name: 'Sample Collected',
        description: status === 'sample_collected' ? 'Processing at lab' : 'Pending collection',
        status: status === 'sample_collected' || status === 'report_ready' ? 'done' : 'pending',
        icon: status === 'sample_collected' || status === 'report_ready' ? CheckCircle2 : Clock
      },
      {
        name: 'Report Ready',
        description: status === 'report_ready' ? 'View your results' : 'In 24-48 hours',
        status: status === 'report_ready' ? 'done' : 'pending',
        icon: status === 'report_ready' ? CheckCircle2 : Clock
      }
    ];
  };

  const isSampleCollected = booking?.status === 'sample_collected' || booking?.status === 'report_ready';

  if (loading) {
    return (
      <div className="mobile-container min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/30 flex items-center justify-center">
        <p className="text-slate-500">Loading...</p>
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/30 pb-8">
      <div className="px-6 pt-12">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center shadow-xl ${
                isSampleCollected 
                  ? 'bg-gradient-to-br from-green-500 to-emerald-600 animate-pulse'
                  : 'bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A]'
              }`}>
                <CircleCheck className="w-14 h-14 text-white" strokeWidth={2.5} />
              </div>
              {isSampleCollected && (
                <div className="absolute inset-0 w-24 h-24 bg-green-500 rounded-full animate-ping opacity-20" />
              )}
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-2">
            {isSampleCollected ? 'Sample Collected!' : 'Booking Confirmed!'}
          </h1>
          <p className="text-base text-slate-500">
            {isSampleCollected 
              ? 'Your sample has been collected successfully'
              : 'Your test has been scheduled successfully'
            }
          </p>
        </div>

        {/* Booking Details */}
        <div className="bg-white rounded-3xl p-5 shadow-lg mb-4 border border-gray-100">
          <h3 className="text-lg font-semibold mb-4">Booking Details</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-teal-600" />
              </div>
              <div>
                <p className="text-xs text-slate-500">Date & Time</p>
                <p className="font-medium text-slate-900">{booking?.date} at {booking?.time}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-violet-600" />
              </div>
              <div>
                <p className="text-xs text-slate-500">Location</p>
                <p className="font-medium text-slate-900">{booking?.address}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Status Progress */}
        <div className="bg-white rounded-3xl p-6 shadow-lg mb-4 border border-gray-100">
          <h3 className="text-lg font-semibold mb-4">Status</h3>
          <div className="space-y-4">
            {getStatusSteps().map((step, index) => (
              <React.Fragment key={step.name}>
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-md ${
                    step.status === 'done' 
                      ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                      : step.status === 'current'
                      ? 'bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A]'
                      : 'border-2 border-yellow-400 bg-yellow-50'
                  }`}>
                    {step.status === 'pending' ? (
                      <Clock className="w-5 h-5 text-yellow-600" />
                    ) : (
                      <CheckCircle2 className="w-6 h-6 text-white" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{step.name}</p>
                    <p className="text-xs text-slate-500">{step.description}</p>
                  </div>
                  <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                    step.status === 'done'
                      ? 'bg-green-100 text-green-700'
                      : step.status === 'current'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {step.status === 'done' ? 'Done' : step.status === 'current' ? 'Active' : 'Pending'}
                  </span>
                </div>
                {index < getStatusSteps().length - 1 && (
                  <div className="ml-5 w-0.5 h-8 bg-gray-200" />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Expected Timeline Card */}
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl p-6 shadow-lg mb-4 text-white">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 backdrop-blur-sm">
              <Clock className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-2">Expected Timeline</h3>
              <p className="text-sm opacity-90 leading-relaxed">
                Your report will be ready in <strong>24-48 hours</strong>. We'll send you a notification as soon as it's available.
              </p>
            </div>
          </div>
        </div>

        {/* Notification Info */}
        <div className="bg-white rounded-3xl p-5 shadow-lg mb-4 border border-gray-100">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <Bell className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-1">Notification Enabled</h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                You'll receive updates via SMS and app notification when your report is ready for review.
              </p>
            </div>
          </div>
        </div>

        {/* Lab Contact Card */}
        <div className="bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A] rounded-3xl p-6 shadow-lg mb-4 text-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-semibold">Need Help?</h3>
              <p className="text-sm opacity-90">Contact our lab support</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleCallLab}
              data-testid="call-lab-btn"
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-xl p-3 transition-all flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              <span className="text-sm font-medium">Call</span>
            </button>
            <button
              onClick={handleWhatsAppLab}
              data-testid="whatsapp-lab-btn"
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-xl p-3 transition-all flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">WhatsApp</span>
            </button>
          </div>
        </div>

        {/* AI Summary Preview */}
        <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-3xl p-6 shadow-lg mb-6 text-white">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 backdrop-blur-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-2">AI Health Summary Coming</h3>
              <p className="text-sm opacity-90 leading-relaxed">
                Once your report is ready, our AI will provide a simple, easy-to-understand health summary with personalized insights.
              </p>
            </div>
          </div>
        </div>

        {/* Dashboard Button */}
        <button 
          onClick={() => navigate('/home')}
          data-testid="view-dashboard-btn"
          className="w-full h-14 text-base font-semibold bg-gradient-to-r from-[#0A5F5F] to-[#0D7A7A] hover:from-[#084848] hover:to-[#0A5F5F] rounded-2xl shadow-lg mb-3 text-white"
        >
          View Dashboard
        </button>

        <p className="text-center text-xs text-slate-500">
          Track your report status in the Reports section
        </p>
      </div>
    </div>
  );
};

export default BookingStatusPage;
