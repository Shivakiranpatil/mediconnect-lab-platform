import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Bell, X, Check, FileText, Calendar, Lightbulb, Clock
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { notificationService } from '@/config/supabase';

const NotificationsPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, [user]);

  const fetchNotifications = async () => {
    try {
      if (user?.id) {
        const data = await notificationService.getNotifications(user.id);
        setNotifications(data || []);
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id) => {
    try {
      await notificationService.markAsRead(id);
      setNotifications(notifications.map(n => 
        n.id === id ? { ...n, read: true } : n
      ));
    } catch (error) {
      console.error('Failed to mark as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      // Mark all locally for now
      setNotifications(notifications.map(n => ({ ...n, read: true })));
    } catch (error) {
      console.error('Failed to mark all as read:', error);
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case 'report': return FileText;
      case 'reminder': return Calendar;
      case 'tip': return Lightbulb;
      default: return Bell;
    }
  };

  const getIconBg = (type) => {
    switch (type) {
      case 'report': return 'bg-violet-100 text-violet-600';
      case 'reminder': return 'bg-amber-100 text-amber-600';
      case 'tip': return 'bg-cyan-100 text-cyan-600';
      default: return 'bg-teal-100 text-teal-600';
    }
  };

  const formatTime = (dateStr) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
    return date.toLocaleDateString();
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-6">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-100">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              data-testid="back-btn"
              onClick={() => navigate('/home')}
              className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Notifications</h1>
              {unreadCount > 0 && (
                <p className="text-sm text-slate-500">{unreadCount} unread</p>
              )}
            </div>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-sm text-teal-600 font-medium"
            >
              Mark all read
            </button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="px-6 py-4 space-y-3">
        {loading ? (
          <div className="text-center py-10 text-slate-500">Loading...</div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-10">
            <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">No notifications yet</p>
          </div>
        ) : (
          notifications.map((notification) => {
            const Icon = getIcon(notification.type);
            return (
              <div
                key={notification.id}
                data-testid={`notification-${notification.id}`}
                onClick={() => markAsRead(notification.id)}
                className={`health-card p-4 cursor-pointer transition-all ${
                  !notification.read ? 'border-l-4 border-teal-500 bg-teal-50/30' : ''
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${getIconBg(notification.type)}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-1">
                      <h3 className="font-semibold text-slate-900 text-sm">{notification.title}</h3>
                      {!notification.read && (
                        <span className="w-2 h-2 bg-teal-500 rounded-full" />
                      )}
                    </div>
                    <p className="text-slate-600 text-sm leading-relaxed mb-2">{notification.message}</p>
                    <div className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span>{formatTime(notification.created_at)}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;
