import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Bell, ChevronRight, Calendar, FileText, Home as HomeIcon, 
  User, Sun, Lightbulb, Egg, Dumbbell, TrendingUp, Heart,
  Droplet, Pill, Stethoscope, Info, Sparkles, MessageCircle,
  Clock, ChevronDown, TrendingDown, Minus, Loader2, Activity,
  Beaker, Thermometer, Zap
} from 'lucide-react';
import AIChatModal from '@/components/AIChatModal';
import RecommendationModal from '@/components/RecommendationModal';
import { useAuth } from '@/context/AuthContext';
import { appointmentService, healthService, notificationService } from '@/config/supabase';

const HomePage = () => {
  const navigate = useNavigate();
  const { user: authUser, isAuthenticated } = useAuth();
  const [user, setUser] = useState(authUser);
  const [greeting, setGreeting] = useState('Good Morning');
  const [showAIChat, setShowAIChat] = useState(false);
  const [selectedRecommendation, setSelectedRecommendation] = useState(null);
  const [biomarkersData, setBiomarkersData] = useState(null);
  const [healthScore, setHealthScore] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasReports, setHasReports] = useState(false);
  const [appointmentStatus, setAppointmentStatus] = useState(null);
  const [upcomingAppointments, setUpcomingAppointments] = useState([]);
  const [aiRecommendations, setAiRecommendations] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
      return;
    }

    const hour = new Date().getHours();
    if (hour < 12) setGreeting('Good Morning');
    else if (hour < 17) setGreeting('Good Afternoon');
    else setGreeting('Good Evening');

    if (authUser?.id) {
      fetchAllData(authUser.id);
    }
  }, [navigate, isAuthenticated, authUser]);

  // Update local user state when authUser changes
  useEffect(() => {
    if (authUser) {
      setUser(authUser);
    }
  }, [authUser]);

  const fetchAllData = async (userId) => {
    try {
      // Fetch all data using Supabase services
      const [statusData, appointmentsData, notificationsData] = await Promise.all([
        appointmentService.checkUserStatus(userId),
        appointmentService.getUserAppointments(userId),
        notificationService.getNotifications(userId)
      ]);
      
      setHasReports(statusData.has_reports);
      setAppointmentStatus(statusData.appointment_status);
      setUpcomingAppointments(appointmentsData.upcoming || []);
      setNotifications(notificationsData);
      
      // Only fetch health data if user has reports
      if (statusData.has_reports) {
        const [biomarkers, score] = await Promise.all([
          healthService.getBiomarkers(userId),
          healthService.getHealthScore(userId)
        ]);
        setBiomarkersData(biomarkers);
        setHealthScore(score);
        
        // Fetch personalized AI recommendations
        setLoadingAI(true);
        try {
          const aiData = await healthService.getAIRecommendations(
            userId, 
            authUser?.name || 'User',
            biomarkers.biomarkers
          );
          setAiRecommendations(aiData);
        } catch (aiError) {
          console.error('Error fetching AI recommendations:', aiError);
        } finally {
          setLoadingAI(false);
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  // Prioritize important biomarkers for key metrics display
  const priorityBiomarkers = [
    'vitamin d', 'glucose', 'fasting glucose', 'blood sugar', 'hba1c',
    'cholesterol', 'total cholesterol', 'ldl', 'hdl', 'triglycerides',
    'hemoglobin', 'iron', 'vitamin b12', 'creatinine', 'tsh'
  ];
  
  const sortBiomarkersByPriority = (biomarkers) => {
    if (!biomarkers || !Array.isArray(biomarkers)) return [];
    
    return [...biomarkers].sort((a, b) => {
      const aName = a.name?.toLowerCase() || '';
      const bName = b.name?.toLowerCase() || '';
      
      const aIndex = priorityBiomarkers.findIndex(p => aName.includes(p));
      const bIndex = priorityBiomarkers.findIndex(p => bName.includes(p));
      
      // If both found in priority list, sort by priority index
      if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
      // If only a is in priority list, it comes first
      if (aIndex !== -1) return -1;
      // If only b is in priority list, it comes first
      if (bIndex !== -1) return 1;
      // Otherwise, prioritize needs_attention and borderline statuses
      const statusPriority = { 'needs_attention': 0, 'borderline': 1, 'normal': 2 };
      const aStatus = statusPriority[a.status?.toLowerCase()] ?? 3;
      const bStatus = statusPriority[b.status?.toLowerCase()] ?? 3;
      return aStatus - bStatus;
    });
  };

  const sortedBiomarkers = sortBiomarkersByPriority(biomarkersData?.biomarkers);
  
  const keyMetrics = sortedBiomarkers.slice(0, 4).map(b => ({
    name: b.name,
    value: b.value,
    unit: b.unit,
    status: b.status,
    statusColor: getStatusColorName(b.status),
    icon: getMetricIcon(b.name, b.category),
    iconBg: getIconBg(b.name, b.category),
    iconColor: getIconColor(b.name, b.category),
    progress: getProgressValue(b.status),
    trend: b.trend || 'stable',
    change: b.change || '0',
    hasComparison: b.has_comparison
  })) || [];

  // Map icon names to actual components for AI recommendations
  const iconMap = {
    'sun': Sun,
    'heart': Heart,
    'pill': Pill,
    'calendar': Calendar,
    'activity': Activity,
    'droplet': Droplet,
    'utensils': Egg,
    'moon': Clock,
    'dumbbell': Dumbbell,
    'egg': Egg,
    'stethoscope': Stethoscope
  };

  // Use AI recommendations if available, otherwise use fallback
  const recommendations = aiRecommendations?.recommendations?.map(rec => ({
    icon: iconMap[rec.icon] || Info,
    iconBg: rec.iconBg || 'bg-teal-400',
    title: rec.title,
    description: rec.description
  })) || [
    { 
      icon: Calendar, 
      iconBg: 'bg-teal-400',
      title: 'Book Your Test',
      description: 'Get your health markers checked to receive personalized AI insights.'
    }
  ];

  const healthTips = aiRecommendations?.health_tips?.map(tip => ({
    icon: iconMap[tip.icon] || Info,
    text: tip.text,
    color: tip.color || 'text-slate-200'
  })) || [
    { icon: Sun, text: 'Get 15-20 minutes of morning sunlight daily', color: 'text-amber-400' },
    { icon: Egg, text: 'Maintain a balanced diet rich in nutrients', color: 'text-slate-200' },
    { icon: Dumbbell, text: 'Stay active with regular exercise', color: 'text-orange-400' }
  ];

  const aiSummary = aiRecommendations?.ai_summary || healthScore?.insights?.[0]?.text || 
    "Your health insights will appear here after your first test.";

  if (loading) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
      </div>
    );
  }

  const testsCompleted = healthScore?.total_parameters || 0;
  const healthScoreValue = healthScore?.score || 0;
  const excellentCount = healthScore?.excellent_count || 0;
  const needsCareCount = healthScore?.needs_care_count || 0;

  // Get next upcoming appointment
  const nextAppointment = upcomingAppointments[0];
  const formatAppointmentDate = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // If no reports yet, show waiting state
  if (!hasReports) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50 pb-24">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 flex items-center justify-between">
          <div>
            <p className="text-slate-500 text-sm flex items-center gap-1">
              {greeting} <Sun className="w-4 h-4 text-amber-400" />
            </p>
            <h1 className="text-2xl font-bold text-slate-900">
              {user?.name || 'Guest'}
            </h1>
          </div>
          <button 
            data-testid="notifications-btn"
            onClick={() => navigate('/notifications')}
            className="relative w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center shadow-sm"
          >
            <Bell className="w-5 h-5 text-slate-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-medium">
                {unreadCount}
              </span>
            )}
          </button>
        </div>

        {/* Waiting for Report Card - shows real appointment status */}
        <div className="px-6 mb-4">
          <div className="rounded-2xl p-6 text-center" style={{
            background: 'linear-gradient(135deg, #0A5F5F 0%, #0D7A7A 100%)'
          }}>
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">
              {nextAppointment ? 'Test Scheduled' : 'Welcome to CareGuard'}
            </h2>
            <p className="text-white/80 text-sm mb-4">
              {appointmentStatus === 'booked' || appointmentStatus === 'confirmed'
                ? `Your test is scheduled for ${nextAppointment?.date || 'soon'}. Once processed, your health data will appear here.`
                : appointmentStatus === 'sample_collected' || appointmentStatus === 'processing'
                ? 'Your sample is being processed! Report will be ready in 24-48 hours.'
                : appointmentStatus === 'report_ready'
                ? 'Your report is ready! View your health insights now.'
                : 'Book your first health test to get started with personalized insights.'
              }
            </p>
            <button
              onClick={() => navigate(appointmentStatus ? '/booking-status' : '/subscription')}
              data-testid="home-cta-btn"
              className="px-6 py-3 bg-white rounded-xl text-teal-700 font-semibold text-sm"
            >
              {appointmentStatus ? 'View Status' : 'Book Your Test'}
            </button>
          </div>
        </div>

        {/* Upcoming Appointments (if any) */}
        {upcomingAppointments.length > 0 && (
          <div className="px-6 mb-4">
            <h3 className="font-semibold text-slate-900 mb-3">Your Scheduled Tests</h3>
            <div className="space-y-3">
              {upcomingAppointments.slice(0, 2).map((apt) => (
                <div key={apt.id} className="health-card p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-teal-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 text-sm">{apt.date}</p>
                      <p className="text-slate-500 text-xs">{apt.time}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    apt.status === 'confirmed' ? 'bg-emerald-50 text-emerald-600' :
                    apt.status === 'sample_collected' ? 'bg-purple-50 text-purple-600' :
                    'bg-amber-50 text-amber-600'
                  }`}>
                    {apt.status?.replace(/_/g, ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty Stats */}
        <div className="px-6 mb-4 grid grid-cols-3 gap-3">
          <div className="health-card p-3 text-center opacity-50">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-2">
              <Info className="w-4 h-4 text-slate-400" />
            </div>
            <p className="text-2xl font-bold text-slate-300">--</p>
            <p className="text-slate-400 text-xs">Tests Done</p>
          </div>
          
          <div className="health-card p-3 text-center opacity-50">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-2">
              <Heart className="w-4 h-4 text-slate-400" />
            </div>
            <p className="text-2xl font-bold text-slate-300">--%</p>
            <p className="text-slate-400 text-xs">Health Score</p>
          </div>
          
          <div className="health-card p-3 text-center opacity-50">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-2">
              <Calendar className="w-4 h-4 text-slate-400" />
            </div>
            <p className="text-2xl font-bold text-slate-300">
              {nextAppointment ? formatAppointmentDate(nextAppointment.date) : '--'}
            </p>
            <p className="text-slate-400 text-xs">Next Test</p>
          </div>
        </div>

        {/* AI Summary Preview - Coming Soon */}
        <div className="px-6 mb-4">
          <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl p-5 text-white shadow-lg">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 backdrop-blur-sm">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-2">AI Health Summary Coming</h3>
                <p className="text-sm opacity-90 leading-relaxed">
                  Once your report is ready, our AI will provide a simple, easy-to-understand health summary with personalized insights.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="bottom-nav h-20 flex items-center justify-around">
          <NavItem icon={TrendingUp} label="Home" active />
          <NavItem icon={FileText} label="Reports" onClick={() => navigate('/reports')} />
          <NavItem icon={Calendar} label="Schedule" onClick={() => navigate('/schedule')} />
          <NavItem icon={User} label="Profile" onClick={() => navigate('/profile')} />
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 flex items-center justify-between">
        <div>
          <p className="text-slate-500 text-sm flex items-center gap-1">
            {greeting} <Sun className="w-4 h-4 text-amber-400" />
          </p>
          <h1 className="text-2xl font-bold text-slate-900">
            {user?.name || 'Guest'}
          </h1>
        </div>
        <button 
          data-testid="notifications-btn"
          onClick={() => navigate('/notifications')}
          className="relative w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center shadow-sm"
        >
          <Bell className="w-5 h-5 text-slate-600" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-medium">
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Today's Health Tip Card */}
      <div className="px-6 mb-4">
        <div className="rounded-2xl p-5 relative overflow-hidden" style={{
          background: 'linear-gradient(135deg, #8B5CF6 0%, #6366F1 50%, #A855F7 100%)'
        }}>
          <div className="flex items-start gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-white/80 text-sm flex items-center gap-1">
                <Lightbulb className="w-4 h-4" /> Today&apos;s Health Tip
              </p>
            </div>
          </div>
          
          <div className="space-y-2 ml-1">
            {healthTips.map((tip, index) => (
              <div key={index} className="flex items-center gap-2 text-white/90 text-sm">
                <tip.icon className={`w-4 h-4 ${tip.color}`} />
                <span>{tip.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Your Health Status Card */}
      <div className="px-6 mb-4">
        <div 
          className="rounded-2xl p-5 relative overflow-hidden cursor-pointer"
          onClick={() => navigate('/health-score')}
          style={{
            background: 'linear-gradient(135deg, #0F766E 0%, #14B8A6 50%, #10B981 100%)'
          }}
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-white/70" />
              <span className="text-white/70 text-sm">Your Health Status</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
          </div>
          
          <h2 className="text-4xl font-bold text-white mb-1">{healthScore?.status || 'Excellent'}</h2>
          <p className="text-white/70 text-sm mb-4">All key metrics are looking great!</p>
          
          <div className="flex gap-3">
            <div className="flex-1 bg-white/20 rounded-xl p-3">
              <p className="text-2xl font-bold text-white">{excellentCount}/{testsCompleted}</p>
              <p className="text-white/70 text-xs">In Range</p>
            </div>
            <div className="flex-1 bg-white/20 rounded-xl p-3">
              <p className="text-2xl font-bold text-white">+5%</p>
              <p className="text-white/70 text-xs">vs Last Test</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-6 mb-4 grid grid-cols-2 gap-3">
        <button 
          data-testid="book-test-btn"
          onClick={() => navigate('/schedule')}
          className="health-card flex items-center gap-3 p-4"
        >
          <div className="w-11 h-11 rounded-xl bg-teal-100 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-teal-600" />
          </div>
          <div className="text-left">
            <p className="font-semibold text-slate-900 text-sm">Book Test</p>
            <p className="text-slate-500 text-xs">Schedule home visit</p>
          </div>
        </button>
        
        <button 
          data-testid="view-reports-btn"
          onClick={() => navigate('/reports')}
          className="health-card flex items-center gap-3 p-4"
        >
          <div className="w-11 h-11 rounded-xl bg-violet-100 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-violet-600" />
          </div>
          <div className="text-left">
            <p className="font-semibold text-slate-900 text-sm">View Reports</p>
            <p className="text-slate-500 text-xs">See all results</p>
          </div>
        </button>
      </div>

      {/* Key Metrics */}
      <div className="px-6 mb-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-slate-900">Key Metrics</h3>
          <button 
            data-testid="view-all-metrics"
            onClick={() => navigate('/metrics')}
            className="text-sm text-teal-600 font-medium"
          >
            View All
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {keyMetrics.map((metric, index) => (
            <div key={index} className="health-card p-4">
              <div className="flex items-start justify-between mb-2">
                <div className={`w-8 h-8 rounded-lg ${metric.iconBg} flex items-center justify-center`}>
                  <metric.icon className={`w-4 h-4 ${metric.iconColor}`} />
                </div>
                {metric.hasComparison && (
                  <div className="flex items-center gap-1">
                    {getTrendIcon(metric.trend)}
                    <span className={`text-xs font-medium ${
                      metric.trend === 'up' ? 'text-emerald-500' : 
                      metric.trend === 'down' ? 'text-amber-500' : 'text-slate-400'
                    }`}>
                      {metric.change}
                    </span>
                  </div>
                )}
              </div>
              
              <p className="text-slate-600 text-xs font-medium mb-1">{metric.name}</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-2xl font-bold text-slate-900">{metric.value}</span>
                <span className="text-slate-400 text-xs">{metric.unit}</span>
              </div>
              
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusColor(metric.statusColor)}`}>
                {metric.status}
              </span>
              
              <div className="mt-3 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${getProgressColor(metric.statusColor)}`}
                  style={{ width: `${metric.progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Why It Matters - AI Section */}
      <div className="px-6 mb-4">
        <div className="health-card border-l-4 border-orange-400 p-4">
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="w-5 h-5 text-orange-400" />
            <span className="font-semibold text-slate-900">Your AI Health Summary</span>
            <span className="text-xs bg-violet-100 text-violet-600 px-2 py-0.5 rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> AI
            </span>
            {aiRecommendations?.generated_for && (
              <span className="text-xs text-slate-400 ml-auto">
                For {aiRecommendations.generated_for}
              </span>
            )}
          </div>
          
          {loadingAI ? (
            <div className="flex items-center gap-2 text-slate-500">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Generating personalized insights...</span>
            </div>
          ) : (
            <>
              <p className="text-slate-600 text-sm leading-relaxed mb-3">
                {aiSummary}
              </p>
              
              <div className="space-y-2">
                {healthScore?.insights?.filter(i => i.type === 'positive').slice(0, 2).map((insight, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm text-slate-600">
                    <span className="text-emerald-500">✓</span>
                    <span>{insight.text}</span>
                  </div>
                ))}
                {healthScore?.insights?.filter(i => i.type === 'warning').slice(0, 1).map((insight, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm text-slate-600">
                    <span className="text-amber-500">⚠</span>
                    <span>{insight.text}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* What to Do Next - AI Recommendations */}
      <div className="px-6 mb-4">
        <div className="rounded-2xl p-5 overflow-hidden" style={{
          background: 'linear-gradient(135deg, #0F766E 0%, #115E59 100%)'
        }}>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <span className="text-white text-lg">✓</span>
            </div>
            <div>
              <h3 className="font-semibold text-white flex items-center gap-2">
                What to Do Next
                <span className="text-xs bg-white/20 text-white/90 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> AI
                </span>
              </h3>
              <p className="text-white/70 text-xs">Tap for detailed recommendations:</p>
            </div>
          </div>
          
          <div className="space-y-3">
            {recommendations.map((rec, index) => (
              <button
                key={index}
                onClick={() => setSelectedRecommendation(rec)}
                data-testid={`recommendation-${index}`}
                className="w-full bg-white/10 rounded-xl p-3 text-left hover:bg-white/20 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg ${rec.iconBg} flex items-center justify-center flex-shrink-0`}>
                    <rec.icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-white text-sm mb-1 flex items-center justify-between">
                      {rec.title}
                      <ChevronRight className="w-4 h-4 text-white/50" />
                    </p>
                    <p className="text-white/70 text-xs leading-relaxed line-clamp-2">{rec.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="px-6 mb-4 grid grid-cols-3 gap-3">
        <button onClick={() => navigate('/tests-completed')} className="health-card p-3 text-center">
          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-2">
            <Info className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{testsCompleted}</p>
          <p className="text-slate-500 text-xs">Tests Done</p>
        </button>
        
        <button onClick={() => navigate('/health-score')} className="health-card p-3 text-center">
          <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center mx-auto mb-2">
            <Heart className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{healthScoreValue}%</p>
          <p className="text-slate-500 text-xs">Health Score</p>
        </button>
        
        <button onClick={() => navigate('/schedule')} className="health-card p-3 text-center">
          <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center mx-auto mb-2">
            <Calendar className="w-4 h-4 text-violet-500" />
          </div>
          <p className="text-2xl font-bold text-slate-900">Jan 10</p>
          <p className="text-slate-500 text-xs">Next Test</p>
        </button>
      </div>

      {/* Ask AI Banner */}
      <div className="px-6 mb-4">
        <button 
          data-testid="ask-ai-btn"
          onClick={() => setShowAIChat(true)}
          className="w-full rounded-2xl p-4 flex items-center justify-between"
          style={{
            background: 'linear-gradient(135deg, #EC4899 0%, #A855F7 100%)'
          }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <p className="font-semibold text-white">Ask AI About Your Health</p>
              <p className="text-white/70 text-xs">Get answers about your test results</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Next Health Check */}
      <div className="px-6 mb-6">
        <button 
          onClick={() => navigate('/schedule')}
          className="w-full health-card border-l-4 border-teal-500 p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center">
              <Clock className="w-5 h-5 text-teal-600" />
            </div>
            <div className="text-left">
              <p className="font-semibold text-slate-900 text-sm">Next Health Check</p>
              <p className="text-slate-500 text-xs">January 9, 2026 - 10:00 AM</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400" />
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="bottom-nav h-20 flex items-center justify-around">
        <NavItem icon={TrendingUp} label="Home" active />
        <NavItem icon={FileText} label="Reports" onClick={() => navigate('/reports')} />
        <NavItem icon={Calendar} label="Schedule" onClick={() => navigate('/schedule')} />
        <NavItem icon={User} label="Profile" onClick={() => navigate('/profile')} />
      </div>

      {/* AI Chat Modal */}
      <AIChatModal isOpen={showAIChat} onClose={() => setShowAIChat(false)} />
      
      {/* Recommendation Modal */}
      <RecommendationModal 
        isOpen={!!selectedRecommendation} 
        onClose={() => setSelectedRecommendation(null)}
        recommendation={selectedRecommendation}
      />
    </div>
  );
};

// Helper functions
const getStatusColorName = (status) => {
  const normalizedStatus = status?.toLowerCase() || '';
  const mapping = {
    'excellent': 'emerald',
    'optimal': 'emerald',
    'normal': 'cyan',
    'slightly low': 'amber',
    'slightly high': 'amber',
    'borderline': 'amber',
    'low': 'rose',
    'high': 'rose',
    'needs_attention': 'rose',
    'needs attention': 'rose'
  };
  return mapping[normalizedStatus] || 'cyan';
};

const getMetricIcon = (name, category) => {
  // First try to match by biomarker name for more accurate icons
  const nameLower = name?.toLowerCase() || '';
  
  // Blood Sugar / Glucose - use Activity (waveform) icon
  if (nameLower.includes('glucose') || nameLower.includes('sugar') || nameLower.includes('hba1c') || nameLower.includes('fasting')) return Activity;
  
  // Vitamins
  if (nameLower.includes('vitamin d') || nameLower.includes('vit d')) return Sun;
  if (nameLower.includes('vitamin b12') || nameLower.includes('b12')) return Pill;
  
  // Cholesterol / Heart
  if (nameLower.includes('cholesterol') || nameLower.includes('ldl') || nameLower.includes('hdl') || nameLower.includes('triglyceride')) return Heart;
  
  // Blood related
  if (nameLower.includes('hemoglobin') || nameLower.includes('rbc') || nameLower.includes('wbc') || nameLower.includes('platelet')) return Droplet;
  
  // Iron
  if (nameLower.includes('iron') || nameLower.includes('ferritin') || nameLower.includes('tibc') || nameLower.includes('transferrin')) return Zap;
  
  // Kidney
  if (nameLower.includes('creatinine') || nameLower.includes('kidney') || nameLower.includes('egfr') || nameLower.includes('urine')) return Beaker;
  
  // Thyroid
  if (nameLower.includes('tsh') || nameLower.includes('thyroid') || nameLower.includes('t3') || nameLower.includes('t4')) return Thermometer;
  
  // Fallback to category
  const icons = {
    'Blood': Droplet,
    'Heart': Heart,
    'Vitamins': Sun,
    'Metabolic': Activity,
    'Kidney': Beaker,
    'Hormones': Thermometer,
    'Parsed': Info
  };
  return icons[category] || TrendingUp;
};

const getIconBg = (name, category) => {
  const nameLower = name?.toLowerCase() || '';
  
  // Blood Sugar / Glucose - cyan
  if (nameLower.includes('glucose') || nameLower.includes('sugar') || nameLower.includes('hba1c') || nameLower.includes('fasting')) return 'bg-cyan-100';
  
  // Vitamins
  if (nameLower.includes('vitamin d') || nameLower.includes('vit d')) return 'bg-amber-100';
  if (nameLower.includes('vitamin b12') || nameLower.includes('b12')) return 'bg-purple-100';
  
  // Cholesterol - rose/red
  if (nameLower.includes('cholesterol') || nameLower.includes('ldl') || nameLower.includes('hdl') || nameLower.includes('triglyceride')) return 'bg-rose-100';
  
  // Blood - red
  if (nameLower.includes('hemoglobin') || nameLower.includes('rbc') || nameLower.includes('wbc') || nameLower.includes('platelet')) return 'bg-red-100';
  
  // Iron - yellow/orange
  if (nameLower.includes('iron') || nameLower.includes('ferritin') || nameLower.includes('tibc') || nameLower.includes('transferrin')) return 'bg-orange-100';
  
  // Kidney - blue
  if (nameLower.includes('creatinine') || nameLower.includes('kidney') || nameLower.includes('egfr') || nameLower.includes('urine')) return 'bg-blue-100';
  
  // Thyroid - violet
  if (nameLower.includes('tsh') || nameLower.includes('thyroid') || nameLower.includes('t3') || nameLower.includes('t4')) return 'bg-violet-100';
  
  const bgs = {
    'Blood': 'bg-red-100',
    'Heart': 'bg-rose-100',
    'Vitamins': 'bg-amber-100',
    'Metabolic': 'bg-cyan-100'
  };
  return bgs[category] || 'bg-slate-100';
};

const getIconColor = (name, category) => {
  const nameLower = name?.toLowerCase() || '';
  
  // Blood Sugar / Glucose - cyan
  if (nameLower.includes('glucose') || nameLower.includes('sugar') || nameLower.includes('hba1c') || nameLower.includes('fasting')) return 'text-cyan-600';
  
  // Vitamins
  if (nameLower.includes('vitamin d') || nameLower.includes('vit d')) return 'text-amber-500';
  if (nameLower.includes('vitamin b12') || nameLower.includes('b12')) return 'text-purple-500';
  
  // Cholesterol - rose
  if (nameLower.includes('cholesterol') || nameLower.includes('ldl') || nameLower.includes('hdl') || nameLower.includes('triglyceride')) return 'text-rose-500';
  
  // Blood - red
  if (nameLower.includes('hemoglobin') || nameLower.includes('rbc') || nameLower.includes('wbc') || nameLower.includes('platelet')) return 'text-red-500';
  
  // Iron - orange
  if (nameLower.includes('iron') || nameLower.includes('ferritin') || nameLower.includes('tibc') || nameLower.includes('transferrin')) return 'text-orange-500';
  
  // Kidney - blue
  if (nameLower.includes('creatinine') || nameLower.includes('kidney') || nameLower.includes('egfr') || nameLower.includes('urine')) return 'text-blue-500';
  
  // Thyroid - violet
  if (nameLower.includes('tsh') || nameLower.includes('thyroid') || nameLower.includes('t3') || nameLower.includes('t4')) return 'text-violet-500';
  
  const colors = {
    'Blood': 'text-red-500',
    'Heart': 'text-rose-500',
    'Vitamins': 'text-amber-500',
    'Metabolic': 'text-cyan-500'
  };
  return colors[category] || 'text-slate-500';
};

const getProgressValue = (status) => {
  const normalizedStatus = status?.toLowerCase() || '';
  const values = {
    'excellent': 90,
    'optimal': 85,
    'normal': 75,
    'slightly low': 50,
    'slightly high': 50,
    'borderline': 50,
    'low': 30,
    'high': 30,
    'needs_attention': 30,
    'needs attention': 30
  };
  return values[normalizedStatus] || 70;
};

const getTrendIcon = (trend) => {
  if (trend === 'up') return <TrendingUp className="w-4 h-4 text-emerald-500" />;
  if (trend === 'down') return <TrendingDown className="w-4 h-4 text-amber-500" />;
  return <Minus className="w-4 h-4 text-slate-400" />;
};

const getStatusColor = (color) => {
  const colors = {
    emerald: 'text-emerald-600 bg-emerald-50',
    amber: 'text-amber-600 bg-amber-50',
    cyan: 'text-cyan-600 bg-cyan-50',
    violet: 'text-violet-600 bg-violet-50',
    rose: 'text-rose-600 bg-rose-50'
  };
  return colors[color] || colors.cyan;
};

const getProgressColor = (color) => {
  const colors = {
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
    cyan: 'bg-cyan-500',
    violet: 'bg-violet-500',
    rose: 'bg-rose-500'
  };
  return colors[color] || colors.cyan;
};

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button 
    data-testid={`nav-${label.toLowerCase()}`}
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 p-2 min-w-[60px] ${
      active ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
    } transition-colors`}
  >
    <Icon className="w-5 h-5" strokeWidth={active ? 2 : 1.5} />
    <span className="text-xs font-medium">{label}</span>
  </button>
);

export default HomePage;
