import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Shield, Activity, Calendar, Bell } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const WelcomePage = () => {
  const navigate = useNavigate();
  const { isAuthenticated, loading } = useAuth();

  // Redirect to home if already authenticated
  useEffect(() => {
    if (!loading && isAuthenticated) {
      navigate('/home');
    }
  }, [isAuthenticated, loading, navigate]);

  const features = [
    { icon: Activity, text: 'Track your biomarkers' },
    { icon: Calendar, text: 'Schedule health tests' },
    { icon: Bell, text: 'Get personalized nudges' },
    { icon: Shield, text: 'UAE data protection' },
  ];

  // Show loading while checking auth
  if (loading) {
    return (
      <div className="mobile-container min-h-screen flex items-center justify-center bg-[#0F766E]">
        <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen flex flex-col">
      {/* Hero Section */}
      <div className="relative flex-1 bg-[#0F766E] hero-pattern overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute top-10 right-10 w-32 h-32 bg-white/5 rounded-full" />
        <div className="absolute top-40 -left-10 w-48 h-48 bg-white/5 rounded-full" />
        <div className="absolute bottom-20 right-5 w-24 h-24 bg-white/5 rounded-full" />
        
        {/* Decorative plant illustration */}
        <div className="absolute bottom-0 right-0 w-48 h-64 opacity-30">
          <svg viewBox="0 0 200 300" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M100 300 Q90 250 100 200 Q110 250 100 300" fill="#fff" opacity="0.3"/>
            <path d="M100 200 Q60 180 40 140 Q80 160 100 200" fill="#fff" opacity="0.4"/>
            <path d="M100 200 Q140 180 160 140 Q120 160 100 200" fill="#fff" opacity="0.4"/>
            <path d="M100 160 Q50 130 30 80 Q70 110 100 160" fill="#fff" opacity="0.3"/>
            <path d="M100 160 Q150 130 170 80 Q130 110 100 160" fill="#fff" opacity="0.3"/>
            <ellipse cx="100" cy="50" rx="30" ry="40" fill="#fff" opacity="0.2"/>
          </svg>
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-end h-full px-8 pb-12 pt-20">
          <div className="animate-fade-in-up">
            <h1 className="text-4xl font-bold text-white leading-tight mb-4">
              Empowering<br />
              Your Health<br />
              Journey
            </h1>
            <p className="text-white/80 text-lg leading-relaxed mb-8 max-w-xs">
              Join the healthcare revolution. Monitor your health, understand your tests, and take proactive steps.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-white px-8 py-8 rounded-t-3xl -mt-6 relative z-20">
        {/* Features */}
        <div className="grid grid-cols-2 gap-3 mb-8 animate-fade-in-up animate-delay-100">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="flex items-center gap-2 text-slate-600 text-sm"
            >
              <div className="w-8 h-8 rounded-full bg-teal-50 flex items-center justify-center">
                <feature.icon className="w-4 h-4 text-[#0F766E]" />
              </div>
              <span>{feature.text}</span>
            </div>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="space-y-3 animate-fade-in-up animate-delay-200">
          <button
            data-testid="login-btn"
            onClick={() => navigate('/login')}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            <span>LOG IN</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <button
            data-testid="signup-btn"
            onClick={() => navigate('/login?signup=true')}
            className="w-full btn-secondary flex items-center justify-center gap-2"
          >
            <span>OPEN ACCOUNT</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Footer text */}
        <p className="text-center text-slate-400 text-xs mt-6">
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </div>
    </div>
  );
};

export default WelcomePage;
