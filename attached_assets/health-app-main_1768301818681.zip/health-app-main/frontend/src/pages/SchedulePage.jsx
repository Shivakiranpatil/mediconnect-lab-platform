import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Calendar as CalendarIcon, Clock, MapPin, CheckCircle,
  ChevronLeft, ChevronRight, FileText, User, Activity, Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { appointmentService } from '@/config/supabase';

const SchedulePage = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedTest, setSelectedTest] = useState('cbc');
  const [upcomingTests, setUpcomingTests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAppointments();
  }, [user]);

  const fetchAppointments = async () => {
    if (!isAuthenticated || !user?.id) {
      setLoading(false);
      return;
    }

    try {
      const data = await appointmentService.getUserAppointments(user.id);
      
      // Transform upcoming appointments for display
      const upcoming = (data.upcoming || []).map(apt => ({
        id: apt.id,
        name: apt.test_name || 'Health Test',
        date: formatDate(apt.date),
        time: apt.time,
        location: 'Home Collection Service',
        status: formatStatus(apt.status)
      }));
      
      setUpcomingTests(upcoming);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  const formatStatus = (status) => {
    const statusMap = {
      'booked': 'Pending',
      'pending': 'Pending',
      'confirmed': 'Confirmed',
      'sample_collected': 'Sample Collected',
      'processing': 'Processing',
      'report_ready': 'Report Ready',
      'completed': 'Completed'
    };
    return statusMap[status] || status;
  };

  const testTypes = [
    { id: 'cbc', name: 'Complete Blood Count (CBC)' },
    { id: 'lipid', name: 'Lipid Profile' },
    { id: 'thyroid', name: 'Thyroid Panel' },
    { id: 'vitamin', name: 'Vitamin Panel' },
    { id: 'kidney', name: 'Kidney Function Test' },
    { id: 'liver', name: 'Liver Function Test' }
  ];

  const timeSlots = [
    '8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM',
    '11:00 AM', '11:30 AM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM'
  ];

  // Calendar helpers
  const daysInMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1).getDay();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  const prevMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 1));
  };

  const selectDay = (day) => {
    const newDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
    if (newDate >= new Date().setHours(0,0,0,0)) {
      setSelectedDate(newDate);
    }
  };

  const isToday = (day) => {
    const today = new Date();
    return day === today.getDate() && 
           selectedDate.getMonth() === today.getMonth() && 
           selectedDate.getFullYear() === today.getFullYear();
  };

  const isSelectedDay = (day) => {
    return day === selectedDate.getDate();
  };

  const isPastDay = (day) => {
    const checkDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
    return checkDate < new Date().setHours(0,0,0,0);
  };

  const handleBooking = () => {
    if (!selectedTime) {
      toast.error('Please select a time slot');
      return;
    }
    toast.success('Appointment booked successfully!');
    navigate('/home');
  };

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-100">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Schedule</h1>
            <p className="text-sm text-slate-500">Manage your appointments</p>
          </div>
        </div>
      </div>

      {/* Upcoming Tests */}
      <div className="px-6 py-4">
        <h2 className="font-semibold text-slate-900 mb-3">Upcoming Tests</h2>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 text-teal-600 animate-spin" />
          </div>
        ) : upcomingTests.length > 0 ? (
          <div className="space-y-3">
            {upcomingTests.map((test) => (
              <div key={test.id} className="health-card p-4" data-testid={`upcoming-test-${test.id}`}>
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-slate-900 text-sm">{test.name}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    test.status === 'Confirmed' 
                      ? 'bg-emerald-50 text-emerald-600' 
                      : test.status === 'Completed'
                      ? 'bg-teal-50 text-teal-600'
                      : 'bg-amber-50 text-amber-600'
                  }`}>
                    {test.status}
                  </span>
                </div>
                <div className="space-y-2 text-sm text-slate-500">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4" />
                    <span>{test.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{test.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{test.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="health-card p-6 text-center">
            <CalendarIcon className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 text-sm">No upcoming tests scheduled</p>
            <p className="text-slate-400 text-xs mt-1">Book a test below to get started</p>
          </div>
        )}
      </div>

      {/* Book New Test */}
      <div className="px-6 py-4">
        <h2 className="font-semibold text-slate-900 mb-3">Book New Test</h2>
        
        {/* Calendar */}
        <div className="health-card p-4 mb-4">
          {/* Month Navigation */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevMonth} className="p-2 hover:bg-slate-100 rounded-lg">
              <ChevronLeft className="w-5 h-5 text-slate-600" />
            </button>
            <h3 className="font-semibold text-slate-900">
              {monthNames[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </h3>
            <button onClick={nextMonth} className="p-2 hover:bg-slate-100 rounded-lg">
              <ChevronRight className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          {/* Day Names */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {dayNames.map((day) => (
              <div key={day} className="text-center text-xs font-medium text-slate-400 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDayOfMonth }).map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const past = isPastDay(day);
              const today = isToday(day);
              const selected = isSelectedDay(day);
              
              return (
                <button
                  key={day}
                  onClick={() => selectDay(day)}
                  disabled={past}
                  className={`aspect-square rounded-xl flex items-center justify-center text-sm font-medium transition-all ${
                    selected
                      ? 'bg-teal-600 text-white'
                      : today
                      ? 'bg-teal-100 text-teal-600'
                      : past
                      ? 'text-slate-300 cursor-not-allowed'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>

        {/* Test Type */}
        <div className="health-card p-4 mb-4">
          <h3 className="font-semibold text-slate-900 text-sm mb-3">Test Type</h3>
          <select
            value={selectedTest}
            onChange={(e) => setSelectedTest(e.target.value)}
            className="w-full p-3 border border-slate-200 rounded-xl text-slate-900 bg-white focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
            data-testid="test-type-select"
          >
            {testTypes.map((test) => (
              <option key={test.id} value={test.id}>{test.name}</option>
            ))}
          </select>
        </div>

        {/* Time Slots */}
        <div className="health-card p-4 mb-4">
          <h3 className="font-semibold text-slate-900 text-sm mb-3">Available Time Slots</h3>
          <div className="grid grid-cols-3 gap-2">
            {timeSlots.map((time) => (
              <button
                key={time}
                onClick={() => setSelectedTime(time)}
                data-testid={`time-slot-${time.replace(/[\s:]/g, '-')}`}
                className={`py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                  selectedTime === time
                    ? 'bg-teal-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {time}
              </button>
            ))}
          </div>
        </div>

        {/* Booking Summary */}
        {selectedTime && (
          <div className="health-card p-4 mb-4 border-l-4 border-teal-500">
            <h3 className="font-semibold text-slate-900 text-sm mb-2">Booking Summary</h3>
            <div className="space-y-2 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-teal-500" />
                <span>{testTypes.find(t => t.id === selectedTest)?.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-teal-500" />
                <span>{selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-teal-500" />
                <span>{selectedTime}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-teal-500" />
                <span>Home Collection Service</span>
              </div>
            </div>
          </div>
        )}

        {/* Confirm Button */}
        <button
          onClick={handleBooking}
          disabled={!selectedTime}
          data-testid="confirm-booking-btn"
          className={`w-full py-4 rounded-xl font-semibold transition-all ${
            selectedTime
              ? 'bg-teal-600 text-white hover:bg-teal-700'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          Confirm Booking
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="bottom-nav h-20 flex items-center justify-around">
        <NavItem icon={Activity} label="Home" onClick={() => navigate('/home')} />
        <NavItem icon={FileText} label="Reports" onClick={() => navigate('/reports')} />
        <NavItem icon={CalendarIcon} label="Schedule" active />
        <NavItem icon={User} label="Profile" onClick={() => navigate('/profile')} />
      </div>
    </div>
  );
};

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button 
    data-testid={`nav-${label.toLowerCase()}`}
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 p-2 min-w-[60px] ${
      active ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
    } transition-colors`}
  >
    <Icon className="w-5 h-5" strokeWidth={active ? 2 : 1.5} />
    <span className="text-xs font-medium">{label}</span>
  </button>
);

export default SchedulePage;
