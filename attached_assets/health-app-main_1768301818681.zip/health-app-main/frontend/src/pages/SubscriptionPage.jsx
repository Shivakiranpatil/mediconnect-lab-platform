import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Sparkles, Heart, Users, Clock, TrendingUp, Shield, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

const SubscriptionPage = () => {
  const navigate = useNavigate();
  const { selectPlan } = useAuth();
  const [planType, setPlanType] = useState('individual');
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!selectedPackage) {
      toast.error('Please select a plan');
      return;
    }

    setLoading(true);
    
    try {
      // Save subscription selection using AuthContext
      await selectPlan(selectedPackage);
      toast.success('Plan selected!');
      // Navigate to profile completion page with package info
      navigate(`/profile-complete?package=${selectedPackage}`);
    } catch (error) {
      console.error('Error selecting subscription:', error);
      // Still navigate even if API fails for now
      navigate(`/profile-complete?package=${selectedPackage}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mobile-container min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/30 pb-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A] px-6 pt-12 pb-8 text-white">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
            <Heart className="w-5 h-5" fill="currentColor" />
          </div>
          <h1 className="text-3xl font-bold">Choose Your Plan</h1>
        </div>
        <p className="text-white/90 leading-relaxed">
          Start your preventive health journey with packages designed for your needs
        </p>
      </div>

      <div className="px-6 pt-6">
        {/* Toggle Individual/Family */}
        <div className="bg-white rounded-2xl p-1.5 shadow-sm mb-6 grid grid-cols-2 gap-1">
          <button
            data-testid="plan-individual"
            onClick={() => setPlanType('individual')}
            className={`py-3 px-4 rounded-xl font-medium transition-all ${
              planType === 'individual'
                ? 'bg-gradient-to-br from-[#0A5F5F] to-[#10B981] text-white shadow-md'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Individual
          </button>
          <button
            data-testid="plan-family"
            onClick={() => setPlanType('family')}
            className={`py-3 px-4 rounded-xl font-medium transition-all ${
              planType === 'family'
                ? 'bg-gradient-to-br from-[#8B5CF6] to-[#EC4899] text-white shadow-md'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Family
          </button>
        </div>

        {planType === 'individual' ? (
          <IndividualPackages selectedPackage={selectedPackage} onSelect={setSelectedPackage} />
        ) : (
          <FamilyPackages selectedPackage={selectedPackage} onSelect={setSelectedPackage} />
        )}

        {/* Continue Button */}
        <div className="mt-6 sticky bottom-6">
          <button
            data-testid="continue-btn"
            onClick={handleContinue}
            disabled={!selectedPackage || loading}
            className="w-full h-14 text-lg bg-gradient-to-r from-[#0A5F5F] to-[#10B981] hover:from-[#083f3f] hover:to-[#0d8f6f] text-white shadow-xl rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-semibold"
          >
            Continue
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

const IndividualPackages = ({ selectedPackage, onSelect }) => {
  return (
    <div className="space-y-6">
      {/* Starter Package */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-3">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
          <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">Starter Package</h3>
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
        </div>
        
        <button
          data-testid="package-individual-starter"
          onClick={() => onSelect('individual-starter')}
          className={`w-full text-left transition-all ${
            selectedPackage === 'individual-starter' ? 'scale-[1.02]' : ''
          }`}
        >
          <div className={`bg-white rounded-3xl p-6 shadow-lg border-2 transition-all ${
            selectedPackage === 'individual-starter'
              ? 'border-[#0A5F5F] shadow-xl'
              : 'border-gray-200 hover:border-gray-300'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="inline-flex items-center gap-1 bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold mb-2">
                  <Sparkles className="w-3 h-3" />
                  One-time • First-timers
                </div>
                <h4 className="text-xl font-bold text-gray-900">Individual Starter</h4>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-[#0A5F5F]">AED 99</div>
              </div>
            </div>

            <div className="space-y-2.5 mb-4">
              <Feature text="1 home blood & urine test (limited preventive panel)" />
              <Feature text="AI-based report explanation in simple words" />
              <Feature text="Health summary (Normal / Borderline / Needs Attention)" />
              <Feature text="App access for 30 days" />
            </div>

            <div className="bg-blue-50 rounded-xl p-3 border border-blue-200">
              <p className="text-xs text-blue-800 font-medium">
                <span className="font-bold">Best for:</span> First-time users • Curious • Price-sensitive customers
              </p>
            </div>
          </div>
        </button>
      </div>

      {/* Preventive Membership */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-3">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
          <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">Preventive Membership</h3>
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
        </div>

        {/* Preventive Starter */}
        <button
          data-testid="package-preventive-starter"
          onClick={() => onSelect('preventive-starter')}
          className={`w-full text-left transition-all ${
            selectedPackage === 'preventive-starter' ? 'scale-[1.02]' : ''
          }`}
        >
          <div className={`bg-white rounded-3xl p-6 shadow-lg border-2 transition-all ${
            selectedPackage === 'preventive-starter'
              ? 'border-green-500 shadow-xl'
              : 'border-gray-200 hover:border-gray-300'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold mb-2">
                  <Shield className="w-3 h-3" />
                  Subscription
                </div>
                <h4 className="text-xl font-bold text-gray-900">Preventive Starter</h4>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-green-600">AED 449</div>
                <div className="text-xs text-gray-500">6 months</div>
              </div>
            </div>

            <div className="space-y-2.5 mb-4">
              <Feature text={<><span className="font-semibold">2 home tests</span> (valid for 6 months)</>} />
              <Feature text="AI insights after each test" />
              <Feature text="Health trends (compare test 1 vs test 2)" />
              <Feature text="Smart nudges & reminders" />
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>AED 224.50 per test</span>
              <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">Save 55%</span>
            </div>
          </div>
        </button>

        {/* Preventive Plus - Most Popular */}
        <button
          data-testid="package-preventive-plus"
          onClick={() => onSelect('preventive-plus')}
          className={`w-full text-left transition-all relative ${
            selectedPackage === 'preventive-plus' ? 'scale-[1.02]' : ''
          }`}
        >
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
            <div className="bg-gradient-to-r from-[#0A5F5F] to-[#10B981] text-white px-4 py-1 rounded-full text-xs font-bold shadow-lg">
              ⭐ MOST POPULAR
            </div>
          </div>
          
          <div className={`bg-white rounded-3xl p-6 shadow-lg border-2 transition-all ${
            selectedPackage === 'preventive-plus'
              ? 'border-[#0A5F5F] shadow-xl'
              : 'border-[#0A5F5F]/30 hover:border-[#0A5F5F]/50'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="inline-flex items-center gap-1 bg-cyan-100 text-cyan-700 px-3 py-1 rounded-full text-xs font-semibold mb-2">
                  <TrendingUp className="w-3 h-3" />
                  Subscription
                </div>
                <h4 className="text-xl font-bold text-gray-900">Preventive Plus</h4>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-[#0A5F5F]">AED 649</div>
                <div className="text-xs text-gray-500">12 months</div>
              </div>
            </div>

            <div className="space-y-2.5 mb-4">
              <Feature text={<><span className="font-semibold">3 home tests</span> (valid for 12 months)</>} />
              <Feature text="Full health timeline" />
              <Feature text="Priority booking slots" />
              <Feature text="AI insights + trend tracking" />
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>AED 216.33 per test</span>
              <span className="bg-cyan-100 text-cyan-700 px-2 py-1 rounded-full font-medium">Save 60%</span>
            </div>
          </div>
        </button>

        {/* Elderly/Chronic Care */}
        <button
          data-testid="package-elderly-care"
          onClick={() => onSelect('elderly-care')}
          className={`w-full text-left transition-all ${
            selectedPackage === 'elderly-care' ? 'scale-[1.02]' : ''
          }`}
        >
          <div className={`bg-white rounded-3xl p-6 shadow-lg border-2 transition-all ${
            selectedPackage === 'elderly-care'
              ? 'border-purple-500 shadow-xl'
              : 'border-gray-200 hover:border-gray-300'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="inline-flex items-center gap-1 bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-semibold mb-2">
                  <Heart className="w-3 h-3" />
                  Subscription
                </div>
                <h4 className="text-xl font-bold text-gray-900">Elderly / Chronic Care</h4>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-purple-600">AED 849</div>
                <div className="text-xs text-gray-500">12 months</div>
              </div>
            </div>

            <div className="space-y-2.5 mb-4">
              <Feature text={<><span className="font-semibold">4 home tests</span> (valid for 12 months)</>} />
              <Feature text="Designed for regular monitoring" />
              <Feature text="Strong nudges & follow-up reminders" />
              <Feature text="All Premium features included" />
            </div>

            <div className="bg-purple-50 rounded-xl p-3 border border-purple-200">
              <p className="text-xs text-purple-800 font-medium">
                <span className="font-bold">Best for:</span> Parents • Chronic condition monitoring • Regular care
              </p>
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500 mt-3">
              <span>AED 212.25 per test</span>
              <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full font-medium">Save 62%</span>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};

const FamilyPackages = ({ selectedPackage, onSelect }) => {
  const familyStarter = [
    { id: 'family-of-2', size: 'Family of 2', price: 199, perPerson: 99, saving: '50%' },
    { id: 'family-of-3', size: 'Family of 3', price: 299, perPerson: 99, saving: '66%' },
    { id: 'family-of-4', size: 'Family of 4', price: 399, perPerson: 99, saving: '75%' },
  ];

  return (
    <div className="space-y-6">
      {/* Family Starter Package */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-3">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
          <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">Family Starter Package</h3>
          <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-lg border-2 border-gray-200">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="inline-flex items-center gap-1 bg-pink-100 text-pink-700 px-3 py-1 rounded-full text-xs font-semibold mb-2">
                <Users className="w-3 h-3" />
                One-time • Same visit, same slot
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">Family Starter</h4>
              <p className="text-sm text-gray-500">Choose your family size</p>
            </div>
          </div>

          <div className="space-y-3 mb-4">
            {familyStarter.map((option) => (
              <button
                key={option.id}
                data-testid={`package-${option.id}`}
                onClick={() => onSelect(option.id)}
                className={`w-full text-left p-4 rounded-2xl border-2 transition-all ${
                  selectedPackage === option.id
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-200 hover:border-pink-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-gray-900">{option.size}</div>
                    <div className="text-xs text-gray-500">AED {option.perPerson}/person</div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-pink-600">AED {option.price}</div>
                    <div className="text-xs text-green-600 font-medium">Save {option.saving}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>

          <div className="space-y-2.5 mb-4 bg-gray-50 rounded-xl p-4">
            <p className="text-xs font-semibold text-gray-700 mb-2">Includes for each family member:</p>
            <FeatureSmall text="Home test for each family member" />
            <FeatureSmall text="Individual AI report for each person" />
            <FeatureSmall text="Family health overview (high-level)" />
            <FeatureSmall text="App access for 30 days" />
          </div>

          <div className="bg-pink-50 rounded-xl p-3 border border-pink-200">
            <p className="text-xs text-pink-800 font-medium">
              <span className="font-bold">Best for:</span> Couples • Parents testing together • First-time family users
            </p>
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-5 text-white shadow-lg">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 backdrop-blur-sm">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold mb-2">Family Preventive Plans Coming Soon!</h4>
            <p className="text-sm opacity-90 leading-relaxed">
              We're working on subscription packages for families. Start with our Family Starter package today and upgrade when available.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const Feature = ({ text }) => (
  <div className="flex items-start gap-2">
    <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
    <span className="text-sm text-gray-700">{text}</span>
  </div>
);

const FeatureSmall = ({ text }) => (
  <div className="flex items-start gap-2">
    <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
    <span className="text-xs text-gray-700">{text}</span>
  </div>
);

export default SubscriptionPage;
