import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Download, ChevronDown, ChevronUp, CheckCircle,
  FileText, Calendar, Home as HomeIcon, User, Activity, Droplet
} from 'lucide-react';

const ReportsPage = () => {
  const navigate = useNavigate();
  const [expandedSections, setExpandedSections] = useState(['cbc', 'lipid']);

  const toggleSection = (section) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const reports = [
    {
      id: 'cbc',
      name: 'Complete Blood Count (CBC)',
      package: 'Preventive Plus Package',
      date: 'December 28, 2025',
      status: 'Done',
      parameters: [
        { name: 'Red Blood Cell Count (RBC)', value: '5.2 M/µL', range: '4.5 - 5.5', status: 'Normal', statusColor: 'emerald' },
        { name: 'Hemoglobin', value: '14.2 g/dL', range: '12.5 - 17.5', status: 'Excellent', statusColor: 'violet' },
        { name: 'White Blood Cell Count (WBC)', value: '7.8 K/µL', range: '4.5 - 11.0', status: 'Normal', statusColor: 'emerald' },
        { name: 'Platelet Count', value: '250 K/µL', range: '150 - 400', status: 'Normal', statusColor: 'emerald' }
      ],
      notes: 'All blood count parameters are within normal range. Hemoglobin levels are excellent, indicating good oxygen-carrying capacity.'
    },
    {
      id: 'vitamin',
      name: 'Vitamin Panel',
      package: 'Preventive Plus Package',
      date: 'December 28, 2025',
      status: 'Done',
      parameters: [
        { name: 'Vitamin D (25-OH)', value: '28 ng/mL', range: '30 - 100', status: 'Slightly Low', statusColor: 'amber' },
        { name: 'Vitamin B12', value: '450 pg/mL', range: '200 - 900', status: 'Normal', statusColor: 'emerald' },
        { name: 'Folate', value: '12 ng/mL', range: '3 - 20', status: 'Normal', statusColor: 'emerald' }
      ],
      notes: 'Vitamin D levels are slightly below optimal range. Consider increasing sunlight exposure (15-20 minutes daily) and adding vitamin D-rich foods to your diet.'
    },
    {
      id: 'lipid',
      name: 'Lipid Profile',
      package: 'Preventive Plus Package',
      date: 'December 28, 2025',
      status: 'Done',
      parameters: [
        { name: 'Total Cholesterol', value: '185 mg/dL', range: '< 200', status: 'Excellent', statusColor: 'violet' },
        { name: 'HDL Cholesterol', value: '58 mg/dL', range: '> 40', status: 'Optimal', statusColor: 'emerald' },
        { name: 'LDL Cholesterol', value: '105 mg/dL', range: '< 130', status: 'Normal', statusColor: 'emerald' },
        { name: 'Triglycerides', value: '110 mg/dL', range: '< 150', status: 'Normal', statusColor: 'emerald' }
      ],
      notes: 'Excellent lipid profile! Your cardiovascular markers are within healthy ranges. Continue maintaining a balanced diet and regular exercise.'
    },
    {
      id: 'thyroid',
      name: 'Thyroid Profile',
      package: 'Preventive Plus Package',
      date: 'December 28, 2025',
      status: 'Done',
      parameters: [
        { name: 'TSH', value: '2.5 mIU/L', range: '0.4 - 4.0', status: 'Normal', statusColor: 'emerald' },
        { name: 'T3 (Triiodothyronine)', value: '120 ng/dL', range: '80 - 200', status: 'Normal', statusColor: 'emerald' },
        { name: 'T4 (Thyroxine)', value: '8.5 µg/dL', range: '5.0 - 12.0', status: 'Normal', statusColor: 'emerald' }
      ],
      notes: 'Thyroid function is normal. All parameters indicate healthy thyroid activity.'
    },
    {
      id: 'kidney',
      name: 'Kidney Function Tests (KFT)',
      package: 'Preventive Plus Package',
      date: 'December 28, 2025',
      status: 'Done',
      parameters: [
        { name: 'Creatinine', value: '1.0 mg/dL', range: '0.7 - 1.3', status: 'Normal', statusColor: 'emerald' },
        { name: 'Blood Urea Nitrogen (BUN)', value: '15 mg/dL', range: '7 - 20', status: 'Normal', statusColor: 'emerald' },
        { name: 'Uric Acid', value: '5.5 mg/dL', range: '3.5 - 7.2', status: 'Normal', statusColor: 'emerald' }
      ],
      notes: 'Kidney function is excellent. All markers indicate healthy kidney activity.'
    }
  ];

  const getStatusColor = (color) => {
    const colors = {
      emerald: 'text-emerald-600 bg-emerald-50',
      amber: 'text-amber-600 bg-amber-50',
      violet: 'text-violet-600 bg-violet-50',
      rose: 'text-rose-600 bg-rose-50'
    };
    return colors[color] || colors.emerald;
  };

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-100">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Reports</h1>
            <p className="text-sm text-slate-500">View your test results</p>
          </div>
        </div>
      </div>

      {/* Reports List */}
      <div className="px-6 py-4 space-y-4">
        {reports.map((report) => (
          <div key={report.id} className="health-card overflow-hidden" data-testid={`report-${report.id}`}>
            {/* Report Header */}
            <button
              onClick={() => toggleSection(report.id)}
              className="w-full p-4 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-teal-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-slate-900 text-sm">{report.name}</h3>
                  <p className="text-slate-500 text-xs">{report.package}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 bg-emerald-50 text-emerald-600 text-xs font-medium rounded-full">
                  {report.status}
                </span>
                {expandedSections.includes(report.id) ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>
            </button>

            {/* Expanded Content */}
            {expandedSections.includes(report.id) && (
              <div className="px-4 pb-4 border-t border-slate-100">
                <div className="flex items-center gap-2 py-3 text-xs text-slate-500">
                  <Calendar className="w-4 h-4" />
                  <span>{report.date}</span>
                </div>

                {/* Parameters */}
                <div className="space-y-3 mb-4">
                  {report.parameters.map((param, index) => (
                    <div key={index} className="bg-slate-50 rounded-xl p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-500" />
                          <span className="font-medium text-slate-900 text-sm">{param.name}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(param.statusColor)}`}>
                          {param.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm pl-6">
                        <span className="text-slate-600">Your Result: <strong>{param.value}</strong></span>
                        <span className="text-slate-400">Range: {param.range}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Clinical Notes */}
                {report.notes && (
                  <div className="bg-teal-50 rounded-xl p-3 mb-4">
                    <p className="text-xs font-medium text-teal-800 mb-1">Clinical Notes</p>
                    <p className="text-sm text-teal-700 leading-relaxed">{report.notes}</p>
                  </div>
                )}

                {/* Download Button */}
                <button className="w-full py-3 bg-slate-900 text-white rounded-xl flex items-center justify-center gap-2 font-medium text-sm hover:bg-slate-800 transition-colors">
                  <Download className="w-4 h-4" />
                  Download Report
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className="bottom-nav h-20 flex items-center justify-around">
        <NavItem icon={Activity} label="Home" onClick={() => navigate('/home')} />
        <NavItem icon={FileText} label="Reports" active />
        <NavItem icon={Calendar} label="Schedule" onClick={() => navigate('/schedule')} />
        <NavItem icon={User} label="Profile" onClick={() => navigate('/profile')} />
      </div>
    </div>
  );
};

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button 
    data-testid={`nav-${label.toLowerCase()}`}
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 p-2 min-w-[60px] ${
      active ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
    } transition-colors`}
  >
    <Icon className="w-5 h-5" strokeWidth={active ? 2 : 1.5} />
    <span className="text-xs font-medium">{label}</span>
  </button>
);

export default ReportsPage;
