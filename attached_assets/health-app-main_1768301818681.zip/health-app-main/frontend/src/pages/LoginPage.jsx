import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Mail, Lock, Loader2, Eye, EyeOff, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

const LoginPage = () => {
  const navigate = useNavigate();
  const { signIn, signUp, resetPassword, isAuthenticated, loading: authLoading } = useAuth();
  const [searchParams] = useSearchParams();
  const isSignupMode = searchParams.get('signup') === 'true';
  const isForgotMode = searchParams.get('forgot') === 'true';
  
  const [mode, setMode] = useState(isForgotMode ? 'forgot' : (isSignupMode ? 'signup' : 'login'));
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      navigate('/home');
    }
  }, [isAuthenticated, authLoading, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email) {
      toast.error('Please enter your email address');
      return;
    }

    // Forgot password flow
    if (mode === 'forgot') {
      setLoading(true);
      try {
        await resetPassword(email);
        setResetSent(true);
        toast.success('Password reset email sent!');
      } catch (error) {
        console.error('Reset error:', error);
        const errorMessages = {
          'auth/user-not-found': 'No account found with this email.',
          'auth/invalid-email': 'Please enter a valid email address.',
          'auth/too-many-requests': 'Too many attempts. Please try again later.'
        };
        toast.error(errorMessages[error.code] || 'Failed to send reset email');
      } finally {
        setLoading(false);
      }
      return;
    }

    // Login/Signup flow
    if (!password) {
      toast.error('Please enter your password');
      return;
    }

    if (mode === 'signup' && password !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signup') {
        await signUp(email, password);
        toast.success('Account created successfully!');
      } else {
        await signIn(email, password);
        toast.success('Welcome back!');
      }
      navigate('/subscription');
    } catch (error) {
      console.error('Auth error:', error);
      
      const errorMessages = {
        'auth/email-already-in-use': 'This email is already registered. Please sign in.',
        'auth/invalid-email': 'Please enter a valid email address.',
        'auth/weak-password': 'Password should be at least 6 characters.',
        'auth/user-not-found': 'No account found with this email. Please sign up.',
        'auth/wrong-password': 'Incorrect password. Please try again.',
        'auth/invalid-credential': 'Invalid email or password.',
        'auth/too-many-requests': 'Too many attempts. Please try again later.'
      };
      
      toast.error(errorMessages[error.code] || error.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode) => {
    setMode(newMode);
    setResetSent(false);
    setPassword('');
    setConfirmPassword('');
  };

  if (authLoading) {
    return (
      <div className="mobile-container min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
      </div>
    );
  }

  // Password reset sent confirmation
  if (resetSent) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50">
        <div className="px-6 pt-6 pb-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center"
            data-testid="back-button"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-8">
          <div className="text-center">
            <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-3">Check Your Email</h1>
            <p className="text-slate-500 mb-2">
              We've sent a password reset link to:
            </p>
            <p className="text-teal-600 font-medium mb-6">{email}</p>
            <p className="text-slate-400 text-sm mb-8">
              Click the link in the email to reset your password. If you don't see it, check your spam folder.
            </p>
            
            <button
              onClick={() => switchMode('login')}
              className="w-full py-4 bg-teal-600 text-white rounded-xl font-semibold text-lg mb-4"
              data-testid="back-to-login"
            >
              BACK TO SIGN IN
            </button>
            
            <button
              onClick={() => setResetSent(false)}
              className="text-teal-600 font-medium text-sm"
            >
              Didn't receive email? Try again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen bg-slate-50">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <button 
          onClick={() => mode === 'forgot' ? switchMode('login') : navigate('/')}
          className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center"
          data-testid="back-button"
        >
          <ArrowLeft className="w-5 h-5 text-slate-600" />
        </button>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-teal-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Mail className="w-8 h-8 text-teal-600" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">
            {mode === 'forgot' ? 'Reset Password' : (mode === 'signup' ? 'Create Account' : 'Welcome Back')}
          </h1>
          <p className="text-slate-500">
            {mode === 'forgot' 
              ? "Enter your email and we'll send you a reset link"
              : (mode === 'signup' ? 'Sign up to get started with CareGuard' : 'Sign in to continue to CareGuard')
            }
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Email Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-12 pr-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 text-base"
                data-testid="email-input"
              />
            </div>
          </div>

          {/* Password Input (not shown for forgot password) */}
          {mode !== 'forgot' && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-12 pr-12 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 text-base"
                  data-testid="password-input"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
          )}

          {/* Confirm Password (Signup only) */}
          {mode === 'signup' && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-12 pr-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 text-base"
                  data-testid="confirm-password-input"
                />
              </div>
            </div>
          )}

          {/* Forgot Password Link (Login only) */}
          {mode === 'login' && (
            <div className="text-right mb-4">
              <button
                type="button"
                onClick={() => switchMode('forgot')}
                className="text-teal-600 text-sm font-medium hover:underline"
                data-testid="forgot-password-link"
              >
                Forgot Password?
              </button>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-teal-600 text-white rounded-xl font-semibold text-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-4"
            data-testid="submit-button"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {mode === 'forgot' ? 'Sending...' : (mode === 'signup' ? 'Creating Account...' : 'Signing In...')}
              </>
            ) : (
              mode === 'forgot' ? 'SEND RESET LINK' : (mode === 'signup' ? 'CREATE ACCOUNT' : 'SIGN IN')
            )}
          </button>

          {/* Toggle Sign In / Sign Up / Back to Login */}
          <div className="text-center">
            {mode === 'forgot' ? (
              <p className="text-slate-500 text-sm">
                Remember your password?
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="text-teal-600 font-medium ml-1"
                >
                  Sign In
                </button>
              </p>
            ) : (
              <p className="text-slate-500 text-sm">
                {mode === 'signup' ? 'Already have an account?' : "Don't have an account?"}
                <button
                  type="button"
                  onClick={() => switchMode(mode === 'signup' ? 'login' : 'signup')}
                  className="text-teal-600 font-medium ml-1"
                >
                  {mode === 'signup' ? 'Sign In' : 'Sign Up'}
                </button>
              </p>
            )}
          </div>
        </form>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 text-center">
        <p className="text-xs text-slate-400">
          By continuing, you agree to our{' '}
          <span className="text-teal-600">Terms of Service</span> and{' '}
          <span className="text-teal-600">Privacy Policy</span>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
