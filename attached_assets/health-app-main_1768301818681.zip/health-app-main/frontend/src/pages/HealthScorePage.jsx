import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Sparkles, Heart, Info, CheckCircle, AlertCircle,
  TrendingUp, Calendar, Droplet, Loader2
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { healthService } from '@/config/supabase';

const HealthScorePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [scoreData, setScoreData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHealthScore();
  }, [user]);

  const fetchHealthScore = async () => {
    try {
      if (user?.id) {
        const data = await healthService.getHealthScore(user.id);
        setScoreData(data);
      }
    } catch (error) {
      console.error('Failed to fetch health score:', error);
    } finally {
      setLoading(false);
    }
  };

  const getIconComponent = (category) => {
    switch (category) {
      case 'Blood': return Droplet;
      case 'Heart': return Heart;
      default: return TrendingUp;
    }
  };

  const getIconBg = (category) => {
    switch (category) {
      case 'Blood': return 'bg-red-100 text-red-500';
      case 'Heart': return 'bg-rose-100 text-rose-500';
      case 'Vitamins': return 'bg-amber-100 text-amber-500';
      default: return 'bg-cyan-100 text-cyan-500';
    }
  };

  if (loading) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
      </div>
    );
  }

  const improvements = [
    { action: 'Optimize Vitamin D levels', points: '+5 points' },
    { action: 'Maintain current exercise routine', points: '+2 points' }
  ];

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-6">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-gradient-to-b from-teal-700 to-teal-600 pb-6">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white">Health Score</h1>
              <span className="text-xs bg-white/20 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> AI Powered
              </span>
            </div>
            <p className="text-white/70 text-sm">Based on your latest test results</p>
          </div>
        </div>

        {/* Score Circle */}
        <div className="flex flex-col items-center pb-4">
          <div className="relative w-40 h-40">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="rgba(255,255,255,0.2)"
                strokeWidth="8"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="white"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${(scoreData?.score || 0) * 2.64} 264`}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-bold text-white">{scoreData?.score || 0}</span>
              <span className="text-white/70 text-sm">out of 100</span>
            </div>
          </div>
          <div className="mt-2 px-4 py-1.5 bg-emerald-400/30 rounded-full">
            <span className="text-white font-semibold">{scoreData?.status || 'Calculating...'}</span>
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="px-6 -mt-3">
        <div className="bg-white rounded-2xl p-4 shadow-sm flex justify-around">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-emerald-600 font-bold text-xl">
              <span>{scoreData?.excellent_count || 0}</span>
            </div>
            <p className="text-slate-500 text-xs">Excellent</p>
          </div>
          <div className="w-px bg-slate-200" />
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-amber-600 font-bold text-xl">
              <span>{scoreData?.needs_care_count || 0}</span>
            </div>
            <p className="text-slate-500 text-xs">Needs Care</p>
          </div>
          <div className="w-px bg-slate-200" />
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-rose-600 font-bold text-xl">
              <span>{scoreData?.critical_count || 0}</span>
            </div>
            <p className="text-slate-500 text-xs">Critical</p>
          </div>
        </div>
      </div>

      {/* AI Health Insights */}
      {scoreData?.insights && scoreData.insights.length > 0 && (
        <div className="px-6 mt-4">
          <div className="rounded-2xl p-4 overflow-hidden" style={{
            background: 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)'
          }}>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-white" />
              <h3 className="font-semibold text-white">AI Health Insights</h3>
            </div>
            <div className="space-y-2">
              {scoreData.insights.map((insight, index) => (
                <div key={index} className="flex items-start gap-2">
                  {insight.type === 'positive' ? (
                    <CheckCircle className="w-5 h-5 text-emerald-300 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-amber-300 flex-shrink-0 mt-0.5" />
                  )}
                  <p className="text-white/90 text-sm leading-relaxed">{insight.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* How It's Calculated */}
      <div className="px-6 mt-4">
        <div className="health-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-5 h-5 text-slate-600" />
            <h3 className="font-semibold text-slate-900">How It's Calculated</h3>
          </div>
          <div className="bg-slate-100 rounded-xl p-3 mb-3">
            <p className="text-slate-600 text-sm font-mono text-center">
              Score = Σ (Parameter Score × Weight)
            </p>
          </div>
          <p className="text-slate-500 text-sm leading-relaxed">
            Your health score is calculated using weighted parameters. Each biomarker contributes based on its importance to your overall health profile.
          </p>
        </div>
      </div>

      {/* Score Breakdown */}
      {scoreData?.breakdown && scoreData.breakdown.length > 0 && (
        <div className="px-6 mt-4">
          <h3 className="font-semibold text-slate-900 mb-3">Score Breakdown by Parameter</h3>
          <div className="space-y-3">
            {scoreData.breakdown.map((item, index) => {
              const Icon = getIconComponent(item.category);
              return (
                <div key={index} className="health-card p-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${getIconBg(item.category)}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-semibold text-slate-900 text-sm">{item.name}</h4>
                        <span className="text-emerald-600 font-bold">{item.score} score</span>
                      </div>
                      <p className="text-slate-500 text-xs mb-2">{item.description}</p>
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>{item.value}</span>
                        <span>Range: {item.range}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* How to Improve */}
      <div className="px-6 mt-4">
        <div className="health-card p-4 border-l-4 border-emerald-500">
          <h3 className="font-semibold text-slate-900 mb-3">How to Improve Your Score</h3>
          <div className="space-y-2">
            {improvements.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-slate-600 text-sm">{item.action}</span>
                </div>
                <span className="text-emerald-600 font-medium text-sm">{item.points}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Track Progress */}
      <div className="px-6 mt-4 mb-6">
        <div className="rounded-2xl p-4 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-teal-400" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">Track Your Progress</h3>
              <p className="text-slate-400 text-sm">Complete regular tests to see how your score improves over time.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthScorePage;
