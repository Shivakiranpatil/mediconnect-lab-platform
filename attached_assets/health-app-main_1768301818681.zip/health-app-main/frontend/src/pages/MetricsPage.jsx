import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, TrendingUp, TrendingDown, Minus, ChevronRight, Sparkles,
  Droplet, Sun, Heart, Activity, Beaker, Zap, Shield, Loader2
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { healthService } from '@/config/supabase';

const MetricsPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeFilter, setActiveFilter] = useState('All');
  const [biomarkersData, setBiomarkersData] = useState(null);
  const [aiInsight, setAiInsight] = useState(null);
  const [loading, setLoading] = useState(true);
  const [insightLoading, setInsightLoading] = useState(false);

  const filters = ['All', 'Blood', 'Heart', 'Vitamins', 'Metabolic'];

  useEffect(() => {
    fetchBiomarkers();
  }, [user]);

  useEffect(() => {
    if (biomarkersData) {
      fetchAIInsight(activeFilter);
    }
  }, [activeFilter, biomarkersData]);

  const fetchBiomarkers = async () => {
    try {
      if (user?.id) {
        const data = await healthService.getBiomarkers(user.id);
        setBiomarkersData(data);
      }
    } catch (error) {
      console.error('Failed to fetch biomarkers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAIInsight = async (category) => {
    setInsightLoading(true);
    try {
      // AI insights would require backend API - show placeholder for now
      setAiInsight({
        insight: `Based on your ${category.toLowerCase()} biomarkers, your health is looking good. Continue your healthy lifestyle!`,
        category
      });
    } catch (error) {
      console.error('Failed to fetch AI insight:', error);
      setAiInsight({
        insight: "Unable to generate insights at this time.",
        category
      });
    } finally {
      setInsightLoading(false);
    }
  };

  const getIcon = (category) => {
    const icons = {
      'Blood': Droplet,
      'Heart': Heart,
      'Vitamins': Sun,
      'Metabolic': Zap
    };
    return icons[category] || Activity;
  };

  const getIconBg = (category) => {
    const bgs = {
      'Blood': 'bg-red-100',
      'Heart': 'bg-rose-100',
      'Vitamins': 'bg-amber-100',
      'Metabolic': 'bg-cyan-100'
    };
    return bgs[category] || 'bg-slate-100';
  };

  const getIconColor = (category) => {
    const colors = {
      'Blood': 'text-red-500',
      'Heart': 'text-rose-500',
      'Vitamins': 'text-amber-500',
      'Metabolic': 'text-cyan-500'
    };
    return colors[category] || 'text-slate-500';
  };

  const allMetrics = biomarkersData?.biomarkers?.map(b => ({
    name: b.name,
    description: b.description || 'Health marker',
    value: b.value,
    unit: b.unit,
    range: b.reference_range,
    status: b.status,
    statusColor: getStatusColorName(b.status),
    icon: getIcon(b.category),
    iconBg: getIconBg(b.category),
    iconColor: getIconColor(b.category),
    progress: getProgressValue(b.status),
    trend: b.trend || 'stable',
    change: b.change || '0',
    category: b.category,
    weight: 10,
    contribution: getProgressValue(b.status) / 10,
    hasComparison: b.has_comparison
  })) || [];

  const filteredMetrics = activeFilter === 'All' 
    ? allMetrics 
    : allMetrics.filter(m => m.category === activeFilter);

  const getTrendIcon = (trend) => {
    if (trend === 'up') return <TrendingUp className="w-4 h-4 text-emerald-500" />;
    if (trend === 'down') return <TrendingDown className="w-4 h-4 text-amber-500" />;
    return <Minus className="w-4 h-4 text-slate-400" />;
  };

  const getStatusColor = (color) => {
    const colors = {
      emerald: 'text-emerald-600 bg-emerald-50 border-emerald-100',
      amber: 'text-amber-600 bg-amber-50 border-amber-100',
      cyan: 'text-cyan-600 bg-cyan-50 border-cyan-100',
      violet: 'text-violet-600 bg-violet-50 border-violet-100',
      rose: 'text-rose-600 bg-rose-50 border-rose-100'
    };
    return colors[color] || colors.cyan;
  };

  const getProgressColor = (color) => {
    const colors = {
      emerald: 'bg-emerald-500',
      amber: 'bg-amber-500',
      cyan: 'bg-cyan-500',
      violet: 'bg-violet-500'
    };
    return colors[color] || colors.cyan;
  };

  if (loading) {
    return (
      <div className="mobile-container min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="mobile-container min-h-screen bg-slate-50 pb-6">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-slate-100">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900">All Key Metrics</h1>
            <p className="text-sm text-slate-500">{filteredMetrics.length} parameters tracked</p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="px-6 pb-4 flex gap-2 overflow-x-auto scrollbar-hide">
          {filters.map((filter) => (
            <button
              key={filter}
              data-testid={`filter-${filter.toLowerCase()}`}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                activeFilter === filter
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* AI Insight Banner - Dynamic based on category */}
      <div className="px-6 py-4">
        <div className="rounded-2xl p-4 flex items-start gap-3" style={{
          background: 'linear-gradient(135deg, #0F766E 0%, #115E59 100%)'
        }}>
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
              AI {activeFilter} Health Insight
              {insightLoading && <Loader2 className="w-4 h-4 animate-spin" />}
            </p>
            {insightLoading ? (
              <p className="text-white/80 text-xs leading-relaxed">Generating personalized insights...</p>
            ) : (
              <p className="text-white/80 text-xs leading-relaxed">
                {aiInsight?.insight || 'Loading insights...'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Comparison Notice */}
      {biomarkersData?.has_previous_report ? (
        <div className="px-6 mb-2">
          <p className="text-xs text-slate-500">
            📊 Comparing with your test from {biomarkersData.previous_report_date}
          </p>
        </div>
      ) : (
        <div className="px-6 mb-2">
          <p className="text-xs text-slate-400">
            ℹ️ Complete another test to see comparison trends
          </p>
        </div>
      )}

      {/* Metrics List */}
      <div className="px-6 space-y-3">
        {filteredMetrics.map((metric, index) => (
          <div 
            key={index} 
            data-testid={`metric-card-${metric.name.toLowerCase().replace(/\s/g, '-')}`}
            className="health-card p-4"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl ${metric.iconBg} flex items-center justify-center`}>
                  <metric.icon className={`w-5 h-5 ${metric.iconColor}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 text-sm">{metric.name}</h3>
                  <p className="text-slate-500 text-xs">{metric.description}</p>
                </div>
              </div>
              {metric.hasComparison && (
                <div className="flex items-center gap-2">
                  {getTrendIcon(metric.trend)}
                  <span className={`text-xs font-medium ${
                    metric.trend === 'up' ? 'text-emerald-500' : 
                    metric.trend === 'down' ? 'text-amber-500' : 'text-slate-400'
                  }`}>
                    {metric.change}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-end justify-between mb-3">
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-slate-900">{metric.value}</span>
                  <span className="text-slate-400 text-sm">{metric.unit}</span>
                </div>
                <p className="text-slate-400 text-xs">Range: {metric.range}</p>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(metric.statusColor)}`}>
                {metric.status}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden mb-3">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${getProgressColor(metric.statusColor)}`}
                style={{ width: `${metric.progress}%` }}
              />
            </div>

            {/* Weight & Contribution */}
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Weight: {metric.weight}%</span>
              <span>Contribution: {Math.round(metric.contribution)} pts</span>
            </div>
          </div>
        ))}
      </div>

      {/* View Health Insights Button */}
      <div className="px-6 pt-6">
        <div className="rounded-2xl p-5" style={{
          background: 'linear-gradient(135deg, #0F766E 0%, #115E59 100%)'
        }}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-400/30 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-white">What's Next?</h3>
          </div>
          <p className="text-white/80 text-sm mb-4 leading-relaxed">
            View your AI-powered health insights and personalized recommendations based on these test results.
          </p>
          <button
            data-testid="view-insights-btn"
            onClick={() => navigate('/health-score')}
            className="w-full py-3 bg-white rounded-xl text-teal-700 font-semibold text-sm hover:bg-slate-50 transition-colors"
          >
            View Health Insights
          </button>
        </div>
      </div>
    </div>
  );
};

// Helper functions
const getStatusColorName = (status) => {
  const mapping = {
    'Excellent': 'emerald',
    'Optimal': 'emerald',
    'Normal': 'cyan',
    'Slightly Low': 'amber',
    'Slightly High': 'amber',
    'Low': 'rose',
    'High': 'rose'
  };
  return mapping[status] || 'cyan';
};

const getProgressValue = (status) => {
  const values = {
    'Excellent': 90,
    'Optimal': 85,
    'Normal': 75,
    'Slightly Low': 50,
    'Slightly High': 50,
    'Low': 30,
    'High': 30
  };
  return values[status] || 70;
};

export default MetricsPage;
