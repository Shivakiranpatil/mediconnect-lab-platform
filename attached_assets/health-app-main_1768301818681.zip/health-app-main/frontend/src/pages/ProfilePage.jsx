import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, User, Phone, Mail, MapPin, Calendar, CreditCard,
  ChevronRight, LogOut, Bell, Shield, HelpCircle, FileText, Activity
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user: authUser, logout } = useAuth();
  const [user, setUser] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    emirate: ''
  });

  useEffect(() => {
    // Use auth context user or fallback to localStorage
    if (authUser) {
      setUser(authUser);
      setFormData({
        name: authUser.name || '',
        emirate: authUser.emirate || ''
      });
    } else {
      const userData = localStorage.getItem('user');
      if (userData) {
        const parsed = JSON.parse(userData);
        setUser(parsed);
        setFormData({
          name: parsed.name || '',
          emirate: parsed.emirate || ''
        });
      }
    }
  }, [authUser]);

  const handleLogout = async () => {
    try {
      await logout();
      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
      // Force clear even if Firebase logout fails
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      localStorage.removeItem('firebase_uid');
      navigate('/');
    }
  };

  const handleSave = async () => {
    try {
      // Import and use userService from supabase
      const { userService } = await import('@/config/supabase');
      const updatedUser = await userService.updateProfile(user.id, formData);
      setUser({ ...user, ...updatedUser });
      localStorage.setItem('user', JSON.stringify({ ...user, ...updatedUser }));
      setEditing(false);
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Profile update error:', error);
      toast.error('Failed to update profile');
    }
  };

  const menuItems = [
    { icon: Bell, label: 'Notifications', subtitle: 'Manage your alerts' },
    { icon: CreditCard, label: 'Subscription', subtitle: 'Preventive Plus - Active' },
    { icon: Shield, label: 'Privacy & Security', subtitle: 'Data protection settings' },
    { icon: HelpCircle, label: 'Help & Support', subtitle: 'Get assistance' }
  ];

  const emirates = ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah', 'Fujairah', 'Umm Al Quwain'];

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-teal-600 to-teal-700 pb-20">
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            data-testid="back-btn"
            onClick={() => navigate('/home')}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white">Profile</h1>
        </div>
      </div>

      {/* Profile Card */}
      <div className="px-6 -mt-16">
        <div className="health-card p-6">
          <div className="flex flex-col items-center mb-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white text-2xl font-bold mb-3">
              {user?.name ? user.name[0].toUpperCase() : 'U'}
            </div>
            {editing ? (
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter your name"
                className="text-xl font-bold text-slate-900 text-center border-b-2 border-teal-500 outline-none bg-transparent"
                data-testid="name-input"
              />
            ) : (
              <h2 className="text-xl font-bold text-slate-900">{user?.name || 'Add your name'}</h2>
            )}
            <p className="text-slate-500 text-sm">Health Member</p>
          </div>

          {/* User Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                <Phone className="w-5 h-5 text-slate-500" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Phone</p>
                <p className="text-slate-900 font-medium">+971 {user?.phone || '---'}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-slate-500" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-slate-400">Emirate</p>
                {editing ? (
                  <select
                    value={formData.emirate}
                    onChange={(e) => setFormData({ ...formData, emirate: e.target.value })}
                    className="w-full py-1 text-slate-900 font-medium bg-transparent border-b border-slate-200 outline-none"
                    data-testid="emirate-select"
                  >
                    <option value="">Select Emirate</option>
                    {emirates.map((e) => (
                      <option key={e} value={e}>{e}</option>
                    ))}
                  </select>
                ) : (
                  <p className="text-slate-900 font-medium">{user?.emirate || 'Not set'}</p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-slate-500" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Member Since</p>
                <p className="text-slate-900 font-medium">
                  {user?.created_at ? new Date(user.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'January 2026'}
                </p>
              </div>
            </div>
          </div>

          {/* Edit/Save Button */}
          <button
            onClick={editing ? handleSave : () => setEditing(true)}
            data-testid="edit-profile-btn"
            className={`w-full mt-6 py-3 rounded-xl font-semibold transition-all ${
              editing
                ? 'bg-teal-600 text-white hover:bg-teal-700'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {editing ? 'Save Changes' : 'Edit Profile'}
          </button>
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-6 mt-4">
        <div className="health-card overflow-hidden">
          {menuItems.map((item, index) => (
            <button
              key={item.label}
              className={`w-full p-4 flex items-center gap-3 hover:bg-slate-50 transition-colors ${
                index !== menuItems.length - 1 ? 'border-b border-slate-100' : ''
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-slate-500" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-slate-900 text-sm">{item.label}</p>
                <p className="text-slate-500 text-xs">{item.subtitle}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300" />
            </button>
          ))}
        </div>
      </div>

      {/* Logout Button */}
      <div className="px-6 mt-4">
        <button
          onClick={handleLogout}
          data-testid="logout-btn"
          className="w-full health-card p-4 flex items-center gap-3 text-rose-600 hover:bg-rose-50 transition-colors"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center">
            <LogOut className="w-5 h-5 text-rose-500" />
          </div>
          <span className="font-medium">Log Out</span>
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="bottom-nav h-20 flex items-center justify-around">
        <NavItem icon={Activity} label="Home" onClick={() => navigate('/home')} />
        <NavItem icon={FileText} label="Reports" onClick={() => navigate('/reports')} />
        <NavItem icon={Calendar} label="Schedule" onClick={() => navigate('/schedule')} />
        <NavItem icon={User} label="Profile" active />
      </div>
    </div>
  );
};

const NavItem = ({ icon: Icon, label, active, onClick }) => (
  <button 
    data-testid={`nav-${label.toLowerCase()}`}
    onClick={onClick}
    className={`flex flex-col items-center justify-center gap-1 p-2 min-w-[60px] ${
      active ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
    } transition-colors`}
  >
    <Icon className="w-5 h-5" strokeWidth={active ? 2 : 1.5} />
    <span className="text-xs font-medium">{label}</span>
  </button>
);

export default ProfilePage;
