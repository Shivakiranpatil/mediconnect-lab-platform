import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, Calendar, Clock, MapPin, ChevronLeft, ChevronRight, 
  CheckCircle, Home, Building, Layers, Map, Search, Navigation
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { appointmentService } from '@/config/supabase';

const BookTestPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState(null);
  const [loading, setLoading] = useState(false);
  const [locationSearch, setLocationSearch] = useState('');
  const [showLocationSuggestions, setShowLocationSuggestions] = useState(false);
  
  const [address, setAddress] = useState({
    flatOffice: '',
    floor: '',
    building: '',
    area: '',
    emirate: 'Dubai',
    landmark: '',
    coordinates: null
  });

  const emirates = [
    'Dubai',
    'Abu Dhabi', 
    'Sharjah',
    'Ajman',
    'Ras Al Khaimah',
    'Fujairah',
    'Umm Al Quwain'
  ];

  const popularAreas = {
    'Dubai': ['Al Barsha', 'Jumeirah', 'Downtown Dubai', 'Dubai Marina', 'Business Bay', 'Deira', 'Bur Dubai', 'JBR', 'Palm Jumeirah', 'Arabian Ranches'],
    'Abu Dhabi': ['Al Reem Island', 'Yas Island', 'Khalifa City', 'Al Ain', 'Saadiyat Island'],
    'Sharjah': ['Al Nahda', 'Al Majaz', 'Al Qasimia', 'Muwaileh'],
    'Ajman': ['Al Nuaimiya', 'Al Rashidiya'],
    'default': ['City Center', 'Main Area']
  };

  // Calendar helpers
  const daysInMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1).getDay();
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  const timeSlots = [
    '8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM',
    '11:00 AM', '11:30 AM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM'
  ];

  const prevMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 1));
  };

  const selectDay = (day) => {
    const newDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
    if (newDate >= new Date().setHours(0,0,0,0)) {
      setSelectedDate(newDate);
    }
  };

  const isToday = (day) => {
    const today = new Date();
    return day === today.getDate() && 
           selectedDate.getMonth() === today.getMonth() && 
           selectedDate.getFullYear() === today.getFullYear();
  };

  const isSelectedDay = (day) => day === selectedDate.getDate();

  const isPastDay = (day) => {
    const checkDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
    return checkDate < new Date().setHours(0,0,0,0);
  };

  const handleAddressChange = (field, value) => {
    setAddress(prev => ({ ...prev, [field]: value }));
  };

  const handleGetCurrentLocation = () => {
    if (navigator.geolocation) {
      toast.info('Getting your location...');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setAddress(prev => ({
            ...prev,
            coordinates: { lat: latitude, lng: longitude }
          }));
          toast.success('Location captured! Please fill in the address details.');
        },
        (error) => {
          toast.error('Unable to get location. Please enter address manually.');
        }
      );
    } else {
      toast.error('Geolocation is not supported by your browser');
    }
  };

  const handleOpenMaps = () => {
    // Open Google Maps for location selection
    const searchQuery = `${address.area}, ${address.emirate}, UAE`;
    window.open(`https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`, '_blank');
  };

  const getFullAddress = () => {
    const parts = [
      address.flatOffice && `${address.flatOffice}`,
      address.floor && `Floor ${address.floor}`,
      address.building,
      address.area,
      address.emirate
    ].filter(Boolean);
    return parts.join(', ');
  };

  const handleBooking = async () => {
    // Validate user is logged in with a valid Supabase ID
    if (!user) {
      toast.error('Please log in to book a test');
      navigate('/login');
      return;
    }
    
    if (!user.id) {
      toast.error('Please complete your profile first');
      navigate('/profile-complete');
      return;
    }
    
    if (!selectedTime) {
      toast.error('Please select a time slot');
      return;
    }
    
    // Validate address fields
    if (!address.flatOffice?.trim()) {
      toast.error('Please enter your flat/office number');
      return;
    }
    if (!address.area?.trim()) {
      toast.error('Please select or enter your area');
      return;
    }
    if (!address.emirate) {
      toast.error('Please select your emirate');
      return;
    }

    setLoading(true);
    
    try {
      console.log('Booking test for user ID:', user.id, 'type:', typeof user.id);
      
      const result = await appointmentService.bookAppointment(user.id, {
        date: selectedDate.toISOString().split('T')[0],
        time: selectedTime,
        address: {
          full_address: getFullAddress(),
          flatOffice: address.flatOffice,
          floor: address.floor,
          building: address.building,
          area: address.area,
          emirate: address.emirate,
          landmark: address.landmark,
          coordinates: address.coordinates
        },
        type: 'home_collection'
      });
      
      console.log('Booking result:', result);
      toast.success('Booking confirmed!');
      navigate('/booking-status');
    } catch (error) {
      console.error('Booking error:', error);
      const errorMsg = error?.message || 'Failed to book appointment';
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const currentAreas = popularAreas[address.emirate] || popularAreas['default'];

  return (
    <div className="mobile-container min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/30 pb-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A] px-6 pt-6 pb-8 text-white">
        <button
          data-testid="back-btn"
          onClick={() => navigate('/profile-complete')}
          className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold mb-2">Book Your Test</h1>
        <p className="text-white/80 text-sm">Schedule a home visit for sample collection</p>
      </div>

      <div className="px-6 pt-6 space-y-4">
        {/* Calendar */}
        <div className="bg-white rounded-3xl p-5 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-teal-600" />
            <h3 className="font-semibold text-slate-900">Select Date</h3>
          </div>
          
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevMonth} className="p-2 hover:bg-slate-100 rounded-lg">
              <ChevronLeft className="w-5 h-5 text-slate-600" />
            </button>
            <h4 className="font-semibold text-slate-900">
              {monthNames[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </h4>
            <button onClick={nextMonth} className="p-2 hover:bg-slate-100 rounded-lg">
              <ChevronRight className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-2">
            {dayNames.map((day) => (
              <div key={day} className="text-center text-xs font-medium text-slate-400 py-2">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDayOfMonth }).map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const past = isPastDay(day);
              const today = isToday(day);
              const selected = isSelectedDay(day);
              
              return (
                <button
                  key={day}
                  onClick={() => selectDay(day)}
                  disabled={past}
                  className={`aspect-square rounded-xl flex items-center justify-center text-sm font-medium transition-all ${
                    selected
                      ? 'bg-gradient-to-br from-[#0A5F5F] to-[#10B981] text-white shadow-md'
                      : today
                      ? 'bg-teal-100 text-teal-600'
                      : past
                      ? 'text-slate-300 cursor-not-allowed'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>

        {/* Time Slots */}
        <div className="bg-white rounded-3xl p-5 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-teal-600" />
            <h3 className="font-semibold text-slate-900">Select Time</h3>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {timeSlots.map((time) => (
              <button
                key={time}
                onClick={() => setSelectedTime(time)}
                data-testid={`time-${time.replace(/[\s:]/g, '-')}`}
                className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all ${
                  selectedTime === time
                    ? 'bg-gradient-to-br from-[#0A5F5F] to-[#10B981] text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {time}
              </button>
            ))}
          </div>
        </div>

        {/* Address Section */}
        <div className="bg-white rounded-3xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-teal-600" />
              <h3 className="font-semibold text-slate-900">Collection Address</h3>
            </div>
            <button
              onClick={handleGetCurrentLocation}
              className="flex items-center gap-1 text-xs text-teal-600 font-medium"
            >
              <Navigation className="w-4 h-4" />
              Use My Location
            </button>
          </div>
          
          <div className="space-y-3">
            {/* Flat/Office & Floor */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Flat/Office No *</label>
                <div className="relative">
                  <input
                    type="text"
                    value={address.flatOffice}
                    onChange={(e) => handleAddressChange('flatOffice', e.target.value)}
                    placeholder="e.g., 204"
                    className="w-full h-11 px-3 pl-10 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                    data-testid="flat-office-input"
                  />
                  <Home className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Floor</label>
                <div className="relative">
                  <input
                    type="text"
                    value={address.floor}
                    onChange={(e) => handleAddressChange('floor', e.target.value)}
                    placeholder="e.g., 2"
                    className="w-full h-11 px-3 pl-10 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                    data-testid="floor-input"
                  />
                  <Layers className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                </div>
              </div>
            </div>

            {/* Building Name */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Building Name</label>
              <div className="relative">
                <input
                  type="text"
                  value={address.building}
                  onChange={(e) => handleAddressChange('building', e.target.value)}
                  placeholder="e.g., Azure Tower"
                  className="w-full h-11 px-3 pl-10 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                  data-testid="building-input"
                />
                <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              </div>
            </div>

            {/* Area */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Area *</label>
              <div className="relative">
                <input
                  type="text"
                  value={address.area}
                  onChange={(e) => handleAddressChange('area', e.target.value)}
                  placeholder="e.g., Al Barsha"
                  className="w-full h-11 px-3 pl-10 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                  data-testid="area-input"
                />
                <Map className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              </div>
              {/* Quick Area Selection */}
              <div className="flex flex-wrap gap-2 mt-2">
                {currentAreas.slice(0, 4).map((area) => (
                  <button
                    key={area}
                    onClick={() => handleAddressChange('area', area)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                      address.area === area
                        ? 'bg-teal-100 text-teal-700 border border-teal-300'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {area}
                  </button>
                ))}
              </div>
            </div>

            {/* Emirate */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Emirate/City *</label>
              <select
                value={address.emirate}
                onChange={(e) => handleAddressChange('emirate', e.target.value)}
                className="w-full h-11 px-3 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                data-testid="emirate-select"
              >
                {emirates.map((emirate) => (
                  <option key={emirate} value={emirate}>{emirate}</option>
                ))}
              </select>
            </div>

            {/* Landmark */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Landmark (Optional)</label>
              <input
                type="text"
                value={address.landmark}
                onChange={(e) => handleAddressChange('landmark', e.target.value)}
                placeholder="Near Mall of Emirates"
                className="w-full h-11 px-3 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none text-sm"
                data-testid="landmark-input"
              />
            </div>

            {/* Open Maps Button */}
            <button
              onClick={handleOpenMaps}
              className="w-full py-3 border border-teal-200 rounded-xl text-teal-600 font-medium flex items-center justify-center gap-2 hover:bg-teal-50 transition-colors"
            >
              <Map className="w-5 h-5" />
              Open in Google Maps
            </button>

            {/* Location Status */}
            {address.coordinates && (
              <div className="flex items-center gap-2 text-xs text-green-600 bg-green-50 p-2 rounded-lg">
                <CheckCircle className="w-4 h-4" />
                Location captured successfully
              </div>
            )}
          </div>
        </div>

        {/* Booking Summary */}
        {selectedTime && (
          <div className="bg-teal-50 rounded-3xl p-5 border border-teal-200">
            <h3 className="font-semibold text-teal-800 mb-3">Booking Summary</h3>
            <div className="space-y-2 text-sm text-teal-700">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Home Collection</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>{selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>{selectedTime}</span>
              </div>
              {address.flatOffice && (
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{getFullAddress()}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Confirm Button */}
        <button
          onClick={handleBooking}
          disabled={!selectedTime || !address.flatOffice || !address.area || loading}
          data-testid="confirm-booking-btn"
          className="w-full h-14 text-lg bg-gradient-to-r from-[#0A5F5F] to-[#10B981] hover:from-[#083f3f] hover:to-[#0d8f6f] text-white shadow-xl rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
        >
          {loading ? 'Booking...' : 'Confirm Booking'}
        </button>
      </div>
    </div>
  );
};

export default BookTestPage;
