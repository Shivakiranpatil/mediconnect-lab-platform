import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  ArrowLeft, User, Mail, Phone, Calendar, Plus, X, Users,
  ChevronRight, UserPlus, Heart
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { userService } from '@/config/supabase';

const ProfileCompletePage = () => {
  const navigate = useNavigate();
  const { user: authUser, updateUser } = useAuth();
  const [searchParams] = useSearchParams();
  const packageId = searchParams.get('package') || '';
  const isFamily = packageId.includes('family');
  
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({
    firstName: '',
    lastName: '',
    age: '',
    phone: '',
    email: ''
  });
  
  const [familyMembers, setFamilyMembers] = useState([]);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMember, setNewMember] = useState({
    name: '',
    age: '',
    relationship: ''
  });

  const relationshipOptions = [
    { value: 'wife', label: 'Wife' },
    { value: 'husband', label: 'Husband' },
    { value: 'father', label: 'Father' },
    { value: 'mother', label: 'Mother' },
    { value: 'son', label: 'Son' },
    { value: 'daughter', label: 'Daughter' },
    { value: 'brother', label: 'Brother' },
    { value: 'sister', label: 'Sister' },
    { value: 'other', label: 'Other' }
  ];

  // Get family size from package
  const getFamilySize = () => {
    if (packageId === 'family-of-2') return 2;
    if (packageId === 'family-of-3') return 3;
    if (packageId === 'family-of-4') return 4;
    return 1;
  };

  const maxFamilyMembers = getFamilySize() - 1; // Minus the primary user

  useEffect(() => {
    // Pre-fill from auth user
    if (authUser) {
      const nameParts = (authUser.name || '').split(' ');
      setProfile(prev => ({
        ...prev,
        firstName: nameParts[0] || '',
        lastName: nameParts.slice(1).join(' ') || '',
        phone: authUser.phone || authUser.phone_number || '',
        email: authUser.email || '',
        age: authUser.age ? String(authUser.age) : ''
      }));
      
      if (authUser.family_members?.length > 0) {
        setFamilyMembers(authUser.family_members);
      }
    }
  }, [authUser]);

  const handleProfileChange = (field, value) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleAddMember = () => {
    if (!newMember.name || !newMember.age || !newMember.relationship) {
      toast.error('Please fill all required fields');
      return;
    }

    setFamilyMembers(prev => [...prev, { ...newMember, id: Date.now() }]);
    setNewMember({ name: '', age: '', relationship: '' });
    setShowAddMember(false);
    toast.success('Family member added');
  };

  const handleRemoveMember = (id) => {
    setFamilyMembers(prev => prev.filter(m => m.id !== id));
  };

  const handleContinue = async () => {
    // Validate required fields
    if (!profile.firstName || !profile.lastName || !profile.age || !profile.phone || !profile.email) {
      toast.error('Please fill all required fields');
      return;
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(profile.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    // For family plans, check if all members are added
    if (isFamily && familyMembers.length < maxFamilyMembers) {
      const remaining = maxFamilyMembers - familyMembers.length;
      toast.error(`Please add ${remaining} more family member(s)`);
      return;
    }

    setLoading(true);

    try {
      // Save profile using Supabase service
      if (authUser?.id) {
        await userService.updateProfile(authUser.id, {
          name: `${profile.firstName} ${profile.lastName}`,
          age: parseInt(profile.age),
          phone_number: profile.phone,
          email: profile.email,
          family_members: isFamily ? familyMembers : []
        });
        
        // Update local auth state
        updateUser({
          ...authUser,
          name: `${profile.firstName} ${profile.lastName}`,
          age: parseInt(profile.age),
          phone: profile.phone,
          email: profile.email,
          family_members: isFamily ? familyMembers : []
        });
      }

      toast.success('Profile saved');
      navigate('/book-test');
    } catch (error) {
      console.error('Error saving profile:', error);
      navigate('/book-test'); // Continue anyway for demo
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mobile-container min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/30 pb-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0A5F5F] to-[#0D7A7A] px-6 pt-6 pb-8 text-white">
        <button
          data-testid="back-btn"
          onClick={() => navigate('/subscription')}
          className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <h1 className="text-2xl font-bold">Complete Your Profile</h1>
        </div>
        <p className="text-white/80 text-sm">
          {isFamily 
            ? `Add details for you and ${maxFamilyMembers} family member(s)`
            : 'We need a few details before booking your test'
          }
        </p>
      </div>

      <div className="px-6 pt-6 space-y-4">
        {/* Primary User Profile */}
        <div className="bg-white rounded-3xl p-5 shadow-lg">
          <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-teal-600" />
            Your Details
          </h3>
          
          <div className="space-y-4">
            {/* Name Row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">First Name *</label>
                <input
                  type="text"
                  value={profile.firstName}
                  onChange={(e) => handleProfileChange('firstName', e.target.value)}
                  placeholder="John"
                  className="w-full h-12 px-4 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
                  data-testid="first-name-input"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Last Name *</label>
                <input
                  type="text"
                  value={profile.lastName}
                  onChange={(e) => handleProfileChange('lastName', e.target.value)}
                  placeholder="Doe"
                  className="w-full h-12 px-4 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
                  data-testid="last-name-input"
                />
              </div>
            </div>

            {/* Age */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Age *</label>
              <input
                type="number"
                value={profile.age}
                onChange={(e) => handleProfileChange('age', e.target.value.replace(/\D/g, ''))}
                placeholder="e.g., 35"
                min="1"
                max="120"
                className="w-full h-12 px-4 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
                data-testid="age-input"
              />
            </div>

            {/* Contact Number */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Contact Number *</label>
              <div className="flex gap-3">
                <div className="w-20 h-12 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center text-slate-600 font-medium">
                  +971
                </div>
                <input
                  type="tel"
                  value={profile.phone}
                  onChange={(e) => handleProfileChange('phone', e.target.value.replace(/\D/g, ''))}
                  placeholder="50 123 4567"
                  className="flex-1 h-12 px-4 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
                  data-testid="phone-input"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Email Address *</label>
              <div className="relative">
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => handleProfileChange('email', e.target.value)}
                  placeholder="john@example.com"
                  className="w-full h-12 px-4 border border-slate-200 rounded-xl text-slate-900 bg-slate-50 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
                  data-testid="email-input"
                />
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Family Members Section - Only for Family Plans */}
        {isFamily && (
          <div className="bg-white rounded-3xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                Family Members ({familyMembers.length}/{maxFamilyMembers})
              </h3>
            </div>

            {/* Added Family Members */}
            {familyMembers.length > 0 && (
              <div className="space-y-3 mb-4">
                {familyMembers.map((member) => (
                  <div 
                    key={member.id}
                    className="flex items-center justify-between p-3 bg-purple-50 rounded-xl border border-purple-100"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-purple-200 flex items-center justify-center">
                        <Heart className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{member.name}</p>
                        <p className="text-xs text-slate-500 capitalize">{member.relationship} • {member.age} years old</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveMember(member.id)}
                      className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center"
                    >
                      <X className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add Member Form */}
            {showAddMember ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div>
                  <input
                    type="text"
                    value={newMember.name}
                    onChange={(e) => setNewMember(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Full Name"
                    className="w-full h-11 px-3 border border-slate-200 rounded-xl text-slate-900 bg-white focus:border-teal-500 outline-none text-sm"
                    data-testid="member-name"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="number"
                    value={newMember.age}
                    onChange={(e) => setNewMember(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="Age"
                    min="1"
                    max="120"
                    className="h-11 px-3 border border-slate-200 rounded-xl text-slate-900 bg-white focus:border-teal-500 outline-none text-sm"
                    data-testid="member-age"
                  />
                  <select
                    value={newMember.relationship}
                    onChange={(e) => setNewMember(prev => ({ ...prev, relationship: e.target.value }))}
                    className="h-11 px-3 border border-slate-200 rounded-xl text-slate-900 bg-white focus:border-teal-500 outline-none text-sm"
                    data-testid="member-relationship"
                  >
                    <option value="">Relationship</option>
                    {relationshipOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowAddMember(false)}
                    className="flex-1 h-11 border border-slate-200 rounded-xl text-slate-600 font-medium text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddMember}
                    className="flex-1 h-11 bg-purple-600 text-white rounded-xl font-medium text-sm"
                    data-testid="confirm-add-member"
                  >
                    Add Member
                  </button>
                </div>
              </div>
            ) : (
              familyMembers.length < maxFamilyMembers && (
                <button
                  onClick={() => setShowAddMember(true)}
                  data-testid="add-member-btn"
                  className="w-full py-4 border-2 border-dashed border-purple-300 rounded-xl text-purple-600 font-medium flex items-center justify-center gap-2 hover:bg-purple-50 transition-colors"
                >
                  <UserPlus className="w-5 h-5" />
                  Add Family Member
                </button>
              )
            )}

            {/* Info */}
            <p className="text-xs text-slate-500 mt-3 text-center">
              All family members will be tested in the same visit
            </p>
          </div>
        )}

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          disabled={loading}
          data-testid="continue-btn"
          className="w-full h-14 text-lg bg-gradient-to-r from-[#0A5F5F] to-[#10B981] hover:from-[#083f3f] hover:to-[#0d8f6f] text-white shadow-xl rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-semibold"
        >
          Continue to Booking
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default ProfileCompletePage;
