import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ClipboardList, Clock, CheckCircle, FileText, 
  Users, TrendingUp, ArrowRight, AlertCircle, Bell,
  RefreshCw, Calendar, Beaker
} from 'lucide-react';
import { toast } from 'sonner';
import { labService } from '@/config/supabase';

const LabDashboard = () => {
  const navigate = useNavigate();
  const [dashboard, setDashboard] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchDashboard = useCallback(async () => {
    const labUser = JSON.parse(localStorage.getItem('labUser') || '{}');
    const labId = labUser.id;
    
    if (!labId) {
      toast.error('Please login again');
      navigate('/lab/login');
      return;
    }

    try {
      const [dashRes, aptsRes] = await Promise.all([
        labService.getDashboard(labId),
        labService.getAppointments(labId)
      ]);
      setDashboard(dashRes.stats);
      setAppointments(aptsRes || []);
      setNotifications([]);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Dashboard error:', error);
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchDashboard();
    // Auto-refresh every 30 seconds for real-time updates
    const interval = setInterval(fetchDashboard, 30000);
    return () => clearInterval(interval);
  }, [fetchDashboard]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchDashboard();
    toast.success('Dashboard refreshed');
  };

  const statusColors = {
    pending: 'bg-yellow-500/20 text-yellow-400',
    booked: 'bg-yellow-500/20 text-yellow-400',
    confirmed: 'bg-blue-500/20 text-blue-400',
    sample_collected: 'bg-purple-500/20 text-purple-400',
    processing: 'bg-orange-500/20 text-orange-400',
    report_ready: 'bg-green-500/20 text-green-400',
    completed: 'bg-teal-500/20 text-teal-400'
  };

  // Get today's and upcoming appointments
  const today = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter(a => a.date === today);
  const upcomingAppointments = appointments.filter(a => a.date > today && ['pending', 'booked', 'confirmed'].includes(a.status));
  const pendingTests = appointments.filter(a => ['pending', 'booked', 'confirmed'].includes(a.status));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 mt-1 flex items-center gap-2">
            Real-time overview of your lab operations
            {lastUpdated && (
              <span className="text-xs text-slate-500">
                • Updated {lastUpdated.toLocaleTimeString()}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/20 rounded-lg">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-400 text-xs font-medium">Auto-refresh ON</span>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Live Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <StatCard 
          icon={Clock} 
          label="Pending" 
          value={dashboard?.pending || 0} 
          color="from-yellow-500 to-orange-500"
          onClick={() => navigate('/lab/appointments?status=pending')}
        />
        <StatCard 
          icon={Calendar} 
          label="Today" 
          value={dashboard?.today || 0} 
          color="from-blue-500 to-cyan-500"
        />
        <StatCard 
          icon={TrendingUp} 
          label="Upcoming" 
          value={dashboard?.upcoming || upcomingAppointments.length} 
          color="from-indigo-500 to-purple-500"
        />
        <StatCard 
          icon={Beaker} 
          label="Sample Collected" 
          value={dashboard?.sample_collected || 0} 
          color="from-purple-500 to-pink-500"
          onClick={() => navigate('/lab/appointments?status=sample_collected')}
        />
        <StatCard 
          icon={FileText} 
          label="Report Ready" 
          value={dashboard?.report_ready || 0} 
          color="from-green-500 to-emerald-500"
        />
        <StatCard 
          icon={CheckCircle} 
          label="Completed" 
          value={dashboard?.completed || 0} 
          color="from-teal-500 to-cyan-500"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Appointments */}
        <div className="lg:col-span-2 bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold">Today's Tests</h2>
                <p className="text-slate-400 text-sm">{todayAppointments.length} scheduled for today</p>
              </div>
            </div>
            <button 
              onClick={() => navigate('/lab/appointments')}
              className="flex items-center gap-2 text-purple-400 hover:text-purple-300 text-sm"
            >
              View All <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="divide-y divide-slate-700 max-h-80 overflow-y-auto">
            {todayAppointments.length > 0 ? (
              todayAppointments.map((apt) => (
                <div 
                  key={apt.id} 
                  className="p-4 hover:bg-slate-700/30 cursor-pointer transition-all"
                  onClick={() => navigate(`/lab/appointments?id=${apt.id}`)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-medium">
                        {apt.user?.name?.[0]?.toUpperCase() || 'U'}
                      </div>
                      <div>
                        <p className="text-white font-medium">{apt.user?.name || 'Unknown'}</p>
                        <p className="text-slate-400 text-sm">{apt.user?.phone} • {apt.time}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${statusColors[apt.status] || 'bg-slate-600 text-slate-400'}`}>
                      {apt.status?.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400">
                <Calendar className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p>No tests scheduled for today</p>
              </div>
            )}
          </div>
        </div>

        {/* Notifications Panel */}
        <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Bell className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold">Recent Activity</h2>
                <p className="text-slate-400 text-sm">{notifications.length} notifications</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-700 max-h-80 overflow-y-auto">
            {notifications.length > 0 ? (
              notifications.slice(0, 8).map((notif, idx) => (
                <div key={idx} className="p-3 hover:bg-slate-700/30 transition-all">
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      notif.status === 'pending' || notif.status === 'booked' ? 'bg-yellow-400' :
                      notif.status === 'sample_collected' ? 'bg-purple-400' :
                      notif.status === 'completed' ? 'bg-green-400' : 'bg-blue-400'
                    }`}></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium">{notif.user_name}</p>
                      <p className="text-slate-400 text-xs">{notif.date} • {notif.time}</p>
                      <span className={`inline-block mt-1 px-2 py-0.5 rounded text-xs ${statusColors[notif.status]}`}>
                        {notif.status?.replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400">
                <Bell className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p className="text-sm">No recent activity</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold">Upcoming Tests</h2>
                <p className="text-slate-400 text-sm">{upcomingAppointments.length} scheduled</p>
              </div>
            </div>
          </div>

          <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {upcomingAppointments.slice(0, 6).map((apt) => (
              <div 
                key={apt.id}
                onClick={() => navigate(`/lab/appointments?id=${apt.id}`)}
                className="p-3 bg-slate-700/50 rounded-xl hover:bg-slate-700 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-medium text-sm">
                    {apt.user?.name?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium truncate">{apt.user?.name}</p>
                    <p className="text-slate-400 text-sm">{apt.date} • {apt.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button 
          onClick={() => navigate('/lab/appointments')}
          className="p-5 bg-slate-800 rounded-2xl border border-slate-700 hover:border-purple-500/50 transition-all text-left group"
        >
          <ClipboardList className="w-8 h-8 text-purple-400 mb-3" />
          <h3 className="text-white font-semibold group-hover:text-purple-400 transition-colors">All Appointments</h3>
          <p className="text-slate-400 text-sm mt-1">View and manage all tests</p>
        </button>
        
        <button 
          onClick={() => navigate('/lab/upload')}
          className="p-5 bg-slate-800 rounded-2xl border border-slate-700 hover:border-green-500/50 transition-all text-left group"
        >
          <FileText className="w-8 h-8 text-green-400 mb-3" />
          <h3 className="text-white font-semibold group-hover:text-green-400 transition-colors">Upload Report</h3>
          <p className="text-slate-400 text-sm mt-1">{dashboard?.sample_collected || 0} ready for report</p>
        </button>

        <button 
          onClick={() => navigate('/lab/stats')}
          className="p-5 bg-slate-800 rounded-2xl border border-slate-700 hover:border-blue-500/50 transition-all text-left group"
        >
          <TrendingUp className="w-8 h-8 text-blue-400 mb-3" />
          <h3 className="text-white font-semibold group-hover:text-blue-400 transition-colors">Statistics</h3>
          <p className="text-slate-400 text-sm mt-1">View performance metrics</p>
        </button>
      </div>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, color, onClick }) => (
  <div 
    onClick={onClick}
    className={`bg-slate-800 rounded-xl p-4 border border-slate-700 ${onClick ? 'cursor-pointer hover:border-slate-500' : ''} transition-all`}
  >
    <div className="flex items-center justify-between">
      <div>
        <p className="text-slate-400 text-xs">{label}</p>
        <p className="text-2xl font-bold text-white mt-1">{value}</p>
      </div>
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
    </div>
  </div>
);

export default LabDashboard;
