export { default as LabLogin } from './LabLogin';
export { default as LabLayout } from './LabLayout';
export { default as LabDashboard } from './LabDashboard';
export { default as LabAppointments } from './LabAppointments';
export { default as LabUploadReport } from './LabUploadReport';
export { default as LabStats } from './LabStats';
