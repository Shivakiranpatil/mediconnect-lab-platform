import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { 
  Search, Filter, Clock, CheckCircle, User, Phone, MapPin,
  ChevronRight, X, Check, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { labService } from '@/config/supabase';

const LabAppointments = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const statuses = [
    { value: 'all', label: 'All', color: 'bg-slate-600' },
    { value: 'pending', label: 'Pending', color: 'bg-yellow-500' },
    { value: 'confirmed', label: 'Confirmed', color: 'bg-blue-500' },
    { value: 'sample_collected', label: 'Sample Collected', color: 'bg-purple-500' },
    { value: 'processing', label: 'Processing', color: 'bg-orange-500' },
    { value: 'report_ready', label: 'Report Ready', color: 'bg-green-500' },
    { value: 'completed', label: 'Completed', color: 'bg-teal-500' }
  ];

  const statusFlow = ['pending', 'confirmed', 'sample_collected', 'processing', 'report_ready', 'completed'];

  const fetchAppointments = async () => {
    const labUser = JSON.parse(localStorage.getItem('labUser') || '{}');
    const labId = labUser.id;
    
    try {
      let allAppointments = await labService.getAppointments(labId);
      
      // Filter by status if needed
      if (statusFilter !== 'all') {
        allAppointments = allAppointments.filter(a => a.status === statusFilter);
      }
      
      setAppointments(allAppointments);
      
      // Check if specific appointment is requested
      const aptId = searchParams.get('id');
      if (aptId) {
        const apt = allAppointments.find(a => a.id === aptId);
        if (apt) setSelectedAppointment(apt);
      }
    } catch (error) {
      console.error('Fetch appointments error:', error);
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [statusFilter]);

  const updateStatus = async (appointmentId, newStatus) => {
    setUpdatingStatus(true);
    
    try {
      const apt = appointments.find(a => a.id === appointmentId);
      await labService.updateAppointmentStatus(appointmentId, newStatus, apt?.user?.id);
      toast.success(`Status updated to ${newStatus.replace(/_/g, ' ')}`);
      fetchAppointments();
      if (selectedAppointment?.id === appointmentId) {
        setSelectedAppointment(prev => ({ ...prev, status: newStatus }));
      }
    } catch (error) {
      console.error('Update status error:', error);
      toast.error('Failed to update status');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const getNextStatus = (currentStatus) => {
    const currentIndex = statusFlow.indexOf(currentStatus);
    if (currentIndex < statusFlow.length - 1) {
      return statusFlow[currentIndex + 1];
    }
    return null;
  };

  const statusColors = {
    pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    confirmed: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    sample_collected: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    processing: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    report_ready: 'bg-green-500/20 text-green-400 border-green-500/30',
    completed: 'bg-teal-500/20 text-teal-400 border-teal-500/30'
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Appointments</h1>
        <p className="text-slate-400 mt-1">Manage tests and update statuses</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {statuses.map((s) => (
          <button
            key={s.value}
            onClick={() => setStatusFilter(s.value)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              statusFilter === s.value
                ? `${s.color} text-white`
                : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Appointments List */}
      <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
        {appointments.length > 0 ? (
          <div className="divide-y divide-slate-700">
            {appointments.map((apt) => (
              <div 
                key={apt.id}
                onClick={() => setSelectedAppointment(apt)}
                className="p-4 hover:bg-slate-700/30 cursor-pointer transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-semibold">
                      {apt.user?.name?.[0]?.toUpperCase() || 'U'}
                    </div>
                    <div>
                      <p className="text-white font-medium">{apt.user?.name || 'Unknown User'}</p>
                      <div className="flex items-center gap-3 text-slate-400 text-sm mt-1">
                        {apt.user?.age && (
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {apt.user.age} yrs
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {apt.user?.phone || apt.user?.email || 'N/A'}
                        </span>
                        {apt.address?.emirate && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {apt.address.emirate}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-white">{apt.date}</p>
                      <p className="text-slate-400 text-sm">{apt.time}</p>
                    </div>
                    <span className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${statusColors[apt.status]}`}>
                      {apt.status?.replace(/_/g, ' ')}
                    </span>
                    <ChevronRight className="w-5 h-5 text-slate-400" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-slate-400">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No appointments found</p>
            <p className="text-sm mt-1">Try changing the filter</p>
          </div>
        )}
      </div>

      {/* Appointment Detail Modal */}
      {selectedAppointment && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h2 className="text-xl font-bold text-white">Appointment Details</h2>
              <button 
                onClick={() => setSelectedAppointment(null)} 
                className="p-2 hover:bg-slate-700 rounded-lg text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* User Info */}
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-xl font-bold">
                  {selectedAppointment.user?.name?.[0]?.toUpperCase() || 'U'}
                </div>
                <div>
                  <p className="text-xl font-semibold text-white">{selectedAppointment.user?.name}</p>
                  <p className="text-slate-400">{selectedAppointment.user?.phone}</p>
                  <p className="text-slate-500 text-sm">{selectedAppointment.user?.email}</p>
                </div>
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700/50 rounded-xl p-3">
                  <p className="text-slate-400 text-xs">Date & Time</p>
                  <p className="text-white font-medium">{selectedAppointment.date} • {selectedAppointment.time}</p>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-3">
                  <p className="text-slate-400 text-xs">Plan Type</p>
                  <p className="text-white font-medium capitalize">{selectedAppointment.user?.plan_type?.replace(/-/g, ' ')}</p>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-3">
                  <p className="text-slate-400 text-xs">Age</p>
                  <p className="text-white font-medium">{selectedAppointment.user?.age || 'N/A'} years</p>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-3">
                  <p className="text-slate-400 text-xs">Location</p>
                  <p className="text-white font-medium">{selectedAppointment.user?.emirate}</p>
                </div>
              </div>

              {/* Address */}
              {selectedAppointment.address && (
                <div className="bg-slate-700/50 rounded-xl p-3">
                  <p className="text-slate-400 text-xs mb-1">Address</p>
                  <p className="text-white text-sm">
                    {selectedAppointment.address.flat && `${selectedAppointment.address.flat}, `}
                    {selectedAppointment.address.building && `${selectedAppointment.address.building}, `}
                    {selectedAppointment.address.area && `${selectedAppointment.address.area}, `}
                    {selectedAppointment.address.emirate}
                  </p>
                </div>
              )}

              {/* Current Status */}
              <div>
                <p className="text-slate-400 text-sm mb-3">Current Status</p>
                <div className="flex flex-wrap gap-2">
                  {statusFlow.map((s, index) => {
                    const currentIndex = statusFlow.indexOf(selectedAppointment.status);
                    const isPast = index < currentIndex;
                    const isCurrent = index === currentIndex;
                    
                    return (
                      <div 
                        key={s}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 ${
                          isCurrent ? statusColors[s] :
                          isPast ? 'bg-green-500/10 text-green-400' :
                          'bg-slate-700 text-slate-500'
                        }`}
                      >
                        {isPast && <Check className="w-3 h-3" />}
                        {s.replace(/_/g, ' ')}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Update Status Button */}
              {getNextStatus(selectedAppointment.status) && (
                <button
                  onClick={() => updateStatus(selectedAppointment.id, getNextStatus(selectedAppointment.status))}
                  disabled={updatingStatus}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {updatingStatus ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Mark as {getNextStatus(selectedAppointment.status)?.replace(/_/g, ' ')}
                    </>
                  )}
                </button>
              )}

              {selectedAppointment.status === 'completed' && (
                <div className="text-center py-3 bg-teal-500/10 rounded-xl border border-teal-500/30">
                  <CheckCircle className="w-8 h-8 text-teal-400 mx-auto mb-2" />
                  <p className="text-teal-400 font-medium">Appointment Completed</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LabAppointments;
