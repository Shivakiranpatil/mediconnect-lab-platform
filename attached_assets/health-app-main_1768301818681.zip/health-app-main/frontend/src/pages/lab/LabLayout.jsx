import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Outlet } from 'react-router-dom';
import { 
  LayoutDashboard, ClipboardList, FileText, BarChart3,
  LogOut, TestTube, Bell, Loader2
} from 'lucide-react';

const LabLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [labUser, setLabUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const verifyLabSession = async () => {
      const token = localStorage.getItem('labToken');
      const user = localStorage.getItem('labUser');
      
      if (!token) {
        navigate('/lab/login');
        return;
      }

      try {
        if (user) {
          setLabUser(JSON.parse(user));
        }
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Lab session verification failed:', error);
        localStorage.removeItem('labToken');
        localStorage.removeItem('labUser');
        navigate('/lab/login');
      } finally {
        setLoading(false);
      }
    };

    verifyLabSession();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('labToken');
    localStorage.removeItem('labUser');
    navigate('/lab/login');
  };

  // Show loading state while verifying session
  if (loading) {
    return (
      <div className="min-h-screen h-screen bg-slate-900 flex items-center justify-center w-full">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-purple-500 animate-spin mx-auto mb-4" />
          <p className="text-slate-400">Verifying session...</p>
        </div>
      </div>
    );
  }

  // Don't render content if not authenticated
  if (!isAuthenticated) {
    return null;
  }

  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/lab' },
    { icon: ClipboardList, label: 'Appointments', path: '/lab/appointments' },
    { icon: FileText, label: 'Upload Report', path: '/lab/upload' },
    { icon: BarChart3, label: 'Statistics', path: '/lab/stats' },
  ];

  const isActive = (path) => {
    if (path === '/lab') return location.pathname === '/lab';
    return location.pathname.startsWith(path);
  };

  return (
    <div className="min-h-screen h-screen bg-slate-900 flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 bg-slate-800 border-r border-slate-700 flex flex-col h-screen">
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <TestTube className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-white text-sm">Lab Portal</span>
              {labUser && (
                <p className="text-xs text-slate-400 truncate max-w-[140px]">{labUser.name}</p>
              )}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              data-testid={`lab-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
                isActive(item.path)
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-slate-700">
          <button
            onClick={handleLogout}
            data-testid="lab-logout"
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        {/* Top Bar */}
        <header className="h-16 flex-shrink-0 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6">
          <div>
            <h1 className="text-white font-semibold">
              {labUser?.name || 'Lab Partner'}
            </h1>
            <p className="text-slate-400 text-sm">{labUser?.emirate} {labUser?.area && `• ${labUser.area}`}</p>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative p-2 hover:bg-slate-700 rounded-lg text-slate-400">
              <Bell className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-auto bg-slate-900">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default LabLayout;
