import React, { useState, useEffect, useRef } from 'react';
import { 
  Upload, User, Plus, X, Check, AlertCircle, FileText, Search, Users,
  Sparkles, FileUp, Loader2, Wand2, Edit3, Clock, CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';
import { labService } from '@/config/supabase';
import { parsePDFLabReport } from '@/services/pdfParser';

const LabUploadReport = () => {
  const [appointments, setAppointments] = useState([]);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [selectedMember, setSelectedMember] = useState('primary'); // 'primary' or family member id
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [parsingPdf, setParsingPdf] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editingReportId, setEditingReportId] = useState(null);
  const fileInputRef = useRef(null);

  const [reportData, setReportData] = useState({
    summary: '',
    biomarkers: [],
    recommendations: [],
    notes: ''
  });

  const [newBiomarker, setNewBiomarker] = useState({
    name: '',
    value: '',
    unit: '',
    reference_range: '',
    status: 'normal',
    category: 'General'
  });

  const [newRecommendation, setNewRecommendation] = useState('');

  const biomarkerStatuses = [
    { value: 'normal', label: 'Normal', color: 'bg-green-500' },
    { value: 'borderline', label: 'Borderline', color: 'bg-yellow-500' },
    { value: 'needs_attention', label: 'Needs Attention', color: 'bg-red-500' }
  ];

  const commonBiomarkers = [
    { name: 'Hemoglobin', unit: 'g/dL', range: '12-17', category: 'Blood' },
    { name: 'Total Cholesterol', unit: 'mg/dL', range: '<200', category: 'Heart' },
    { name: 'LDL Cholesterol', unit: 'mg/dL', range: '<100', category: 'Heart' },
    { name: 'HDL Cholesterol', unit: 'mg/dL', range: '>40', category: 'Heart' },
    { name: 'Triglycerides', unit: 'mg/dL', range: '<150', category: 'Heart' },
    { name: 'Vitamin D', unit: 'ng/mL', range: '30-100', category: 'Vitamins' },
    { name: 'Vitamin B12', unit: 'pg/mL', range: '200-900', category: 'Vitamins' },
    { name: 'Fasting Glucose', unit: 'mg/dL', range: '70-100', category: 'Metabolic' },
    { name: 'HbA1c', unit: '%', range: '<5.7', category: 'Metabolic' },
    { name: 'TSH', unit: 'mIU/L', range: '0.4-4.0', category: 'Hormones' },
    { name: 'Creatinine', unit: 'mg/dL', range: '0.6-1.2', category: 'Kidney' },
    { name: 'Iron', unit: 'mcg/dL', range: '60-170', category: 'Blood' },
  ];

  const fetchAppointments = async () => {
    const labUser = JSON.parse(localStorage.getItem('labUser') || '{}');
    const labId = labUser.id;
    
    console.log('Fetching appointments for lab:', labId);
    
    try {
      if (labId) {
        const allAppointments = await labService.getAppointments(labId);
        console.log('All appointments received:', allAppointments);
        
        // Show ALL appointments except completed (more than 24h ago)
        // This allows editing reports within 24 hours
        const now = new Date();
        const appointmentsWithEditStatus = (allAppointments || []).map(apt => {
          const canEdit = apt.report_uploaded_at ? 
            (now - new Date(apt.report_uploaded_at)) < 24 * 60 * 60 * 1000 : false;
          return { ...apt, canEditReport: canEdit };
        });
        
        console.log('Appointments with edit status:', appointmentsWithEditStatus);
        setAppointments(appointmentsWithEditStatus);
      }
    } catch (error) {
      console.error('Fetch appointments error:', error);
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const handleSelectAppointment = (apt) => {
    setSelectedAppointment(apt);
    setSelectedMember('primary');
    setEditMode(false);
    setEditingReportId(null);
    // Reset report data
    setReportData({ summary: '', biomarkers: [], recommendations: [], notes: '' });
  };

  const handleEditReport = async (apt) => {
    setSelectedAppointment(apt);
    setSelectedMember('primary');
    setEditMode(true);
    
    try {
      // Fetch existing report data
      const report = await labService.getReportByAppointment(apt.id);
      if (report) {
        setEditingReportId(report.id);
        setReportData({
          summary: report.summary || '',
          biomarkers: report.biomarkers || [],
          recommendations: report.recommendations || [],
          notes: report.notes || ''
        });
        toast.info('Editing existing report');
      }
    } catch (error) {
      console.error('Error fetching report:', error);
      toast.error('Failed to load report for editing');
    }
  };

  const getStatusBadge = (apt) => {
    if (['report_ready', 'completed'].includes(apt.status)) {
      const canEdit = apt.canEditReport;
      return (
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 rounded-lg text-xs font-medium bg-green-500/20 text-green-400">
            Report Uploaded
          </span>
          {canEdit && (
            <span className="px-2 py-1 rounded-lg text-xs font-medium bg-yellow-500/20 text-yellow-400 flex items-center gap-1">
              <Clock className="w-3 h-3" /> Editable
            </span>
          )}
        </div>
      );
    }
    return (
      <span className="px-2 py-1 rounded-lg text-xs font-medium bg-blue-500/20 text-blue-400">
        {apt.status?.replace(/_/g, ' ')}
      </span>
    );
  };

  const handleAddBiomarker = () => {
    if (!newBiomarker.name || !newBiomarker.value) {
      toast.error('Please fill biomarker name and value');
      return;
    }
    setReportData(prev => ({
      ...prev,
      biomarkers: [...prev.biomarkers, { ...newBiomarker, id: Date.now() }]
    }));
    setNewBiomarker({
      name: '',
      value: '',
      unit: '',
      reference_range: '',
      status: 'normal',
      category: 'General'
    });
  };

  const handleQuickAddBiomarker = (bio) => {
    setNewBiomarker({
      name: bio.name,
      value: '',
      unit: bio.unit,
      reference_range: bio.range,
      status: 'normal',
      category: bio.category
    });
  };

  const handleRemoveBiomarker = (id) => {
    setReportData(prev => ({
      ...prev,
      biomarkers: prev.biomarkers.filter(b => b.id !== id)
    }));
  };

  const handleAddRecommendation = () => {
    if (!newRecommendation.trim()) return;
    setReportData(prev => ({
      ...prev,
      recommendations: [...prev.recommendations, newRecommendation.trim()]
    }));
    setNewRecommendation('');
  };

  // PDF Upload and AI Parsing
  const handlePdfUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf')) {
      toast.error('Please upload a PDF file');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size must be less than 10MB');
      return;
    }

    setParsingPdf(true);
    toast.info('Analyzing PDF with AI...', { duration: 5000 });

    try {
      const result = await parsePDFLabReport(file);
      
      if (result.success && result.data) {
        const { summary, biomarkers, recommendations } = result.data;
        
        // Update report data with parsed values
        setReportData(prev => ({
          ...prev,
          summary: summary || prev.summary,
          biomarkers: biomarkers || [],
          recommendations: recommendations || []
        }));
        
        toast.success(`Successfully extracted ${biomarkers?.length || 0} biomarkers from PDF!`);
      } else {
        toast.error('Failed to parse PDF. Please enter data manually.');
      }
    } catch (error) {
      console.error('PDF parsing error:', error);
      toast.error(error.message || 'Failed to parse PDF. Please enter data manually.');
    } finally {
      setParsingPdf(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const getSelectedPersonName = () => {
    if (!selectedAppointment) return '';
    if (selectedMember === 'primary') {
      return selectedAppointment.user?.name || 'Primary User';
    }
    const member = selectedAppointment.user?.family_members?.find(m => m.id?.toString() === selectedMember || m.name === selectedMember);
    return member?.name || 'Family Member';
  };

  const handleSubmitReport = async () => {
    if (!selectedAppointment) {
      toast.error('Please select an appointment');
      return;
    }
    if (!selectedAppointment.user?.id) {
      toast.error('User information not found for this appointment. Please refresh and try again.');
      return;
    }
    if (!reportData.summary) {
      toast.error('Please add a summary');
      return;
    }
    if (reportData.biomarkers.length === 0) {
      toast.error('Please add at least one biomarker');
      return;
    }

    setSubmitting(true);

    try {
      console.log('Uploading report for user:', selectedAppointment.user?.id, 'appointment:', selectedAppointment.id);
      
      const reportPayload = {
        appointment_id: selectedAppointment.id,
        user_id: selectedAppointment.user.id,
        summary: reportData.summary,
        biomarkers: reportData.biomarkers,
        recommendations: reportData.recommendations,
        notes: reportData.notes,
        member_type: selectedMember === 'primary' ? 'primary' : 'family',
        member_id: selectedMember === 'primary' ? null : selectedMember,
        member_name: getSelectedPersonName(),
        health_score: calculateHealthScore(reportData.biomarkers)
      };

      if (editMode && editingReportId) {
        // Update existing report
        await labService.updateReport(editingReportId, reportPayload);
        toast.success(`Report updated for ${getSelectedPersonName()}!`);
      } else {
        // Create new report
        await labService.uploadReport(reportPayload);
        toast.success(`Report uploaded for ${getSelectedPersonName()}!`);
      }
      
      // Reset form
      setSelectedAppointment(null);
      setSelectedMember('primary');
      setReportData({ summary: '', biomarkers: [], recommendations: [], notes: '' });
      setEditMode(false);
      setEditingReportId(null);
      fetchAppointments();
    } catch (error) {
      console.error('Upload report error:', error);
      toast.error('Failed to save report');
    } finally {
      setSubmitting(false);
    }
  };
  
  const calculateHealthScore = (biomarkers) => {
    if (!biomarkers?.length) return 75;
    const normalCount = biomarkers.filter(b => b.status === 'normal').length;
    return Math.round((normalCount / biomarkers.length) * 100);
  };

  const filteredAppointments = appointments.filter(apt => 
    apt.user?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apt.user?.phone?.includes(searchTerm)
  );

  // Check if family plan
  const isFamilyPlan = selectedAppointment?.user?.plan_type?.includes('family');
  const familyMembers = selectedAppointment?.user?.family_members || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Upload Report</h1>
        <p className="text-slate-400 mt-1">Add health reports for completed tests</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Appointment Selection - Left Panel */}
        <div className="lg:col-span-4">
          <div className="bg-slate-800 rounded-2xl border border-slate-700 p-5 sticky top-6">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-400" />
              Select Patient
            </h3>
            
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name or phone..."
                className="w-full h-11 pl-10 pr-4 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {filteredAppointments.length > 0 ? (
                filteredAppointments.map((apt) => {
                  const hasReport = ['report_ready', 'completed'].includes(apt.status);
                  const canEdit = apt.canEditReport;
                  
                  return (
                    <div
                      key={apt.id}
                      className={`w-full p-4 rounded-xl text-left transition-all ${
                        selectedAppointment?.id === apt.id
                          ? 'bg-purple-600 border-purple-500'
                          : 'bg-slate-700/50 hover:bg-slate-700 border-transparent'
                      } border`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-semibold">
                          {apt.user?.name?.[0]?.toUpperCase() || 'U'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white font-medium truncate">{apt.user?.name || 'Unknown'}</p>
                          <p className="text-slate-400 text-sm">
                            {apt.user?.phone || apt.user?.email || 'No contact'}
                            {apt.user?.age && <span className="ml-2">• {apt.user.age} yrs</span>}
                          </p>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            {hasReport ? (
                              <>
                                <span className="px-2 py-0.5 rounded text-xs bg-green-500/20 text-green-400 flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3" /> Report Uploaded
                                </span>
                                {canEdit && (
                                  <span className="px-2 py-0.5 rounded text-xs bg-yellow-500/20 text-yellow-400 flex items-center gap-1">
                                    <Clock className="w-3 h-3" /> Editable
                                  </span>
                                )}
                              </>
                            ) : (
                              <span className={`px-2 py-0.5 rounded text-xs ${
                                apt.status === 'sample_collected' 
                                  ? 'bg-purple-500/20 text-purple-400' 
                                  : 'bg-orange-500/20 text-orange-400'
                              }`}>
                                {apt.status?.replace(/_/g, ' ')}
                              </span>
                            )}
                            <span className="text-slate-500 text-xs">{apt.date}</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Action Buttons */}
                      <div className="mt-3 flex gap-2">
                        {hasReport ? (
                          canEdit ? (
                            <button
                              onClick={() => handleEditReport(apt)}
                              className="flex-1 py-2 px-3 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 rounded-lg text-sm font-medium flex items-center justify-center gap-2"
                            >
                              <Edit3 className="w-4 h-4" /> Edit Report
                            </button>
                          ) : (
                            <div className="flex-1 py-2 px-3 bg-slate-600/50 text-slate-400 rounded-lg text-sm text-center">
                              Edit window expired (24h)
                            </div>
                          )
                        ) : (
                          <button
                            onClick={() => handleSelectAppointment(apt)}
                            className="flex-1 py-2 px-3 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-lg text-sm font-medium flex items-center justify-center gap-2"
                          >
                            <Upload className="w-4 h-4" /> Upload Report
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-slate-400">
                  <AlertCircle className="w-10 h-10 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No appointments found</p>
                  <p className="text-xs text-slate-500 mt-1">Appointments assigned to your lab will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Report Form - Right Panel */}
        <div className="lg:col-span-8 space-y-6">
          {selectedAppointment ? (
            <>
              {/* Selected User Info Card */}
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl font-bold">
                      {selectedAppointment.user?.name?.[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="text-xl font-semibold text-white">{selectedAppointment.user?.name}</p>
                      <p className="text-slate-400">{selectedAppointment.user?.phone} • {selectedAppointment.user?.age} years</p>
                      <p className="text-slate-500 text-sm">{selectedAppointment.user?.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-lg text-sm font-medium capitalize">
                      {selectedAppointment.user?.plan_type?.replace(/-/g, ' ')}
                    </span>
                    <p className="text-slate-500 text-sm mt-2">{selectedAppointment.date} • {selectedAppointment.time}</p>
                  </div>
                </div>

                {/* Family Member Selection */}
                {isFamilyPlan && familyMembers.length > 0 && (
                  <div className="mt-5 pt-5 border-t border-slate-700">
                    <p className="text-white font-medium mb-3 flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-400" />
                      Select Person for Report
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {/* Primary User */}
                      <button
                        onClick={() => setSelectedMember('primary')}
                        className={`p-3 rounded-xl text-left transition-all border ${
                          selectedMember === 'primary'
                            ? 'bg-purple-600 border-purple-500'
                            : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                        }`}
                      >
                        <p className="text-white font-medium truncate">{selectedAppointment.user?.name}</p>
                        <p className="text-slate-400 text-xs">Primary</p>
                      </button>
                      
                      {/* Family Members */}
                      {familyMembers.map((member, idx) => (
                        <button
                          key={member.id || idx}
                          onClick={() => setSelectedMember(member.id?.toString() || member.name)}
                          className={`p-3 rounded-xl text-left transition-all border ${
                            selectedMember === (member.id?.toString() || member.name)
                              ? 'bg-purple-600 border-purple-500'
                              : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                          }`}
                        >
                          <p className="text-white font-medium truncate">{member.name}</p>
                          <p className="text-slate-400 text-xs capitalize">{member.relationship} • {member.age}y</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Currently Uploading For */}
              <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <User className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <p className="text-green-400 font-medium">Uploading Report For:</p>
                  <p className="text-green-300 text-lg">{getSelectedPersonName()}</p>
                </div>
              </div>

              {/* AI PDF Upload Section */}
              <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/30 rounded-2xl border border-purple-500/30 p-5">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-6 h-6 text-purple-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold flex items-center gap-2">
                      <Wand2 className="w-4 h-4 text-purple-400" />
                      AI-Powered PDF Parsing
                    </h3>
                    <p className="text-slate-400 text-sm mt-1">
                      Upload a PDF lab report and let AI automatically extract biomarkers, values, and recommendations.
                    </p>
                    
                    <div className="mt-4">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".pdf"
                        onChange={handlePdfUpload}
                        className="hidden"
                        id="pdf-upload"
                        disabled={parsingPdf}
                      />
                      <label
                        htmlFor="pdf-upload"
                        className={`inline-flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all cursor-pointer ${
                          parsingPdf
                            ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                            : 'bg-purple-600 hover:bg-purple-500 text-white'
                        }`}
                      >
                        {parsingPdf ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Analyzing PDF...
                          </>
                        ) : (
                          <>
                            <FileUp className="w-5 h-5" />
                            Upload PDF Report
                          </>
                        )}
                      </label>
                      <p className="text-slate-500 text-xs mt-2">
                        Supported: PDF files up to 10MB • Uses OpenAI GPT-4o
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-5">
                <h3 className="text-white font-semibold mb-3">Report Summary</h3>
                <textarea
                  value={reportData.summary}
                  onChange={(e) => setReportData(prev => ({ ...prev, summary: e.target.value }))}
                  placeholder="Overall health summary and key findings..."
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none resize-none"
                />
              </div>

              {/* Biomarkers */}
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-5">
                <h3 className="text-white font-semibold mb-3">Biomarkers</h3>
                
                {/* Quick Add */}
                <div className="mb-4">
                  <p className="text-slate-400 text-sm mb-2">Quick Add Common Tests:</p>
                  <div className="flex flex-wrap gap-2">
                    {commonBiomarkers.map((bio) => (
                      <button
                        key={bio.name}
                        onClick={() => handleQuickAddBiomarker(bio)}
                        className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg text-xs transition-all"
                      >
                        + {bio.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Added Biomarkers */}
                {reportData.biomarkers.length > 0 && (
                  <div className="space-y-2 mb-4">
                    {reportData.biomarkers.map((bio) => (
                      <div key={bio.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-xl">
                        <div className="flex items-center gap-3">
                          <span className={`w-3 h-3 rounded-full ${
                            bio.status === 'normal' ? 'bg-green-500' :
                            bio.status === 'borderline' ? 'bg-yellow-500' : 'bg-red-500'
                          }`}></span>
                          <div>
                            <p className="text-white font-medium">{bio.name}</p>
                            <p className="text-slate-400 text-sm">{bio.value} {bio.unit} (Ref: {bio.reference_range})</p>
                          </div>
                        </div>
                        <button onClick={() => handleRemoveBiomarker(bio.id)} className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add New Biomarker */}
                <div className="grid grid-cols-12 gap-2">
                  <input
                    type="text"
                    value={newBiomarker.name}
                    onChange={(e) => setNewBiomarker(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Biomarker name"
                    className="col-span-4 h-11 px-3 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={newBiomarker.value}
                    onChange={(e) => setNewBiomarker(prev => ({ ...prev, value: e.target.value }))}
                    placeholder="Value"
                    className="col-span-2 h-11 px-3 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={newBiomarker.unit}
                    onChange={(e) => setNewBiomarker(prev => ({ ...prev, unit: e.target.value }))}
                    placeholder="Unit"
                    className="col-span-2 h-11 px-3 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
                  />
                  <select
                    value={newBiomarker.status}
                    onChange={(e) => setNewBiomarker(prev => ({ ...prev, status: e.target.value }))}
                    className="col-span-3 h-11 px-3 bg-slate-700 border border-slate-600 rounded-xl text-white focus:border-purple-500 focus:outline-none"
                  >
                    {biomarkerStatuses.map(s => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                  <button
                    onClick={handleAddBiomarker}
                    className="col-span-1 h-11 bg-purple-600 hover:bg-purple-500 text-white rounded-xl transition-all flex items-center justify-center"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-slate-800 rounded-2xl border border-slate-700 p-5">
                <h3 className="text-white font-semibold mb-3">Recommendations</h3>
                
                {reportData.recommendations.length > 0 && (
                  <div className="space-y-2 mb-4">
                    {reportData.recommendations.map((rec, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-xl">
                        <span className="text-white">{rec}</span>
                        <button 
                          onClick={() => setReportData(prev => ({
                            ...prev,
                            recommendations: prev.recommendations.filter((_, i) => i !== idx)
                          }))}
                          className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newRecommendation}
                    onChange={(e) => setNewRecommendation(e.target.value)}
                    placeholder="Add recommendation..."
                    className="flex-1 h-11 px-4 bg-slate-700 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:border-purple-500 focus:outline-none"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddRecommendation()}
                  />
                  <button
                    onClick={handleAddRecommendation}
                    className="px-6 bg-slate-600 hover:bg-slate-500 text-white rounded-xl transition-all"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Submit */}
              <button
                onClick={handleSubmitReport}
                disabled={submitting}
                className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl font-semibold transition-all disabled:opacity-50 flex items-center justify-center gap-3 text-lg"
              >
                {submitting ? (
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Upload className="w-6 h-6" />
                    Upload Report for {getSelectedPersonName()}
                  </>
                )}
              </button>
            </>
          ) : (
            <div className="bg-slate-800 rounded-2xl border border-slate-700 p-16 text-center">
              <FileText className="w-20 h-20 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400 text-lg">Select a patient from the list</p>
              <p className="text-slate-500 text-sm mt-2">Choose an appointment to upload the health report</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LabUploadReport;
