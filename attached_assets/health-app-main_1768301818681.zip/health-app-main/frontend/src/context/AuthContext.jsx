import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  auth, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
} from '@/config/firebase';
import { userService } from '@/config/supabase';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [firebaseUser, setFirebaseUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Timeout to ensure loading doesn't get stuck
    const loadingTimeout = setTimeout(() => {
      if (loading) {
        console.log('Auth loading timeout - setting loading to false');
        setLoading(false);
      }
    }, 5000);
    
    // Check for stored user on initial load
    const storedUser = localStorage.getItem('user');
    const storedUid = localStorage.getItem('firebase_uid');
    
    if (storedUser && storedUid) {
      try {
        setUser(JSON.parse(storedUser));
        setIsAuthenticated(true);
      } catch (e) {
        console.error('Failed to parse stored user');
      }
    }
    
    // Listen for Firebase auth state changes
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        setFirebaseUser(fbUser);
        try {
          // Get or create user in Supabase
          const supabaseUser = await userService.createOrGetUser(
            fbUser.uid,
            fbUser.email || fbUser.phoneNumber || ''
          );
          
          const userData = {
            id: supabaseUser.id, // Always use Supabase ID
            supabase_id: supabaseUser.id,
            firebase_uid: supabaseUser.firebase_uid || fbUser.uid,
            email: fbUser.email || supabaseUser.email,
            phone: supabaseUser.phone_number,
            name: supabaseUser.name,
            age: supabaseUser.age,
            plan_type: supabaseUser.plan_type,
            family_members: supabaseUser.family_members || []
          };
          
          console.log('User authenticated with Supabase ID:', supabaseUser.id);
          
          setUser(userData);
          setIsAuthenticated(true);
          
          // Store in localStorage for persistence
          localStorage.setItem('user', JSON.stringify(userData));
          localStorage.setItem('firebase_uid', fbUser.uid);
        } catch (error) {
          console.error('Supabase user error:', error);
          // Still set as authenticated with Firebase data only
          // Note: Booking won't work without Supabase user
          const basicUser = {
            email: fbUser.email,
            firebase_uid: fbUser.uid,
            id: null // No valid Supabase ID - booking will prompt to complete profile
          };
          console.warn('User authenticated but no Supabase record - booking features limited');
          setUser(basicUser);
          setIsAuthenticated(true);
          localStorage.setItem('user', JSON.stringify(basicUser));
          localStorage.setItem('firebase_uid', fbUser.uid);
        }
      } else {
        setFirebaseUser(null);
        setUser(null);
        setIsAuthenticated(false);
        localStorage.removeItem('user');
        localStorage.removeItem('firebase_uid');
      }
      setLoading(false);
      clearTimeout(loadingTimeout);
    });

    return () => {
      unsubscribe();
      clearTimeout(loadingTimeout);
    };
  }, []);

  // Sign up with email/password
  const signUp = async (email, password) => {
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      return { success: true, user: result.user };
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  };

  // Sign in with email/password
  const signIn = async (email, password) => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      return { success: true, user: result.user };
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  };

  // Reset password
  const resetPassword = async (email) => {
    try {
      await sendPasswordResetEmail(auth, email);
      return { success: true };
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  };

  // Logout
  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setFirebaseUser(null);
      setIsAuthenticated(false);
      localStorage.removeItem('user');
      localStorage.removeItem('firebase_uid');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Update user profile
  const updateUser = async (userData) => {
    if (!user?.id) return;
    
    try {
      const updatedUser = await userService.updateProfile(user.id, userData);
      const newUser = {
        ...user,
        ...updatedUser,
        phone: updatedUser.phone_number
      };
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return newUser;
    } catch (error) {
      console.error('Update user error:', error);
      throw error;
    }
  };

  // Select plan
  const selectPlan = async (planType) => {
    if (!user?.id) return;
    
    try {
      const updatedUser = await userService.selectPlan(user.id, planType);
      const newUser = { ...user, plan_type: planType };
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return newUser;
    } catch (error) {
      console.error('Select plan error:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      firebaseUser,
      loading,
      isAuthenticated,
      signUp,
      signIn,
      resetPassword,
      logout,
      updateUser,
      selectPlan
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
