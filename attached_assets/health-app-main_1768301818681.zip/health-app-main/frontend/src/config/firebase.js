// Firebase configuration for CareGuard UAE
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY || "AIzaSyCxH0TwFmtBE6sEEXbEt_vUOswYZdHPfiM",
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN || "healthapp-57239.firebaseapp.com",
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID || "healthapp-57239",
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET || "healthapp-57239.firebasestorage.app",
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID || "620520888566",
  appId: process.env.REACT_APP_FIREBASE_APP_ID || "1:620520888566:web:3ede24fe0605dc2e9c34d7",
  measurementId: process.env.REACT_APP_FIREBASE_MEASUREMENT_ID || "G-CK5V9NQENW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { 
  app, 
  auth, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail
};
