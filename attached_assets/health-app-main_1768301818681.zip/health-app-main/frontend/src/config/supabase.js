// Supabase client and database service
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'https://onfewzfjpknffsrgtbti.supabase.co';
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9uZmV3emZqcGtuZmZzcmd0YnRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc0NjEyMTgsImV4cCI6MjA4MzAzNzIxOH0.sJOmlqerjFem9DKRVoJX3xSKwS0bM9qFBC-XrMliHWA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ============== USER OPERATIONS ==============

export const userService = {
  // Create or get user after Firebase auth
  async createOrGetUser(firebaseUid, emailOrPhone) {
    try {
      console.log('Creating/getting user for Firebase UID:', firebaseUid);
      
      // Check if user exists
      const { data: existingUsers, error: fetchError } = await supabase
        .from('users')
        .select('*')
        .eq('firebase_uid', firebaseUid);

      if (fetchError) {
        console.error('Supabase fetch error:', fetchError);
        // If table doesn't exist, return a mock user
        if (fetchError.code === '42P01' || fetchError.message?.includes('does not exist')) {
          console.warn('Users table not found - database schema needs to be created');
          return {
            id: firebaseUid,
            firebase_uid: firebaseUid,
            email: emailOrPhone?.includes('@') ? emailOrPhone : '',
            phone_number: emailOrPhone?.includes('@') ? '' : emailOrPhone,
            name: null,
            age: null,
            plan_type: null,
            family_members: []
          };
        }
        throw fetchError;
      }

      if (existingUsers && existingUsers.length > 0) {
        console.log('Found existing user:', existingUsers[0].id);
        return existingUsers[0];
      }

      // Determine if it's email or phone
      const isEmail = emailOrPhone && emailOrPhone.includes('@');
      console.log('Creating new user with email:', isEmail ? emailOrPhone : 'N/A');

      // Create new user
      const { data: newUser, error: insertError } = await supabase
        .from('users')
        .insert({
          firebase_uid: firebaseUid,
          phone_number: isEmail ? '' : (emailOrPhone || ''),
          email: isEmail ? emailOrPhone : '',
        })
        .select()
        .single();

      if (insertError) {
        console.error('Supabase insert error:', insertError);
        // Return mock user if insert fails
        return {
          id: firebaseUid,
          firebase_uid: firebaseUid,
          email: isEmail ? emailOrPhone : '',
          phone_number: isEmail ? '' : (emailOrPhone || ''),
          name: null,
          age: null,
          plan_type: null,
          family_members: []
        };
      }

      console.log('Created new user:', newUser.id);

      // Create welcome notification (don't fail if this errors)
      try {
        await supabase.from('notifications').insert({
          user_id: newUser.id,
          title: 'Welcome to CareGuard! 🎉',
          message: 'Your journey to better health starts here. Book your first test to get personalized insights.',
          type: 'welcome'
        });
      } catch (notifError) {
        console.warn('Failed to create welcome notification:', notifError);
      }

      return newUser;
    } catch (error) {
      console.error('createOrGetUser error:', error);
      // Return a fallback user to prevent auth from breaking
      return {
        id: firebaseUid,
        firebase_uid: firebaseUid,
        email: emailOrPhone?.includes('@') ? emailOrPhone : '',
        phone_number: '',
        name: null,
        age: null,
        plan_type: null,
        family_members: []
      };
    }
  },

  // Get user by Firebase UID
  async getUserByFirebaseUid(firebaseUid) {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('firebase_uid', firebaseUid)
      .single();

    if (error) throw error;
    return data;
  },

  // Update user profile
  async updateProfile(userId, profileData) {
    const { data, error } = await supabase
      .from('users')
      .update({
        ...profileData,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Select subscription plan
  async selectPlan(userId, planType) {
    const { data, error } = await supabase
      .from('users')
      .update({
        plan_type: planType,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }
};

// ============== APPOINTMENT OPERATIONS ==============

export const appointmentService = {
  // Book appointment
  async bookAppointment(userId, appointmentData) {
    if (!userId) {
      console.error('No user ID provided for booking');
      throw new Error('User not authenticated');
    }
    
    console.log('bookAppointment called with userId:', userId, 'data:', appointmentData);
    
    try {
      // Find nearest lab based on emirate
      const emirate = appointmentData.address?.emirate || 'Dubai';
      let assignedLab = null;
      
      try {
        const { data: labs, error: labError } = await supabase
          .from('partner_labs')
          .select('*')
          .eq('emirate', emirate)
          .eq('status', 'active')
          .limit(1);

        if (labError) {
          console.warn('Error fetching labs:', labError.message || labError);
        } else {
          assignedLab = labs?.[0] || null;
        }
      } catch (labErr) {
        console.warn('Lab fetch error:', labErr);
      }

      console.log('Assigned lab:', assignedLab?.name || 'None');

      const insertData = {
        user_id: userId,
        date: appointmentData.date,
        time: appointmentData.time,
        address: appointmentData.address,
        phone: appointmentData.phone || null,
        type: appointmentData.type || 'home_collection',
        status: 'booked',
        assigned_lab_id: assignedLab?.id || null,
        assigned_lab_name: assignedLab?.name || null,
        assignment_type: assignedLab ? 'auto' : null
      };

      console.log('Inserting appointment:', insertData);

      const { data: appointment, error } = await supabase
        .from('appointments')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('Supabase insert error:', error);
        const errorMessage = typeof error === 'object' ? (error.message || JSON.stringify(error)) : String(error);
        throw new Error(errorMessage);
      }

      console.log('Appointment created:', appointment);

      // Create notification (don't fail if this errors)
      try {
        await supabase.from('notifications').insert({
          user_id: userId,
          title: 'Booking Confirmed! 📅',
          message: `Your test is scheduled for ${appointmentData.date} at ${appointmentData.time}.`,
          type: 'booking'
        });
      } catch (notifError) {
        console.warn('Failed to create notification:', notifError);
      }

      return appointment;
    } catch (err) {
      console.error('bookAppointment error:', err);
      // Ensure we always throw an Error object, not a plain object
      if (err instanceof Error) {
        throw err;
      } else {
        const errorMessage = typeof err === 'object' ? (err.message || JSON.stringify(err)) : String(err);
        throw new Error(errorMessage);
      }
    }
  },

  // Get all appointments for user
  async getUserAppointments(userId) {
    if (!userId) {
      console.log('getUserAppointments: No userId provided');
      return { upcoming: [], completed: [], all: [] };
    }
    
    console.log('getUserAppointments: Fetching for userId:', userId);
    
    try {
      const { data, error } = await supabase
        .from('appointments')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching appointments:', error);
        return { upcoming: [], completed: [], all: [] };
      }

      console.log('getUserAppointments: Raw data:', data);

      const upcoming = data?.filter(a => ['booked', 'confirmed', 'sample_collected', 'processing'].includes(a.status)) || [];
      const completed = data?.filter(a => ['completed', 'report_ready'].includes(a.status)) || [];

      console.log('getUserAppointments: Upcoming:', upcoming.length, 'Completed:', completed.length);

      return { upcoming, completed, all: data || [] };
    } catch (err) {
      console.error('getUserAppointments error:', err);
      return { upcoming: [], completed: [], all: [] };
    }
  },

  // Check if user has reports
  async checkUserStatus(userId) {
    if (!userId) {
      return {
        has_reports: false,
        report_count: 0,
        has_appointment: false,
        appointment_status: null
      };
    }
    
    try {
      const { data: reports } = await supabase
        .from('reports')
        .select('id')
        .eq('user_id', userId);

      const { data: appointments } = await supabase
        .from('appointments')
        .select('status')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);

      return {
        has_reports: (reports?.length || 0) > 0,
        report_count: reports?.length || 0,
        has_appointment: (appointments?.length || 0) > 0,
        appointment_status: appointments?.[0]?.status || null
      };
    } catch (err) {
      console.error('checkUserStatus error:', err);
      return {
        has_reports: false,
        report_count: 0,
        has_appointment: false,
        appointment_status: null
      };
    }
  }
};

// ============== HEALTH DATA OPERATIONS ==============

export const healthService = {
  // Get biomarkers from latest report
  async getBiomarkers(userId) {
    if (!userId) {
      return { biomarkers: [], test_date: null };
    }
    
    try {
      const { data: reports, error } = await supabase
        .from('reports')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) {
        console.error('Error fetching biomarkers:', error);
        return { biomarkers: [], test_date: null };
      }

      if (!reports?.length) {
        return { biomarkers: [], test_date: null };
      }

      return {
        biomarkers: reports[0].biomarkers || [],
        test_date: reports[0].test_date
      };
    } catch (err) {
      console.error('getBiomarkers error:', err);
      return { biomarkers: [], test_date: null };
    }
  },

  // Calculate health score
  async getHealthScore(userId) {
    if (!userId) {
      return {
        score: 0,
        status: 'No Data',
        excellent_count: 0,
        needs_care_count: 0,
        total_parameters: 0
      };
    }
    
    try {
      const { data: reports, error } = await supabase
        .from('reports')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1);

    if (!reports?.length) {
      return { score: 0, status: 'No Data', excellent_count: 0, needs_care_count: 0, total_parameters: 0, insights: [] };
    }

    const biomarkers = reports[0].biomarkers || [];
    const excellentStatuses = ['excellent', 'optimal', 'normal'];
    const borderlineStatuses = ['borderline', 'slightly low', 'slightly high'];

    let excellentCount = 0;
    let needsCareCount = 0;
    let totalScore = 0;

    biomarkers.forEach(b => {
      const status = (b.status || '').toLowerCase();
      if (excellentStatuses.includes(status)) {
        totalScore += 85;
        excellentCount++;
      } else if (borderlineStatuses.includes(status)) {
        totalScore += 60;
        needsCareCount++;
      } else {
        totalScore += 40;
        needsCareCount++;
      }
    });

    const overallScore = biomarkers.length ? Math.round(totalScore / biomarkers.length) : 0;
    const status = overallScore >= 90 ? 'Excellent' : overallScore >= 75 ? 'Good' : overallScore >= 60 ? 'Fair' : 'Needs Attention';

    const excellentMarkers = biomarkers.filter(b => excellentStatuses.includes((b.status || '').toLowerCase())).map(b => b.name);
    const attentionMarkers = biomarkers.filter(b => !excellentStatuses.includes((b.status || '').toLowerCase())).map(b => b.name);

    return {
      score: overallScore,
      status,
      excellent_count: excellentCount,
      needs_care_count: needsCareCount,
      total_parameters: biomarkers.length,
      insights: [
        excellentCount > 0 ? { type: 'positive', text: `Your ${excellentMarkers.slice(0, 3).join(', ')} levels are within healthy ranges.` } : null,
        needsCareCount > 0 ? { type: 'warning', text: `${attentionMarkers.join(', ')} need attention. Consider lifestyle changes or consult a doctor.` } : null
      ].filter(Boolean)
    };
    } catch (err) {
      console.error('getHealthScore error:', err);
      return {
        score: 0,
        status: 'No Data',
        excellent_count: 0,
        needs_care_count: 0,
        total_parameters: 0,
        insights: []
      };
    }
  },

  // Get AI recommendations (calls Supabase Edge Function)
  async getAIRecommendations(userId, userName, biomarkers) {
    try {
      const { data, error } = await supabase.functions.invoke('ai-recommendations', {
        body: { userId, userName, biomarkers }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('AI recommendations error:', error);
      // Return fallback recommendations
      return generateFallbackRecommendations(biomarkers, userName);
    }
  }
};

// ============== NOTIFICATIONS ==============

export const notificationService = {
  async getNotifications(userId) {
    if (!userId) return [];
    
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Error fetching notifications:', error);
        return [];
      }
      return data || [];
    } catch (err) {
      console.error('getNotifications error:', err);
      return [];
    }
  },

  async markAsRead(notificationId) {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (error) {
        console.error('Error marking notification as read:', error);
      }
    } catch (err) {
      console.error('markAsRead error:', err);
    }
  }
};

// ============== SUBSCRIPTION PLANS ==============

export const planService = {
  async getPlans() {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true);

      if (error) {
        console.error('Error fetching plans:', error);
        return [];
      }
      return data || [];
    } catch (err) {
      console.error('getPlans error:', err);
      return [];
    }
  }
};

// ============== ADMIN OPERATIONS ==============

export const adminService = {
  async login(email, password) {
    try {
      // Simple admin login (in production, use proper auth)
      const { data: admin, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('email', email)
        .single();

      if (error || !admin || password !== 'admin123') {
        throw new Error('Invalid credentials');
      }

      return admin;
    } catch (err) {
      console.error('Admin login error:', err);
      throw new Error('Invalid credentials');
    }
  },

  async getAnalytics() {
    try {
      const [usersRes, appointmentsRes, reportsRes, labsRes] = await Promise.all([
        supabase.from('users').select('*', { count: 'exact', head: true }),
        supabase.from('appointments').select('*', { count: 'exact', head: true }),
        supabase.from('reports').select('*', { count: 'exact', head: true }),
        supabase.from('partner_labs').select('*', { count: 'exact', head: true })
      ]);

      return {
        total_users: usersRes.count || 0,
        total_appointments: appointmentsRes.count || 0,
        total_reports: reportsRes.count || 0,
        total_labs: labsRes.count || 0
      };
    } catch (err) {
      console.error('getAnalytics error:', err);
      return {
        total_users: 0,
        total_appointments: 0,
        total_reports: 0,
        total_labs: 0
      };
    }
  },

  async getUsers() {
    try {
      const { data, error } = await supabase.from('users').select('*').order('created_at', { ascending: false });
      if (error) {
        console.error('Error fetching users:', error);
        return [];
      }
      return data || [];
    } catch (err) {
      console.error('getUsers error:', err);
      return [];
    }
  },

  async getLabs() {
    try {
      const { data, error } = await supabase.from('partner_labs').select('*').order('created_at', { ascending: false });
      if (error) {
        console.error('Error fetching labs:', error);
        return [];
      }
      return data || [];
    } catch (err) {
      console.error('getLabs error:', err);
      return [];
    }
  },

  async getAllAppointments() {
    try {
      // Get all appointments
      const { data: appointments, error: aptError } = await supabase
        .from('appointments')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (aptError) {
        console.error('Error fetching all appointments:', aptError);
        return [];
      }

      if (!appointments || appointments.length === 0) {
        return [];
      }

      // Get unique user IDs and lab IDs
      const userIds = [...new Set(appointments.map(a => a.user_id).filter(Boolean))];
      const labIds = [...new Set(appointments.map(a => a.assigned_lab_id).filter(Boolean))];

      // Fetch users
      let usersMap = {};
      if (userIds.length > 0) {
        const { data: users } = await supabase
          .from('users')
          .select('id, name, phone_number, email')
          .in('id', userIds);
        
        if (users) {
          usersMap = users.reduce((acc, user) => {
            acc[user.id] = user;
            return acc;
          }, {});
        }
      }

      // Fetch labs
      let labsMap = {};
      if (labIds.length > 0) {
        const { data: labs } = await supabase
          .from('partner_labs')
          .select('id, name')
          .in('id', labIds);
        
        if (labs) {
          labsMap = labs.reduce((acc, lab) => {
            acc[lab.id] = lab;
            return acc;
          }, {});
        }
      }

      return appointments.map(apt => {
        const user = usersMap[apt.user_id];
        const lab = labsMap[apt.assigned_lab_id];
        return {
          id: apt.id,
          date: apt.date,
          time: apt.time,
          status: apt.status,
          user_name: user?.name || 'Unknown',
          user_phone: user?.phone_number,
          user_email: user?.email,
          lab_name: lab?.name || apt.assigned_lab_name || 'Unassigned',
          created_at: apt.created_at
        };
      });
    } catch (err) {
      console.error('getAllAppointments error:', err);
      return [];
    }
  }
};

// ============== LAB PARTNER OPERATIONS ==============

export const labService = {
  async login(email, password) {
    try {
      const { data: lab, error } = await supabase
        .from('partner_labs')
        .select('*')
        .eq('email', email)
        .single();

      if (error || !lab || password !== 'lab123') {
        throw new Error('Invalid credentials');
      }

      return lab;
    } catch (err) {
      console.error('Lab login error:', err);
      throw new Error('Invalid credentials');
    }
  },

  async getDashboard(labId) {
    if (!labId) {
      return {
        stats: { total: 0, pending: 0, sample_collected: 0, processing: 0, completed: 0, upcoming: 0, today: 0, report_ready: 0 }
      };
    }
    
    try {
      const { data: appointments, error } = await supabase
        .from('appointments')
        .select('*')
        .eq('assigned_lab_id', labId);

      if (error) {
        console.error('getDashboard error:', error);
        return {
          stats: { total: 0, pending: 0, sample_collected: 0, processing: 0, completed: 0, upcoming: 0, today: 0, report_ready: 0 }
        };
      }

      const allApts = appointments || [];
      const today = new Date().toISOString().split('T')[0];
      
      return {
        stats: {
          total: allApts.length,
          pending: allApts.filter(a => ['booked', 'confirmed', 'pending'].includes(a.status)).length,
          sample_collected: allApts.filter(a => a.status === 'sample_collected').length,
          processing: allApts.filter(a => a.status === 'processing').length,
          completed: allApts.filter(a => a.status === 'completed').length,
          report_ready: allApts.filter(a => a.status === 'report_ready').length,
          upcoming: allApts.filter(a => {
            const aptDate = a.date;
            return aptDate >= today && ['booked', 'confirmed', 'pending'].includes(a.status);
          }).length,
          today: allApts.filter(a => a.date === today).length
        }
      };
    } catch (err) {
      console.error('getDashboard error:', err);
      return {
        stats: { total: 0, pending: 0, sample_collected: 0, processing: 0, completed: 0, upcoming: 0, today: 0, report_ready: 0 }
      };
    }
  },

  async getAppointments(labId) {
    if (!labId) return [];
    
    try {
      // First, get appointments
      const { data: appointments, error: aptError } = await supabase
        .from('appointments')
        .select('*')
        .eq('assigned_lab_id', labId)
        .order('created_at', { ascending: false });

      if (aptError) {
        console.error('Error fetching lab appointments:', aptError);
        return [];
      }

      if (!appointments || appointments.length === 0) {
        return [];
      }

      // Get unique user IDs
      const userIds = [...new Set(appointments.map(a => a.user_id).filter(Boolean))];
      
      // Fetch users separately
      let usersMap = {};
      if (userIds.length > 0) {
        const { data: users, error: userError } = await supabase
          .from('users')
          .select('id, name, phone_number, email, age, plan_type, family_members')
          .in('id', userIds);
        
        if (!userError && users) {
          usersMap = users.reduce((acc, user) => {
            acc[user.id] = user;
            return acc;
          }, {});
        }
      }

      // Map appointments with user data
      // Also fetch reports to check uploaded_at time
      const appointmentIds = appointments.map(a => a.id);
      let reportsMap = {};
      
      if (appointmentIds.length > 0) {
        const { data: reports } = await supabase
          .from('reports')
          .select('appointment_id, created_at')
          .in('appointment_id', appointmentIds);
        
        if (reports) {
          reportsMap = reports.reduce((acc, r) => {
            acc[r.appointment_id] = r.created_at;
            return acc;
          }, {});
        }
      }

      return appointments.map(apt => {
        const user = usersMap[apt.user_id] || null;
        const reportUploadedAt = reportsMap[apt.id] || null;
        
        return {
          id: apt.id,
          date: apt.date,
          time: apt.time,
          status: apt.status,
          address: apt.address,
          user_id: apt.user_id,
          report_uploaded_at: reportUploadedAt,
          user: user ? {
            id: user.id,
            name: user.name || 'Unknown',
            phone: user.phone_number,
            email: user.email,
            age: user.age,
            plan_type: user.plan_type,
            family_members: user.family_members || []
          } : {
            id: apt.user_id,
            name: 'Unknown User',
            phone: null,
            email: null,
            age: null,
            plan_type: null,
            family_members: []
          }
        };
      });
    } catch (err) {
      console.error('getAppointments error:', err);
      return [];
    }
  },

  async updateAppointmentStatus(appointmentId, status, userId) {
    try {
      await supabase
        .from('appointments')
        .update({ status })
        .eq('id', appointmentId);

      // Create notification
      const statusMessages = {
        confirmed: 'Your appointment has been confirmed!',
        sample_collected: 'Sample collected! Processing will begin shortly.',
        processing: 'Your sample is being processed.',
        report_ready: 'Your health report is ready! View your results now.'
      };

      if (statusMessages[status] && userId) {
        await supabase.from('notifications').insert({
          user_id: userId,
          title: `Status Update: ${status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}`,
          message: statusMessages[status],
          type: 'status_update'
        });
      }
    } catch (err) {
      console.error('updateAppointmentStatus error:', err);
    }
  },

  async uploadReport(reportData) {
    try {
      const { data, error } = await supabase
        .from('reports')
        .insert({
          appointment_id: reportData.appointment_id,
          user_id: reportData.user_id,
          member_id: reportData.member_id,
          summary: reportData.summary,
          biomarkers: reportData.biomarkers,
          health_score: reportData.health_score,
          recommendations: reportData.recommendations,
          test_date: new Date().toISOString()
        })
        .select()
        .single();

      if (error) {
        console.error('Error uploading report:', error);
        throw new Error('Failed to upload report');
      }

      // Update appointment status
      await supabase
        .from('appointments')
        .update({ status: 'report_ready' })
        .eq('id', reportData.appointment_id);

      // Notify user
      if (reportData.user_id) {
        await supabase.from('notifications').insert({
          user_id: reportData.user_id,
          title: 'Your Report is Ready! 📊',
          message: 'Your health report has been uploaded. Check your dashboard for detailed insights.',
          type: 'report_ready'
        });
      }

      return data;
    } catch (err) {
      console.error('uploadReport error:', err);
      throw err;
    }
  },

  async getReportByAppointment(appointmentId) {
    try {
      const { data, error } = await supabase
        .from('reports')
        .select('*')
        .eq('appointment_id', appointmentId)
        .single();

      if (error) {
        console.error('Error fetching report:', error);
        return null;
      }

      return data;
    } catch (err) {
      console.error('getReportByAppointment error:', err);
      return null;
    }
  },

  async updateReport(reportId, reportData) {
    try {
      const { data, error } = await supabase
        .from('reports')
        .update({
          summary: reportData.summary,
          biomarkers: reportData.biomarkers,
          recommendations: reportData.recommendations,
          notes: reportData.notes,
          health_score: reportData.health_score,
          updated_at: new Date().toISOString()
        })
        .eq('id', reportId)
        .select()
        .single();

      if (error) {
        console.error('Error updating report:', error);
        throw error;
      }

      return data;
    } catch (err) {
      console.error('updateReport error:', err);
      throw err;
    }
  }
};

// ============== HELPER FUNCTIONS ==============

function generateFallbackRecommendations(biomarkers, userName) {
  const recommendations = [];
  const healthTips = [];

  (biomarkers || []).forEach(b => {
    const name = (b.name || '').toLowerCase();
    const status = (b.status || '').toLowerCase();

    if (['borderline', 'needs_attention', 'high', 'low'].includes(status)) {
      if (name.includes('cholesterol')) {
        recommendations.push({
          icon: 'heart',
          iconBg: 'bg-rose-400',
          title: 'Manage Cholesterol',
          description: `Your ${b.name} is ${b.value}. Consider reducing saturated fats and increasing fiber intake.`
        });
        healthTips.push({ icon: 'utensils', text: 'Include more oats, nuts, and olive oil', color: 'text-rose-400' });
      } else if (name.includes('glucose') || name.includes('sugar') || name.includes('hba1c')) {
        recommendations.push({
          icon: 'activity',
          iconBg: 'bg-cyan-400',
          title: 'Monitor Blood Sugar',
          description: `Your ${b.name} needs attention. Limit refined carbs and increase physical activity.`
        });
        healthTips.push({ icon: 'dumbbell', text: '30 min walking after meals helps regulate sugar', color: 'text-cyan-400' });
      } else if (name.includes('vitamin d')) {
        recommendations.push({
          icon: 'sun',
          iconBg: 'bg-amber-400',
          title: 'Boost Vitamin D',
          description: 'Get 15-20 minutes of morning sunlight and consider supplements.'
        });
        healthTips.push({ icon: 'sun', text: 'Morning sunlight is the best Vitamin D source', color: 'text-amber-400' });
      }
    }
  });

  if (recommendations.length < 4) {
    recommendations.push({
      icon: 'calendar',
      iconBg: 'bg-teal-400',
      title: 'Schedule Follow-up',
      description: 'Book a follow-up test in 3 months to track your progress.'
    });
  }

  if (healthTips.length < 3) {
    healthTips.push(
      { icon: 'moon', text: 'Aim for 7-8 hours of quality sleep', color: 'text-indigo-400' },
      { icon: 'droplet', text: 'Stay hydrated with 8 glasses of water daily', color: 'text-blue-400' }
    );
  }

  const attentionCount = (biomarkers || []).filter(b => !['normal', 'excellent', 'optimal'].includes((b.status || '').toLowerCase())).length;
  const normalCount = (biomarkers || []).filter(b => ['normal', 'excellent', 'optimal'].includes((b.status || '').toLowerCase())).length;

  let aiSummary = `Hi ${userName}! `;
  if (attentionCount > 0) aiSummary += `You have ${attentionCount} biomarker(s) that need attention. `;
  if (normalCount > 0) aiSummary += `Great news - ${normalCount} of your markers are healthy! `;
  aiSummary += 'Focus on the recommendations below.';

  return {
    recommendations: recommendations.slice(0, 4),
    health_tips: healthTips.slice(0, 3),
    ai_summary: aiSummary,
    generated_for: userName
  };
}

export default supabase;
