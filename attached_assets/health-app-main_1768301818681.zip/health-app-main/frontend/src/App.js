import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";

// User Pages
import WelcomePage from "@/pages/WelcomePage";
import LoginPage from "@/pages/LoginPage";
import SubscriptionPage from "@/pages/SubscriptionPage";
import BookTestPage from "@/pages/BookTestPage";
import BookingStatusPage from "@/pages/BookingStatusPage";
import HomePage from "@/pages/HomePage";
import MetricsPage from "@/pages/MetricsPage";
import HealthScorePage from "@/pages/HealthScorePage";
import ReportsPage from "@/pages/ReportsPage";
import SchedulePage from "@/pages/SchedulePage";
import ProfilePage from "@/pages/ProfilePage";
import NotificationsPage from "@/pages/NotificationsPage";
import TestsCompletedPage from "@/pages/TestsCompletedPage";
import ProfileCompletePage from "@/pages/ProfileCompletePage";

// Admin Pages
import {
  AdminLogin,
  AdminLayout,
  AdminDashboard,
  AdminUsers,
  AdminLabs,
  AdminPlans,
  AdminTests,
  AdminReports,
  AdminSettings
} from "@/pages/admin";

// Lab Partner Pages
import {
  LabLogin,
  LabLayout,
  LabDashboard,
  LabAppointments,
  LabUploadReport,
  LabStats
} from "@/pages/lab";

// Protected Route Component for Users - uses AuthContext
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  // Show loading state while checking auth
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  return children;
};

// App Routes wrapped in AuthProvider
const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<WelcomePage />} />
      <Route path="/login" element={<LoginPage />} />
      
      {/* Subscription Flow (after login) */}
      <Route path="/subscription" element={
        <ProtectedRoute>
          <SubscriptionPage />
        </ProtectedRoute>
      } />
      <Route path="/profile-complete" element={
        <ProtectedRoute>
          <ProfileCompletePage />
        </ProtectedRoute>
      } />
      <Route path="/book-test" element={
        <ProtectedRoute>
          <BookTestPage />
        </ProtectedRoute>
      } />
      <Route path="/booking-status" element={
        <ProtectedRoute>
          <BookingStatusPage />
        </ProtectedRoute>
      } />
      
      {/* Main App Routes */}
      <Route path="/home" element={
        <ProtectedRoute>
          <HomePage />
        </ProtectedRoute>
      } />
      <Route path="/metrics" element={
        <ProtectedRoute>
          <MetricsPage />
        </ProtectedRoute>
      } />
      <Route path="/health-score" element={
        <ProtectedRoute>
          <HealthScorePage />
        </ProtectedRoute>
      } />
      <Route path="/reports" element={
        <ProtectedRoute>
          <ReportsPage />
        </ProtectedRoute>
      } />
      <Route path="/schedule" element={
        <ProtectedRoute>
          <SchedulePage />
        </ProtectedRoute>
      } />
      <Route path="/profile" element={
        <ProtectedRoute>
          <ProfilePage />
        </ProtectedRoute>
      } />
      <Route path="/notifications" element={
        <ProtectedRoute>
          <NotificationsPage />
        </ProtectedRoute>
      } />
      <Route path="/tests-completed" element={
        <ProtectedRoute>
          <TestsCompletedPage />
        </ProtectedRoute>
      } />

      {/* Admin Routes */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="users" element={<AdminUsers />} />
        <Route path="labs" element={<AdminLabs />} />
        <Route path="plans" element={<AdminPlans />} />
        <Route path="tests" element={<AdminTests />} />
        <Route path="reports" element={<AdminReports />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>

      {/* Lab Partner Routes */}
      <Route path="/lab/login" element={<LabLogin />} />
      <Route path="/lab" element={<LabLayout />}>
        <Route index element={<LabDashboard />} />
        <Route path="appointments" element={<LabAppointments />} />
        <Route path="upload" element={<LabUploadReport />} />
        <Route path="stats" element={<LabStats />} />
      </Route>
      
      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
      <Toaster position="top-center" richColors />
    </div>
  );
}

export default App;
