// PDF Parsing Service using pdf.js and Backend API
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf';

// Set the worker source for pdf.js v3.x
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

/**
 * Extract text from a PDF file
 * @param {File} file - The PDF file to parse
 * @returns {Promise<string>} - Extracted text from the PDF
 */
export async function extractTextFromPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  
  let fullText = '';
  
  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();
    const pageText = textContent.items.map(item => item.str).join(' ');
    fullText += pageText + '\n';
  }
  
  return fullText;
}

/**
 * Parse lab report text using Backend API
 * @param {string} pdfText - Extracted text from PDF
 * @returns {Promise<Object>} - Parsed biomarker data
 */
export async function parseLabReportWithAI(pdfText) {
  const backendUrl = process.env.REACT_APP_BACKEND_URL || '';
  
  try {
    const response = await fetch(`${backendUrl}/api/lab/parse-text`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text: pdfText })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Failed to parse lab report');
    }

    const result = await response.json();
    
    // Ensure biomarkers have unique IDs
    if (result.data && Array.isArray(result.data.biomarkers)) {
      result.data.biomarkers = result.data.biomarkers.map((biomarker, index) => ({
        ...biomarker,
        id: Date.now() + index
      }));
    }

    return result.data;
  } catch (error) {
    console.error('Backend parsing error:', error);
    throw new Error(`Failed to parse lab report: ${error.message}`);
  }
}

/**
 * Main function to parse a PDF lab report
 * @param {File} file - The PDF file to parse
 * @returns {Promise<Object>} - Parsed report data
 */
export async function parsePDFLabReport(file) {
  // Step 1: Extract text from PDF
  const pdfText = await extractTextFromPDF(file);
  
  if (!pdfText.trim()) {
    throw new Error('Could not extract text from PDF. The file may be image-based or empty.');
  }
  
  // Step 2: Parse with Backend AI
  const parsedData = await parseLabReportWithAI(pdfText);
  
  return {
    success: true,
    data: parsedData,
    rawTextPreview: pdfText.substring(0, 500) + (pdfText.length > 500 ? '...' : '')
  };
}

export default parsePDFLabReport;
