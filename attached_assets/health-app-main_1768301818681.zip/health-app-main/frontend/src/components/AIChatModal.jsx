import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles, Loader2 } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AIChatModal = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState([
    {
      type: 'ai',
      text: "Hello! I'm your AI health assistant. Ask me anything about your test results or health metrics. How can I help you today?",
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const suggestedQuestions = [
    "What does my Vitamin D level mean?",
    "How can I improve my cholesterol?",
    "Are my blood sugar levels normal?",
    "What foods help with low Vitamin D?"
  ];

  const handleSend = async (question) => {
    const questionText = question || input;
    if (!questionText.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { type: 'user', text: questionText }]);
    setInput('');
    setLoading(true);

    const token = localStorage.getItem('token');
    try {
      const response = await axios.post(`${API}/ai/chat`, 
        { question: questionText },
        { headers: { Authorization: `Bearer ${token}` }}
      );
      
      setMessages(prev => [...prev, { 
        type: 'ai', 
        text: response.data.answer,
        disclaimer: response.data.disclaimer
      }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        type: 'ai', 
        text: "I'm sorry, I couldn't process your question. Please try again.",
        isError: true
      }]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-md bg-white rounded-t-3xl max-h-[85vh] flex flex-col animate-slide-up">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-slate-900">AI Health Assistant</h2>
              <p className="text-xs text-slate-500">Ask about your health</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-2xl p-3 ${
                message.type === 'user' 
                  ? 'bg-teal-600 text-white rounded-br-md' 
                  : message.isError
                  ? 'bg-rose-50 text-rose-700 rounded-bl-md'
                  : 'bg-slate-100 text-slate-700 rounded-bl-md'
              }`}>
                <p className="text-sm leading-relaxed">{message.text}</p>
                {message.disclaimer && (
                  <p className="text-xs mt-2 opacity-70 border-t border-slate-200 pt-2">
                    ⚠️ {message.disclaimer}
                  </p>
                )}
              </div>
            </div>
          ))}
          
          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-100 rounded-2xl rounded-bl-md p-3">
                <Loader2 className="w-5 h-5 text-slate-500 animate-spin" />
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length <= 2 && (
          <div className="px-4 pb-2">
            <p className="text-xs text-slate-400 mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((q, index) => (
                <button
                  key={index}
                  onClick={() => handleSend(q)}
                  className="px-3 py-1.5 bg-slate-100 text-slate-600 text-xs rounded-full hover:bg-slate-200 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about your health..."
              className="flex-1 h-12 px-4 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
              disabled={loading}
            />
            <button
              onClick={() => handleSend()}
              disabled={loading || !input.trim()}
              className="w-12 h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-teal-700 transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIChatModal;
