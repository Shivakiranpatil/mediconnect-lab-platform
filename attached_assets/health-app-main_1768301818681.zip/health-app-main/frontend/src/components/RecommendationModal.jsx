import React, { useState, useEffect } from 'react';
import { X, ChevronDown, ChevronUp, Sun, Pill, Calendar, Stethoscope, Loader2 } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const RecommendationModal = ({ isOpen, onClose, recommendation }) => {
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (isOpen && recommendation) {
      fetchDetails();
    }
  }, [isOpen, recommendation]);

  const fetchDetails = async () => {
    setLoading(true);
    const token = localStorage.getItem('token');
    try {
      const response = await axios.post(`${API}/ai/recommendation-details`,
        { topic: recommendation.title },
        { headers: { Authorization: `Bearer ${token}` }}
      );
      setDetails(response.data);
    } catch (error) {
      console.error('Failed to fetch details:', error);
      setDetails({
        details: "Unable to load detailed recommendations at this time. Please try again later.",
        disclaimer: "This is informational only and not medical advice."
      });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !recommendation) return null;

  const icons = {
    'Increase Vitamin D': Sun,
    'Consider Supplements': Pill,
    'Follow-up Test': Calendar,
    'Doctor Consultation': Stethoscope
  };

  const Icon = icons[recommendation.title] || Sun;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md bg-white rounded-t-3xl max-h-[80vh] overflow-auto animate-slide-up">
        {/* Header */}
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl ${recommendation.iconBg} flex items-center justify-center`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-slate-900">{recommendation.title}</h2>
              <p className="text-xs text-slate-500">AI Recommendation</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Original recommendation */}
          <div className="bg-teal-50 rounded-xl p-4 mb-4">
            <p className="text-teal-700 text-sm leading-relaxed">{recommendation.description}</p>
          </div>

          {/* Detailed AI Response */}
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
            </div>
          ) : details ? (
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900">Detailed Guidance</h3>
              <div className="text-slate-600 text-sm leading-relaxed whitespace-pre-line">
                {details.details}
              </div>
              
              {details.disclaimer && (
                <div className="bg-amber-50 rounded-xl p-3 mt-4">
                  <p className="text-amber-700 text-xs">⚠️ {details.disclaimer}</p>
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default RecommendationModal;
