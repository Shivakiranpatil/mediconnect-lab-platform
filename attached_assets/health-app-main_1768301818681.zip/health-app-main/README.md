# CareGuard UAE - Preventive Health MVP

A UAE-based preventive health membership app with Firebase Email/Password Authentication and Supabase backend.

## Tech Stack

- **Frontend**: React 18 + Tailwind CSS + Shadcn/UI
- **Backend**: FastAPI (Python) with Supabase
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Firebase Email/Password
- **AI**: OpenAI GPT-4o (for health insights)
- **Deployment**: Vercel

## Prerequisites

1. **Firebase Project** with Email/Password Authentication enabled
2. **Supabase Project** with database created
3. **Vercel Account** for deployment

## Setup Instructions

### 1. Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select existing one
3. Go to **Authentication** → **Sign-in method**
4. Enable **Email/Password** provider
5. Go to **Project Settings** → **General** → **Your apps**
6. Create a web app and copy the Firebase config values

### 2. Supabase Database Setup

1. Go to your [Supabase Dashboard](https://app.supabase.com/)
2. Create a new project
3. Go to **SQL Editor**
4. Copy and paste the contents of `/app/database/supabase_schema.sql`
5. Run the SQL to create all tables
6. Go to **Settings** → **API** to get your URL and keys

### 3. Environment Variables

#### For Vercel Deployment

Add these environment variables in your Vercel project settings:

```env
# Firebase Configuration
REACT_APP_FIREBASE_API_KEY=your-firebase-api-key
REACT_APP_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=your-project-id
REACT_APP_FIREBASE_STORAGE_BUCKET=your-project.firebasestorage.app
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
REACT_APP_FIREBASE_APP_ID=your-app-id

# Supabase Configuration
REACT_APP_SUPABASE_URL=https://your-project.supabase.co
REACT_APP_SUPABASE_ANON_KEY=your-anon-key
```

### 4. Deploy to Vercel

1. Push code to GitHub
2. Go to [Vercel](https://vercel.com) and import your repository
3. Set the **Root Directory** to `frontend`
4. Add all environment variables from step 3
5. Deploy!

## Project Structure

```
/app/
├── backend/
│   ├── server_supabase.py    # Supabase-based API (optional for serverless)
│   ├── requirements.txt
│   └── .env
├── database/
│   └── supabase_schema.sql   # Database schema - RUN THIS FIRST
├── frontend/
│   ├── src/
│   │   ├── config/
│   │   │   ├── firebase.js   # Firebase config
│   │   │   └── supabase.js   # Supabase client & services
│   │   ├── context/
│   │   │   └── AuthContext.jsx  # Firebase Auth context
│   │   └── pages/
│   │       ├── LoginPage.jsx    # Email/Password login
│   │       └── ...
│   ├── vercel.json
│   └── package.json
└── README.md
```

## Features

### User App
- Email/Password authentication via Firebase
- Health test booking with home collection
- AI-powered health insights
- Biomarker tracking with trends
- Family member management

### Admin Dashboard (/admin)
- User management
- Lab partner management
- Subscription plans management
- Analytics dashboard

### Lab Partner Portal (/lab)
- Appointment management
- PDF report upload with AI parsing
- Status updates with user notifications

## Test Credentials

- **Admin**: admin@healthapp.com / admin123
- **Lab**: lab@dubai.com / lab123
- **User**: Sign up with any email/password

## Authentication Flow

1. User enters email and password on login page
2. Firebase authenticates the user
3. On success, the app creates/retrieves user from Supabase
4. User data is stored in context and localStorage
5. Protected routes check authentication state

## How It Works

The app uses a **serverless architecture**:

1. **Firebase** handles all authentication (signup, login, password reset)
2. **Supabase** stores all application data (users, appointments, reports)
3. **Frontend** calls Supabase directly using the JS client
4. No backend server is required for basic operations

For advanced features like AI PDF parsing, you can deploy the `server_supabase.py` as a separate API or use Supabase Edge Functions.

## Troubleshooting

### "Invalid Firebase token" error
- Make sure Email/Password is enabled in Firebase Console
- Verify your Firebase config values are correct
- Check that environment variables are set in Vercel

### "User not found in database" error
- Run the SQL schema in Supabase first
- Check your Supabase URL and anon key are correct
- Make sure the `users` table exists

### Blank page after login
- Check browser console for errors
- Verify all environment variables are set
- Make sure the build completed successfully

## License

MIT
