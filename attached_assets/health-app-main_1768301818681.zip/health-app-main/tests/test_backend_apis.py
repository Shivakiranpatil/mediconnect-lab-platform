"""
Backend API Tests for UAE Preventive Health MVP
Tests: Auth, Appointments, Admin, Lab Portal APIs
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://preventivehealth.preview.emergentagent.com')

class TestHealthEndpoints:
    """Health check endpoints"""
    
    def test_api_root(self):
        response = requests.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "CareGuard" in data["message"]
    
    def test_health_check(self):
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"


class TestUserAuthentication:
    """User OTP authentication flow"""
    
    def test_send_otp(self):
        response = requests.post(f"{BASE_URL}/api/auth/send-otp", json={
            "phone": "501234567"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["otp_sent"] == True
        assert "1234" in data["message"]  # Test OTP hint
    
    def test_verify_otp_success(self):
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "1234"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "user" in data
        assert data["user"]["phone"] == "501234567"
    
    def test_verify_otp_invalid(self):
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "9999"
        })
        # Backend returns 400 for invalid OTP (Bad Request)
        assert response.status_code in [400, 401]
    
    def test_auth_me_with_token(self):
        # First get token
        login_response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "1234"
        })
        token = login_response.json()["access_token"]
        
        # Then verify /auth/me
        response = requests.get(f"{BASE_URL}/api/auth/me", headers={
            "Authorization": f"Bearer {token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert data["phone"] == "501234567"
    
    def test_auth_me_without_token(self):
        response = requests.get(f"{BASE_URL}/api/auth/me")
        assert response.status_code == 401


class TestAppointmentsAPI:
    """Appointments API tests"""
    
    @pytest.fixture
    def auth_token(self):
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_get_all_appointments(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/appointments/all", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "upcoming" in data
        assert "past" in data
        assert "total" in data
    
    def test_get_current_appointment(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/appointments/current", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
    
    def test_user_has_reports(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/user/has-reports", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "has_reports" in data
        assert "report_count" in data


class TestBiomarkersAPI:
    """Biomarkers and health data APIs"""
    
    @pytest.fixture
    def auth_token(self):
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_get_biomarkers(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/biomarkers", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "biomarkers" in data
    
    def test_get_health_score(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/health-score", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "score" in data
        assert "status" in data


class TestNotificationsAPI:
    """Notifications API tests"""
    
    @pytest.fixture
    def auth_token(self):
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": "501234567",
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_get_notifications(self, auth_token):
        response = requests.get(f"{BASE_URL}/api/notifications", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        assert isinstance(response.json(), list)


class TestAdminAuthentication:
    """Admin dashboard authentication"""
    
    def test_admin_login_success(self):
        response = requests.post(f"{BASE_URL}/api/admin/login", json={
            "email": "admin@healthapp.com",
            "password": "admin123"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["admin"]["role"] == "admin"
    
    def test_admin_login_invalid(self):
        response = requests.post(f"{BASE_URL}/api/admin/login", json={
            "email": "admin@healthapp.com",
            "password": "wrongpassword"
        })
        assert response.status_code == 401
    
    def test_admin_verify_token(self):
        # Get admin token
        login_response = requests.post(f"{BASE_URL}/api/admin/login", json={
            "email": "admin@healthapp.com",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Verify token
        response = requests.get(f"{BASE_URL}/api/admin/verify", headers={
            "Authorization": f"Bearer {token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] == True


class TestAdminAPIs:
    """Admin dashboard APIs"""
    
    @pytest.fixture
    def admin_token(self):
        response = requests.post(f"{BASE_URL}/api/admin/login", json={
            "email": "admin@healthapp.com",
            "password": "admin123"
        })
        return response.json()["access_token"]
    
    def test_get_all_users(self, admin_token):
        response = requests.get(f"{BASE_URL}/api/admin/users", headers={
            "Authorization": f"Bearer {admin_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "users" in data
        assert "total" in data
    
    def test_get_all_labs(self, admin_token):
        response = requests.get(f"{BASE_URL}/api/admin/labs", headers={
            "Authorization": f"Bearer {admin_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "labs" in data


class TestLabPortalAuthentication:
    """Lab partner portal authentication"""
    
    def test_lab_login_success(self):
        response = requests.post(f"{BASE_URL}/api/lab/login", json={
            "email": "lab@dubai.com",
            "password": "lab123"
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "lab" in data
    
    def test_lab_login_invalid(self):
        response = requests.post(f"{BASE_URL}/api/lab/login", json={
            "email": "lab@dubai.com",
            "password": "wrongpassword"
        })
        assert response.status_code == 401


class TestLabPortalAPIs:
    """Lab partner portal APIs"""
    
    @pytest.fixture
    def lab_token(self):
        response = requests.post(f"{BASE_URL}/api/lab/login", json={
            "email": "lab@dubai.com",
            "password": "lab123"
        })
        return response.json()["access_token"]
    
    def test_lab_dashboard(self, lab_token):
        response = requests.get(f"{BASE_URL}/api/lab/dashboard", headers={
            "Authorization": f"Bearer {lab_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "stats" in data
    
    def test_lab_appointments(self, lab_token):
        response = requests.get(f"{BASE_URL}/api/lab/appointments", headers={
            "Authorization": f"Bearer {lab_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "appointments" in data
    
    def test_lab_verify_token(self, lab_token):
        response = requests.get(f"{BASE_URL}/api/lab/verify", headers={
            "Authorization": f"Bearer {lab_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["valid"] == True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
