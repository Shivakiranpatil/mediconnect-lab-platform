"""
Test Profile Complete Flow - UAE Preventive Health App
Tests: Login -> Subscription -> Profile Complete -> Book Test
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestAuthFlow:
    """Authentication flow tests"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test data"""
        self.test_phone = "501234567"
        self.test_otp = "1234"
    
    def test_send_otp(self):
        """Test sending OTP"""
        response = requests.post(f"{BASE_URL}/api/auth/send-otp", json={
            "phone": self.test_phone
        })
        assert response.status_code == 200
        data = response.json()
        assert data["otp_sent"] == True
        assert data["phone"] == self.test_phone
        print(f"✓ OTP sent successfully to {self.test_phone}")
    
    def test_verify_otp(self):
        """Test OTP verification and get token"""
        # First send OTP
        requests.post(f"{BASE_URL}/api/auth/send-otp", json={
            "phone": self.test_phone
        })
        
        # Verify OTP
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": self.test_phone,
            "otp": self.test_otp
        })
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "user" in data
        print(f"✓ OTP verified, token received")
        return data["access_token"]


class TestSubscriptionFlow:
    """Subscription selection tests"""
    
    @pytest.fixture
    def auth_token(self):
        """Get auth token"""
        phone = "501234567"
        requests.post(f"{BASE_URL}/api/auth/send-otp", json={"phone": phone})
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": phone,
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_select_individual_package(self, auth_token):
        """Test selecting individual starter package"""
        response = requests.post(
            f"{BASE_URL}/api/subscription/select",
            json={"package_id": "individual-starter"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        print("✓ Individual starter package selected")
    
    def test_select_family_package(self, auth_token):
        """Test selecting family-of-2 package"""
        response = requests.post(
            f"{BASE_URL}/api/subscription/select",
            json={"package_id": "family-of-2"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        print("✓ Family-of-2 package selected")
    
    def test_select_preventive_plus(self, auth_token):
        """Test selecting preventive plus package"""
        response = requests.post(
            f"{BASE_URL}/api/subscription/select",
            json={"package_id": "preventive-plus"},
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        print("✓ Preventive plus package selected")


class TestProfileComplete:
    """Profile completion tests"""
    
    @pytest.fixture
    def auth_token(self):
        """Get auth token"""
        phone = "501234567"
        requests.post(f"{BASE_URL}/api/auth/send-otp", json={"phone": phone})
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": phone,
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_complete_profile_individual(self, auth_token):
        """Test completing profile for individual plan"""
        response = requests.put(
            f"{BASE_URL}/api/auth/profile/complete",
            json={
                "first_name": "John",
                "last_name": "Doe",
                "dob": "1990-05-15",
                "phone": "501234567",
                "email": "john.doe@test.com",
                "family_members": []
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "user" in data
        print("✓ Profile completed for individual plan")
    
    def test_complete_profile_with_family(self, auth_token):
        """Test completing profile with family members"""
        response = requests.put(
            f"{BASE_URL}/api/auth/profile/complete",
            json={
                "first_name": "Ahmed",
                "last_name": "Khan",
                "dob": "1985-03-20",
                "phone": "501234567",
                "email": "ahmed.khan@test.com",
                "family_members": [
                    {"name": "Sara Khan", "age": "32", "relationship": "wife"}
                ]
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        print("✓ Profile completed with family member")


class TestBookTest:
    """Book test appointment tests"""
    
    @pytest.fixture
    def auth_token(self):
        """Get auth token"""
        phone = "501234567"
        requests.post(f"{BASE_URL}/api/auth/send-otp", json={"phone": phone})
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": phone,
            "otp": "1234"
        })
        return response.json()["access_token"]
    
    def test_book_appointment(self, auth_token):
        """Test booking an appointment"""
        response = requests.post(
            f"{BASE_URL}/api/appointments/book",
            json={
                "date": "2025-01-15",
                "time": "9:00 AM",
                "address": "204, Floor 2, Azure Tower, Al Barsha, Dubai",
                "type": "home_collection"
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "appointment_id" in data
        print("✓ Appointment booked successfully")
    
    def test_get_current_appointment(self, auth_token):
        """Test getting current appointment"""
        # First book an appointment
        requests.post(
            f"{BASE_URL}/api/appointments/book",
            json={
                "date": "2025-01-15",
                "time": "10:00 AM",
                "address": "101, Floor 1, Marina Tower, Dubai Marina, Dubai",
                "type": "home_collection"
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        
        # Get current appointment
        response = requests.get(
            f"{BASE_URL}/api/appointments/current",
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "time" in data
        print("✓ Current appointment retrieved")


class TestFullFlow:
    """Full end-to-end flow test"""
    
    def test_complete_user_journey(self):
        """Test complete user journey: Login -> Subscription -> Profile -> Book"""
        phone = "509876543"
        
        # Step 1: Send OTP
        response = requests.post(f"{BASE_URL}/api/auth/send-otp", json={"phone": phone})
        assert response.status_code == 200
        print("Step 1: OTP sent ✓")
        
        # Step 2: Verify OTP
        response = requests.post(f"{BASE_URL}/api/auth/verify-otp", json={
            "phone": phone,
            "otp": "1234"
        })
        assert response.status_code == 200
        token = response.json()["access_token"]
        user = response.json()["user"]
        print(f"Step 2: OTP verified, user created ✓")
        
        # Step 3: Select subscription
        response = requests.post(
            f"{BASE_URL}/api/subscription/select",
            json={"package_id": "family-of-2"},
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        print("Step 3: Family-of-2 subscription selected ✓")
        
        # Step 4: Complete profile with family member
        response = requests.put(
            f"{BASE_URL}/api/auth/profile/complete",
            json={
                "first_name": "Test",
                "last_name": "User",
                "dob": "1990-01-01",
                "phone": phone,
                "email": "test.user@example.com",
                "family_members": [
                    {"name": "Family Member", "age": "30", "relationship": "wife"}
                ]
            },
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        print("Step 4: Profile completed with family member ✓")
        
        # Step 5: Book test
        response = requests.post(
            f"{BASE_URL}/api/appointments/book",
            json={
                "date": "2025-01-20",
                "time": "9:30 AM",
                "address": "505, Floor 5, Business Bay Tower, Business Bay, Dubai",
                "type": "home_collection"
            },
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        print("Step 5: Test appointment booked ✓")
        
        print("\n✅ FULL USER JOURNEY COMPLETED SUCCESSFULLY!")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
