#!/usr/bin/env python3
"""
Extended Backend API Testing for CareGuard UAE Health MVP
Tests all health-related endpoints and AI features
"""

import requests
import sys
import json
from datetime import datetime

class ExtendedCareGuardAPITester:
    def __init__(self, base_url="https://preventivehealth.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_phone = "501234567"  # Test phone number

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        if details:
            print(f"   Details: {details}")

    def authenticate(self):
        """Authenticate and get token"""
        print("\n🔍 Authenticating...")
        
        try:
            # Send OTP
            payload = {"phone": self.test_phone}
            response = requests.post(f"{self.api_url}/auth/send-otp", 
                                   json=payload, timeout=10)
            
            if response.status_code != 200:
                print(f"❌ Failed to send OTP: {response.status_code}")
                return False
            
            # Verify OTP
            payload = {"phone": self.test_phone, "otp": "1234"}
            response = requests.post(f"{self.api_url}/auth/verify-otp", 
                                   json=payload, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.token = data["access_token"]
                self.user_data = data["user"]
                print(f"✅ Authentication successful, User ID: {self.user_data.get('id', 'N/A')}")
                return True
            else:
                print(f"❌ Failed to verify OTP: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Authentication failed: {str(e)}")
            return False

    def test_notifications(self):
        """Test notifications endpoints"""
        print("\n🔍 Testing Notifications...")
        
        if not self.token:
            self.log_test("Notifications", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            # Get notifications
            response = requests.get(f"{self.api_url}/notifications", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                success = isinstance(data, list)
                notification_count = len(data)
                unread_count = len([n for n in data if not n.get('read', True)])
                
                self.log_test("Get Notifications", success, 
                             f"Found {notification_count} notifications, {unread_count} unread")
                
                # Test mark as read if we have notifications
                if data and not data[0].get('read', True):
                    notif_id = data[0]['id']
                    response = requests.put(f"{self.api_url}/notifications/{notif_id}/read", 
                                          headers=headers, timeout=10)
                    mark_success = response.status_code == 200
                    self.log_test("Mark Notification Read", mark_success, 
                                 f"Status: {response.status_code}")
                
                # Test mark all as read
                response = requests.put(f"{self.api_url}/notifications/read-all", 
                                      headers=headers, timeout=10)
                mark_all_success = response.status_code == 200
                self.log_test("Mark All Notifications Read", mark_all_success, 
                             f"Status: {response.status_code}")
                
            else:
                self.log_test("Get Notifications", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Notifications", False, str(e))
            return False

    def test_biomarkers(self):
        """Test biomarkers endpoint"""
        print("\n🔍 Testing Biomarkers...")
        
        if not self.token:
            self.log_test("Biomarkers", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/biomarkers", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["biomarkers", "has_previous_report"]
                has_fields = all(field in data for field in expected_fields)
                biomarker_count = len(data.get("biomarkers", []))
                
                success = has_fields and biomarker_count > 0
                self.log_test("Get Biomarkers", success, 
                             f"Found {biomarker_count} biomarkers, Has previous: {data.get('has_previous_report')}")
            else:
                self.log_test("Get Biomarkers", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Biomarkers", False, str(e))
            return False

    def test_health_score(self):
        """Test health score endpoint"""
        print("\n🔍 Testing Health Score...")
        
        if not self.token:
            self.log_test("Health Score", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/health-score", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["score", "status", "insights", "breakdown"]
                has_fields = all(field in data for field in expected_fields)
                score = data.get("score", 0)
                insights_count = len(data.get("insights", []))
                
                success = has_fields and score > 0
                self.log_test("Get Health Score", success, 
                             f"Score: {score}, Status: {data.get('status')}, Insights: {insights_count}")
            else:
                self.log_test("Get Health Score", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Health Score", False, str(e))
            return False

    def test_tests_completed(self):
        """Test tests completed endpoint"""
        print("\n🔍 Testing Tests Completed...")
        
        if not self.token:
            self.log_test("Tests Completed", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/tests-completed", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["total_tests", "tests_by_category", "reports"]
                has_fields = all(field in data for field in expected_fields)
                total_tests = data.get("total_tests", 0)
                categories = len(data.get("tests_by_category", {}))
                
                success = has_fields and total_tests > 0
                self.log_test("Get Tests Completed", success, 
                             f"Total tests: {total_tests}, Categories: {categories}")
            else:
                self.log_test("Get Tests Completed", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Tests Completed", False, str(e))
            return False

    def test_ai_insights(self):
        """Test AI insights endpoint"""
        print("\n🔍 Testing AI Insights...")
        
        if not self.token:
            self.log_test("AI Insights", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            # Test different categories
            categories = ["All", "Blood", "Heart", "Vitamins", "Metabolic"]
            
            for category in categories:
                payload = {"category": category}
                response = requests.post(f"{self.api_url}/ai/insights", 
                                       json=payload, headers=headers, timeout=15)
                
                success = response.status_code == 200
                if success:
                    data = response.json()
                    has_insight = "insight" in data and len(data["insight"]) > 10
                    success = has_insight
                    
                    self.log_test(f"AI Insights ({category})", success, 
                                 f"Insight length: {len(data.get('insight', ''))}")
                else:
                    self.log_test(f"AI Insights ({category})", False, 
                                 f"Status: {response.status_code}")
            
            return True
        except Exception as e:
            self.log_test("AI Insights", False, str(e))
            return False

    def test_ai_chat(self):
        """Test AI chat endpoint"""
        print("\n🔍 Testing AI Chat...")
        
        if not self.token:
            self.log_test("AI Chat", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            # Test chat with a health question
            payload = {"question": "What does my Vitamin D level mean?"}
            response = requests.post(f"{self.api_url}/ai/chat", 
                                   json=payload, headers=headers, timeout=15)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["question", "answer", "disclaimer"]
                has_fields = all(field in data for field in expected_fields)
                answer_length = len(data.get("answer", ""))
                
                success = has_fields and answer_length > 10
                self.log_test("AI Chat", success, 
                             f"Answer length: {answer_length}, Has disclaimer: {'disclaimer' in data}")
            else:
                self.log_test("AI Chat", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("AI Chat", False, str(e))
            return False

    def test_recommendation_details(self):
        """Test recommendation details endpoint"""
        print("\n🔍 Testing Recommendation Details...")
        
        if not self.token:
            self.log_test("Recommendation Details", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            # Test recommendation details
            payload = {"topic": "Increase Vitamin D"}
            response = requests.post(f"{self.api_url}/ai/recommendation-details", 
                                   json=payload, headers=headers, timeout=15)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["topic", "details", "disclaimer"]
                has_fields = all(field in data for field in expected_fields)
                details_length = len(data.get("details", ""))
                
                success = has_fields and details_length > 10
                self.log_test("Recommendation Details", success, 
                             f"Details length: {details_length}, Topic: {data.get('topic')}")
            else:
                self.log_test("Recommendation Details", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Recommendation Details", False, str(e))
            return False

    def run_all_tests(self):
        """Run all extended backend tests"""
        print("🚀 Starting Extended CareGuard UAE Backend API Tests")
        print(f"Testing against: {self.api_url}")
        print("=" * 60)
        
        # Authenticate first
        if not self.authenticate():
            print("❌ Authentication failed, cannot proceed with tests")
            return 1
        
        # Test sequence
        tests = [
            self.test_notifications,
            self.test_biomarkers,
            self.test_health_score,
            self.test_tests_completed,
            self.test_ai_insights,
            self.test_ai_chat,
            self.test_recommendation_details,
        ]
        
        for test in tests:
            try:
                test()
            except Exception as e:
                print(f"❌ Test {test.__name__} crashed: {str(e)}")
        
        # Print summary
        print("\n" + "=" * 60)
        print(f"📊 Test Summary: {self.tests_passed}/{self.tests_run} tests passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All extended tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} tests failed")
            return 1

def main():
    tester = ExtendedCareGuardAPITester()
    return tester.run_all_tests()

if __name__ == "__main__":
    sys.exit(main())