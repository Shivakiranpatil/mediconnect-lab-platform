-- CareGuard UAE - Supabase Database Schema
-- Run this in Supabase SQL Editor
-- Updated for Firebase Email/Password Authentication

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing tables if they exist (careful in production!)
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS reports CASCADE;
DROP TABLE IF EXISTS appointments CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS partner_labs CASCADE;
DROP TABLE IF EXISTS admin_users CASCADE;
DROP TABLE IF EXISTS subscription_plans CASCADE;
DROP TABLE IF EXISTS api_settings CASCADE;

-- Users table (linked to Firebase Auth)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    firebase_uid TEXT UNIQUE NOT NULL,
    email TEXT,
    phone_number TEXT DEFAULT '',
    name TEXT,
    age INTEGER,
    plan_type TEXT,
    family_members JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on firebase_uid for fast lookups
CREATE INDEX idx_users_firebase_uid ON users(firebase_uid);
CREATE INDEX idx_users_email ON users(email);

-- Partner Labs table
CREATE TABLE partner_labs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    password_hash TEXT NOT NULL,
    emirate TEXT NOT NULL,
    area TEXT,
    address TEXT,
    capacity_per_day INTEGER DEFAULT 50,
    current_load INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Appointments table
CREATE TABLE appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    address JSONB,
    phone TEXT,
    type TEXT DEFAULT 'home_collection',
    status TEXT DEFAULT 'booked',
    assigned_lab_id UUID REFERENCES partner_labs(id),
    assigned_lab_name TEXT,
    assignment_type TEXT,
    family_member_id TEXT,
    test_name TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_appointments_user ON appointments(user_id);
CREATE INDEX idx_appointments_lab ON appointments(assigned_lab_id);
CREATE INDEX idx_appointments_status ON appointments(status);

-- Reports table
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    appointment_id UUID REFERENCES appointments(id),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    member_id TEXT,
    summary TEXT,
    biomarkers JSONB DEFAULT '[]'::jsonb,
    recommendations JSONB DEFAULT '[]'::jsonb,
    health_score INTEGER,
    test_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_reports_user ON reports(user_id);

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT DEFAULT 'info',
    read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id);

-- Subscription Plans table
CREATE TABLE subscription_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    duration_days INTEGER,
    tests_included INTEGER,
    features JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Admin users table
CREATE TABLE admin_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT,
    role TEXT DEFAULT 'admin',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- API Settings table
CREATE TABLE api_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    setting_key TEXT UNIQUE NOT NULL,
    setting_value TEXT,
    is_enabled BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default admin user (password: admin123)
INSERT INTO admin_users (email, password_hash, name, role) 
VALUES ('admin@healthapp.com', 'admin123', 'Admin', 'super_admin');

-- Insert default lab partner (password: lab123)
INSERT INTO partner_labs (name, email, phone, password_hash, emirate, area, capacity_per_day, status)
VALUES ('Dubai Health Lab', 'lab@dubai.com', '+971501234567', 'lab123', 'Dubai', 'Business Bay', 50, 'active');

-- Insert Abu Dhabi lab partner
INSERT INTO partner_labs (name, email, phone, password_hash, emirate, area, capacity_per_day, status)
VALUES ('Abu Dhabi Medical Lab', 'lab@abudhabi.com', '+971502234567', 'lab123', 'Abu Dhabi', 'Al Reem Island', 50, 'active');

-- Insert Sharjah lab partner
INSERT INTO partner_labs (name, email, phone, password_hash, emirate, area, capacity_per_day, status)
VALUES ('Sharjah Health Lab', 'lab@sharjah.com', '+971503234567', 'lab123', 'Sharjah', 'Al Nahda', 50, 'active');

-- Insert default subscription plans
INSERT INTO subscription_plans (name, type, price, duration_days, tests_included, features) VALUES
('Starter', 'individual', 99, 30, 1, '["Basic health checkup", "1 home visit", "Digital report"]'::jsonb),
('Preventive Starter', 'individual', 449, 90, 3, '["Comprehensive health panel", "3 home visits", "AI health insights", "Priority support"]'::jsonb),
('Preventive Plus', 'individual', 649, 180, 6, '["Full body checkup", "6 home visits", "AI recommendations", "Doctor consultation", "Priority support"]'::jsonb),
('Family of 2', 'family', 199, 30, 2, '["For 2 family members", "Basic health checkup", "Home collection", "Digital reports"]'::jsonb),
('Family of 3', 'family', 299, 30, 3, '["For 3 family members", "Basic health checkup", "Home collection", "Digital reports"]'::jsonb),
('Family of 4', 'family', 399, 30, 4, '["For 4 family members", "Basic health checkup", "Home collection", "Digital reports"]'::jsonb);

-- NOTE: Row Level Security (RLS) is DISABLED because we're using Firebase Auth, not Supabase Auth
-- The backend uses the service_role key which bypasses RLS anyway
-- If you want to enable RLS later with Firebase, you'll need custom JWT verification
