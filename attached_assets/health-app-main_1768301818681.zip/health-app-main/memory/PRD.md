# CareGuard UAE - Preventive Health Membership MVP

## Product Requirements Document

### Overview
A UAE-based preventive health membership mobile web app (PWA) that enables users to book home health tests, view AI-powered report explanations, and track their health over time.

---

## Architecture (Updated December 2025)

### Tech Stack
- **Frontend:** React 18 + Tailwind CSS + Shadcn/UI
- **Database:** Supabase (PostgreSQL)
- **Authentication:** Firebase Email/Password
- **Hosting Target:** Vercel (serverless)
- **AI Features:** OpenAI GPT-4o (direct frontend integration)
- **PDF Parsing:** pdf.js + OpenAI GPT-4o

### Key Files
- `/app/frontend/src/config/firebase.js` - Firebase configuration
- `/app/frontend/src/config/supabase.js` - Supabase client & service layer
- `/app/frontend/src/context/AuthContext.jsx` - Firebase auth state management
- `/app/frontend/src/services/pdfParser.js` - PDF parsing service (NEW)
- `/app/database/supabase_schema.sql` - Database schema (run in Supabase SQL Editor)

---

## Portals

### 1. User App
- **URL:** `/` (welcome), `/login`, `/home`
- **Auth:** Firebase Email/Password

### 2. Admin Dashboard
- **URL:** `/admin/login`, `/admin/*`
- **Credentials:** admin@healthapp.com / admin123

### 3. Lab Partner Portal
- **URL:** `/lab/login`, `/lab/*`
- **Credentials:** lab@dubai.com / lab123

---

## Core Features

### A) User App

#### Authentication
- Email/Password login via Firebase
- **Forgot Password** - Email-based password reset via Firebase
- Session persistence via AuthContext and localStorage
- Profile completion page after subscription (Name, Age, Email, Phone)
- Family member management for family plans (Name, Age, Relationship)

#### Subscription Plans
- Individual Plans: Starter (AED 99), Preventive Starter (AED 449), Preventive Plus (AED 649)
- Family Plans: Family of 2 (AED 199), Family of 3 (AED 299), Family of 4 (AED 399)

#### Booking Flow
1. Login → Select Plan → Complete Profile → Book Test → Confirmation
2. Detailed address fields: Flat/Office, Floor, Building, Area, Emirate, Landmark
3. Time slot selection with calendar

#### Health Dashboard
- Home page with health status, key metrics, AI tips
- Health Score calculation based on biomarkers
- Biomarker cards (Normal/Borderline/Needs Attention)
- AI-powered personalized recommendations

### B) Admin Dashboard

#### Dashboard Analytics
- Total Users, Appointments, Reports, Partner Labs
- System Overview with counts
- Database Status (Supabase Connected, Firebase Active)
- Quick Actions

#### User Management (CRM)
- View all registered users
- Search and filter users

#### Partner Labs Management
- View all partner labs
- Lab information display

### C) Lab Partner Portal

#### Dashboard
- Real-time appointment overview
- Pending, Confirmed, Sample Collected, Processing, Completed stats
- Today's tests scheduled
- Auto-refresh functionality

#### Appointment Management
- View and filter appointments by status
- Update appointment status
- View customer details and address

#### Report Upload (NEW - AI-Powered)
- Upload lab reports for completed tests
- **AI-powered PDF parsing using OpenAI GPT-4o**
- Automatic extraction of biomarkers, values, and status
- Manual entry fallback if AI parsing fails

---

## Implementation Status

### Completed ✅
1. **Firebase Email/Password Authentication** - User signup/login working
2. **Supabase Integration** - Direct frontend-to-Supabase calls
3. **Admin Dashboard** - Login, analytics, users list, labs list
4. **Lab Portal** - Login, dashboard, appointments view
5. **Database Schema** - Complete schema in `/app/database/supabase_schema.sql`
6. **Updated README** - Setup instructions for Vercel deployment
7. **AI PDF Parsing** - Frontend-based PDF parsing with OpenAI (NEW)
8. **Forgot Password** - Email-based password reset
9. **Appointment Booking** - Full booking flow with lab assignment

### For Vercel Deployment
User needs to:
1. Enable Email/Password in Firebase Console
2. Run `supabase_schema.sql` in Supabase SQL Editor
3. Set environment variables in Vercel dashboard (including REACT_APP_OPENAI_API_KEY)
4. Deploy from the `frontend` directory

---

## Environment Variables (for Vercel)

```env
REACT_APP_FIREBASE_API_KEY=xxx
REACT_APP_FIREBASE_AUTH_DOMAIN=xxx
REACT_APP_FIREBASE_PROJECT_ID=xxx
REACT_APP_FIREBASE_STORAGE_BUCKET=xxx
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=xxx
REACT_APP_FIREBASE_APP_ID=xxx
REACT_APP_SUPABASE_URL=xxx
REACT_APP_SUPABASE_ANON_KEY=xxx
REACT_APP_OPENAI_API_KEY=xxx
```

---

## Recent Changes (December 2025)

### PDF Parsing Implementation
- Created `/app/frontend/src/services/pdfParser.js`
- Uses `pdf.js` library for text extraction
- Uses OpenAI GPT-4o for intelligent biomarker parsing
- Automatically extracts: patient info, biomarkers, values, units, reference ranges, status, recommendations
- Added `REACT_APP_OPENAI_API_KEY` to frontend environment

### Appointment Visibility Fix
- Fixed ID mismatch between Firebase UID and Supabase UUID in AuthContext
- Ensured `user.id` consistently refers to Supabase UUID for all data operations
- Added detailed logging for debugging appointment fetching

---

## Future Tasks (Backlog)

### P1 - High Priority
- Test and verify appointment visibility fix on Vercel deployment
- Test PDF parsing with real lab reports

### P2 - Medium Priority
- Google Maps API integration for address search
- WhatsApp notifications
- Email verification

### P3 - Lower Priority
- Role-Based Access Control (RBAC) for admin
- Advanced analytics and charts
- Multi-language support (Arabic)

---

## Test Credentials

| Portal | Email | Password |
|--------|-------|----------|
| Admin | admin@healthapp.com | admin123 |
| Lab (Dubai) | lab@dubai.com | lab123 |
| Lab (Abu Dhabi) | lab@abudhabi.com | lab123 |
| Lab (Sharjah) | lab@sharjah.com | lab123 |
| User | Sign up with any email | min 6 chars |

---

*Last Updated: December 2025*
