#!/usr/bin/env python3
"""
Subscription Flow Testing for CareGuard UAE Health MVP
Tests subscription selection, booking, and status endpoints
"""

import requests
import sys
import json
from datetime import datetime

class SubscriptionFlowTester:
    def __init__(self, base_url="https://preventivehealth.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_phone = "505551234"  # Different phone for new user

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        if details:
            print(f"   Details: {details}")

    def setup_new_user(self):
        """Create a new user for testing subscription flow"""
        print("\n🔍 Setting up new user for subscription flow...")
        
        try:
            # Send OTP
            payload = {"phone": self.test_phone}
            response = requests.post(f"{self.api_url}/auth/send-otp", 
                                   json=payload, timeout=10)
            
            if response.status_code != 200:
                self.log_test("Setup - Send OTP", False, f"Status: {response.status_code}")
                return False
            
            # Verify OTP
            payload = {"phone": self.test_phone, "otp": "1234"}
            response = requests.post(f"{self.api_url}/auth/verify-otp", 
                                   json=payload, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.token = data["access_token"]
                self.user_data = data["user"]
                self.log_test("Setup - New User", True, 
                             f"User created with ID: {self.user_data.get('id')}")
                return True
            else:
                self.log_test("Setup - New User", False, f"Status: {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("Setup - New User", False, str(e))
            return False

    def test_subscription_select(self):
        """Test subscription package selection"""
        print("\n🔍 Testing Subscription Selection...")
        
        if not self.token:
            self.log_test("Subscription Select", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            # Test individual package selection
            payload = {"package_id": "preventive-plus"}
            response = requests.post(f"{self.api_url}/subscription/select", 
                                   json=payload, headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                success = data.get("success") is True and "subscription_id" in data
                self.log_test("Subscription Select", success, 
                             f"Response: {data}")
            else:
                self.log_test("Subscription Select", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Subscription Select", False, str(e))
            return False

    def test_current_subscription(self):
        """Test getting current subscription"""
        print("\n🔍 Testing Get Current Subscription...")
        
        if not self.token:
            self.log_test("Get Subscription", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/subscription/current", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                # Should have subscription data now
                has_subscription = "package_id" in data
                self.log_test("Get Subscription", has_subscription, 
                             f"Subscription data: {data}")
                return has_subscription
            else:
                self.log_test("Get Subscription", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            self.log_test("Get Subscription", False, str(e))
            return False

    def test_book_appointment(self):
        """Test booking an appointment"""
        print("\n🔍 Testing Book Appointment...")
        
        if not self.token:
            self.log_test("Book Appointment", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            payload = {
                "date": "2026-01-10",
                "time": "10:00 AM",
                "address": "Test Address, Dubai, UAE",
                "phone": self.test_phone,
                "type": "home_collection"
            }
            response = requests.post(f"{self.api_url}/appointments/book", 
                                   json=payload, headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                success = data.get("success") is True and "appointment_id" in data
                self.log_test("Book Appointment", success, 
                             f"Response: {data}")
            else:
                self.log_test("Book Appointment", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Book Appointment", False, str(e))
            return False

    def test_current_appointment(self):
        """Test getting current appointment"""
        print("\n🔍 Testing Get Current Appointment...")
        
        if not self.token:
            self.log_test("Get Appointment", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/appointments/current", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                # Should have appointment data now
                has_appointment = "status" in data and "date" in data
                self.log_test("Get Appointment", has_appointment, 
                             f"Appointment data: {data}")
                return has_appointment
            else:
                self.log_test("Get Appointment", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            self.log_test("Get Appointment", False, str(e))
            return False

    def test_user_has_reports(self):
        """Test checking if user has reports"""
        print("\n🔍 Testing User Has Reports Check...")
        
        if not self.token:
            self.log_test("Has Reports Check", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/user/has-reports", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["has_reports", "report_count", "has_appointment", "appointment_status"]
                has_fields = all(field in data for field in expected_fields)
                self.log_test("Has Reports Check", has_fields, 
                             f"Report status: {data}")
                return has_fields
            else:
                self.log_test("Has Reports Check", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            self.log_test("Has Reports Check", False, str(e))
            return False

    def test_notifications(self):
        """Test getting notifications"""
        print("\n🔍 Testing Get Notifications...")
        
        if not self.token:
            self.log_test("Get Notifications", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/notifications", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                # Should be a list of notifications
                is_list = isinstance(data, list)
                self.log_test("Get Notifications", is_list, 
                             f"Notifications count: {len(data) if is_list else 'Not a list'}")
                return is_list
            else:
                self.log_test("Get Notifications", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            self.log_test("Get Notifications", False, str(e))
            return False

    def run_all_tests(self):
        """Run all subscription flow tests"""
        print("🚀 Starting CareGuard UAE Subscription Flow Tests")
        print(f"Testing against: {self.api_url}")
        print("=" * 60)
        
        # Test sequence
        tests = [
            self.setup_new_user,
            self.test_subscription_select,
            self.test_current_subscription,
            self.test_book_appointment,
            self.test_current_appointment,
            self.test_user_has_reports,
            self.test_notifications,
        ]
        
        for test in tests:
            try:
                result = test()
                if not result and test == self.setup_new_user:
                    print("❌ Setup failed, stopping tests")
                    break
            except Exception as e:
                print(f"❌ Test {test.__name__} crashed: {str(e)}")
        
        # Print summary
        print("\n" + "=" * 60)
        print(f"📊 Test Summary: {self.tests_passed}/{self.tests_run} tests passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All subscription flow tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} tests failed")
            return 1

def main():
    tester = SubscriptionFlowTester()
    return tester.run_all_tests()

if __name__ == "__main__":
    sys.exit(main())