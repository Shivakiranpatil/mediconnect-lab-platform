from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from supabase import create_client, Client
import os
import logging
from pathlib import Path
from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import httpx
import json

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Supabase connection
SUPABASE_URL = os.environ.get('SUPABASE_URL')
SUPABASE_SERVICE_KEY = os.environ.get('SUPABASE_SERVICE_KEY')
FIREBASE_PROJECT_ID = os.environ.get('FIREBASE_PROJECT_ID')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')

supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)

# Security
security = HTTPBearer(auto_error=False)

# Create the main app
app = FastAPI(title="CareGuard UAE - Preventive Health MVP")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============== MODELS ==============

class FirebaseLoginRequest(BaseModel):
    firebase_token: str
    email: Optional[str] = None

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    firebase_uid: str
    email: Optional[str] = None
    phone_number: Optional[str] = None
    name: Optional[str] = None
    age: Optional[int] = None
    plan_type: Optional[str] = None
    family_members: Optional[List[Dict]] = []
    created_at: Optional[str] = None

class ProfileComplete(BaseModel):
    first_name: str
    last_name: str
    age: str
    phone: str
    email: str
    family_members: Optional[List[Dict[str, Any]]] = []

class AppointmentBook(BaseModel):
    date: str
    time: str
    address: Any
    phone: Optional[str] = None
    type: str = "home_collection"

class AdminLoginRequest(BaseModel):
    email: str
    password: str

class LabLoginRequest(BaseModel):
    email: str
    password: str

# ============== AUTH HELPERS ==============

async def verify_firebase_token(token: str) -> dict:
    """Verify Firebase ID token using Google's public keys"""
    try:
        # Use Google's token info endpoint for verification
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={token}"
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=401, detail="Invalid Firebase token")
            
            token_info = response.json()
            
            # Verify the token is for our Firebase project
            if token_info.get('aud') != FIREBASE_PROJECT_ID and not token_info.get('aud', '').startswith(FIREBASE_PROJECT_ID):
                raise HTTPException(status_code=401, detail="Token not for this project")
            
            return {
                'uid': token_info.get('sub'),
                'email': token_info.get('email'),
                'email_verified': token_info.get('email_verified') == 'true'
            }
    except httpx.HTTPError as e:
        logger.error(f"Firebase token verification error: {e}")
        raise HTTPException(status_code=401, detail="Token verification failed")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from Firebase token"""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = credentials.credentials
    
    # Verify Firebase token
    firebase_user = await verify_firebase_token(token)
    firebase_uid = firebase_user['uid']
    
    # Get user from Supabase
    result = supabase.table('users').select('*').eq('firebase_uid', firebase_uid).execute()
    
    if not result.data:
        raise HTTPException(status_code=401, detail="User not found in database")
    
    user = result.data[0]
    user['id'] = str(user['id'])
    return user

# ============== AUTH ENDPOINTS ==============

@api_router.post("/auth/firebase-login")
async def firebase_login(request: FirebaseLoginRequest):
    """Login/Register user with Firebase token"""
    try:
        # Verify the Firebase token
        firebase_user = await verify_firebase_token(request.firebase_token)
        firebase_uid = firebase_user['uid']
        email = firebase_user.get('email') or request.email
        
        # Check if user exists
        result = supabase.table('users').select('*').eq('firebase_uid', firebase_uid).execute()
        
        if result.data:
            # Existing user
            user = result.data[0]
        else:
            # Create new user
            new_user = {
                'firebase_uid': firebase_uid,
                'email': email or '',
                'phone_number': '',
                'created_at': datetime.now(timezone.utc).isoformat()
            }
            
            insert_result = supabase.table('users').insert(new_user).execute()
            user = insert_result.data[0]
            
            # Create welcome notification
            supabase.table('notifications').insert({
                'user_id': user['id'],
                'title': 'Welcome to CareGuard! 🎉',
                'message': 'Your journey to better health starts here. Book your first test to get personalized insights.',
                'type': 'welcome'
            }).execute()
        
        user['id'] = str(user['id'])
        
        return {
            "success": True,
            "user": user,
            "message": "Login successful"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Firebase login error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    """Get current authenticated user"""
    return current_user

@api_router.put("/auth/profile/complete")
async def complete_profile(request: ProfileComplete, current_user: dict = Depends(get_current_user)):
    """Complete user profile after subscription selection"""
    update_data = {
        'name': f"{request.first_name} {request.last_name}",
        'age': int(request.age) if request.age.isdigit() else None,
        'phone_number': request.phone,
        'email': request.email,
        'updated_at': datetime.now(timezone.utc).isoformat()
    }
    
    if request.family_members:
        update_data['family_members'] = request.family_members
    
    supabase.table('users').update(update_data).eq('id', current_user['id']).execute()
    
    result = supabase.table('users').select('*').eq('id', current_user['id']).execute()
    user = result.data[0]
    user['id'] = str(user['id'])
    
    return {"success": True, "user": user}

@api_router.put("/subscription/select")
async def select_subscription(plan_type: str, current_user: dict = Depends(get_current_user)):
    """Select subscription plan"""
    supabase.table('users').update({
        'plan_type': plan_type,
        'updated_at': datetime.now(timezone.utc).isoformat()
    }).eq('id', current_user['id']).execute()
    
    return {"success": True, "plan_type": plan_type}

# ============== APPOINTMENTS ENDPOINTS ==============

@api_router.post("/appointments/book")
async def book_appointment(request: AppointmentBook, current_user: dict = Depends(get_current_user)):
    """Book a new appointment"""
    # Find nearest lab based on emirate
    emirate = request.address.get('emirate', 'Dubai') if isinstance(request.address, dict) else 'Dubai'
    
    labs_result = supabase.table('partner_labs').select('*').eq('emirate', emirate).eq('status', 'active').limit(1).execute()
    assigned_lab = labs_result.data[0] if labs_result.data else None
    
    appointment_data = {
        'user_id': current_user['id'],
        'date': request.date,
        'time': request.time,
        'address': request.address if isinstance(request.address, dict) else {'full_address': request.address},
        'phone': request.phone or current_user.get('phone_number'),
        'type': request.type,
        'status': 'booked',
        'assigned_lab_id': str(assigned_lab['id']) if assigned_lab else None,
        'assigned_lab_name': assigned_lab['name'] if assigned_lab else None,
        'assignment_type': 'auto' if assigned_lab else None,
        'created_at': datetime.now(timezone.utc).isoformat()
    }
    
    result = supabase.table('appointments').insert(appointment_data).execute()
    appointment = result.data[0]
    
    # Create notification
    supabase.table('notifications').insert({
        'user_id': current_user['id'],
        'title': 'Booking Confirmed! 📅',
        'message': f"Your test is scheduled for {request.date} at {request.time}.",
        'type': 'booking'
    }).execute()
    
    appointment['id'] = str(appointment['id'])
    return {"success": True, "appointment": appointment}

@api_router.get("/appointments/all")
async def get_all_appointments(current_user: dict = Depends(get_current_user)):
    """Get all appointments for user"""
    result = supabase.table('appointments').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).execute()
    
    appointments = result.data or []
    for apt in appointments:
        apt['id'] = str(apt['id'])
    
    upcoming = [a for a in appointments if a['status'] in ['booked', 'confirmed', 'sample_collected', 'processing']]
    completed = [a for a in appointments if a['status'] in ['completed', 'report_ready']]
    
    return {
        "upcoming": upcoming,
        "completed": completed,
        "all": appointments
    }

@api_router.get("/appointments/status")
async def get_appointment_status(current_user: dict = Depends(get_current_user)):
    """Get status of latest appointment"""
    result = supabase.table('appointments').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).limit(1).execute()
    
    if not result.data:
        return {"has_appointment": False, "appointment": None}
    
    appointment = result.data[0]
    appointment['id'] = str(appointment['id'])
    
    return {"has_appointment": True, "appointment": appointment}

# ============== HEALTH DATA ENDPOINTS ==============

@api_router.get("/biomarkers")
async def get_biomarkers(current_user: dict = Depends(get_current_user)):
    """Get user's latest biomarkers"""
    result = supabase.table('reports').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).limit(1).execute()
    
    if not result.data:
        return {"biomarkers": [], "test_date": None, "has_reports": False}
    
    report = result.data[0]
    return {
        "biomarkers": report.get('biomarkers', []),
        "test_date": report.get('test_date'),
        "has_reports": True
    }

@api_router.get("/health-score")
async def get_health_score(current_user: dict = Depends(get_current_user)):
    """Calculate and return health score"""
    result = supabase.table('reports').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).limit(1).execute()
    
    if not result.data:
        return {
            "score": 0,
            "status": "No Data",
            "excellent_count": 0,
            "needs_care_count": 0,
            "total_parameters": 0,
            "insights": []
        }
    
    biomarkers = result.data[0].get('biomarkers', [])
    excellent_statuses = ['excellent', 'optimal', 'normal']
    
    excellent_count = 0
    needs_care_count = 0
    total_score = 0
    
    for b in biomarkers:
        status = (b.get('status') or '').lower()
        if status in excellent_statuses:
            total_score += 85
            excellent_count += 1
        elif status in ['borderline', 'slightly low', 'slightly high']:
            total_score += 60
            needs_care_count += 1
        else:
            total_score += 40
            needs_care_count += 1
    
    overall_score = round(total_score / len(biomarkers)) if biomarkers else 0
    
    if overall_score >= 90:
        status = 'Excellent'
    elif overall_score >= 75:
        status = 'Good'
    elif overall_score >= 60:
        status = 'Fair'
    else:
        status = 'Needs Attention'
    
    return {
        "score": overall_score,
        "status": status,
        "excellent_count": excellent_count,
        "needs_care_count": needs_care_count,
        "total_parameters": len(biomarkers),
        "insights": []
    }

@api_router.get("/reports")
async def get_reports(current_user: dict = Depends(get_current_user)):
    """Get user's health reports"""
    result = supabase.table('reports').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).execute()
    
    reports = result.data or []
    for report in reports:
        report['id'] = str(report['id'])
    
    return reports

# ============== NOTIFICATIONS ==============

@api_router.get("/notifications")
async def get_notifications(current_user: dict = Depends(get_current_user)):
    """Get user notifications"""
    result = supabase.table('notifications').select('*').eq('user_id', current_user['id']).order('created_at', desc=True).limit(20).execute()
    
    notifications = result.data or []
    for n in notifications:
        n['id'] = str(n['id'])
    
    return notifications

@api_router.put("/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, current_user: dict = Depends(get_current_user)):
    """Mark notification as read"""
    supabase.table('notifications').update({'read': True}).eq('id', notification_id).execute()
    return {"success": True}

# ============== SUBSCRIPTION PLANS ==============

@api_router.get("/subscription/plans")
async def get_subscription_plans():
    """Get available subscription plans"""
    result = supabase.table('subscription_plans').select('*').eq('is_active', True).execute()
    
    plans = result.data or []
    for plan in plans:
        plan['id'] = str(plan['id'])
    
    return plans

# ============== USER STATUS ==============

@api_router.get("/user/status")
async def get_user_status(current_user: dict = Depends(get_current_user)):
    """Check if user has reports and appointment status"""
    reports_result = supabase.table('reports').select('id').eq('user_id', current_user['id']).execute()
    appointments_result = supabase.table('appointments').select('status').eq('user_id', current_user['id']).order('created_at', desc=True).limit(1).execute()
    
    return {
        "has_reports": len(reports_result.data or []) > 0,
        "report_count": len(reports_result.data or []),
        "has_appointment": len(appointments_result.data or []) > 0,
        "appointment_status": appointments_result.data[0]['status'] if appointments_result.data else None
    }

# ============== ADMIN ENDPOINTS ==============

@api_router.post("/admin/login")
async def admin_login(request: AdminLoginRequest):
    """Admin login"""
    result = supabase.table('admin_users').select('*').eq('email', request.email).execute()
    
    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    admin = result.data[0]
    
    # Simple password check (in production, use proper hashing)
    if request.password != 'admin123':
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    admin['id'] = str(admin['id'])
    return {"success": True, "admin": admin}

@api_router.get("/admin/analytics")
async def get_admin_analytics():
    """Get admin dashboard analytics"""
    users = supabase.table('users').select('id', count='exact').execute()
    appointments = supabase.table('appointments').select('id', count='exact').execute()
    reports = supabase.table('reports').select('id', count='exact').execute()
    labs = supabase.table('partner_labs').select('id', count='exact').execute()
    
    return {
        "total_users": users.count or 0,
        "total_appointments": appointments.count or 0,
        "total_reports": reports.count or 0,
        "total_labs": labs.count or 0
    }

@api_router.get("/admin/users")
async def get_admin_users():
    """Get all users for admin"""
    result = supabase.table('users').select('*').order('created_at', desc=True).execute()
    
    users = result.data or []
    for user in users:
        user['id'] = str(user['id'])
    
    return users

@api_router.get("/admin/labs")
async def get_admin_labs():
    """Get all labs for admin"""
    result = supabase.table('partner_labs').select('*').order('created_at', desc=True).execute()
    
    labs = result.data or []
    for lab in labs:
        lab['id'] = str(lab['id'])
    
    return labs

# ============== LAB PARTNER ENDPOINTS ==============

@api_router.post("/lab/login")
async def lab_login(request: LabLoginRequest):
    """Lab partner login"""
    result = supabase.table('partner_labs').select('*').eq('email', request.email).execute()
    
    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    lab = result.data[0]
    
    # Simple password check (in production, use proper hashing)
    if request.password != 'lab123':
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    lab['id'] = str(lab['id'])
    return {"success": True, "lab": lab}

@api_router.get("/lab/dashboard/{lab_id}")
async def get_lab_dashboard(lab_id: str):
    """Get lab dashboard stats"""
    result = supabase.table('appointments').select('*').eq('assigned_lab_id', lab_id).execute()
    
    appointments = result.data or []
    
    return {
        "stats": {
            "total": len(appointments),
            "pending": len([a for a in appointments if a['status'] in ['booked', 'confirmed']]),
            "sample_collected": len([a for a in appointments if a['status'] == 'sample_collected']),
            "processing": len([a for a in appointments if a['status'] == 'processing']),
            "completed": len([a for a in appointments if a['status'] in ['completed', 'report_ready']]),
            "upcoming": len([a for a in appointments if a['status'] in ['booked', 'confirmed', 'sample_collected']])
        }
    }

@api_router.get("/lab/appointments/{lab_id}")
async def get_lab_appointments(lab_id: str):
    """Get appointments for a lab"""
    result = supabase.table('appointments').select('*, users(id, name, phone_number, family_members)').eq('assigned_lab_id', lab_id).order('created_at', desc=True).execute()
    
    appointments = []
    for apt in (result.data or []):
        user = apt.pop('users', {}) or {}
        appointments.append({
            'id': str(apt['id']),
            'date': apt['date'],
            'time': apt['time'],
            'status': apt['status'],
            'address': apt['address'],
            'user': {
                'id': str(user.get('id', '')),
                'name': user.get('name', 'Unknown'),
                'phone': user.get('phone_number'),
                'family_members': user.get('family_members', [])
            }
        })
    
    return appointments

@api_router.put("/lab/appointments/{appointment_id}/status")
async def update_appointment_status(appointment_id: str, status: str, user_id: Optional[str] = None):
    """Update appointment status"""
    supabase.table('appointments').update({'status': status}).eq('id', appointment_id).execute()
    
    # Create notification for user
    status_messages = {
        'confirmed': 'Your appointment has been confirmed!',
        'sample_collected': 'Sample collected! Processing will begin shortly.',
        'processing': 'Your sample is being processed.',
        'report_ready': 'Your health report is ready! View your results now.'
    }
    
    if status in status_messages and user_id:
        supabase.table('notifications').insert({
            'user_id': user_id,
            'title': f"Status Update: {status.replace('_', ' ').title()}",
            'message': status_messages[status],
            'type': 'status_update'
        }).execute()
    
    return {"success": True}

@api_router.post("/lab/upload-report")
async def upload_report(
    appointment_id: str = Form(...),
    user_id: str = Form(...),
    member_id: Optional[str] = Form(None),
    summary: str = Form(...),
    biomarkers: str = Form(...),
    health_score: int = Form(...)
):
    """Upload lab report"""
    report_data = {
        'appointment_id': appointment_id,
        'user_id': user_id,
        'member_id': member_id,
        'summary': summary,
        'biomarkers': json.loads(biomarkers),
        'health_score': health_score,
        'test_date': datetime.now(timezone.utc).isoformat(),
        'created_at': datetime.now(timezone.utc).isoformat()
    }
    
    result = supabase.table('reports').insert(report_data).execute()
    report = result.data[0]
    
    # Update appointment status
    supabase.table('appointments').update({'status': 'report_ready'}).eq('id', appointment_id).execute()
    
    # Notify user
    supabase.table('notifications').insert({
        'user_id': user_id,
        'title': 'Your Report is Ready! 📊',
        'message': 'Your health report has been uploaded. Check your dashboard for detailed insights.',
        'type': 'report_ready'
    }).execute()
    
    report['id'] = str(report['id'])
    return {"success": True, "report": report}

# ============== HEALTH CHECK ==============

@api_router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "CareGuard UAE API", "database": "Supabase"}

# ============== CORS & APP SETUP ==============

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include the router
app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
