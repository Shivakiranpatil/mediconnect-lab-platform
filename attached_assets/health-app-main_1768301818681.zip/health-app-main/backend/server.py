from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import json
import base64
import io

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'test_database')]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET_KEY', 'default-secret-key')
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24 * 7

# LLM Keys
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')

# Security
security = HTTPBearer(auto_error=False)

# Create the main app
app = FastAPI(title="CareGuard UAE - Preventive Health MVP")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============== MODELS ==============

class OTPRequest(BaseModel):
    phone: str

class OTPVerify(BaseModel):
    phone: str
    otp: str

class UserCreate(BaseModel):
    phone: Optional[str] = None
    name: Optional[str] = None
    emirate: Optional[str] = None
    dob: Optional[str] = None

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    phone: str
    name: Optional[str] = None
    emirate: Optional[str] = None
    dob: Optional[str] = None
    plan_type: Optional[str] = None
    plan_status: Optional[str] = None
    next_test_due: Optional[str] = None
    created_at: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class OTPResponse(BaseModel):
    message: str
    phone: str
    otp_sent: bool

class NotificationResponse(BaseModel):
    id: str
    title: str
    message: str
    type: str
    read: bool
    created_at: str

class BiomarkerData(BaseModel):
    name: str
    value: float
    unit: str
    reference_range: str
    status: str
    category: str

class ReportResponse(BaseModel):
    id: str
    user_id: str
    test_name: str
    test_date: str
    biomarkers: List[Dict[str, Any]]
    ai_summary: Optional[str] = None
    created_at: str

class AIInsightRequest(BaseModel):
    category: Optional[str] = "All"
    biomarkers: Optional[List[Dict[str, Any]]] = None

class AIChatRequest(BaseModel):
    question: str
    context: Optional[str] = None

class SubscriptionSelect(BaseModel):
    package_id: str

class AppointmentBook(BaseModel):
    date: str
    time: str
    address: Any  # Can be string or dict with flat, building, area, emirate
    phone: Optional[str] = None
    type: str = "home_collection"

# ============== AUTH HELPERS ==============

def create_access_token(user_id: str, phone: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRY_HOURS)
    payload = {
        "sub": user_id,
        "phone": phone,
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    payload = decode_token(credentials.credentials)
    user_id = payload.get("sub")
    
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    return user

# ============== AI HELPERS ==============

async def generate_ai_insight(prompt: str) -> str:
    """Generate AI insight using emergentintegrations"""
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
        
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"insight-{uuid.uuid4()}",
            system_message="""You are a helpful health assistant for CareGuard UAE. 
            Provide clear, actionable health insights based on biomarker data.
            IMPORTANT: Always include this disclaimer: "This is informational only and not medical advice. Consult a licensed clinician for medical decisions."
            Keep responses concise (2-3 sentences per point).
            Never diagnose or prescribe treatment."""
        ).with_model("openai", "gpt-4o-mini")
        
        user_message = UserMessage(text=prompt)
        response = await chat.send_message(user_message)
        return response
    except Exception as e:
        logger.error(f"AI generation error: {e}")
        return "Unable to generate AI insight at this time. Please try again later."

async def generate_category_insight(category: str, biomarkers: List[Dict]) -> str:
    """Generate category-specific AI insight"""
    category_prompts = {
        "Blood": f"Based on these blood test results: {json.dumps(biomarkers)}, provide a brief insight about the user's blood health focusing on hemoglobin, RBC, and related markers.",
        "Heart": f"Based on these cardiovascular markers: {json.dumps(biomarkers)}, provide insight about heart health focusing on cholesterol levels and cardiovascular risk.",
        "Vitamins": f"Based on these vitamin levels: {json.dumps(biomarkers)}, provide insight about vitamin status and recommendations for any deficiencies.",
        "Metabolic": f"Based on these metabolic markers: {json.dumps(biomarkers)}, provide insight about metabolic health including blood sugar and kidney function.",
        "All": f"Based on all these health markers: {json.dumps(biomarkers)}, provide a comprehensive health overview highlighting key findings and areas of attention."
    }
    
    prompt = category_prompts.get(category, category_prompts["All"])
    return await generate_ai_insight(prompt)

async def compare_reports(current: List[Dict], previous: List[Dict]) -> Dict:
    """Compare current and previous report biomarkers"""
    comparisons = {}
    prev_dict = {b['name']: b for b in previous}
    
    for biomarker in current:
        name = biomarker['name']
        if name in prev_dict:
            prev_value = prev_dict[name]['value']
            curr_value = biomarker['value']
            
            if curr_value > prev_value:
                trend = 'up'
                change = f"+{round(curr_value - prev_value, 2)}"
            elif curr_value < prev_value:
                trend = 'down'
                change = f"{round(curr_value - prev_value, 2)}"
            else:
                trend = 'stable'
                change = "0"
            
            comparisons[name] = {
                "trend": trend,
                "change": change,
                "previous_value": prev_value
            }
    
    return comparisons

# ============== AUTH ENDPOINTS ==============

@api_router.post("/auth/send-otp", response_model=OTPResponse)
async def send_otp(request: OTPRequest):
    """Send OTP to phone number (Mock - OTP is always 1234)"""
    phone = request.phone.strip()
    
    if not phone or len(phone) < 9:
        raise HTTPException(status_code=400, detail="Invalid phone number")
    
    otp_code = "1234"
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=10)
    
    await db.otps.update_one(
        {"phone": phone},
        {
            "$set": {
                "phone": phone,
                "otp": otp_code,
                "expires_at": expires_at.isoformat(),
                "verified": False,
                "created_at": datetime.now(timezone.utc).isoformat()
            }
        },
        upsert=True
    )
    
    logger.info(f"OTP sent to {phone}: {otp_code}")
    
    return OTPResponse(
        message="OTP sent successfully. For testing, use: 1234",
        phone=phone,
        otp_sent=True
    )

@api_router.post("/auth/verify-otp", response_model=TokenResponse)
async def verify_otp(request: OTPVerify):
    """Verify OTP and return JWT token"""
    phone = request.phone.strip()
    otp = request.otp.strip()
    
    otp_record = await db.otps.find_one({"phone": phone}, {"_id": 0})
    
    if not otp_record:
        raise HTTPException(status_code=400, detail="OTP not found. Please request a new OTP.")
    
    if otp_record.get("otp") != otp and otp != "1234":
        raise HTTPException(status_code=400, detail="Invalid OTP")
    
    expires_at = datetime.fromisoformat(otp_record["expires_at"])
    if datetime.now(timezone.utc) > expires_at:
        raise HTTPException(status_code=400, detail="OTP has expired. Please request a new OTP.")
    
    await db.otps.update_one({"phone": phone}, {"$set": {"verified": True}})
    
    existing_user = await db.users.find_one({"phone": phone}, {"_id": 0})
    
    if existing_user:
        user_data = existing_user
    else:
        # Create new user - no plan yet (must select subscription)
        user_data = {
            "id": str(uuid.uuid4()),
            "phone": phone,
            "name": None,
            "emirate": None,
            "dob": None,
            "plan_type": None,  # No plan until subscription selected
            "plan_status": None,
            "next_test_due": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "consent_given": False,
            "whatsapp_consent": False
        }
        await db.users.insert_one(user_data)
        
        # Create welcome notification
        await db.notifications.insert_one({
            "id": str(uuid.uuid4()),
            "user_id": user_data["id"],
            "title": "Welcome to CareGuard! 🎉",
            "message": "Start your health journey by selecting a plan and booking your first test.",
            "type": "welcome",
            "read": False,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        
        user_data = await db.users.find_one({"id": user_data["id"]}, {"_id": 0})
    
    token = create_access_token(user_data["id"], phone)
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(**user_data)
    )

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    """Get current authenticated user"""
    return UserResponse(**current_user)

@api_router.put("/auth/profile", response_model=UserResponse)
async def update_profile(update: UserCreate, current_user: dict = Depends(get_current_user)):
    """Update user profile"""
    update_data = {}
    if update.name:
        update_data["name"] = update.name
    if update.emirate:
        update_data["emirate"] = update.emirate
    if update.dob:
        update_data["dob"] = update.dob
    
    if update_data:
        await db.users.update_one(
            {"id": current_user["id"]},
            {"$set": update_data}
        )
    
    updated_user = await db.users.find_one({"id": current_user["id"]}, {"_id": 0})
    return UserResponse(**updated_user)

class ProfileComplete(BaseModel):
    first_name: str
    last_name: str
    age: str
    phone: str
    email: str
    family_members: Optional[List[Dict[str, Any]]] = []

@api_router.put("/auth/profile/complete")
async def complete_profile(request: ProfileComplete, current_user: dict = Depends(get_current_user)):
    """Complete user profile after subscription selection"""
    update_data = {
        "first_name": request.first_name,
        "last_name": request.last_name,
        "name": f"{request.first_name} {request.last_name}",
        "age": request.age,
        "phone": request.phone,
        "email": request.email,
        "profile_completed": True
    }
    
    if request.family_members:
        update_data["family_members"] = request.family_members
    
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$set": update_data}
    )
    
    updated_user = await db.users.find_one({"id": current_user["id"]}, {"_id": 0})
    return {"success": True, "user": updated_user}

# ============== NOTIFICATIONS ENDPOINTS ==============

@api_router.get("/notifications", response_model=List[NotificationResponse])
async def get_notifications(current_user: dict = Depends(get_current_user)):
    """Get user notifications"""
    notifications = await db.notifications.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("created_at", -1).to_list(50)
    
    # Add sample notifications if none exist
    if not notifications:
        sample_notifications = [
            {
                "id": str(uuid.uuid4()),
                "user_id": current_user["id"],
                "title": "Your report is ready! 📋",
                "message": "Your Complete Blood Count results are now available. Tap to view.",
                "type": "report",
                "read": False,
                "created_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": current_user["id"],
                "title": "Time for your next test 🗓️",
                "message": "You're due for your follow-up Vitamin D test. Book now to stay on track.",
                "type": "reminder",
                "read": False,
                "created_at": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": current_user["id"],
                "title": "Health tip of the day 💡",
                "message": "Getting 15-20 minutes of morning sunlight can help boost your Vitamin D levels naturally.",
                "type": "tip",
                "read": True,
                "created_at": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
            }
        ]
        await db.notifications.insert_many(sample_notifications)
        notifications = sample_notifications
    
    return notifications

@api_router.put("/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, current_user: dict = Depends(get_current_user)):
    """Mark notification as read"""
    await db.notifications.update_one(
        {"id": notification_id, "user_id": current_user["id"]},
        {"$set": {"read": True}}
    )
    return {"success": True}

@api_router.put("/notifications/read-all")
async def mark_all_notifications_read(current_user: dict = Depends(get_current_user)):
    """Mark all notifications as read"""
    await db.notifications.update_many(
        {"user_id": current_user["id"]},
        {"$set": {"read": True}}
    )
    return {"success": True}

# ============== REPORTS & BIOMARKERS ENDPOINTS ==============

@api_router.get("/reports")
async def get_reports(current_user: dict = Depends(get_current_user)):
    """Get user's health reports"""
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("test_date", -1).to_list(100)
    
    # Create sample report if none exist
    if not reports:
        sample_report = await create_sample_report(current_user["id"])
        reports = [sample_report]
    
    return reports

@api_router.get("/reports/{report_id}")
async def get_report(report_id: str, current_user: dict = Depends(get_current_user)):
    """Get specific report"""
    report = await db.reports.find_one(
        {"id": report_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report

@api_router.get("/biomarkers")
async def get_biomarkers(current_user: dict = Depends(get_current_user)):
    """Get user's latest biomarkers with comparison to previous"""
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("test_date", -1).to_list(2)
    
    if not reports:
        sample_report = await create_sample_report(current_user["id"])
        reports = [sample_report]
    
    current_report = reports[0]
    previous_report = reports[1] if len(reports) > 1 else None
    
    biomarkers = current_report.get("biomarkers", [])
    comparisons = {}
    
    if previous_report:
        comparisons = await compare_reports(biomarkers, previous_report.get("biomarkers", []))
    
    # Add comparison data to biomarkers
    for biomarker in biomarkers:
        name = biomarker['name']
        if name in comparisons:
            biomarker['trend'] = comparisons[name]['trend']
            biomarker['change'] = comparisons[name]['change']
            biomarker['previous_value'] = comparisons[name]['previous_value']
            biomarker['has_comparison'] = True
        else:
            biomarker['has_comparison'] = False
            biomarker['trend'] = 'stable'
            biomarker['change'] = '0'
    
    return {
        "biomarkers": biomarkers,
        "has_previous_report": previous_report is not None,
        "report_date": current_report.get("test_date"),
        "previous_report_date": previous_report.get("test_date") if previous_report else None
    }

@api_router.get("/tests-completed")
async def get_tests_completed(current_user: dict = Depends(get_current_user)):
    """Get completed tests history"""
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("test_date", -1).to_list(100)
    
    if not reports:
        sample_report = await create_sample_report(current_user["id"])
        reports = [sample_report]
    
    # Group by test category
    tests_by_category = {}
    for report in reports:
        for biomarker in report.get("biomarkers", []):
            category = biomarker.get("category", "Other")
            if category not in tests_by_category:
                tests_by_category[category] = []
            tests_by_category[category].append({
                "name": biomarker["name"],
                "value": biomarker["value"],
                "unit": biomarker["unit"],
                "status": biomarker["status"],
                "test_date": report["test_date"],
                "reference_range": biomarker.get("reference_range", "")
            })
    
    total_tests = sum(len(tests) for tests in tests_by_category.values())
    
    return {
        "total_tests": total_tests,
        "tests_by_category": tests_by_category,
        "reports": reports
    }

@api_router.get("/health-score")
async def get_health_score(current_user: dict = Depends(get_current_user)):
    """Calculate and return health score"""
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("test_date", -1).to_list(2)
    
    if not reports:
        sample_report = await create_sample_report(current_user["id"])
        reports = [sample_report]
    
    current_report = reports[0]
    biomarkers = current_report.get("biomarkers", [])
    
    # Calculate score - handle both capitalized and lowercase status values
    excellent_count = 0
    needs_care_count = 0
    critical_count = 0
    total_score = 0
    
    status_scores = {
        # Capitalized versions
        "Excellent": 100,
        "Optimal": 95,
        "Normal": 85,
        "Slightly Low": 60,
        "Slightly High": 60,
        "Low": 40,
        "High": 40,
        "Critical": 20,
        # Lowercase versions (from PDF parsing)
        "excellent": 100,
        "optimal": 95,
        "normal": 85,
        "borderline": 60,
        "slightly low": 60,
        "slightly high": 60,
        "low": 40,
        "high": 40,
        "needs_attention": 40,
        "needs attention": 40,
        "critical": 20
    }
    
    excellent_statuses = ["Excellent", "Optimal", "Normal", "excellent", "optimal", "normal"]
    borderline_statuses = ["Slightly Low", "Slightly High", "borderline", "slightly low", "slightly high"]
    
    for biomarker in biomarkers:
        status = biomarker.get("status", "Normal")
        score = status_scores.get(status, 70)
        total_score += score
        
        if status in excellent_statuses:
            excellent_count += 1
        elif status in borderline_statuses:
            needs_care_count += 1
        else:
            critical_count += 1
    
    overall_score = round(total_score / len(biomarkers)) if biomarkers else 0
    
    # Determine status
    if overall_score >= 90:
        status = "Excellent"
    elif overall_score >= 75:
        status = "Good"
    elif overall_score >= 60:
        status = "Fair"
    else:
        status = "Needs Attention"
    
    # Generate AI insights
    insights = []
    excellent_markers = [b["name"] for b in biomarkers if b.get("status") in excellent_statuses]
    attention_markers = [b["name"] for b in biomarkers if b.get("status") not in excellent_statuses]
    
    if excellent_markers:
        insights.append({
            "type": "positive",
            "text": f"Your {', '.join(excellent_markers[:3])} levels are within healthy ranges."
        })
    
    if attention_markers:
        insights.append({
            "type": "warning", 
            "text": f"{', '.join(attention_markers)} need attention. Consider lifestyle changes or consult a doctor."
        })
    
    # Score breakdown
    breakdown = []
    for biomarker in biomarkers[:5]:
        breakdown.append({
            "name": biomarker["name"],
            "description": biomarker.get("description", "Health marker"),
            "value": f"{biomarker['value']} {biomarker['unit']}",
            "range": biomarker.get("reference_range", ""),
            "score": status_scores.get(biomarker.get("status", "Normal"), 70),
            "category": biomarker.get("category", "General")
        })
    
    return {
        "score": overall_score,
        "status": status,
        "excellent_count": excellent_count,
        "needs_care_count": needs_care_count,
        "critical_count": critical_count,
        "insights": insights,
        "breakdown": breakdown,
        "total_parameters": len(biomarkers)
    }

# ============== AI ENDPOINTS ==============

@api_router.post("/ai/insights")
async def get_ai_insights(request: AIInsightRequest, current_user: dict = Depends(get_current_user)):
    """Get AI-generated health insights based on category"""
    
    # Get user's biomarkers if not provided
    if not request.biomarkers:
        reports = await db.reports.find(
            {"user_id": current_user["id"]},
            {"_id": 0}
        ).sort("test_date", -1).to_list(1)
        
        if reports:
            request.biomarkers = reports[0].get("biomarkers", [])
    
    if not request.biomarkers:
        return {"insight": "No health data available. Please complete a health test first."}
    
    # Filter by category if specified
    if request.category and request.category != "All":
        filtered = [b for b in request.biomarkers if b.get("category") == request.category]
        if filtered:
            request.biomarkers = filtered
    
    insight = await generate_category_insight(request.category or "All", request.biomarkers)
    
    return {
        "category": request.category,
        "insight": insight,
        "disclaimer": "This is informational only and not medical advice. Consult a licensed clinician for medical decisions."
    }

@api_router.post("/ai/chat")
async def ai_chat(request: AIChatRequest, current_user: dict = Depends(get_current_user)):
    """Chat with AI about health questions"""
    
    # Get user's latest biomarkers for context
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("test_date", -1).to_list(1)
    
    context = ""
    if reports:
        biomarkers = reports[0].get("biomarkers", [])
        context = f"User's latest health data: {json.dumps(biomarkers)}"
    
    prompt = f"""
    User Question: {request.question}
    
    {context}
    
    Provide a helpful, concise answer. Remember to:
    1. Be informative but not diagnostic
    2. Suggest consulting a doctor for medical decisions
    3. Keep the response under 200 words
    """
    
    response = await generate_ai_insight(prompt)
    
    return {
        "question": request.question,
        "answer": response,
        "disclaimer": "This is informational only and not medical advice. Consult a licensed clinician for medical decisions."
    }

@api_router.post("/ai/recommendation-details")
async def get_recommendation_details(request: dict, current_user: dict = Depends(get_current_user)):
    """Get detailed AI recommendation for specific health action"""
    
    topic = request.get("topic", "")
    
    prompt = f"""
    Provide detailed, actionable advice for: {topic}
    
    Include:
    1. Why this is important for health
    2. 3-4 specific steps the user can take
    3. Foods or lifestyle changes that help
    4. When to see a doctor
    
    Keep it practical and encouraging.
    """
    
    response = await generate_ai_insight(prompt)
    
    return {
        "topic": topic,
        "details": response,
        "disclaimer": "This is informational only and not medical advice. Consult a licensed clinician for medical decisions."
    }

@api_router.get("/ai/personalized-recommendations")
async def get_personalized_recommendations(current_user: dict = Depends(get_current_user)):
    """Get AI-generated personalized health recommendations based on user's actual report data"""
    from openai import OpenAI
    
    # Get user's latest report
    reports = await db.reports.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("created_at", -1).to_list(1)
    
    if not reports:
        return {
            "recommendations": [
                {
                    "icon": "calendar",
                    "iconBg": "bg-teal-400",
                    "title": "Book Your First Test",
                    "description": "Get your baseline health markers checked to receive personalized insights and recommendations."
                }
            ],
            "health_tips": [
                {"icon": "activity", "text": "Stay active with 30 minutes of daily exercise", "color": "text-teal-400"},
                {"icon": "utensils", "text": "Maintain a balanced diet rich in vegetables", "color": "text-emerald-400"},
                {"icon": "moon", "text": "Get 7-8 hours of quality sleep each night", "color": "text-indigo-400"}
            ],
            "ai_summary": "Welcome! Book your first health test to get personalized AI-powered insights based on your biomarkers.",
            "generated_for": current_user.get("name", "User")
        }
    
    report = reports[0]
    biomarkers = report.get("biomarkers", [])
    summary = report.get("summary", "")
    
    # Identify biomarkers that need attention
    attention_markers = [b for b in biomarkers if b.get("status", "").lower() in ["borderline", "needs_attention", "high", "low"]]
    normal_markers = [b for b in biomarkers if b.get("status", "").lower() in ["normal", "excellent", "optimal"]]
    
    # Build biomarker summary for AI
    biomarker_text = "\n".join([
        f"- {b['name']}: {b['value']} {b.get('unit', '')} (Status: {b.get('status', 'unknown')}, Reference: {b.get('reference_range', 'N/A')})"
        for b in biomarkers
    ])
    
    if not OPENAI_API_KEY:
        # Fallback to rule-based recommendations if no OpenAI key
        return generate_fallback_recommendations(biomarkers, current_user.get("name"))
    
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        prompt = f"""Based on this user's actual lab report data, generate personalized health recommendations.

User: {current_user.get('name', 'User')}
Report Summary: {summary}

Biomarkers:
{biomarker_text}

Generate a JSON response with:
1. "recommendations": Array of 4 specific, actionable recommendations based on THEIR data. Each should have:
   - "icon": one of ["sun", "heart", "pill", "calendar", "activity", "droplet", "utensils", "moon"]
   - "iconBg": tailwind color class like "bg-amber-400", "bg-rose-400", etc.
   - "title": short title (3-5 words)
   - "description": detailed actionable advice (2-3 sentences)

2. "health_tips": Array of 3 quick tips relevant to their specific results. Each with:
   - "icon": one of ["sun", "egg", "dumbbell", "droplet", "heart", "utensils"]
   - "text": one-line tip
   - "color": tailwind text color like "text-amber-400"

3. "ai_summary": A 2-3 sentence personalized summary of their health status and key action items.

Focus on:
- Biomarkers that are borderline or need attention
- Practical lifestyle and dietary changes
- When to follow up with a doctor
- Positive reinforcement for normal markers

Be specific to their actual values, not generic advice."""

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a health advisor AI. Generate personalized recommendations based on lab results. Always return valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.7
        )
        
        result = json.loads(response.choices[0].message.content)
        result["generated_for"] = current_user.get("name", "User")
        result["report_date"] = report.get("created_at", "")
        
        return result
        
    except Exception as e:
        logger.error(f"OpenAI recommendation error: {e}")
        return generate_fallback_recommendations(biomarkers, current_user.get("name"))

def generate_fallback_recommendations(biomarkers: list, user_name: str) -> dict:
    """Generate rule-based recommendations when OpenAI is unavailable"""
    recommendations = []
    health_tips = []
    
    for b in biomarkers:
        name_lower = b.get("name", "").lower()
        status_lower = b.get("status", "").lower()
        
        if status_lower in ["borderline", "needs_attention", "high", "low"]:
            if "cholesterol" in name_lower:
                recommendations.append({
                    "icon": "heart",
                    "iconBg": "bg-rose-400",
                    "title": "Manage Cholesterol",
                    "description": f"Your {b['name']} is {b['value']} {b.get('unit', '')}. Consider reducing saturated fats, increasing fiber intake, and regular cardio exercise."
                })
                health_tips.append({"icon": "utensils", "text": "Include more oats, nuts, and olive oil in your diet", "color": "text-rose-400"})
            elif "glucose" in name_lower or "sugar" in name_lower or "hba1c" in name_lower:
                recommendations.append({
                    "icon": "activity",
                    "iconBg": "bg-cyan-400",
                    "title": "Monitor Blood Sugar",
                    "description": f"Your {b['name']} at {b['value']} {b.get('unit', '')} needs attention. Limit refined carbs and sugary foods, increase physical activity."
                })
                health_tips.append({"icon": "dumbbell", "text": "30 minutes of walking after meals helps regulate blood sugar", "color": "text-cyan-400"})
            elif "vitamin d" in name_lower:
                recommendations.append({
                    "icon": "sun",
                    "iconBg": "bg-amber-400",
                    "title": "Boost Vitamin D",
                    "description": f"Your Vitamin D is {b['value']} {b.get('unit', '')}. Get 15-20 minutes of morning sunlight and consider supplements after consulting your doctor."
                })
                health_tips.append({"icon": "sun", "text": "Morning sunlight is the best natural source of Vitamin D", "color": "text-amber-400"})
            elif "iron" in name_lower or "hemoglobin" in name_lower:
                recommendations.append({
                    "icon": "droplet",
                    "iconBg": "bg-red-400",
                    "title": "Improve Iron Levels",
                    "description": f"Your {b['name']} at {b['value']} {b.get('unit', '')} could be better. Include iron-rich foods like spinach, lentils, and lean red meat."
                })
                health_tips.append({"icon": "egg", "text": "Pair iron-rich foods with Vitamin C for better absorption", "color": "text-red-400"})
    
    # Add general recommendations if we don't have enough specific ones
    if len(recommendations) < 4:
        recommendations.append({
            "icon": "calendar",
            "iconBg": "bg-teal-400",
            "title": "Schedule Follow-up",
            "description": "Book a follow-up test in 3 months to track your progress and ensure your health markers are improving."
        })
    
    if len(health_tips) < 3:
        health_tips.extend([
            {"icon": "moon", "text": "Aim for 7-8 hours of quality sleep each night", "color": "text-indigo-400"},
            {"icon": "droplet", "text": "Stay hydrated with 8 glasses of water daily", "color": "text-blue-400"}
        ])
    
    # Build AI summary
    attention_count = len([b for b in biomarkers if b.get("status", "").lower() in ["borderline", "needs_attention"]])
    normal_count = len([b for b in biomarkers if b.get("status", "").lower() in ["normal", "excellent", "optimal"]])
    
    ai_summary = f"Hi {user_name}! "
    if attention_count > 0:
        ai_summary += f"You have {attention_count} biomarker(s) that need attention. "
    if normal_count > 0:
        ai_summary += f"Great news - {normal_count} of your markers are in the healthy range! "
    ai_summary += "Focus on the recommendations below for optimal health."
    
    return {
        "recommendations": recommendations[:4],
        "health_tips": health_tips[:3],
        "ai_summary": ai_summary,
        "generated_for": user_name
    }

# ============== HELPER FUNCTIONS ==============

async def create_sample_report(user_id: str) -> dict:
    """Create a sample report for demo purposes"""
    sample_report = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "test_name": "Preventive Plus Package",
        "test_date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "biomarkers": [
            {"name": "Hemoglobin", "value": 14.2, "unit": "g/dL", "reference_range": "12.5 - 17.5", "status": "Excellent", "category": "Blood", "description": "Oxygen-carrying protein in blood"},
            {"name": "Red Blood Cell", "value": 5.2, "unit": "M/µL", "reference_range": "4.5 - 5.5", "status": "Normal", "category": "Blood", "description": "Oxygen transport cells"},
            {"name": "White Blood Cell", "value": 7.8, "unit": "K/µL", "reference_range": "4.5 - 11.0", "status": "Normal", "category": "Blood", "description": "Immune system cells"},
            {"name": "Platelet Count", "value": 250, "unit": "K/µL", "reference_range": "150 - 400", "status": "Normal", "category": "Blood", "description": "Blood clotting cells"},
            {"name": "Vitamin D", "value": 28, "unit": "ng/mL", "reference_range": "30 - 100", "status": "Slightly Low", "category": "Vitamins", "description": "Bone health & immunity"},
            {"name": "Vitamin B12", "value": 450, "unit": "pg/mL", "reference_range": "200 - 900", "status": "Normal", "category": "Vitamins", "description": "Nerve & blood cell health"},
            {"name": "Folate", "value": 12, "unit": "ng/mL", "reference_range": "3 - 20", "status": "Normal", "category": "Vitamins", "description": "Cell growth vitamin"},
            {"name": "Total Cholesterol", "value": 185, "unit": "mg/dL", "reference_range": "< 200", "status": "Excellent", "category": "Heart", "description": "Cardiovascular marker"},
            {"name": "HDL Cholesterol", "value": 58, "unit": "mg/dL", "reference_range": "> 40", "status": "Optimal", "category": "Heart", "description": "Good cholesterol"},
            {"name": "LDL Cholesterol", "value": 105, "unit": "mg/dL", "reference_range": "< 130", "status": "Normal", "category": "Heart", "description": "Bad cholesterol"},
            {"name": "Triglycerides", "value": 110, "unit": "mg/dL", "reference_range": "< 150", "status": "Normal", "category": "Heart", "description": "Blood fat level"},
            {"name": "Blood Sugar", "value": 95, "unit": "mg/dL", "reference_range": "70 - 100", "status": "Normal", "category": "Metabolic", "description": "Glucose metabolism"},
            {"name": "Creatinine", "value": 1.0, "unit": "mg/dL", "reference_range": "0.7 - 1.3", "status": "Normal", "category": "Metabolic", "description": "Kidney function marker"},
            {"name": "TSH", "value": 2.5, "unit": "mIU/L", "reference_range": "0.4 - 4.0", "status": "Normal", "category": "Metabolic", "description": "Thyroid function"}
        ],
        "ai_summary": "Overall health profile is excellent. Most markers are within optimal ranges. Vitamin D levels are slightly below optimal - consider increasing sun exposure and dietary intake.",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.reports.insert_one(sample_report)
    return sample_report

# ============== SUBSCRIPTION ENDPOINTS ==============

@api_router.post("/subscription/select")
async def select_subscription(request: SubscriptionSelect, current_user: dict = Depends(get_current_user)):
    """Select a subscription package"""
    package_prices = {
        "individual-starter": {"price": 99, "tests": 1, "duration": 30},
        "preventive-starter": {"price": 449, "tests": 2, "duration": 180},
        "preventive-plus": {"price": 649, "tests": 3, "duration": 365},
        "elderly-care": {"price": 849, "tests": 4, "duration": 365},
        "family-of-2": {"price": 199, "tests": 2, "duration": 30},
        "family-of-3": {"price": 299, "tests": 3, "duration": 30},
        "family-of-4": {"price": 399, "tests": 4, "duration": 30},
    }
    
    package = package_prices.get(request.package_id)
    if not package:
        raise HTTPException(status_code=400, detail="Invalid package")
    
    subscription = {
        "id": str(uuid.uuid4()),
        "user_id": current_user["id"],
        "package_id": request.package_id,
        "price": package["price"],
        "tests_included": package["tests"],
        "tests_remaining": package["tests"],
        "duration_days": package["duration"],
        "status": "active",
        "start_date": datetime.now(timezone.utc).isoformat(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.subscriptions.insert_one(subscription)
    
    # Update user's plan
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$set": {
            "plan_type": request.package_id,
            "plan_status": "active"
        }}
    )
    
    return {"success": True, "subscription_id": subscription["id"]}

@api_router.get("/subscription/current")
async def get_current_subscription(current_user: dict = Depends(get_current_user)):
    """Get user's current subscription"""
    subscription = await db.subscriptions.find_one(
        {"user_id": current_user["id"], "status": "active"},
        {"_id": 0}
    )
    return subscription or {}

# ============== APPOINTMENT ENDPOINTS ==============

@api_router.post("/appointments/book")
async def book_appointment(request: AppointmentBook, current_user: dict = Depends(get_current_user)):
    """Book a test appointment"""
    appointment_id = str(uuid.uuid4())
    
    # Get user's emirate from address or profile
    user_emirate = "Dubai"  # Default
    user_area = None
    
    if isinstance(request.address, dict):
        user_emirate = request.address.get("emirate", "Dubai")
        user_area = request.address.get("area")
    elif current_user.get("emirate"):
        user_emirate = current_user.get("emirate")
    
    appointment = {
        "id": appointment_id,
        "user_id": current_user["id"],
        "date": request.date,
        "time": request.time,
        "address": request.address,
        "phone": request.phone or current_user.get("phone"),
        "type": request.type,
        "status": "booked",  # booked, confirmed, sample_collected, report_ready
        "lab_phone": "+971501234567",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Auto-assign lab based on user's location
    assigned_lab = await find_nearest_lab(user_emirate, user_area)
    if assigned_lab:
        appointment["assigned_lab_id"] = assigned_lab["id"]
        appointment["assigned_lab_name"] = assigned_lab["name"]
        appointment["assignment_type"] = "auto"
        appointment["assigned_at"] = datetime.now(timezone.utc).isoformat()
        
        # Increment lab load
        await db.partner_labs.update_one(
            {"id": assigned_lab["id"]},
            {"$inc": {"current_load": 1}}
        )
    
    await db.appointments.insert_one(appointment)
    
    # Create notification
    await db.notifications.insert_one({
        "id": str(uuid.uuid4()),
        "user_id": current_user["id"],
        "title": "Booking Confirmed! 📅",
        "message": f"Your test is scheduled for {request.date} at {request.time}. We'll collect the sample at your location.",
        "type": "booking",
        "read": False,
        "created_at": datetime.now(timezone.utc).isoformat()
    })
    
    return {"success": True, "appointment_id": appointment["id"], "assigned_lab": assigned_lab.get("name") if assigned_lab else None}

@api_router.get("/appointments/current")
async def get_current_appointment(current_user: dict = Depends(get_current_user)):
    """Get user's current/latest appointment"""
    appointment = await db.appointments.find_one(
        {"user_id": current_user["id"]},
        {"_id": 0},
        sort=[("created_at", -1)]
    )
    
    if appointment:
        # Format date nicely
        try:
            date_obj = datetime.fromisoformat(appointment["date"])
            appointment["date_formatted"] = date_obj.strftime("%B %d, %Y")
        except:
            pass
    
    return appointment or {}

@api_router.get("/appointments/all")
async def get_all_user_appointments(current_user: dict = Depends(get_current_user)):
    """Get all user appointments with status"""
    appointments = await db.appointments.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("date", -1).to_list(100)
    
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    
    upcoming = []
    past = []
    
    for apt in appointments:
        apt_date = apt.get("date", "")
        if apt_date >= today and apt.get("status") not in ["completed", "cancelled"]:
            upcoming.append(apt)
        else:
            past.append(apt)
    
    return {
        "upcoming": upcoming,
        "past": past,
        "total": len(appointments)
    }

@api_router.get("/appointments/{appointment_id}")
async def get_appointment_by_id(appointment_id: str, current_user: dict = Depends(get_current_user)):
    """Get specific appointment details"""
    appointment = await db.appointments.find_one(
        {"id": appointment_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    # Get assigned lab info
    if appointment.get("assigned_lab_id"):
        lab = await db.partner_labs.find_one({"id": appointment["assigned_lab_id"]}, {"_id": 0, "name": 1, "phone": 1, "address": 1})
        if lab:
            appointment["lab"] = lab
    
    return {"appointment": appointment}

@api_router.put("/appointments/{appointment_id}/status")
async def update_appointment_status(appointment_id: str, status: str, current_user: dict = Depends(get_current_user)):
    """Update appointment status (for admin use)"""
    await db.appointments.update_one(
        {"id": appointment_id},
        {"$set": {"status": status}}
    )
    return {"success": True}

@api_router.get("/user/has-reports")
async def check_user_has_reports(current_user: dict = Depends(get_current_user)):
    """Check if user has any reports uploaded"""
    report_count = await db.reports.count_documents({"user_id": current_user["id"]})
    appointment = await db.appointments.find_one(
        {"user_id": current_user["id"]},
        {"_id": 0}
    )
    
    return {
        "has_reports": report_count > 0,
        "report_count": report_count,
        "has_appointment": appointment is not None,
        "appointment_status": appointment.get("status") if appointment else None
    }

# ============== ADMIN MODELS ==============

class AdminLogin(BaseModel):
    email: str
    password: str

class PartnerLab(BaseModel):
    name: str
    contact_person: str
    email: str
    phone: str
    address: str
    emirate: str = "Dubai"
    area: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    capacity_per_day: int = 50
    current_load: int = 0
    status: str = "active"

class SubscriptionPlan(BaseModel):
    name: str
    plan_type: str  # individual, family
    price: float
    duration_months: int
    num_tests: int
    features: List[str]
    description: Optional[str] = None
    badge: Optional[str] = None  # "most_popular", "recommended"
    status: str = "active"

class TestType(BaseModel):
    name: str
    category: str
    description: Optional[str] = None
    biomarkers: List[str] = []
    price: float
    status: str = "active"

class APISettings(BaseModel):
    provider: str
    api_key: Optional[str] = None
    enabled: bool = False
    config: Optional[Dict[str, Any]] = {}

class AdminUserCreate(BaseModel):
    phone: str
    name: str
    email: Optional[str] = None
    age: Optional[str] = None
    emirate: str = "Dubai"
    plan_type: Optional[str] = None
    family_members: Optional[List[Dict[str, Any]]] = []

# ============== ADMIN AUTH ==============

ADMIN_CREDENTIALS = {
    "email": "admin@healthapp.com",
    "password": "admin123"
}

def create_admin_token(email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=24)
    payload = {
        "sub": email,
        "role": "admin",
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_admin_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Admin authentication required")
    
    payload = decode_token(credentials.credentials)
    if payload.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    return payload

@api_router.post("/admin/login")
async def admin_login(request: AdminLogin):
    """Admin login endpoint"""
    if request.email == ADMIN_CREDENTIALS["email"] and request.password == ADMIN_CREDENTIALS["password"]:
        token = create_admin_token(request.email)
        return {
            "access_token": token,
            "token_type": "bearer",
            "admin": {"email": request.email, "role": "admin"}
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

@api_router.get("/admin/verify")
async def verify_admin(admin: dict = Depends(get_admin_user)):
    """Verify admin token"""
    return {"valid": True, "email": admin.get("sub")}

# ============== ADMIN USER MANAGEMENT ==============

@api_router.get("/admin/users")
async def get_all_users(
    search: Optional[str] = None,
    plan_type: Optional[str] = None,
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 20,
    admin: dict = Depends(get_admin_user)
):
    """Get all users with filters"""
    query = {}
    if search:
        query["$or"] = [
            {"phone": {"$regex": search, "$options": "i"}},
            {"name": {"$regex": search, "$options": "i"}},
            {"email": {"$regex": search, "$options": "i"}}
        ]
    if plan_type:
        query["plan_type"] = plan_type
    if status:
        query["plan_status"] = status
    
    skip = (page - 1) * limit
    total = await db.users.count_documents(query)
    users = await db.users.find(query, {"_id": 0}).skip(skip).limit(limit).to_list(limit)
    
    return {
        "users": users,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit
    }

@api_router.get("/admin/users/{phone}")
async def get_user_by_phone(phone: str, admin: dict = Depends(get_admin_user)):
    """Get user by phone number with family details"""
    user = await db.users.find_one({"phone": phone}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get user appointments
    appointments = await db.appointments.find({"user_id": user["id"]}, {"_id": 0}).to_list(100)
    # Get user reports
    reports = await db.reports.find({"user_id": user["id"]}, {"_id": 0}).to_list(100)
    
    return {
        "user": user,
        "appointments": appointments,
        "reports": reports
    }

@api_router.post("/admin/users")
async def create_user_admin(request: AdminUserCreate, admin: dict = Depends(get_admin_user)):
    """Create a new user (admin)"""
    existing = await db.users.find_one({"phone": request.phone})
    if existing:
        raise HTTPException(status_code=400, detail="User with this phone already exists")
    
    user_id = str(uuid.uuid4())
    user_data = {
        "id": user_id,
        "phone": request.phone,
        "name": request.name,
        "email": request.email,
        "age": request.age,
        "emirate": request.emirate,
        "plan_type": request.plan_type,
        "plan_status": "active" if request.plan_type else None,
        "family_members": request.family_members or [],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "created_by": "admin"
    }
    
    await db.users.insert_one(user_data)
    return {"success": True, "user_id": user_id, "user": {k: v for k, v in user_data.items() if k != "_id"}}

@api_router.put("/admin/users/{user_id}")
async def update_user_admin(user_id: str, request: AdminUserCreate, admin: dict = Depends(get_admin_user)):
    """Update user details (admin)"""
    update_data = {
        "name": request.name,
        "email": request.email,
        "age": request.age,
        "emirate": request.emirate,
        "plan_type": request.plan_type,
        "family_members": request.family_members or [],
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    result = await db.users.update_one({"id": user_id}, {"$set": update_data})
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    updated_user = await db.users.find_one({"id": user_id}, {"_id": 0})
    return {"success": True, "user": updated_user}

@api_router.delete("/admin/users/{user_id}")
async def delete_user_admin(user_id: str, admin: dict = Depends(get_admin_user)):
    """Delete user (admin)"""
    result = await db.users.delete_one({"id": user_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"success": True}

# ============== ADMIN PARTNER LABS ==============

@api_router.get("/admin/labs")
async def get_all_labs(admin: dict = Depends(get_admin_user)):
    """Get all partner labs"""
    labs = await db.partner_labs.find({}, {"_id": 0}).to_list(100)
    return {"labs": labs}

@api_router.post("/admin/labs")
async def create_lab(request: PartnerLab, admin: dict = Depends(get_admin_user)):
    """Create partner lab"""
    lab_data = {
        "id": str(uuid.uuid4()),
        **request.model_dump(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.partner_labs.insert_one(lab_data)
    return {"success": True, "lab": {k: v for k, v in lab_data.items() if k != "_id"}}

@api_router.put("/admin/labs/{lab_id}")
async def update_lab(lab_id: str, request: PartnerLab, admin: dict = Depends(get_admin_user)):
    """Update partner lab"""
    update_data = {**request.model_dump(), "updated_at": datetime.now(timezone.utc).isoformat()}
    result = await db.partner_labs.update_one({"id": lab_id}, {"$set": update_data})
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Lab not found")
    return {"success": True}

@api_router.delete("/admin/labs/{lab_id}")
async def delete_lab(lab_id: str, admin: dict = Depends(get_admin_user)):
    """Delete partner lab"""
    result = await db.partner_labs.delete_one({"id": lab_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Lab not found")
    return {"success": True}

# ============== LAB ASSIGNMENT LOGIC ==============

class LabAssignment(BaseModel):
    user_id: Optional[str] = None
    appointment_id: Optional[str] = None
    lab_id: str
    reason: Optional[str] = "manual_assignment"
    priority: str = "normal"  # normal, urgent, emergency

async def find_nearest_lab(emirate: str, area: Optional[str] = None) -> Optional[Dict]:
    """Find the nearest available lab based on user location"""
    # First try to find lab in the same emirate
    query = {"status": "active", "emirate": emirate}
    labs = await db.partner_labs.find(query, {"_id": 0}).to_list(100)
    
    if not labs:
        # Fallback to any active lab
        labs = await db.partner_labs.find({"status": "active"}, {"_id": 0}).to_list(100)
    
    if not labs:
        return None
    
    # Sort by current load (least busy first)
    labs_sorted = sorted(labs, key=lambda x: x.get("current_load", 0) / max(x.get("capacity_per_day", 50), 1))
    
    # If area is provided, prioritize labs in the same area
    if area:
        area_labs = [l for l in labs_sorted if l.get("area", "").lower() == area.lower()]
        if area_labs:
            return area_labs[0]
    
    return labs_sorted[0] if labs_sorted else None

async def auto_assign_lab(user_id: str, appointment_id: str) -> Optional[Dict]:
    """Automatically assign a lab to an appointment based on user location"""
    # Get user details
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        return None
    
    emirate = user.get("emirate", "Dubai")
    area = user.get("area")
    
    # Find nearest lab
    lab = await find_nearest_lab(emirate, area)
    if not lab:
        return None
    
    # Update appointment with assigned lab
    await db.appointments.update_one(
        {"id": appointment_id},
        {"$set": {
            "assigned_lab_id": lab["id"],
            "assigned_lab_name": lab["name"],
            "assignment_type": "auto",
            "assigned_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    # Increment lab load
    await db.partner_labs.update_one(
        {"id": lab["id"]},
        {"$inc": {"current_load": 1}}
    )
    
    return lab

@api_router.post("/admin/labs/assign")
async def manual_assign_lab(request: LabAssignment, admin: dict = Depends(get_admin_user)):
    """Manually assign a lab to a user or appointment (for emergencies)"""
    lab = await db.partner_labs.find_one({"id": request.lab_id}, {"_id": 0})
    if not lab:
        raise HTTPException(status_code=404, detail="Lab not found")
    
    update_data = {
        "assigned_lab_id": request.lab_id,
        "assigned_lab_name": lab["name"],
        "assignment_type": "manual",
        "assignment_reason": request.reason,
        "assignment_priority": request.priority,
        "assigned_at": datetime.now(timezone.utc).isoformat(),
        "assigned_by": admin.get("sub")
    }
    
    result = None
    if request.appointment_id:
        # Assign to specific appointment
        result = await db.appointments.update_one(
            {"id": request.appointment_id},
            {"$set": update_data}
        )
    elif request.user_id:
        # Assign to user's latest pending appointment
        appointment = await db.appointments.find_one(
            {"user_id": request.user_id, "status": "pending"},
            sort=[("created_at", -1)]
        )
        if appointment:
            result = await db.appointments.update_one(
                {"id": appointment["id"]},
                {"$set": update_data}
            )
        else:
            # If no pending appointment, store as user's preferred lab
            await db.users.update_one(
                {"id": request.user_id},
                {"$set": {"preferred_lab_id": request.lab_id, "preferred_lab_name": lab["name"]}}
            )
            return {"success": True, "message": "Lab set as user's preferred lab"}
    
    if result and result.modified_count > 0:
        # Increment lab load
        await db.partner_labs.update_one(
            {"id": request.lab_id},
            {"$inc": {"current_load": 1}}
        )
        return {"success": True, "lab": lab}
    
    raise HTTPException(status_code=400, detail="Failed to assign lab")

@api_router.get("/admin/labs/assignments")
async def get_lab_assignments(
    lab_id: Optional[str] = None,
    status: Optional[str] = None,
    admin: dict = Depends(get_admin_user)
):
    """Get all lab assignments"""
    query = {"assigned_lab_id": {"$exists": True}}
    if lab_id:
        query["assigned_lab_id"] = lab_id
    if status:
        query["status"] = status
    
    appointments = await db.appointments.find(query, {"_id": 0}).to_list(100)
    
    # Enrich with user details
    for apt in appointments:
        user = await db.users.find_one({"id": apt.get("user_id")}, {"_id": 0, "name": 1, "phone": 1, "emirate": 1})
        if user:
            apt["user_name"] = user.get("name")
            apt["user_phone"] = user.get("phone")
            apt["user_emirate"] = user.get("emirate")
    
    return {"assignments": appointments}

@api_router.put("/admin/labs/{lab_id}/reassign/{appointment_id}")
async def reassign_lab(
    lab_id: str, 
    appointment_id: str, 
    reason: str = "reassignment",
    admin: dict = Depends(get_admin_user)
):
    """Reassign an appointment to a different lab"""
    # Get old assignment
    appointment = await db.appointments.find_one({"id": appointment_id})
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    old_lab_id = appointment.get("assigned_lab_id")
    
    # Get new lab
    new_lab = await db.partner_labs.find_one({"id": lab_id}, {"_id": 0})
    if not new_lab:
        raise HTTPException(status_code=404, detail="Lab not found")
    
    # Update appointment
    await db.appointments.update_one(
        {"id": appointment_id},
        {"$set": {
            "assigned_lab_id": lab_id,
            "assigned_lab_name": new_lab["name"],
            "assignment_type": "reassigned",
            "reassignment_reason": reason,
            "reassigned_at": datetime.now(timezone.utc).isoformat(),
            "reassigned_by": admin.get("sub"),
            "previous_lab_id": old_lab_id
        }}
    )
    
    # Update lab loads
    if old_lab_id:
        await db.partner_labs.update_one({"id": old_lab_id}, {"$inc": {"current_load": -1}})
    await db.partner_labs.update_one({"id": lab_id}, {"$inc": {"current_load": 1}})
    
    return {"success": True, "new_lab": new_lab}

@api_router.get("/admin/labs/{lab_id}/stats")
async def get_lab_stats(lab_id: str, admin: dict = Depends(get_admin_user)):
    """Get statistics for a specific lab"""
    lab = await db.partner_labs.find_one({"id": lab_id}, {"_id": 0})
    if not lab:
        raise HTTPException(status_code=404, detail="Lab not found")
    
    # Count assignments
    total_assignments = await db.appointments.count_documents({"assigned_lab_id": lab_id})
    pending_assignments = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "pending"})
    completed_assignments = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "completed"})
    
    return {
        "lab": lab,
        "stats": {
            "total_assignments": total_assignments,
            "pending": pending_assignments,
            "completed": completed_assignments,
            "capacity_used": f"{(lab.get('current_load', 0) / max(lab.get('capacity_per_day', 50), 1)) * 100:.1f}%"
        }
    }

@api_router.get("/labs/nearest")
async def get_nearest_lab(emirate: str, area: Optional[str] = None):
    """Public endpoint to find nearest lab (for booking flow)"""
    lab = await find_nearest_lab(emirate, area)
    if not lab:
        return {"lab": None, "message": "No labs available in your area"}
    return {"lab": lab}

# ============== LAB PARTNER DASHBOARD ==============

class LabLogin(BaseModel):
    email: str
    password: str

class StatusUpdate(BaseModel):
    status: str  # pending, confirmed, sample_collected, processing, report_ready, completed
    notes: Optional[str] = None

class ReportUpload(BaseModel):
    appointment_id: str
    summary: str
    biomarkers: List[Dict[str, Any]]
    recommendations: Optional[List[str]] = []
    notes: Optional[str] = None
    member_type: Optional[str] = "primary"  # primary or family
    member_id: Optional[str] = None
    member_name: Optional[str] = None

def create_lab_token(lab_id: str, lab_name: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=12)
    payload = {
        "sub": lab_id,
        "name": lab_name,
        "role": "lab_partner",
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_lab_partner(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Lab authentication required")
    
    payload = decode_token(credentials.credentials)
    if payload.get("role") != "lab_partner":
        raise HTTPException(status_code=403, detail="Lab partner access required")
    
    return payload

@api_router.post("/lab/login")
async def lab_login(request: LabLogin):
    """Lab partner login - uses email from lab record"""
    lab = await db.partner_labs.find_one({"email": request.email, "status": "active"}, {"_id": 0})
    if not lab:
        raise HTTPException(status_code=401, detail="Invalid credentials or lab inactive")
    
    # Simple password: lab phone number (last 6 digits) or "lab123" for demo
    expected_password = lab.get("phone", "")[-6:] or "lab123"
    if request.password != expected_password and request.password != "lab123":
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_lab_token(lab["id"], lab["name"])
    return {
        "access_token": token,
        "token_type": "bearer",
        "lab": {
            "id": lab["id"],
            "name": lab["name"],
            "emirate": lab.get("emirate"),
            "area": lab.get("area")
        }
    }

@api_router.get("/lab/verify")
async def verify_lab(lab: dict = Depends(get_lab_partner)):
    """Verify lab token"""
    return {"valid": True, "lab_id": lab.get("sub"), "lab_name": lab.get("name")}

@api_router.get("/lab/dashboard")
async def get_lab_dashboard(lab: dict = Depends(get_lab_partner)):
    """Get lab dashboard summary"""
    lab_id = lab.get("sub")
    
    # Get today's date
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    
    # Counts by status - include "booked" in pending
    total = await db.appointments.count_documents({"assigned_lab_id": lab_id})
    pending = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": {"$in": ["pending", "booked"]}})
    confirmed = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "confirmed"})
    sample_collected = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "sample_collected"})
    processing = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "processing"})
    report_ready = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "report_ready"})
    completed = await db.appointments.count_documents({"assigned_lab_id": lab_id, "status": "completed"})
    
    # Today's appointments
    todays_appointments = await db.appointments.count_documents({
        "assigned_lab_id": lab_id,
        "date": today
    })
    
    # Upcoming appointments (future dates)
    upcoming = await db.appointments.count_documents({
        "assigned_lab_id": lab_id,
        "date": {"$gt": today},
        "status": {"$in": ["pending", "booked", "confirmed"]}
    })
    
    return {
        "stats": {
            "total": total,
            "pending": pending,
            "confirmed": confirmed,
            "sample_collected": sample_collected,
            "processing": processing,
            "report_ready": report_ready,
            "completed": completed,
            "today": todays_appointments,
            "upcoming": upcoming
        }
    }

@api_router.get("/lab/appointments")
async def get_lab_appointments(
    status: Optional[str] = None,
    date: Optional[str] = None,
    lab: dict = Depends(get_lab_partner)
):
    """Get appointments assigned to this lab"""
    lab_id = lab.get("sub")
    
    query = {"assigned_lab_id": lab_id}
    if status:
        query["status"] = status
    if date:
        query["date"] = date
    
    appointments = await db.appointments.find(query, {"_id": 0}).sort("date", 1).to_list(100)
    
    # Enrich with user details
    for apt in appointments:
        user = await db.users.find_one({"id": apt.get("user_id")}, {"_id": 0})
        if user:
            apt["user"] = {
                "name": user.get("name", "Unknown"),
                "phone": user.get("phone"),
                "email": user.get("email"),
                "age": user.get("age"),
                "emirate": user.get("emirate"),
                "plan_type": user.get("plan_type"),
                "family_members": user.get("family_members", [])
            }
    
    return {"appointments": appointments}

@api_router.get("/lab/appointments/{appointment_id}")
async def get_appointment_details(appointment_id: str, lab: dict = Depends(get_lab_partner)):
    """Get single appointment details"""
    lab_id = lab.get("sub")
    
    appointment = await db.appointments.find_one({
        "id": appointment_id,
        "assigned_lab_id": lab_id
    }, {"_id": 0})
    
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    # Get user details
    user = await db.users.find_one({"id": appointment.get("user_id")}, {"_id": 0})
    if user:
        appointment["user"] = {
            "name": user.get("name"),
            "phone": user.get("phone"),
            "email": user.get("email"),
            "age": user.get("age"),
            "emirate": user.get("emirate"),
            "area": user.get("area"),
            "plan_type": user.get("plan_type"),
            "family_members": user.get("family_members", [])
        }
    
    # Get existing report if any
    report = await db.reports.find_one({"appointment_id": appointment_id}, {"_id": 0})
    if report:
        appointment["report"] = report
    
    return {"appointment": appointment}

@api_router.put("/lab/appointments/{appointment_id}/status")
async def update_appointment_status(
    appointment_id: str,
    request: StatusUpdate,
    lab: dict = Depends(get_lab_partner)
):
    """Update appointment status"""
    lab_id = lab.get("sub")
    
    valid_statuses = ["pending", "confirmed", "sample_collected", "processing", "report_ready", "completed"]
    if request.status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
    
    update_data = {
        "status": request.status,
        "status_updated_at": datetime.now(timezone.utc).isoformat(),
        "status_updated_by": lab.get("name")
    }
    
    if request.notes:
        update_data["lab_notes"] = request.notes
    
    # Add status history
    status_entry = {
        "status": request.status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "by": lab.get("name"),
        "notes": request.notes
    }
    
    result = await db.appointments.update_one(
        {"id": appointment_id, "assigned_lab_id": lab_id},
        {
            "$set": update_data,
            "$push": {"status_history": status_entry}
        }
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    # Create notification for user
    appointment = await db.appointments.find_one({"id": appointment_id})
    if appointment:
        notification_messages = {
            "confirmed": "Your appointment has been confirmed by the lab.",
            "sample_collected": "Your sample has been collected successfully.",
            "processing": "Your sample is being processed at the lab.",
            "report_ready": "Your health report is ready! Check the Reports section.",
            "completed": "Your health checkup is complete. View your report now."
        }
        
        if request.status in notification_messages:
            await db.notifications.insert_one({
                "id": str(uuid.uuid4()),
                "user_id": appointment.get("user_id"),
                "type": "status_update",
                "title": f"Appointment Update: {request.status.replace('_', ' ').title()}",
                "message": notification_messages[request.status],
                "read": False,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
    
    return {"success": True, "status": request.status}

@api_router.post("/lab/appointments/{appointment_id}/report")
async def upload_report(
    appointment_id: str,
    request: ReportUpload,
    lab: dict = Depends(get_lab_partner)
):
    """Upload health report for an appointment"""
    lab_id = lab.get("sub")
    
    # Verify appointment belongs to this lab
    appointment = await db.appointments.find_one({
        "id": appointment_id,
        "assigned_lab_id": lab_id
    })
    
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    user_id = appointment.get("user_id")
    
    # Calculate health score from biomarkers
    total_score = 0
    marker_count = 0
    for marker in request.biomarkers:
        status = marker.get("status", "").lower()
        if status == "normal":
            total_score += 100
        elif status == "borderline":
            total_score += 70
        else:  # needs_attention or abnormal
            total_score += 40
        marker_count += 1
    
    health_score = round(total_score / marker_count) if marker_count > 0 else 75
    
    # Create report
    report_data = {
        "id": str(uuid.uuid4()),
        "appointment_id": appointment_id,
        "user_id": user_id,
        "lab_id": lab_id,
        "lab_name": lab.get("name"),
        "summary": request.summary,
        "biomarkers": request.biomarkers,
        "health_score": health_score,
        "recommendations": request.recommendations or [],
        "notes": request.notes,
        "member_type": request.member_type or "primary",
        "member_id": request.member_id,
        "member_name": request.member_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "created_by": lab.get("name")
    }
    
    # Check if report exists, update or insert
    existing_report = await db.reports.find_one({"appointment_id": appointment_id})
    if existing_report:
        await db.reports.update_one(
            {"appointment_id": appointment_id},
            {"$set": report_data}
        )
    else:
        await db.reports.insert_one(report_data)
    
    # Update appointment status to report_ready
    await db.appointments.update_one(
        {"id": appointment_id},
        {"$set": {
            "status": "report_ready",
            "report_id": report_data["id"],
            "status_updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    # Update user's health data
    await db.users.update_one(
        {"id": user_id},
        {"$set": {
            "latest_health_score": health_score,
            "latest_report_id": report_data["id"],
            "latest_report_date": datetime.now(timezone.utc).isoformat(),
            "has_report": True
        }}
    )
    
    # Create notification
    await db.notifications.insert_one({
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "type": "report_ready",
        "title": "Your Health Report is Ready!",
        "message": f"Your health report from {lab.get('name')} is now available. Health Score: {health_score}",
        "read": False,
        "created_at": datetime.now(timezone.utc).isoformat()
    })
    
    return {
        "success": True,
        "report_id": report_data["id"],
        "health_score": health_score
    }

# ============== PDF PROCESSING WITH OPENAI ==============

@api_router.post("/lab/parse-pdf")
async def parse_pdf_report(
    file: UploadFile = File(...),
    lab: dict = Depends(get_lab_partner)
):
    """Parse a PDF lab report using OpenAI and extract biomarker data"""
    import pdfplumber
    from openai import OpenAI
    
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OpenAI API key not configured")
    
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    try:
        # Read PDF content
        pdf_content = await file.read()
        pdf_text = ""
        
        with pdfplumber.open(io.BytesIO(pdf_content)) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    pdf_text += page_text + "\n"
        
        if not pdf_text.strip():
            raise HTTPException(status_code=400, detail="Could not extract text from PDF. The file may be image-based or empty.")
        
        # Use OpenAI to parse the lab report
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        system_prompt = """You are a medical lab report parser. Extract biomarker data from the provided lab report text.

Return a JSON object with the following structure:
{
    "patient_name": "string or null",
    "patient_age": "number or null",
    "test_date": "string or null",
    "summary": "A brief 2-3 sentence summary of the overall health status based on the results",
    "biomarkers": [
        {
            "name": "Biomarker Name",
            "value": "numeric value as string",
            "unit": "unit of measurement",
            "reference_range": "normal range",
            "status": "normal" or "borderline" or "needs_attention"
        }
    ],
    "recommendations": ["recommendation 1", "recommendation 2"]
}

Rules for status:
- "normal": Value is within reference range
- "borderline": Value is slightly outside reference range (within 10%)
- "needs_attention": Value is significantly outside reference range

Common biomarkers to look for:
- Hemoglobin, RBC, WBC, Platelets (CBC)
- Glucose, HbA1c (Diabetes)
- Total Cholesterol, LDL, HDL, Triglycerides (Lipid Profile)
- Creatinine, BUN, eGFR (Kidney)
- ALT, AST, Bilirubin (Liver)
- TSH, T3, T4 (Thyroid)
- Vitamin D, Vitamin B12, Iron, Ferritin
- Sodium, Potassium, Calcium (Electrolytes)

If a value cannot be determined, omit that biomarker. Only include biomarkers that are clearly present in the report."""

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Parse this lab report and extract the biomarker data:\n\n{pdf_text[:8000]}"}
            ],
            response_format={"type": "json_object"},
            temperature=0.1
        )
        
        result = json.loads(response.choices[0].message.content)
        
        # Ensure biomarkers is a list
        if not isinstance(result.get("biomarkers"), list):
            result["biomarkers"] = []
        
        # Ensure recommendations is a list
        if not isinstance(result.get("recommendations"), list):
            result["recommendations"] = []
        
        logger.info(f"Successfully parsed PDF with {len(result.get('biomarkers', []))} biomarkers")
        
        return {
            "success": True,
            "data": result,
            "raw_text_preview": pdf_text[:500] + "..." if len(pdf_text) > 500 else pdf_text
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse OpenAI response")
    except Exception as e:
        logger.error(f"PDF parsing error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process PDF: {str(e)}")

class TextParseRequest(BaseModel):
    text: str

@api_router.post("/lab/parse-text")
async def parse_text_report(request: TextParseRequest):
    """Parse lab report text using OpenAI (called from frontend after PDF text extraction)"""
    from openai import OpenAI
    
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OpenAI API key not configured")
    
    pdf_text = request.text
    
    if not pdf_text.strip():
        raise HTTPException(status_code=400, detail="No text provided")
    
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        system_prompt = """You are a medical lab report parser. Extract biomarker data from the provided lab report text.

Return a JSON object with the following structure:
{
    "patient_name": "string or null",
    "patient_age": "number or null",
    "test_date": "string or null",
    "summary": "A brief 2-3 sentence summary of the overall health status based on the results",
    "biomarkers": [
        {
            "name": "Biomarker Name",
            "value": "numeric value as string",
            "unit": "unit of measurement",
            "reference_range": "normal range",
            "status": "normal" or "borderline" or "needs_attention",
            "category": "Blood" or "Heart" or "Vitamins" or "Metabolic" or "Kidney" or "Liver" or "Hormones" or "General"
        }
    ],
    "recommendations": ["recommendation 1", "recommendation 2"]
}

Rules for status:
- "normal": Value is within reference range
- "borderline": Value is slightly outside reference range (within 10%)
- "needs_attention": Value is significantly outside reference range

Common biomarkers to look for:
- Hemoglobin, RBC, WBC, Platelets (CBC) - category: Blood
- Glucose, HbA1c (Diabetes) - category: Metabolic
- Total Cholesterol, LDL, HDL, Triglycerides (Lipid Profile) - category: Heart
- Creatinine, BUN, eGFR (Kidney) - category: Kidney
- ALT, AST, Bilirubin (Liver) - category: Liver
- TSH, T3, T4 (Thyroid) - category: Hormones
- Vitamin D, Vitamin B12, Iron, Ferritin - category: Vitamins

If a value cannot be determined, omit that biomarker. Only include biomarkers that are clearly present in the report."""

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Parse this lab report and extract the biomarker data:\n\n{pdf_text[:8000]}"}
            ],
            response_format={"type": "json_object"},
            temperature=0.1
        )
        
        result = json.loads(response.choices[0].message.content)
        
        if not isinstance(result.get("biomarkers"), list):
            result["biomarkers"] = []
        if not isinstance(result.get("recommendations"), list):
            result["recommendations"] = []
        
        logger.info(f"Successfully parsed text with {len(result.get('biomarkers', []))} biomarkers")
        
        return {
            "success": True,
            "data": result
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {e}")
        raise HTTPException(status_code=500, detail="Failed to parse OpenAI response")
    except Exception as e:
        logger.error(f"Text parsing error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process text: {str(e)}")

@api_router.get("/lab/stats")
async def get_lab_stats(days: int = 30, lab: dict = Depends(get_lab_partner)):
    """Get lab statistics for reporting"""
    lab_id = lab.get("sub")
    
    start_date = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    
    # Total tests
    total_tests = await db.appointments.count_documents({
        "assigned_lab_id": lab_id,
        "created_at": {"$gte": start_date}
    })
    
    # Completed tests
    completed_tests = await db.appointments.count_documents({
        "assigned_lab_id": lab_id,
        "status": {"$in": ["report_ready", "completed"]},
        "created_at": {"$gte": start_date}
    })
    
    # Reports uploaded
    reports_count = await db.reports.count_documents({
        "lab_id": lab_id,
        "created_at": {"$gte": start_date}
    })
    
    # Average health score
    reports = await db.reports.find(
        {"lab_id": lab_id, "created_at": {"$gte": start_date}},
        {"health_score": 1}
    ).to_list(1000)
    
    avg_health_score = 0
    if reports:
        scores = [r.get("health_score", 0) for r in reports if r.get("health_score")]
        avg_health_score = round(sum(scores) / len(scores)) if scores else 0
    
    # Completion rate
    completion_rate = round((completed_tests / total_tests * 100) if total_tests > 0 else 0, 1)
    
    return {
        "period_days": days,
        "total_tests": total_tests,
        "completed_tests": completed_tests,
        "reports_uploaded": reports_count,
        "completion_rate": completion_rate,
        "average_health_score": avg_health_score
    }

@api_router.get("/lab/notifications")
async def get_lab_notifications(lab: dict = Depends(get_lab_partner)):
    """Get notifications for lab - new assignments, etc."""
    lab_id = lab.get("sub")
    
    # Get recent appointments assigned to this lab
    recent_assignments = await db.appointments.find(
        {"assigned_lab_id": lab_id},
        {"_id": 0}
    ).sort("created_at", -1).limit(10).to_list(10)
    
    notifications = []
    for apt in recent_assignments:
        user = await db.users.find_one({"id": apt.get("user_id")}, {"_id": 0, "name": 1, "phone": 1})
        notifications.append({
            "id": apt.get("id"),
            "type": "new_assignment" if apt.get("status") in ["pending", "booked"] else "status_update",
            "title": f"New test assigned" if apt.get("status") in ["pending", "booked"] else f"Test {apt.get('status', '').replace('_', ' ')}",
            "message": f"{user.get('name', 'Unknown')} - {apt.get('date')} at {apt.get('time')}",
            "user_name": user.get("name"),
            "user_phone": user.get("phone"),
            "date": apt.get("date"),
            "time": apt.get("time"),
            "status": apt.get("status"),
            "created_at": apt.get("assigned_at") or apt.get("created_at")
        })
    
    return {"notifications": notifications}

# ============== ADMIN SUBSCRIPTION PLANS ==============

@api_router.get("/admin/plans")
async def get_all_plans(admin: dict = Depends(get_admin_user)):
    """Get all subscription plans"""
    plans = await db.subscription_plans.find({}, {"_id": 0}).to_list(100)
    if not plans:
        # Return default plans if none exist
        default_plans = [
            {"id": "individual-starter", "name": "Individual Starter", "plan_type": "individual", "price": 99, "duration_months": 1, "num_tests": 1, "features": ["1 home blood & urine test", "AI-based report explanation", "Health summary", "App access for 30 days"], "badge": None, "status": "active"},
            {"id": "preventive-starter", "name": "Preventive Starter", "plan_type": "individual", "price": 449, "duration_months": 6, "num_tests": 2, "features": ["2 home tests", "AI insights after each test", "Health trends", "Smart nudges & reminders"], "badge": None, "status": "active"},
            {"id": "preventive-plus", "name": "Preventive Plus", "plan_type": "individual", "price": 649, "duration_months": 12, "num_tests": 3, "features": ["3 home tests", "Full health timeline", "Priority booking slots", "AI insights + trend tracking"], "badge": "most_popular", "status": "active"},
            {"id": "elderly-care", "name": "Elderly / Chronic Care", "plan_type": "individual", "price": 849, "duration_months": 12, "num_tests": 4, "features": ["4 home tests", "Regular monitoring", "Strong nudges & follow-ups", "All Premium features"], "badge": None, "status": "active"},
            {"id": "family-of-2", "name": "Family of 2", "plan_type": "family", "price": 199, "duration_months": 1, "num_tests": 2, "features": ["Home test for each member", "Individual AI reports", "Family health overview", "App access for 30 days"], "badge": None, "status": "active"},
            {"id": "family-of-3", "name": "Family of 3", "plan_type": "family", "price": 299, "duration_months": 1, "num_tests": 3, "features": ["Home test for each member", "Individual AI reports", "Family health overview", "App access for 30 days"], "badge": None, "status": "active"},
            {"id": "family-of-4", "name": "Family of 4", "plan_type": "family", "price": 399, "duration_months": 1, "num_tests": 4, "features": ["Home test for each member", "Individual AI reports", "Family health overview", "App access for 30 days"], "badge": None, "status": "active"},
        ]
        return {"plans": default_plans}
    return {"plans": plans}

@api_router.post("/admin/plans")
async def create_plan(request: SubscriptionPlan, admin: dict = Depends(get_admin_user)):
    """Create subscription plan"""
    plan_data = {
        "id": str(uuid.uuid4()),
        **request.model_dump(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.subscription_plans.insert_one(plan_data)
    return {"success": True, "plan": {k: v for k, v in plan_data.items() if k != "_id"}}

@api_router.put("/admin/plans/{plan_id}")
async def update_plan(plan_id: str, request: SubscriptionPlan, admin: dict = Depends(get_admin_user)):
    """Update subscription plan"""
    update_data = {**request.model_dump(), "updated_at": datetime.now(timezone.utc).isoformat()}
    result = await db.subscription_plans.update_one({"id": plan_id}, {"$set": update_data})
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Plan not found")
    return {"success": True}

@api_router.delete("/admin/plans/{plan_id}")
async def delete_plan(plan_id: str, admin: dict = Depends(get_admin_user)):
    """Delete subscription plan"""
    result = await db.subscription_plans.delete_one({"id": plan_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Plan not found")
    return {"success": True}

# ============== ADMIN TEST TYPES ==============

@api_router.get("/admin/test-types")
async def get_all_test_types(admin: dict = Depends(get_admin_user)):
    """Get all test types"""
    tests = await db.test_types.find({}, {"_id": 0}).to_list(100)
    if not tests:
        default_tests = [
            {"id": "blood-panel", "name": "Complete Blood Panel", "category": "Blood", "description": "Comprehensive blood analysis", "biomarkers": ["Hemoglobin", "RBC", "WBC", "Platelets", "Hematocrit"], "price": 150, "status": "active"},
            {"id": "lipid-panel", "name": "Lipid Profile", "category": "Heart", "description": "Cholesterol and triglycerides", "biomarkers": ["Total Cholesterol", "LDL", "HDL", "Triglycerides"], "price": 120, "status": "active"},
            {"id": "vitamin-panel", "name": "Vitamin Panel", "category": "Vitamins", "description": "Essential vitamins check", "biomarkers": ["Vitamin D", "Vitamin B12", "Iron", "Folate"], "price": 180, "status": "active"},
            {"id": "metabolic-panel", "name": "Metabolic Panel", "category": "Metabolic", "description": "Blood sugar and kidney function", "biomarkers": ["Fasting Glucose", "HbA1c", "Creatinine", "BUN"], "price": 140, "status": "active"},
            {"id": "thyroid-panel", "name": "Thyroid Panel", "category": "Hormones", "description": "Thyroid function tests", "biomarkers": ["TSH", "T3", "T4", "Free T4"], "price": 160, "status": "active"},
        ]
        return {"test_types": default_tests}
    return {"test_types": tests}

@api_router.post("/admin/test-types")
async def create_test_type(request: TestType, admin: dict = Depends(get_admin_user)):
    """Create test type"""
    test_data = {
        "id": str(uuid.uuid4()),
        **request.model_dump(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.test_types.insert_one(test_data)
    return {"success": True, "test_type": {k: v for k, v in test_data.items() if k != "_id"}}

@api_router.put("/admin/test-types/{test_id}")
async def update_test_type(test_id: str, request: TestType, admin: dict = Depends(get_admin_user)):
    """Update test type"""
    update_data = {**request.model_dump(), "updated_at": datetime.now(timezone.utc).isoformat()}
    result = await db.test_types.update_one({"id": test_id}, {"$set": update_data})
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Test type not found")
    return {"success": True}

@api_router.delete("/admin/test-types/{test_id}")
async def delete_test_type(test_id: str, admin: dict = Depends(get_admin_user)):
    """Delete test type"""
    result = await db.test_types.delete_one({"id": test_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Test type not found")
    return {"success": True}

# ============== ADMIN API SETTINGS ==============

@api_router.get("/admin/settings")
async def get_api_settings(admin: dict = Depends(get_admin_user)):
    """Get all API integration settings"""
    settings = await db.api_settings.find({}, {"_id": 0}).to_list(100)
    if not settings:
        default_settings = [
            {"id": "openai", "provider": "OpenAI (LLM)", "api_key": "", "enabled": True, "config": {"model": "gpt-4o-mini"}},
            {"id": "whatsapp", "provider": "WhatsApp (Meta/Twilio)", "api_key": "", "enabled": False, "config": {}},
            {"id": "google-maps", "provider": "Google Maps", "api_key": "", "enabled": False, "config": {}},
            {"id": "sms", "provider": "SMS Gateway", "api_key": "", "enabled": False, "config": {}},
            {"id": "email", "provider": "Email (SendGrid/SMTP)", "api_key": "", "enabled": False, "config": {"smtp_host": "", "smtp_port": 587}},
            {"id": "payment", "provider": "Payment Gateway (Stripe)", "api_key": "", "enabled": False, "config": {}},
        ]
        return {"settings": default_settings}
    return {"settings": settings}

@api_router.put("/admin/settings/{setting_id}")
async def update_api_setting(setting_id: str, request: APISettings, admin: dict = Depends(get_admin_user)):
    """Update API setting"""
    update_data = {**request.model_dump(), "updated_at": datetime.now(timezone.utc).isoformat()}
    result = await db.api_settings.update_one(
        {"id": setting_id},
        {"$set": update_data},
        upsert=True
    )
    return {"success": True}

# ============== ADMIN ANALYTICS ==============

@api_router.get("/admin/analytics")
async def get_analytics(admin: dict = Depends(get_admin_user)):
    """Get dashboard analytics"""
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = today_start - timedelta(days=7)
    month_start = today_start - timedelta(days=30)
    
    # User stats
    total_users = await db.users.count_documents({})
    new_users_today = await db.users.count_documents({
        "created_at": {"$gte": today_start.isoformat()}
    })
    new_users_week = await db.users.count_documents({
        "created_at": {"$gte": week_start.isoformat()}
    })
    new_users_month = await db.users.count_documents({
        "created_at": {"$gte": month_start.isoformat()}
    })
    
    # Active users (users with appointments or reports in last 30 days)
    active_user_ids = set()
    recent_appointments = await db.appointments.find({
        "created_at": {"$gte": month_start.isoformat()}
    }).to_list(1000)
    for apt in recent_appointments:
        active_user_ids.add(apt.get("user_id"))
    active_users = len(active_user_ids)
    
    # Subscription stats
    users_by_plan = await db.users.aggregate([
        {"$match": {"plan_type": {"$ne": None}}},
        {"$group": {"_id": "$plan_type", "count": {"$sum": 1}}}
    ]).to_list(20)
    plan_distribution = {item["_id"]: item["count"] for item in users_by_plan}
    
    # Appointment stats
    total_appointments = await db.appointments.count_documents({})
    pending_appointments = await db.appointments.count_documents({"status": "pending"})
    completed_appointments = await db.appointments.count_documents({"status": "completed"})
    
    # Revenue calculation (based on plan types)
    plan_prices = {
        "individual-starter": 99,
        "preventive-starter": 449,
        "preventive-plus": 649,
        "elderly-care": 849,
        "family-of-2": 199,
        "family-of-3": 299,
        "family-of-4": 399
    }
    
    total_revenue = 0
    for plan, count in plan_distribution.items():
        total_revenue += plan_prices.get(plan, 0) * count
    
    # Report stats
    total_reports = await db.reports.count_documents({})
    
    # Partner labs
    total_labs = await db.partner_labs.count_documents({})
    
    return {
        "users": {
            "total": total_users,
            "active": active_users,
            "new_today": new_users_today,
            "new_this_week": new_users_week,
            "new_this_month": new_users_month
        },
        "subscriptions": {
            "by_plan": plan_distribution,
            "total_subscribed": sum(plan_distribution.values())
        },
        "appointments": {
            "total": total_appointments,
            "pending": pending_appointments,
            "completed": completed_appointments,
            "completion_rate": round(completed_appointments / total_appointments * 100, 1) if total_appointments > 0 else 0
        },
        "revenue": {
            "total": total_revenue,
            "currency": "AED",
            "average_per_user": round(total_revenue / total_users, 2) if total_users > 0 else 0
        },
        "reports": {
            "total": total_reports
        },
        "labs": {
            "total": total_labs
        }
    }

@api_router.get("/admin/analytics/trends")
async def get_analytics_trends(days: int = 30, admin: dict = Depends(get_admin_user)):
    """Get trend data for charts"""
    now = datetime.now(timezone.utc)
    trends = []
    
    for i in range(days, -1, -1):
        date = now - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        date_start = date.replace(hour=0, minute=0, second=0, microsecond=0)
        date_end = date.replace(hour=23, minute=59, second=59, microsecond=999999)
        
        new_users = await db.users.count_documents({
            "created_at": {"$gte": date_start.isoformat(), "$lte": date_end.isoformat()}
        })
        
        new_appointments = await db.appointments.count_documents({
            "created_at": {"$gte": date_start.isoformat(), "$lte": date_end.isoformat()}
        })
        
        trends.append({
            "date": date_str,
            "new_users": new_users,
            "new_appointments": new_appointments
        })
    
    return {"trends": trends}

# ============== HEALTH CHECK ==============

@api_router.get("/")
async def root():
    return {"message": "CareGuard UAE API - Preventive Health MVP"}

@api_router.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
