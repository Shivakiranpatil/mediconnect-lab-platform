#!/usr/bin/env python3
"""
Backend API Testing for CareGuard UAE Health MVP
Tests all authentication endpoints and core functionality
"""

import requests
import sys
import json
from datetime import datetime

class CareGuardAPITester:
    def __init__(self, base_url="https://preventivehealth.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_phone = "501234567"  # Test phone number

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        if details:
            print(f"   Details: {details}")

    def test_health_check(self):
        """Test basic health endpoints"""
        print("\n🔍 Testing Health Check Endpoints...")
        
        try:
            # Test root endpoint
            response = requests.get(f"{self.api_url}/", timeout=10)
            success = response.status_code == 200
            self.log_test("Root endpoint", success, 
                         f"Status: {response.status_code}, Response: {response.text[:100]}")
            
            # Test health endpoint
            response = requests.get(f"{self.api_url}/health", timeout=10)
            success = response.status_code == 200
            self.log_test("Health endpoint", success, 
                         f"Status: {response.status_code}, Response: {response.text[:100]}")
            
            return True
        except Exception as e:
            self.log_test("Health check", False, str(e))
            return False

    def test_send_otp(self):
        """Test OTP sending endpoint"""
        print("\n🔍 Testing Send OTP...")
        
        try:
            payload = {"phone": self.test_phone}
            response = requests.post(f"{self.api_url}/auth/send-otp", 
                                   json=payload, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["message", "phone", "otp_sent"]
                has_fields = all(field in data for field in expected_fields)
                success = has_fields and data["otp_sent"] is True
                
                self.log_test("Send OTP", success, 
                             f"Response: {data}")
            else:
                self.log_test("Send OTP", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Send OTP", False, str(e))
            return False

    def test_verify_otp_invalid(self):
        """Test OTP verification with invalid OTP"""
        print("\n🔍 Testing Verify OTP (Invalid)...")
        
        try:
            payload = {"phone": self.test_phone, "otp": "9999"}
            response = requests.post(f"{self.api_url}/auth/verify-otp", 
                                   json=payload, timeout=10)
            
            # Should fail with 400
            success = response.status_code == 400
            self.log_test("Verify OTP (Invalid)", success, 
                         f"Status: {response.status_code}, Expected: 400")
            
            return success
        except Exception as e:
            self.log_test("Verify OTP (Invalid)", False, str(e))
            return False

    def test_verify_otp_valid(self):
        """Test OTP verification with valid OTP (1234)"""
        print("\n🔍 Testing Verify OTP (Valid)...")
        
        try:
            payload = {"phone": self.test_phone, "otp": "1234"}
            response = requests.post(f"{self.api_url}/auth/verify-otp", 
                                   json=payload, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["access_token", "token_type", "user"]
                has_fields = all(field in data for field in expected_fields)
                
                if has_fields:
                    self.token = data["access_token"]
                    self.user_data = data["user"]
                    success = True
                    self.log_test("Verify OTP (Valid)", success, 
                                 f"Token received, User ID: {self.user_data.get('id', 'N/A')}")
                else:
                    success = False
                    self.log_test("Verify OTP (Valid)", success, 
                                 f"Missing fields in response: {data}")
            else:
                self.log_test("Verify OTP (Valid)", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Verify OTP (Valid)", False, str(e))
            return False

    def test_get_me(self):
        """Test authenticated user endpoint"""
        print("\n🔍 Testing Get Current User...")
        
        if not self.token:
            self.log_test("Get Me", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.api_url}/auth/me", 
                                  headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                expected_fields = ["id", "phone"]
                has_fields = all(field in data for field in expected_fields)
                success = has_fields
                
                self.log_test("Get Me", success, 
                             f"User data: {data}")
            else:
                self.log_test("Get Me", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Get Me", False, str(e))
            return False

    def test_update_profile(self):
        """Test profile update endpoint"""
        print("\n🔍 Testing Update Profile...")
        
        if not self.token:
            self.log_test("Update Profile", False, "No token available")
            return False
        
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            payload = {
                "name": "Test User",
                "emirate": "Dubai",
                "dob": "1990-01-01"
            }
            response = requests.put(f"{self.api_url}/auth/profile", 
                                  json=payload, headers=headers, timeout=10)
            
            success = response.status_code == 200
            if success:
                data = response.json()
                success = (data.get("name") == "Test User" and 
                          data.get("emirate") == "Dubai")
                
                self.log_test("Update Profile", success, 
                             f"Updated profile: {data}")
            else:
                self.log_test("Update Profile", False, 
                             f"Status: {response.status_code}, Response: {response.text}")
            
            return success
        except Exception as e:
            self.log_test("Update Profile", False, str(e))
            return False

    def test_unauthorized_access(self):
        """Test accessing protected endpoint without token"""
        print("\n🔍 Testing Unauthorized Access...")
        
        try:
            response = requests.get(f"{self.api_url}/auth/me", timeout=10)
            
            # Should fail with 401
            success = response.status_code == 401
            self.log_test("Unauthorized Access", success, 
                         f"Status: {response.status_code}, Expected: 401")
            
            return success
        except Exception as e:
            self.log_test("Unauthorized Access", False, str(e))
            return False

    def run_all_tests(self):
        """Run all backend tests"""
        print("🚀 Starting CareGuard UAE Backend API Tests")
        print(f"Testing against: {self.api_url}")
        print("=" * 60)
        
        # Test sequence
        tests = [
            self.test_health_check,
            self.test_unauthorized_access,
            self.test_send_otp,
            self.test_verify_otp_invalid,
            self.test_verify_otp_valid,
            self.test_get_me,
            self.test_update_profile,
        ]
        
        for test in tests:
            try:
                test()
            except Exception as e:
                print(f"❌ Test {test.__name__} crashed: {str(e)}")
        
        # Print summary
        print("\n" + "=" * 60)
        print(f"📊 Test Summary: {self.tests_passed}/{self.tests_run} tests passed")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} tests failed")
            return 1

def main():
    tester = CareGuardAPITester()
    return tester.run_all_tests()

if __name__ == "__main__":
    sys.exit(main())